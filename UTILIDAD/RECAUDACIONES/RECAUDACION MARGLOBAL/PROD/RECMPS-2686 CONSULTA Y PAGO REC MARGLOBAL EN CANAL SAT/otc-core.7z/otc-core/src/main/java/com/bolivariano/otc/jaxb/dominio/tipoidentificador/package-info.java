@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.bolivariano.com/dominio/TipoIdentificador")
package com.bolivariano.otc.jaxb.dominio.tipoidentificador;
