package com.bolivariano.otc.exception;

public class OTCCoreException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1875607790803671868L;

	
	public OTCCoreException(String message) {
		super(message);
	}
	
	public OTCCoreException(Exception ex) {
		super(ex);
	}
	
	public OTCCoreException(String message, Exception ex) {
		super(message, ex);
	}

}
