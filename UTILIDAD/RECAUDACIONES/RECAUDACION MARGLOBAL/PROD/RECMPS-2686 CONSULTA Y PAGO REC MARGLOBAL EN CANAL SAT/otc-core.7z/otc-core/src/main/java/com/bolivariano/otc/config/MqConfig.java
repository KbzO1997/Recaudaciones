package com.bolivariano.otc.config;

import com.ibm.mq.jms.MQQueueConnectionFactory;
import com.ibm.msg.client.wmq.WMQConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.support.converter.MarshallingMessageConverter;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.jms.support.converter.MessageType;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;


@Configuration
public class MqConfig {
    private static final Logger log = LoggerFactory.getLogger(MqConfig.class);

    @Value("${servers.mq.host}")
    private String host;
    @Value("${servers.mq.port}")
    private Integer port;
    @Value("${servers.mq.queue-manager}")
    private String queueManager;
    @Value("${servers.mq.channel}")
    private String channel;
    @Value("${servers.mq.timeout}")
    private long timeout;

    @Bean
    @Primary
    public MQQueueConnectionFactory mqQueueConnectionFactory() {
        MQQueueConnectionFactory mqQueueConnectionFactory = new MQQueueConnectionFactory();
        try {
            log.debug("host -->" + host);
            log.debug("port -->" + port);
            log.debug("channel -->" + channel);
            log.debug("queueManager -->" + queueManager);

            mqQueueConnectionFactory.setHostName(host);
            mqQueueConnectionFactory.setQueueManager(queueManager);
            mqQueueConnectionFactory.setPort(port);
            mqQueueConnectionFactory.setChannel(channel);
            mqQueueConnectionFactory.setTransportType(WMQConstants.WMQ_CM_CLIENT);
            mqQueueConnectionFactory.setCCSID(1208);

            log.debug("mqQueueConnectionFactory -->" + mqQueueConnectionFactory);

        } catch (Exception e) {
            log.error("Error al inicializar MQ Configuracion " + e.getMessage());
        }
        return mqQueueConnectionFactory;
    }

    @Bean
    public Jaxb2Marshaller marshaller() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setContextPath("com.bolivariano.otc.jaxb.mensajeosb");
        return marshaller;
    }

    @Bean // Serialize message content to json using TextMessage
    public MessageConverter jaxbJmsMessageConverter(Jaxb2Marshaller marshaller) {
        MarshallingMessageConverter converter = new MarshallingMessageConverter();
        converter.setMarshaller(marshaller);
        converter.setUnmarshaller(marshaller);
        converter.setTargetType(MessageType.TEXT);
        return converter;
    }

    @Bean
    public JmsTemplate queueTemplate(MQQueueConnectionFactory mqQueueConnectionFactory) {
        log.debug("INSTANCIA DE JMS TEMPLATE >>> TIMEOUT: " + timeout);
        JmsTemplate jmsTemplate = new JmsTemplate(mqQueueConnectionFactory);
        jmsTemplate.setReceiveTimeout(timeout);
        jmsTemplate.setMessageConverter(jaxbJmsMessageConverter(marshaller()));
        return jmsTemplate;
    }

}
