package com.bolivariano.otc.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.XMLConstants;
import javax.xml.transform.*;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.URISyntaxException;

public class XSLTransform {

	private static final Logger log = LoggerFactory.getLogger(XSLTransform.class);

	private XSLTransform() {
		//Constructor por sonarq
	}
	
//Metodo para aplicar transformacion desde string
//Se comenta por refactory NO_USE
	public static String transformFromString(String xsltString, String xmlMessage)
			throws IOException, URISyntaxException, TransformerException {
		Source xslt = new StreamSource(new StringReader(xsltString));
		Source xml = new StreamSource(new StringReader(xmlMessage));
		
	    TransformerFactory factory = TransformerFactory.newInstance();
        
		factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, ""); 
        factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, ""); 	    
		
		Transformer transformer = factory.newTransformer(xslt);

		log.info(xsltString);
		log.info(xmlMessage);

		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		transformer.transform(xml, result);

		return writer.toString();
	}

	public static String transformFromFile(String xsltFile, String xmlMessage)
			throws IOException, URISyntaxException, TransformerException {

		Source xslt = new StreamSource(new File(xsltFile));
		Source xml = new StreamSource(new StringReader(xmlMessage));
		TransformerFactory factory = TransformerFactory.newInstance();

		factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
		factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");

		Transformer transformer = factory.newTransformer(xslt);
		transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");

		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		transformer.transform(xml, result);

		String transformedResult = writer.toString();
		log.debug("TRANSFORMED REQUEST: " + transformedResult.replaceAll("(\n)", ""));
		return transformedResult;
	}
}
