package com.bolivariano.otc.route;


import com.bolivariano.otc.message.MensajeEntradaProcesar;
import com.bolivariano.otc.message.MensajeSalidaProcesar;
import com.bolivariano.otc.processor.OTCCoreProcessor;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.rest.RestBindingMode;
import org.springframework.stereotype.Component;

import javax.ws.rs.core.MediaType;

@Component
public class CoreRoute extends RouteBuilder {

    // @Override
    public void configure() {

        restConfiguration().contextPath("/camel") //
                .port(9002)
                .enableCORS(true)
                .apiContextPath("/api-doc")
                .apiProperty("api.title", "OTC Core")
                .apiProperty("api.version", "v1")
                .apiProperty("cors", "true") // cross-site
                .apiContextRouteId("doc-api")
                .component("servlet")
                .bindingMode(RestBindingMode.json)
                .dataFormatProperty("prettyPrint", "true");

        rest("/api/").description("Teste REST Service")
                .id("api-route")
                .post("/engine")
                .produces(MediaType.APPLICATION_JSON)
                .consumes(MediaType.APPLICATION_JSON)
                .bindingMode(RestBindingMode.auto)
                .type(MensajeEntradaProcesar.class)
                .enableCORS(true)
                .outType(MensajeSalidaProcesar.class)
                .to("direct:remoteService");

        from("direct:remoteService")
                .routeId("direct-route")
                .tracing()
                .process(new OTCCoreProcessor())
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(201));

    }
}
