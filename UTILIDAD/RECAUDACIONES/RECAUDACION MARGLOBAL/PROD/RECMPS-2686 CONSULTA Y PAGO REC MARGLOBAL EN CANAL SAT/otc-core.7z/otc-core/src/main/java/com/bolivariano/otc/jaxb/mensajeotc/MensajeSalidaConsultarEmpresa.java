
package com.bolivariano.otc.jaxb.mensajeotc;

import com.bolivariano.otc.jaxb.dominio.empresa.Empresa;

import javax.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>Java class for mensajeSalidaConsultarEmpresa complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="mensajeSalidaConsultarEmpresa"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="codigoError" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="empresas" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="empresa" type="{http://www.bolivariano.com/dominio/Empresa}empresa" maxOccurs="unbounded" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="mensajeUsuario" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="mensajeSistema" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "salidaConsultarEmpresa", propOrder = {
    "codigoError",
    "empresas",
    "mensajeUsuario",
    "mensajeSistema"
})
@XmlRootElement(name = "salidaConsultarEmpresa")
public class MensajeSalidaConsultarEmpresa {

    protected String codigoError;
    protected MensajeSalidaConsultarEmpresa.Empresas empresas;
    protected String mensajeUsuario;
    protected String mensajeSistema;

    /**
     * Gets the value of the codigoError property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getCodigoError() {
        return codigoError;
    }

    /**
     * Sets the value of the codigoError property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setCodigoError(String value) {
        this.codigoError = value;
    }

    /**
     * Gets the value of the empresas property.
     *
     * @return
     *     possible object is
     *     {@link MensajeSalidaConsultarEmpresa.Empresas }
     *
     */
    public MensajeSalidaConsultarEmpresa.Empresas getEmpresas() {
        return empresas;
    }

    /**
     * Sets the value of the empresas property.
     *
     * @param value
     *     allowed object is
     *     {@link MensajeSalidaConsultarEmpresa.Empresas }
     *
     */
    public void setEmpresas(MensajeSalidaConsultarEmpresa.Empresas value) {
        this.empresas = value;
    }

    /**
     * Gets the value of the mensajeUsuario property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMensajeUsuario() {
        return mensajeUsuario;
    }

    /**
     * Sets the value of the mensajeUsuario property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMensajeUsuario(String value) {
        this.mensajeUsuario = value;
    }

    /**
     * Gets the value of the mensajeSistema property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMensajeSistema() {
        return mensajeSistema;
    }

    /**
     * Sets the value of the mensajeSistema property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMensajeSistema(String value) {
        this.mensajeSistema = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="empresa" type="{http://www.bolivariano.com/dominio/Empresa}empresa" maxOccurs="unbounded" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "empresa"
    })
    public static class Empresas {

        @XmlElement(nillable = true)
        protected List<Empresa> empresa;

        /**
         * Gets the value of the empresa property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the empresa property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getEmpresa().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link Empresa }
         * 
         * 
         */
        public List<Empresa> getEmpresa() {
            if (empresa == null) {
                empresa = new ArrayList<>();
            }
            return this.empresa;
        }

    }

}
