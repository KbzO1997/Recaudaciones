package com.bolivariano.microservice.comprobantecvms.beantrn;

import java.io.Serializable;
import java.math.BigDecimal;

import com.bolivariano.microservice.comprobantecvms.utils.ComprobanteUtils;

public class Deposit implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1948989373875586143L;

	private String accountNumber;
	private String accountTypeCode;
	private BigDecimal amountCash;
	private BigDecimal amountCheck;	
	private Integer nCheck;
	private String fundsSource;
	private String fundsDestination;
	private String sign;
	private Client client;

	public Integer getnCheck() {
		return nCheck;
	}
	public void setnCheck(Integer nCheck) {
		this.nCheck = nCheck;
	}	

	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountTypeCode() {
		return accountTypeCode;
	}
	public void setAccountTypeCode(String accountTypeCode) {
		this.accountTypeCode = accountTypeCode;
	}
	
	public BigDecimal getAmountCash() {
		return amountCash;
	}
	public void setAmountCash(BigDecimal amountCash) {
		this.amountCash =ComprobanteUtils.getRoundVal(amountCash);
	}
	public BigDecimal getAmountCheck() {
		return amountCheck;
	}
	public void setAmountCheck(BigDecimal amountCheck) {
		this.amountCheck = ComprobanteUtils.getRoundVal(amountCheck);
	}

	public String getFundsSource() {
		return fundsSource;
	}
	public void setFundsSource(String fundsSource) {
		this.fundsSource = fundsSource;
	}
	public String getFundsDestination() {
		return fundsDestination;
	}
	public void setFundsDestination(String fundsDestination) {
		this.fundsDestination = fundsDestination;
	}
	public Client getClient() {
		return client;
	}
	public void setClient(Client client) {
		this.client = client;
	}
	public String getSign() {
		return sign;
	}
	public void setSign(String sign) {
		this.sign = sign;
	}
	

}
