package com.bolivariano.microservice.comprobantecvms.helper;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.NumberFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.Random;

import javax.imageio.ImageIO;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.bolivariano.microservice.comprobantecvms.bean.Configuration;
import com.bolivariano.microservice.comprobantecvms.bean.CustomExcepcion;
import com.bolivariano.microservice.comprobantecvms.bean.RandomString;
import com.bolivariano.microservice.comprobantecvms.service.ComprobanteService;


import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Helper {

	private static final Logger logger = LoggerFactory.getLogger(ComprobanteService.class);
	public static final Integer codErrorGeneral = -1;
	public static final String msjErrorGeneral = "Transaccion no exitosa";

	public static final Integer codExito = 0;
	public static final String msjExito = "Transaccion ok";
	
	public static CustomExcepcion answerMessage(int errorCode) {
		if (errorCode == 200)
			return new CustomExcepcion(errorCode, "OK");
		else if (errorCode == 201)
			return new CustomExcepcion(errorCode, "Created");
		else if (errorCode == 202)
			return new CustomExcepcion(errorCode, "Aceppted");
		else if (errorCode == 204)
			return new CustomExcepcion(errorCode, "No content");
		else if (errorCode == 400)
			return new CustomExcepcion(errorCode, "Bad request");
		else if (errorCode == 401)
			return new CustomExcepcion(errorCode, "Unauthorized");
		else if (errorCode == 404)
			return new CustomExcepcion(errorCode, "Not found");
		else if (errorCode == 405)
			return new CustomExcepcion(errorCode, "Method Not Allowed");
		else if (errorCode == 408)
			return new CustomExcepcion(errorCode, "Request Timeout");
		else if (errorCode == 415)
			return new CustomExcepcion(errorCode, "Unsupported media type");
		else if (errorCode == 422)
			return new CustomExcepcion(errorCode, "Data validation failed");
		else if (errorCode == 429)
			return new CustomExcepcion(errorCode, "Too many requets");
		else if (errorCode == 500)
			return new CustomExcepcion(errorCode, "Internal Server Error");
		else if (errorCode == 502)
			return new CustomExcepcion(errorCode, "Bad Gateway");
		else if (errorCode == 503)
			return new CustomExcepcion(errorCode, "Service Unavailable");
		else
			return new CustomExcepcion(errorCode, "Gateway Timeout");
	}

	public static String replaceSpecialCharacter(String str) {
		str = str.replaceAll("á", "&aacute;");
		str = str.replaceAll("é", "&eacute;");
		str = str.replaceAll("í", "&iacute;");
		str = str.replaceAll("ó", "&oacute;");
		str = str.replaceAll("ú", "&uacute;");

		str = str.replaceAll("Á", "&Aacute;");
		str = str.replaceAll("É", "&Eacute;");
		str = str.replaceAll("Í", "&Iacute;");
		str = str.replaceAll("Ó", "&Oacute;");
		str = str.replaceAll("Ú", "&Uacute;");

		str = str.replaceAll("ñ", "&ntilde;");
		str = str.replaceAll("Ñ", "&Ntilde;");

		str = str.replaceAll("ü", "&uuml;");
		str = str.replaceAll("Ü", "&Uuml;");

		return str;
	}

	public static String randomNumber(int seed) {
		Random generator = new Random(seed);
		RandomString randStr = new RandomString(8, generator);
		String s = randStr.nextString();

		return s; // + "_" + seed;
	}

	public static String formatNumber(String value)// may not be used
	{
		NumberFormat format = NumberFormat.getCurrencyInstance(Locale.CANADA);
		String currency = "";
		if (value != null) {
			currency = format.format(Double.parseDouble(value));
		}
		return currency;
	}

	public static JSONObject readJsonFile()// used only for testing
	{
		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject = null;

		File file = new File("data.json");

		try {
			if (file.exists()) {
				FileReader reader = new FileReader("data.json");
				// Read JSON file
				Object obj = jsonParser.parse(reader);
				jsonObject = (JSONObject) obj;
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			logger.error("Error reading pdf file - FileNotFoundException", e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();
			logger.error("IOException error", e.getMessage());
		} catch (ParseException e) {
			e.printStackTrace();
			logger.error("ParseException error ", e.getMessage());
		}
		return jsonObject;
	}

	public Configuration readJsonFileConfiguration(String transCode) {
		Configuration configuration = new Configuration();
		String idTrx = "";
		boolean exists = false;
		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject = null;
		try {
			InputStream input = this.getClass().getResourceAsStream("/static/configuration.json");
			// Read JSON file
			Object obj = jsonParser.parse(new InputStreamReader(input, "UTF-8"));

			JSONArray transactions = (JSONArray) obj;
			logger.info("Información de archivo de Configuración, " + transactions);

			for (int i = 0; i < transactions.size(); i++) {
				jsonObject = (JSONObject) transactions.get(i);
				JSONObject transactionObject = (JSONObject) jsonObject.get("transaction");
				idTrx = transactionObject.get("idTrx").toString();

				if (idTrx.equals(transCode)) {
					configuration.setClassName(transactionObject.get("class").toString());
					configuration.setMainMethod(transactionObject.get("mainMethod").toString());
					configuration.setApplication(transactionObject.get("application").toString());
					configuration.setIdtransaction(idTrx);
					configuration.setCode(0);
					configuration.setMessage("Ok");
					exists = true;
					i = transactions.size() + 1;
				}
			}

			if (!exists) {
				configuration.setCode(-1);
				logger.info("No se encontro la configuración de la transacción " + transCode);
			}

		} catch (FileNotFoundException e) {
			logger.error("Error reading file - FileNotFoundException", ExceptionUtils.getStackTrace(e));
		} catch (IOException e) {
			logger.error("IOException error", ExceptionUtils.getStackTrace(e));
		} catch (ParseException e) {
			logger.error("ParseException error ", ExceptionUtils.getStackTrace(e));
		} catch (Exception e) {
			logger.error("Exception error ", ExceptionUtils.getStackTrace(e));
		}
		return configuration;
	}

	public static byte[] encodeFileBase64(String path) throws IOException {
		byte[] input_file = null;
		try {
			input_file = Files.readAllBytes(Paths.get(path));
		} catch (IOException e) {
			e.printStackTrace();
			logger.error("Cannot encode pdf file to byte array - IOException error", e.getMessage());
		}
		return input_file;
	}

	public static byte[] toByteArray(BufferedImage bi, String format) throws IOException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ImageIO.write(bi, format, baos);
		byte[] bytes = baos.toByteArray();
		baos.close();
		return bytes;

	}

	public static GregorianCalendar dateToGregorianCalendar(Date date) {
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(date);
		return cal;
	}
	
	

	public static void validaParametro(Object elemento, String campo) throws CustomExcepcion {
		if (elemento == null || (elemento instanceof String && String.valueOf(elemento).isEmpty()))
			throw new CustomExcepcion(codErrorGeneral, msjErrorGeneral, "Se requiere " + campo);
	}

}
