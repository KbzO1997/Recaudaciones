package com.bolivariano.microservice.comprobantecvms.beantrn;

import java.io.Serializable;
import java.util.List;

public class Company  extends Service implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -734363527567655759L;
	private Integer idCompany;
	private String nameCompany;
	private List<Catalog> type;
	private List<Catalog> region;
	private List<Catalog> area;
	public Integer getIdCompany() {
		return idCompany;
	}
	public void setIdCompany(Integer idCompany) {
		this.idCompany = idCompany;
	}
	
	public String getNameCompany() {
		return nameCompany;
	}
	public void setNameCompany(String nameCompany) {
		this.nameCompany = nameCompany;
	}
	public List<Catalog> getType() {
		return type;
	}
	public void setType(List<Catalog> type) {
		this.type = type;
	}
	public List<Catalog> getRegion() {
		return region;
	}
	public void setRegion(List<Catalog> region) {
		this.region = region;
	}
	public List<Catalog> getArea() {
		return area;
	}
	public void setArea(List<Catalog> area) {
		this.area = area;
	}
	
	

}
