package com.bolivariano.microservice.comprobantecvms.service;

import com.bolivariano.microservice.comprobantecvms.configuration.*;
import com.bolivariano.microservice.notification_gateway.estructura.*;
import com.bolivariano.microservice.notification_gateway.microservicio.notificationgateway.*;

import java.net.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import com.bolivariano.microservice.comprobantecvms.bean.Comprobante;
import com.bolivariano.microservice.comprobantecvms.bean.MensajeEntradaMis;
import com.bolivariano.microservice.comprobantecvms.bean.MensajeRptaCola;
import com.bolivariano.microservice.comprobantecvms.bean.MensajeSalidaMis;
import com.bolivariano.microservice.comprobantecvms.business.mainCajaVerde;

@Service
public class NotificacionesService {
	@Value("${misNotificaciones.servicioWeb.url}")
	private String url;
	
	@Autowired
	private WebServiceConfig serviceConfig;
	
	private static final Logger logger = LoggerFactory.getLogger(NotificacionesService.class);
	
	private MensajeEntradaEnviarNotificacion msjEntNot = null;
	private MensajeSalidaEnviarNotificacion msjSalNot = null;
	private Notificacion not = null;
	private DatosComunNotificacion dc = null;
	private DatosAdicionalesNotificacion da = null;
	private ClaveValorNotificacion claveValorNot = null;
	private List<ClaveValorNotificacion> param = null;	
	private MediosEnvio mse = null;
	private MedioEnvio me = null;
	private List<MedioEnvio> paramMe = null;	
	
	//private NotificacionesSOAPService servicioSOAP = new NotificacionesSOAPService();
		

	public MensajeSalidaMis ParametrosMIS(Document doc)
	{
		MensajeEntradaMis e = new MensajeEntradaMis();
		MensajeSalidaMis c = new MensajeSalidaMis();

		NodeList params = doc.getFirstChild().getLastChild().getFirstChild().getChildNodes();//Params

		for (int i = 1; i < params.getLength(); i++)//iterando sobre Params
		{
			String node = params.item(i).getFirstChild().getTextContent();
			String node_name_attribute = params.item(i).getAttributes().getNamedItem("name").getTextContent();

			if(node_name_attribute.equals("@i_operacion") || 
					node_name_attribute.equals("@i_fecha") ||
					node_name_attribute.equals("@i_hora") ||
					node_name_attribute.equals("@i_tipoServ") ||
					node_name_attribute.equals("@i_ente") ||
					node_name_attribute.equals("@i_nemonico") ||
					node_name_attribute.equals("@i_identificacion") ||
					node_name_attribute.equals("@i_medio") ||
					node_name_attribute.equals("@i_canal") ||
					node_name_attribute.equals("@email") ||
					node_name_attribute.equals("@i_cuenta") ||
					node_name_attribute.equals("@i_producto") ||
					node_name_attribute.equals("@gsm") ||
					//wlopezc TCRE-CC-SGC00041008
					node_name_attribute.equals("@i_cliente") ||
					node_name_attribute.equals("@i_nombre") ||
					node_name_attribute.equals("@i_prod_deb") ||
					node_name_attribute.equals("@i_desc_producto") ||
					node_name_attribute.equals("@i_empresa") ||
					node_name_attribute.equals("@i_cta_deb") ||
					node_name_attribute.equals("@i_motivo") ||
					node_name_attribute.equals("@i_cta") ||
					node_name_attribute.equals("@i_cta_cre") ||
					node_name_attribute.equals("@i_plantilla") ||
					node_name_attribute.equals("@i_valor1") ||
					node_name_attribute.equals("@i_valor2") ||
					node_name_attribute.equals("@i_servicio") ||
					node_name_attribute.equals("@i_desc_canal") ||
					node_name_attribute.equals("@i_mail") ||
					node_name_attribute.equals("@i_telefono") ||
					node_name_attribute.equals("@i_secuencial")
					//wlopezc
					)
			{
				if(node_name_attribute.equals("@i_operacion"))
				{
					e.setCodigo_operacion(node); 
					continue;
				}
				else if(node_name_attribute.equals("@i_ente"))
				{
					e.setCodigo_Mis(node);
					continue;
				}
				else if(node_name_attribute.equals("@i_fecha"))
				{
					e.setFecha(node);
					continue;
				}
				else 
					if(node_name_attribute.equals("@i_hora"))
					{
						e.setHora(node);
						continue;
					}
					else if(node_name_attribute.equals("@i_tipoServ"))
					{
						e.setTipo_Servicio(node);
						continue;
					}
					else if(node_name_attribute.equals("@i_nemonico"))
					{
						e.setServicio_Nemonico(node);
						continue;
					}
					else if(node_name_attribute.equals("@i_identificacion"))
					{
						e.setIdentificacion_Cliente(node);
						continue;
					}
					else if(node_name_attribute.equals("@i_medio"))
					{
						e.setMedio(node);
						continue;
					}        	
					else if(node_name_attribute.equals("@i_canal"))
					{
						e.setCanal(node);
						continue;
					}
					else if(node_name_attribute.equals("@email"))
					{
						e.setMail(node);
						continue;
					}
					else if(node_name_attribute.equals("@i_cuenta"))
					{
						e.setCuenta(node);
						continue;
					}
					else if(node_name_attribute.equals("@gsm"))
					{
						e.setCelular(node);
						continue;
					}
					else if(node_name_attribute.equals("@i_producto"))
					{
						e.setProducto(node);
						continue;
					}
				//ini: wlopezc
					else if(node_name_attribute.equals("@i_cliente"))
					{
						e.setCodigo_Mis(node);
						continue;
					}
					else if(node_name_attribute.equals("@i_nombre"))
					{
						e.setNombre_Cliente(node);
						continue;
					}
					else if(node_name_attribute.equals("@i_prod_deb"))
					{
						e.setI_prod_deb(node);
						continue;
					}
					else if(node_name_attribute.equals("@i_desc_producto"))
					{
						e.setI_desc_producto(node);
						continue;
					}
					else if(node_name_attribute.equals("@i_empresa"))
					{
						e.setI_empresa(node);
						continue;
					}				
					else if(node_name_attribute.equals("@i_cta_deb"))
					{
						e.setI_cta_deb(node);
						continue;
					}
					else if(node_name_attribute.equals("@i_motivo"))
					{
						e.setI_motivo(node);
						continue;
					}
					else if(node_name_attribute.equals("@i_cta"))
					{
						e.setI_cta(node);
						continue;
					}
					else if(node_name_attribute.equals("@i_cta_cre"))
					{
						e.setI_cta_cre(node);
						continue;
					}
					else if(node_name_attribute.equals("@i_plantilla"))
					{
						e.setI_plantilla(node);
						continue;
					}
					else if(node_name_attribute.equals("@i_valor1"))
					{
						e.setI_valor1(node);
						continue;
					}
					else if(node_name_attribute.equals("@i_valor2"))
					{
						e.setI_valor2(node);
						continue;
					}
					else if(node_name_attribute.equals("@i_servicio"))
					{
						e.setServicio_Nemonico(node);
						continue;
					}
					else if(node_name_attribute.equals("@i_desc_canal"))
					{
						e.setI_desc_canal(node);
						continue;
					}
					else if(node_name_attribute.equals("@i_mail"))
					{
						e.setMail(node);
						continue;
					}
					else if(node_name_attribute.equals("@i_telefono"))
					{
						e.setCelular(node);
						continue;
					}
					else if(node_name_attribute.equals("@i_secuencial"))
					{
						e.setI_secuencial(node);
						continue;
					}
				//ini: wlopezc
			}
			else
				continue;
		}    

		c = EnviarNotificacion(e);

		return c;
	}

	public MensajeSalidaMis EnviarNotificacion(MensajeEntradaMis EntradaMis) {
		MensajeSalidaMis MensajeRespuesta = new MensajeSalidaMis();
		if (EntradaMis.getServicio_Nemonico().equals("ADMIS")) {
			MensajeRespuesta = NotificacionADMIS(EntradaMis);
		}

		if (EntradaMis.getServicio_Nemonico().equals("CDIRE")) {
			MensajeRespuesta = NotificacionCDIRE(EntradaMis);
		}
		//wlopezc - TCRE-CC-SGC00041008
		if (EntradaMis.getServicio_Nemonico().equals("CMADE") ||
		    EntradaMis.getServicio_Nemonico().equals("CMADF") ||
			EntradaMis.getServicio_Nemonico().equals("ACDAT") ||
			EntradaMis.getServicio_Nemonico().equals("ACCOR") ||
			EntradaMis.getServicio_Nemonico().equals("ACSMS")
			)
		{
			MensajeRespuesta = NotificacionesALatinia(EntradaMis);
		}
		//wlopezc

		return MensajeRespuesta;
	}

	public MensajeSalidaMis NotificacionADMIS(MensajeEntradaMis EntradaMis) {
		MensajeSalidaMis MensajeRespuesta = new MensajeSalidaMis();		
		String cod_resp = null;
		String msj_resp = null;
		param = new ArrayList<ClaveValorNotificacion>();
		paramMe = new ArrayList<MedioEnvio>();

		String cod_mis = EntradaMis.getCodigo_Mis();
		try {							
			msjEntNot = new MensajeEntradaEnviarNotificacion();
			
			not = new Notificacion();
			dc = new DatosComunNotificacion();
			da = new DatosAdicionalesNotificacion();
			claveValorNot = new ClaveValorNotificacion();
			
			//Notificación
			not.setIdRequerimiento("");
			not.setRefServicio(EntradaMis.getServicio_Nemonico());
			not.setCodEnte(cod_mis);
			//not.setEnte("ENTE");

			//DatosComún
			dc.setCanal(EntradaMis.getCanal());
			//dc.setCuenta(EntradaMis.getCuenta());		
			
			mse = new MediosEnvio();
			me = new MedioEnvio();
			
			if(!EntradaMis.getFecha().isEmpty() && EntradaMis.getFecha()!= null)
			{				
				claveValorNot = new ClaveValorNotificacion();
				claveValorNot.setClave("fecha_tope");
				claveValorNot.setValor(EntradaMis.getFecha());		
				param.add(claveValorNot);
			}
			if(!EntradaMis.getHora().isEmpty() && EntradaMis.getHora()!= null)
			{
				claveValorNot = new ClaveValorNotificacion();
				claveValorNot.setClave("fecha2");
				claveValorNot.setValor(EntradaMis.getHora());		
				param.add(claveValorNot);
			}
			if(!EntradaMis.getTipo_Servicio().isEmpty())
			{
				claveValorNot = new ClaveValorNotificacion();
				claveValorNot.setClave("planilla");
				claveValorNot.setValor(EntradaMis.getTipo_Servicio());		
				param.add(claveValorNot);
			}
			if(!EntradaMis.getIdentificacion_Cliente().isEmpty())
			{
				claveValorNot = new ClaveValorNotificacion();
				claveValorNot.setClave("beneficiario");
				claveValorNot.setValor(EntradaMis.getIdentificacion_Cliente());		
				param.add(claveValorNot);
			}
			if(!EntradaMis.getMedio().isEmpty())
			{
				claveValorNot = new ClaveValorNotificacion();
				claveValorNot.setClave("nombre");
				claveValorNot.setValor(EntradaMis.getMedio());	
				param.add(claveValorNot);
			}
			if(!EntradaMis.getNombre_Cliente().isEmpty())
			{
				claveValorNot = new ClaveValorNotificacion();
				claveValorNot.setClave("identificacion");
				claveValorNot.setValor(EntradaMis.getNombre_Cliente());		
				param.add(claveValorNot);
			}

			da.getParametrosNotificacion().addAll(param);
			
			if(EntradaMis.getMail()!= null )
			{
				if  (!EntradaMis.getMail().isEmpty())
				{
				me = new MedioEnvio();
				
				me.setTipo(TipoMedio.M);
				me.setValor(EntradaMis.getMail());	
				paramMe.add(me);
				}
			}
			if(EntradaMis.getCelular()!= null )
			{
				if  (!EntradaMis.getCelular().isEmpty())
				{
				me = new MedioEnvio();
				
				me.setTipo(TipoMedio.C);
				me.setValor(EntradaMis.getCelular());	
				paramMe.add(me);
				}
			}
			
			mse.getMedioEnvio().addAll(paramMe);
			
			msjEntNot.setNotificacion(not);
			msjEntNot.setDatosComunNotificacion(dc);
			msjEntNot.setAdicionalesNotificacion(da);
			msjEntNot.setMediosEnvio(mse);
			
			msjSalNot = new MensajeSalidaEnviarNotificacion();
			
			NotificacionesPortType portType = serviceConfig.clienteNotificacionMIS();
			//NotificacionesPortType portType;
            //servicioSOAP = new NotificacionesSOAPService(new URL(url));
            //portType = servicioSOAP.getNotificacionesSOAP11BindingQSPort();  
			
			if(EntradaMis.getMail()!= null && !EntradaMis.getMail().isEmpty() )
			{
				try {
					msjSalNot = portType.enviarNotificacion(msjEntNot);
				} catch (Exception ex) {
					MensajeRespuesta.setMensaje_ejecucion("Error en comunicación con MICROSERVICIO NOTIFICACIONES.");
					MensajeRespuesta.setCodigo_respuesta("100");
					MensajeRespuesta.setMensaje_error("Error en consulta de usuario: " + ex.getMessage());
					throw ex;
					
				}
				cod_resp = msjSalNot.getCodigoError().toString();
				msj_resp = msjSalNot.getMensajeSistema().toString();
			}		
			else
			{
				cod_resp = "0";
				msj_resp = "No existe correo para notificar";
			}
			MensajeRespuesta.setCodigo_mis(cod_mis);
			MensajeRespuesta.setMensaje_ejecucion(msj_resp);
			MensajeRespuesta.setCodigo_respuesta(cod_resp);

		} catch (MalformedURLException e) {
			e.printStackTrace();
			MensajeRespuesta.setMensaje_ejecucion("Error en comunicación con MICROSERVICIO, no se envía notificación");
			MensajeRespuesta.setCodigo_respuesta("100");
			MensajeRespuesta.setMensaje_error("Error en envío de notificación: " + e.getMessage());

			return MensajeRespuesta;
		}
		 catch (Exception e) {
			MensajeRespuesta.setMensaje_ejecucion("Error en comunicación con MICROSERVICIO, no se envía notificación");
			MensajeRespuesta.setCodigo_respuesta("100");
			MensajeRespuesta.setMensaje_error("Error en envío de notificación: " + e.getMessage());
	
			return MensajeRespuesta;
		}

		return MensajeRespuesta;
	}

	public MensajeSalidaMis NotificacionCDIRE(MensajeEntradaMis EntradaMis) {
		MensajeSalidaMis MensajeRespuesta = new MensajeSalidaMis();		
		String cod_resp = null;
		String msj_resp = null;
		param = new ArrayList<ClaveValorNotificacion>();	
		paramMe = new ArrayList<MedioEnvio>();
		mse = new MediosEnvio();

		String cod_mis = EntradaMis.getCodigo_Mis();
		try {							
			msjEntNot = new MensajeEntradaEnviarNotificacion();
			
			not = new Notificacion();
			dc = new DatosComunNotificacion();
			da = new DatosAdicionalesNotificacion();
			claveValorNot = new ClaveValorNotificacion();

		//Notificación
		not.setIdRequerimiento("");
		not.setRefServicio(EntradaMis.getServicio_Nemonico());
		not.setCodEnte(cod_mis);

		//DatosComún
		dc.setCanal(EntradaMis.getCanal());
		//dc.setCuenta(EntradaMis.getCuenta());

		//Datos Adicionales
		if(!EntradaMis.getProducto().isEmpty())
		{
			claveValorNot = new ClaveValorNotificacion();
			claveValorNot.setClave("producto");
			claveValorNot.setValor(EntradaMis.getProducto());		
			param.add(claveValorNot);
		}
		if(!EntradaMis.getCuenta().isEmpty() )
		{
			if  (!EntradaMis.getCuenta().isEmpty())
			{
			claveValorNot = new ClaveValorNotificacion();
			claveValorNot.setClave("cuenta");
			claveValorNot.setValor(EntradaMis.getCuenta());	
			param.add(claveValorNot);
			}
		}

		da.getParametrosNotificacion().addAll(param);
		
		if(EntradaMis.getMail() != null )
		{
			if  (!EntradaMis.getMail().isEmpty())
			{
			me = new MedioEnvio();
			
			me.setTipo(TipoMedio.M);
			me.setValor(EntradaMis.getMail());	
			paramMe.add(me);
			}
		}
		if(EntradaMis.getCelular()!= null )
		{
			if  (!EntradaMis.getCelular().isEmpty())
			{
			me = new MedioEnvio();
			
			me.setTipo(TipoMedio.C);
			me.setValor(EntradaMis.getCelular());	
			paramMe.add(me);
			}
		}
		
		mse.getMedioEnvio().addAll(paramMe);

		msjEntNot.setNotificacion(not);
		msjEntNot.setDatosComunNotificacion(dc);
		msjEntNot.setAdicionalesNotificacion(da);
		msjEntNot.setMediosEnvio(mse);
		
		msjSalNot = new MensajeSalidaEnviarNotificacion();
				
		NotificacionesPortType portType = serviceConfig.clienteNotificacionMIS();
		//NotificacionesPortType portType;
        //servicioSOAP = new NotificacionesSOAPService(new URL(url));
        //portType = servicioSOAP.getNotificacionesSOAP11BindingQSPort();   
		
		if(EntradaMis.getMail()!= null || EntradaMis.getCelular()!= null )
		{
			try {
					msjSalNot = portType.enviarNotificacion(msjEntNot);
				} catch (Exception ex) 
				{
					MensajeRespuesta.setMensaje_ejecucion("Error en comunicación con MICROSERVICIO NOTIFICACIONES.");
					MensajeRespuesta.setCodigo_respuesta("100");
					MensajeRespuesta.setMensaje_error("Error en consulta de usuario: " + ex.getMessage());
					throw ex;					
				}
				cod_resp = msjSalNot.getCodigoError().toString();
				msj_resp = msjSalNot.getMensajeSistema().toString();			
		}		
		else
		{
			cod_resp = "0";
			msj_resp = "No existe medios de envío para notificar";
		}
		MensajeRespuesta.setCodigo_mis(cod_mis);
		MensajeRespuesta.setMensaje_ejecucion(msj_resp);
		MensajeRespuesta.setCodigo_respuesta(cod_resp);

		} catch (Exception e) {
			MensajeRespuesta.setMensaje_ejecucion("Error en comunicación con MICROSERVICIO, no se envía notificación");
			MensajeRespuesta.setCodigo_respuesta("100");
			MensajeRespuesta.setMensaje_error("Error en envío de notificación: " + e.getMessage());

			return MensajeRespuesta;
		}

		return MensajeRespuesta;
	}
	
	public String respuestaColaMis(MensajeRptaCola queue_data, MensajeSalidaMis datosMis)
	{
		String xmlColaSalida;
		xmlColaSalida = "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?><CTSMessage>" + 
				"<CTSHeader>" + 
				"<Field name=\"kernelHeader\" type=\"S\">" + queue_data.getKernelHeader() + "</Field>" + 
				"<Field name=\"fromServer\" type=\"S\">" + queue_data.getFromServer() + "</Field>" + 
				"<Field name=\"srv\" type=\"S\">" + queue_data.getSrv() + "</Field>" + 
				"<Field name=\"sesn\" type=\"N\">" + queue_data.getSesn() + "</Field>" + 
				"<Field name=\"transaccion\" type=\"N\">" + queue_data.getTransaccion() + "</Field>" + 
				"<Field name=\"usuario\" type=\"N\">" + queue_data.getUsuario() + "</Field>" + 
				"<Field name=\"secuencial\" type=\"N\">" + queue_data.getSecuencial() + "</Field>" + 
				"<Field name=\"terminal\" type=\"N\">" + queue_data.getTerminal() + "</Field>" + 
				"</CTSHeader>" + 
				"<Data>" + 
				"<ProcedureResponse>" ;//+ 

		if (queue_data.getCodRpta().equals("0")) {
			xmlColaSalida = xmlColaSalida + "<ResultSet>" +
					"<Header>" +
					"<col name=\"ClaseMedio\" type=\"39\" len=\"20\" />" +
					"<col name=\"TipoMedio\" type=\"39\" len=\"20\" />" +
					"<col name=\"ValorMedio\" type=\"39\" len=\"20\" />" +
					"</Header>";

			xmlColaSalida = xmlColaSalida + "</ResultSet>";
			xmlColaSalida = xmlColaSalida + "<return>" + queue_data.getCodRpta() + "</return>" ;
		}
		else
		{
			xmlColaSalida = xmlColaSalida + "<Message msgNo=\"0\" type=\"3\">" + queue_data.getMensajeRpta() + "</Message>";
			xmlColaSalida = xmlColaSalida + "<return>" +  datosMis.getMensaje_error() + "</return>" ;
		}

		xmlColaSalida = xmlColaSalida +  "</ProcedureResponse></Data></CTSMessage>"; 
		return xmlColaSalida;
	}
	
	//ini: wlopezc - TCRE-CC-SGC00041008
	public MensajeSalidaMis NotificacionesALatinia(MensajeEntradaMis EntradaMis) {
			MensajeSalidaMis MensajeRespuesta = new MensajeSalidaMis();		
			String cod_resp = null;
			String msj_resp = null;
			param = new ArrayList<ClaveValorNotificacion>(); //Datos de notificacion
			paramMe = new ArrayList<MedioEnvio>(); //Medios de envio

			String cod_mis = EntradaMis.getCodigo_Mis();
			try {							
				msjEntNot = new MensajeEntradaEnviarNotificacion();
				
				not = new Notificacion();
				dc = new DatosComunNotificacion();
				da = new DatosAdicionalesNotificacion();
				//Medio de Envio
				mse = new MediosEnvio();
				me = new MedioEnvio();
					
				claveValorNot = new ClaveValorNotificacion();
				
				//ini: Cabecera de NotificaciÃ³n
				not.setIdRequerimiento(EntradaMis.getI_secuencial());
				not.setRefServicio(EntradaMis.getServicio_Nemonico());
				not.setRefCompania("BOLIVARIANO");
				not.setCodEnte(cod_mis);		
				//fin: Cabecera de NotificaciÃ³n

				//ini: Datos de Notificacion
				if (EntradaMis.getServicio_Nemonico().equals("CMADE") ||
						EntradaMis.getServicio_Nemonico().equals("CMADF"))
				{
					
					if((EntradaMis.getCodigo_Operacion()!= null) && 
						(EntradaMis.getCodigo_Operacion() != "")){
						claveValorNot = new ClaveValorNotificacion();
						claveValorNot.setClave("i_operacion"); 
						claveValorNot.setValor(EntradaMis.getCodigo_Operacion());		
						param.add(claveValorNot);
					}
					
					if((EntradaMis.getCodigo_Mis()!= null) && 
							(EntradaMis.getCodigo_Mis() != "")) {
						claveValorNot = new ClaveValorNotificacion();
						claveValorNot.setClave("i_cliente"); 
						claveValorNot.setValor(EntradaMis.getCodigo_Mis());		
						param.add(claveValorNot);

					}
					if((EntradaMis.getNombre_Cliente()!= null) && 
							(EntradaMis.getNombre_Cliente() != "")) {
						claveValorNot = new ClaveValorNotificacion();
						claveValorNot.setClave("nombre_cliente"); 
						claveValorNot.setValor(EntradaMis.getNombre_Cliente());		
						param.add(claveValorNot);
					}
					
					if (EntradaMis.getServicio_Nemonico().equals("CMADF")){

						if((EntradaMis.getI_prod_deb()!= null) && 
								(EntradaMis.getI_prod_deb() != "")) {
							claveValorNot = new ClaveValorNotificacion();
							claveValorNot.setClave("desc1");
							claveValorNot.setValor(EntradaMis.getI_prod_deb());		
							param.add(claveValorNot);
						}

						if((EntradaMis.getI_desc_producto()!= null) && 
								(EntradaMis.getI_desc_producto() != "")) {
							claveValorNot = new ClaveValorNotificacion();
							claveValorNot.setClave("dato1");
							claveValorNot.setValor(EntradaMis.getI_desc_producto());		
							param.add(claveValorNot);
						}

						if((EntradaMis.getCuenta()!= null) && 
								(EntradaMis.getCuenta() != "")) {
							claveValorNot = new ClaveValorNotificacion();
							claveValorNot.setClave("mensaje1");
							claveValorNot.setValor(EntradaMis.getCuenta());		
							param.add(claveValorNot);
						}

						if((EntradaMis.getI_empresa()!= null) && 
								(EntradaMis.getI_empresa() != "")) {
							claveValorNot = new ClaveValorNotificacion();
							claveValorNot.setClave("desc2");
							claveValorNot.setValor(EntradaMis.getI_empresa());		
							param.add(claveValorNot);
						}
						
						if((EntradaMis.getI_cta_deb()!= null) && 
								(EntradaMis.getI_cta_deb() != "")) {
							claveValorNot = new ClaveValorNotificacion();
							claveValorNot.setClave("dato2");
							claveValorNot.setValor(EntradaMis.getI_cta_deb());		
							param.add(claveValorNot);
						}
						
						if((EntradaMis.getI_motivo()!= null) && 
								(EntradaMis.getI_motivo() != "")) {
							claveValorNot = new ClaveValorNotificacion();
							claveValorNot.setClave("mensaje2");
							claveValorNot.setValor(EntradaMis.getI_motivo());		
							param.add(claveValorNot);
						}
						
						if((EntradaMis.getI_Cta()!= null) && 
								(EntradaMis.getI_Cta() != "")) {
							claveValorNot = new ClaveValorNotificacion();
							claveValorNot.setClave("desc3");
							claveValorNot.setValor(EntradaMis.getI_Cta());		
							param.add(claveValorNot);
						}
						
						if((EntradaMis.getI_cta_cre()!= null) && 
								(EntradaMis.getI_cta_cre() != "")) {
							claveValorNot = new ClaveValorNotificacion();
							claveValorNot.setClave("dato3");
							claveValorNot.setValor(EntradaMis.getI_cta_cre());		
							param.add(claveValorNot);
						}
						
						if((EntradaMis.getI_plantilla()!= null) && 
								(EntradaMis.getI_plantilla() != "")) {
							claveValorNot = new ClaveValorNotificacion();
							claveValorNot.setClave("mensaje3");
							claveValorNot.setValor(EntradaMis.getI_plantilla());		
							param.add(claveValorNot);
						}
					}
					
					if (EntradaMis.getServicio_Nemonico().equals("CMADE")){
						
						if((EntradaMis.getI_valor1()!= null) && 
								(EntradaMis.getI_valor1() != "")) {
							claveValorNot = new ClaveValorNotificacion();
							claveValorNot.setClave("num_doc");
							claveValorNot.setValor(EntradaMis.getI_valor1());		
							param.add(claveValorNot);
						}

						if((EntradaMis.getI_cta_cre()!= null) && 
								(EntradaMis.getI_cta_cre() != "")) {
							claveValorNot = new ClaveValorNotificacion();
							claveValorNot.setClave("desccanal");
							claveValorNot.setValor(EntradaMis.getI_cta_cre());		
							param.add(claveValorNot);
						}
						
						if((EntradaMis.getI_valor2()!= null) && 
								(EntradaMis.getI_valor2() != "")) {
							claveValorNot = new ClaveValorNotificacion();
							claveValorNot.setClave("fecha");
							claveValorNot.setValor(EntradaMis.getI_valor2());		
							param.add(claveValorNot);
						}
						
						if((EntradaMis.getI_motivo()!= null) && 
								(EntradaMis.getI_motivo() != "")) {
							claveValorNot = new ClaveValorNotificacion();
							claveValorNot.setClave("hora");
							claveValorNot.setValor(EntradaMis.getI_motivo());		
							param.add(claveValorNot);
						}
					}
					
					if((EntradaMis.getServicio_Nemonico()!= null) && 
							(EntradaMis.getServicio_Nemonico() != "")) {
						claveValorNot = new ClaveValorNotificacion();
						claveValorNot.setClave("i_servicio");
						claveValorNot.setValor(EntradaMis.getServicio_Nemonico());		
						param.add(claveValorNot);
					}
					
					if((EntradaMis.getProducto()!= null) && 
							(EntradaMis.getProducto() != "")) {
						claveValorNot = new ClaveValorNotificacion();
						claveValorNot.setClave("i_producto");
						claveValorNot.setValor(EntradaMis.getProducto());		
						param.add(claveValorNot);
					}

					if((EntradaMis.getCanal()!= null) && 
							(EntradaMis.getCanal() != "")) {
						claveValorNot = new ClaveValorNotificacion();
						claveValorNot.setClave("i_canal");
						claveValorNot.setValor(EntradaMis.getCanal());		
						param.add(claveValorNot);
					}

					if((EntradaMis.getI_desc_canal()!= null) && 
							(EntradaMis.getI_desc_canal() != "")) {
						claveValorNot = new ClaveValorNotificacion();
						claveValorNot.setClave("i_desc_canal");
						claveValorNot.setValor(EntradaMis.getI_desc_canal());		
						param.add(claveValorNot);
					}
				}
				
				//FMI -NOTIFICACIONES POR ANULACION DE SOLICITUD ACTDATO
				//DCV-AP-SGC00040529-SGC00041709
				if (EntradaMis.getServicio_Nemonico().equals("ACDAT") ||
						EntradaMis.getServicio_Nemonico().equals("ACCOR") ||
						EntradaMis.getServicio_Nemonico().equals("ACSMS")
					)
				{
					
					if((EntradaMis.getNombre_Cliente()!= null) && 
							(EntradaMis.getNombre_Cliente() != "")) {
						claveValorNot = new ClaveValorNotificacion();
						claveValorNot.setClave("nombre_cliente");
						claveValorNot.setValor(EntradaMis.getNombre_Cliente());		
						param.add(claveValorNot);
					}
					
					if((EntradaMis.getI_motivo()!= null) && 
							(EntradaMis.getI_motivo() != "")) {
						claveValorNot = new ClaveValorNotificacion();
						claveValorNot.setClave("resultado");
						claveValorNot.setValor(EntradaMis.getI_motivo());		
						param.add(claveValorNot);
					}
					
					if((EntradaMis.getI_desc_canal()!= null) && 
							(EntradaMis.getI_desc_canal() != "")) {
						claveValorNot = new ClaveValorNotificacion();
						claveValorNot.setClave("desccanal");
						claveValorNot.setValor(EntradaMis.getI_desc_canal());		
						param.add(claveValorNot);
					}
					
					if((EntradaMis.getIdentificacion_Cliente()!= null) && 
							(EntradaMis.getIdentificacion_Cliente() != "")) {
						claveValorNot = new ClaveValorNotificacion();
						claveValorNot.setClave("identificacion");
						claveValorNot.setValor(EntradaMis.getIdentificacion_Cliente());		
						param.add(claveValorNot);
					}
					
					if((EntradaMis.getFecha()!= null) && 
							(EntradaMis.getFecha() != "")) {
						claveValorNot = new ClaveValorNotificacion();
						claveValorNot.setClave("fecha");
						claveValorNot.setValor(EntradaMis.getFecha());		
						param.add(claveValorNot);
					}
					
					if((EntradaMis.getFecha()!= null) && 
							(EntradaMis.getFecha() != "")) {
						claveValorNot = new ClaveValorNotificacion();
						claveValorNot.setClave("fecha_tope");
						claveValorNot.setValor(EntradaMis.getFecha());		
						param.add(claveValorNot);
					}
					
					if (EntradaMis.getServicio_Nemonico().equals("ACCOR")){
						
						if((EntradaMis.getI_valor1() != null) && 
								(EntradaMis.getI_valor1() != "")) {
							claveValorNot = new ClaveValorNotificacion();
							claveValorNot.setClave("correo");
							claveValorNot.setValor(EntradaMis.getI_valor1());		
							param.add(claveValorNot);
						}
						
						if((EntradaMis.getI_Cta()!= null) && 
								(EntradaMis.getI_Cta() != "")) {
							claveValorNot = new ClaveValorNotificacion();
							claveValorNot.setClave("marca_latinia");
							claveValorNot.setValor(EntradaMis.getI_Cta());		
							param.add(claveValorNot);
						} 
						
					}
					
					if (EntradaMis.getServicio_Nemonico().equals("ACSMS")){
						
						if((EntradaMis.getI_valor2() != null) && 
								(EntradaMis.getI_valor2() != "")) {
							claveValorNot = new ClaveValorNotificacion();
							claveValorNot.setClave("celular");
							claveValorNot.setValor(EntradaMis.getI_valor2());		
							param.add(claveValorNot);
						}
						
						if((EntradaMis.getI_Cta()!= null) && 
								(EntradaMis.getI_Cta() != "")) {
							claveValorNot = new ClaveValorNotificacion();
							claveValorNot.setClave("marca_latinia");
							claveValorNot.setValor(EntradaMis.getI_Cta());		
							param.add(claveValorNot);
						} 
					}
					
				}

				da.getParametrosNotificacion().addAll(param); //Agrega todos los parametros
				//fin: Datos de Notificacion
				
				//ini: Medio de envio
				if((EntradaMis.getMail()!= null) && 
						(EntradaMis.getMail() != "")) {
					me = new MedioEnvio();
					me.setTipo(TipoMedio.M); me.setValor(EntradaMis.getMail());	
					paramMe.add(me); 
				}

				if((EntradaMis.getCelular()!= null) && 
						(EntradaMis.getCelular() != "")) {
					me = new MedioEnvio();
					me.setTipo(TipoMedio.C); me.setValor(EntradaMis.getCelular());	
					paramMe.add(me);
				}			
				mse.getMedioEnvio().addAll(paramMe); //Agrega medios de envio
				//ini: Medio de envio
				//Arma msg para latinia
				msjEntNot.setNotificacion(not);
				msjEntNot.setDatosComunNotificacion(dc);
				msjEntNot.setAdicionalesNotificacion(da);
				msjEntNot.setMediosEnvio(mse);
				msjSalNot = new MensajeSalidaEnviarNotificacion();
				
				NotificacionesPortType portType = serviceConfig.clienteNotificacionMIS();

				//Envio de notificacion
				try {
					msjSalNot = portType.enviarNotificacion(msjEntNot);
				} catch (Exception ex) {
					MensajeRespuesta.setMensaje_ejecucion("Error en comunicacion con MICROSERVICIO NOTIFICACIONES.");
					MensajeRespuesta.setCodigo_respuesta("100");
					MensajeRespuesta.setMensaje_error("Error en consulta de usuario: " + ex.getMessage());
					throw ex;
				}
				
				cod_resp = msjSalNot.getCodigoError().toString();
				msj_resp = msjSalNot.getMensajeSistema().toString();

				MensajeRespuesta.setCodigo_mis(cod_mis);
				MensajeRespuesta.setMensaje_ejecucion(msj_resp);
				MensajeRespuesta.setCodigo_respuesta(cod_resp);

			} catch (MalformedURLException e) {
				e.printStackTrace();
				MensajeRespuesta.setMensaje_ejecucion("Error en comunicaciÃ³n con MICROSERVICIO, no se envÃ­a notificaciÃ³n");
				MensajeRespuesta.setCodigo_respuesta("100");
				MensajeRespuesta.setMensaje_error("Error en envÃ­o de notificaciÃ³n: " + e.getMessage());

				return MensajeRespuesta;
			}
			 catch (Exception e) {
				MensajeRespuesta.setMensaje_ejecucion("Error en comunicaciÃ³n con MICROSERVICIO, no se envÃ­a notificaciÃ³n");
				MensajeRespuesta.setCodigo_respuesta("100");
				MensajeRespuesta.setMensaje_error("Error en envÃ­o de notificaciÃ³n: " + e.getMessage());
		
				return MensajeRespuesta;
			}

			return MensajeRespuesta;
		}

	//fin: wlopezc
	
	public void enviarComprobanteDeposito(Comprobante comp, String pdf64)
	{		
		try
		{
			NotificacionesPortType portType = serviceConfig.clienteNotificacionMIS();
			MensajeEntradaEnviarNotificacion not = new MensajeEntradaEnviarNotificacion();
			DatosAdjunto adjuntos= new DatosAdjunto();
			adjuntos.getDatoAdjunto().add(adjuntar(pdf64,"base64","comprobante.png","application/png"));
			not.setDatosAdjunto(adjuntos);
			MediosEnvio medios = new MediosEnvio();
			MedioEnvio medio = setMedio(comp.getMail(), "M");
			if (medio != null)
				medios.getMedioEnvio().add(medio);
			
			not.setMediosEnvio(medios);
			
			Notificacion n = new Notificacion();
			n.setIdRequerimiento("");
			String refSrv = comp.isDeposit()?"DEPCV":comp.isPayCard()?"PTCCV":"PSRCV";
			logger.info("Plantilla: " +refSrv);
			n.setRefServicio(refSrv);
			n.setRefCompania("BOLIVARIANO");
			n.setEtiquetaMensaje("Avisos24");
			not.setNotificacion(n);
			
			DatosComunNotificacion info = new DatosComunNotificacion();
			
			info.setCanal("CV");
			not.setDatosComunNotificacion(info);
			
			not.setAdicionalesNotificacion(getDatosNotificacion(comp));
			
			MensajeSalidaEnviarNotificacion response = new MensajeSalidaEnviarNotificacion();
			//12-10-2021 - Se realizó la validación del correo nulo para el envío de las notificaciones.
			if (medio != null) {
				response = portType.enviarNotificacion(not);
			}else {
				logger.info("No existe correo para el envío de la notificación.");
			}
			
			if (response.getCodigoError() == null || !response.getCodigoError().equals("0")) {
				String mensajeSistema = response.getMensajeUsuario() != null ? response.getMensajeUsuario() : "-";
				mensajeSistema += response.getMensajeSistema() != null ? response.getMensajeSistema() : "";
				logger.error("Error al enviar notificación: " + mensajeSistema);
			}
			
		}
		catch (Exception e) {
			logger.error("Error al enviar notificación",e);
		}
		
	}
	private DatoAdjunto adjuntar(String valor, String cod, String nombre, String tipo) {
		DatoAdjunto adjunto= new DatoAdjunto();
		adjunto.setValor(valor);
		adjunto.setCodificacion(cod);
		adjunto.setNombre(nombre);
		adjunto.setTipo(tipo);
		return adjunto;
	}
	
	private MedioEnvio setMedio(String medio, String tipo) {
		MedioEnvio retorno = null;
		if (medio != null && !medio.trim().isEmpty()) {
			retorno = new MedioEnvio();
			retorno.setTipo(TipoMedio.fromValue(tipo));
			retorno.setValor(medio);
		}
		return retorno;

	}
	
	private DatosAdicionalesNotificacion getDatosNotificacion(Comprobante comp) {
		DatosAdicionalesNotificacion datos = new DatosAdicionalesNotificacion();

		datos = setAdicionales(datos, "valor", comp.getTotal());
		String tipoCta = "";
		String cta = "";
		if (comp.isDeposit()) {
			if (comp.getBenfTypeAccount() != null) {
				tipoCta = comp.getBenfTypeAccount().equals("AHO") ? "AHORRO" : "CORRIENTE";
			}
			if (comp.getBenfNumberAccount() != null) {
				cta = enmascararCta(comp.getBenfNumberAccount());
			}
		}
		else if (comp.isPayCard()) {
			tipoCta = comp.getBenfTypeAccount();
			cta = comp.getBenfNumberAccount();
			if (cta != null) {
				cta = cta.substring(cta.length() - 3, cta.length());
			}
		} else {
			cta = comp.getBenfNumberAccount() +" "+ comp.getCodeRec();
		}
		
		datos = setAdicionales(datos, "tipo_cta", tipoCta);
		datos = setAdicionales(datos, "numcta", cta);
		datos = setAdicionales(datos, "numtrj", cta);
		datos = setAdicionales(datos, "tipotrj", tipoCta);

		String fechaActual = this.fechaAcadena(new Date(), "dd-MM-yyyy");
		String fechaHora = this.fechaAcadena(new Date(), "HH:mm:ss");

		datos = setAdicionales(datos, "fecha_tope", fechaActual);
		datos = setAdicionales(datos, "fecha1", fechaHora);
		datos = setAdicionales(datos, "desccanal", "Ventanilla");
		
		datos = setAdicionales(datos, "beneficiario", comp.getBenfNameAccount());		
		datos = setAdicionales(datos, "nombre_cliente", comp.getBenfNameAccount());	
		datos = setAdicionales(datos, "nombre", comp.getBenfNameAccount());	
		
		datos = setAdicionales(datos, "deservicio", comp.getTransDescripction());	
		datos = setAdicionales(datos, "planilla", comp.getBenfNumberAccount());
		datos = setAdicionales(datos, "empresa", comp.getCompanyName());
		datos = setAdicionales(datos, "valor2", comp.getCommission());

		return datos;
	}
	private DatosAdicionalesNotificacion setAdicionales(DatosAdicionalesNotificacion datos, String clave,
			Object valor) {
		ClaveValorNotificacion registro = new ClaveValorNotificacion();
		if (valor != null) {
			registro.setClave(clave);
			registro.setValor(String.valueOf(valor));
			datos.getParametrosNotificacion().add(registro);
		}
		return datos;

	}

	private String enmascararCta(String cta) {
		StringBuilder retorno = new StringBuilder();
		try {
			retorno.append(cta.substring(0, 4));
			retorno.append("****");
			retorno.append(cta.substring(cta.length() - 4, cta.length()));
		} catch (Exception e) {
			logger.error("Error al enmascarar cuenta", e);
		}
		return retorno.toString();

	}
	public String fechaAcadena(Date fecha, String formato) {
		DateFormat formatoFecha = new SimpleDateFormat(formato);
		String fechaResult = formatoFecha.format(fecha);
		return fechaResult;
	}

	

}

