package com.bolivariano.microservice.comprobantecvms.bean;

import java.io.Serializable;

import com.bolivariano.microservice.comprobantecvms.helper.Helper;

//import com.bolivariano.microservice.comprobantecvms.helper.Helper;

public class Comprobante implements Serializable {
	private static final long serialVersionUID = 1L;

	// Beneficiario
	private String Benf_Account_Name;
	private String Benf_Account_Number;
	private String Benf_Account_Type;

	// Datos de la Transacción
	private String uuid;
	private String uniqueTransCode;
	private String ipAgency;
	private String dateTrans;
	private String officeCode;
	private String officeUser;
	private String officeHours;
	private String currency;
	private String sec;
	private String transCode;
	private String transDescripction;

	private String EFE;
	private String EFE_CHEQUE;
	private String CANT_CHEQUES;
	private String TOTAL;
	
	private String sign;
	private String mail;
	private String transactionType;
	private String codCt;
	
	private boolean deposit;
	private boolean payCard;
	private boolean payService;
	

	private String codeRec;
	private String closingDate;
	private String amountCheckOb;
	private String amountCheckMi;
	private String amountCheckNy;
	private String amountCheckOp;
	private String amountDebit;
	
	private String rucCompanyVal;
	private String benfIdetification;
	private String amountVal;
	private String amountToDate;
	private String accesKey;
	private String companyName;
	private String companyId;
	
	private String category;
	private String categoryId;	
	private String typeService;
	private String unpaidMonth;
	
	private String bill;
	private String billDate;
	private String startDate;
	private String commission;
	private String direction;
	
	public String getBill() {
		return bill;
	}

	public void setBill(String bill) {
		this.bill = bill;
	}

	public String getBillDate() {
		return billDate;
	}

	public void setBillDate(String billDate) {
		this.billDate = billDate;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getUnpaidMonth() {
		return unpaidMonth;
	}

	public void setUnpaidMonth(String unpaidMonth) {
		this.unpaidMonth = unpaidMonth;
	}

	public String getTypeService() {
		return typeService;
	}

	public void setTypeService(String typeService) {
		this.typeService = typeService;
	}


	public Comprobante() {
		Benf_Account_Name = "**********";
		Benf_Account_Number = "**********";
		Benf_Account_Type = "**********";
		uuid = "-1";
		uniqueTransCode = "*********";
		ipAgency = "***";
		dateTrans = "2100-01-01 00:00:01";
		officeCode = "***";
		officeUser = "****";
		officeHours = "***";
		currency = "****";
		sec = "**********";
		transCode = "*****";
		transDescripction = "***********";
		EFE = "0.00";
		EFE_CHEQUE = "0.00";
		CANT_CHEQUES = "0";
		TOTAL = "0.00";
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
		
		if(uuid != null)
			this.uniqueTransCode = Helper.randomNumber(Integer.parseInt(uuid));
	}

	public String getUniqueTransCode() {
		return uniqueTransCode;
	}

	/*
	 * public void setUniqueTransCode(String uniqueTransCode) { this.uniqueTransCode
	 * = uniqueTransCode; }
	 */

	public String getIpAgency() {
		return ipAgency;
	}

	public void setIpAgency(String ipAgency) {
		this.ipAgency = ipAgency;
	}

	public String getDateTrans() {
		return dateTrans;
	}

	public void setDateTrans(String dateTrans) {
		this.dateTrans = dateTrans;
	}

	public String getOfficeCode() {
		return officeCode;
	}

	public void setOfficeCode(String officeCode) {
		this.officeCode = officeCode;
	}

	public String getOfficeUser() {
		return officeUser;
	}

	public void setOfficeUser(String officeUser) {
		this.officeUser = officeUser;
	}

	public String getOfficeHours() {
		return officeHours;
	}

	public void setOfficeHours(String officeHours) {
		this.officeHours = officeHours;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getSec() {
		return sec;
	}

	public void setSec(String sec) {
		this.sec = sec;
	}

	public String getTransCode() {
		return transCode;
	}

	public void setTransCode(String transCode) {
		this.transCode = transCode;
	}

	public String getTransDescripction() {
		return transDescripction;
	}

	public void setTransDescripction(String transDescripction) {
		this.transDescripction = transDescripction;
	}
	
	public String getEfectivo() {
		return EFE;
	}

	public void setEfectivo(String efectivo) {
		EFE = efectivo;
	}

	public String getEfeCheque() {
		return EFE_CHEQUE;
	}

	public void setEfeCheque(String efe_Cheque) {
		EFE_CHEQUE = efe_Cheque;
	}

	public String getCantcheques() {
		return CANT_CHEQUES;
	}

	public void setCantcheques(String cant_cheques) {
		CANT_CHEQUES = cant_cheques;
	}

	public String getTotal() {
		return TOTAL;
	}

	public void setTotal(String total) {
		TOTAL = total;
	}

	public String getBenfNameAccount() {
		return Benf_Account_Name;
	}

	public void setBenfNameAccount(String benf_Name_Account) {
		Benf_Account_Name = benf_Name_Account;
	}

	public String getBenfNumberAccount() {
		return Benf_Account_Number;
	}

	public void setBenfNumberAccount(String benf_Number_Account) {
		Benf_Account_Number = benf_Number_Account;
	}

	public String getBenfTypeAccount() {
		return Benf_Account_Type;
	}

	public void setBenfTypeAccount(String benf_Type_Account) {
		Benf_Account_Type = benf_Type_Account;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		if (transactionType != null) {
			this.deposit = transactionType.equals("46") ? true : false;
			this.payCard = transactionType.equals("86") ? true : false;
			this.payService = transactionType.equals("51") ? true : false;
		}
		this.transactionType = transactionType;
	}

	public String getCodCt() {
		return codCt;
	}

	public void setCodCt(String codCt) {
		this.codCt = codCt;
	}

	public boolean isDeposit() {
		return deposit;
	}

	public boolean isPayCard() {
		return payCard;
	}

	public boolean isPayService() {
		return payService;
	}

	public String getClosingDate() {
		return closingDate;
	}

	public void setClosingDate(String closingDate) {
		this.closingDate = closingDate;
	}

	public String getAmountCheckOb() {
		return amountCheckOb;
	}

	public void setAmountCheckOb(String amountCheckOb) {
		this.amountCheckOb = amountCheckOb;
	}

	public String getAmountCheckMi() {
		return amountCheckMi;
	}

	public void setAmountCheckMi(String amountCheckMi) {
		this.amountCheckMi = amountCheckMi;
	}

	public String getAmountCheckNy() {
		return amountCheckNy;
	}

	public void setAmountCheckNy(String amountCheckNy) {
		this.amountCheckNy = amountCheckNy;
	}

	public String getAmountCheckOp() {
		return amountCheckOp;
	}

	public void setAmountCheckOp(String amountCheckOp) {
		this.amountCheckOp = amountCheckOp;
	}

	public String getCodeRec() {
		return codeRec;
	}

	public void setCodeRec(String codeRec) {
		this.codeRec = codeRec;
	}

	public String getAmountDebit() {
		return amountDebit;
	}

	public void setAmountDebit(String amountDebit) {
		this.amountDebit = amountDebit;
	}

	

	

	public String getBenfIdetification() {
		return benfIdetification;
	}

	public void setBenfIdetification(String benfIdetification) {
		this.benfIdetification = benfIdetification;
	}

	public String getAmountVal() {
		return amountVal;
	}

	public void setAmountVal(String amountVal) {
		this.amountVal = amountVal;
	}

	public String getAmountToDate() {
		return amountToDate;
	}

	public void setAmountToDate(String amountToDate) {
		this.amountToDate = amountToDate;
	}

	public String getAccesKey() {
		return accesKey;
	}

	public void setAccesKey(String accesKey) {
		this.accesKey = accesKey;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getRucCompanyVal() {
		return rucCompanyVal;
	}

	public void setRucCompanyVal(String rucCompanyVal) {
		this.rucCompanyVal = rucCompanyVal;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}

	public String getCommission() {
		return commission;
	}

	public void setCommission(String commission) {
		this.commission = commission;
	}

	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	
	
}
