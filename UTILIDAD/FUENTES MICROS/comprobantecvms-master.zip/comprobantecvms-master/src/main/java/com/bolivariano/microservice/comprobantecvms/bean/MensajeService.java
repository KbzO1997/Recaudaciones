package com.bolivariano.microservice.comprobantecvms.bean;

public class MensajeService {

	
	private int code;
	private String message;
	
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	public MensajeService() 
	{
		//valor por defecto
		code = -21;
		message = "";
	}
	
	public MensajeService(int code, String message) 
	{
		this.code = code;
		this.message = message;
	}
}
