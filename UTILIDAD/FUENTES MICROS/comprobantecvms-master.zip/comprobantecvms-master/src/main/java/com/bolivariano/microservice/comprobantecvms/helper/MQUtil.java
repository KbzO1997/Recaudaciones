package com.bolivariano.microservice.comprobantecvms.helper;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ibm.mq.MQEnvironment;
import com.ibm.mq.MQException;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.ibm.mq.constants.MQConstants;

public class MQUtil 
{
	private String hostname;
	private String channel;
	private int port;
	private String queueManager;
	private String requestQueue;	
	private MQMessage outMsg;
	private MQQueue outQueue;
	private MQQueueManager qmgr; //Connection to Queue Manager	
	
	private final static Logger logger = LoggerFactory.getLogger(MQUtil.class);
	
	public MQUtil() {
		super();
	}
	
	
	/*
	 * Constructor
	 */
	public MQUtil(String hostname,String channel, int port, String queueManager, String requestQueue){
		this.hostname = hostname;
		this.channel = channel;
		this.port = port;
		this.queueManager = queueManager;
		this.requestQueue = requestQueue;
	}
	
	
	/*
	 * Create a new Queue Manager connection if one doesn't exist
	 */
	@SuppressWarnings("unchecked")
	private MQQueueManager getQueueManager() throws MQException {
		MQEnvironment.hostname = this.hostname;
		MQEnvironment.port = this.port;
		MQEnvironment.channel = this.channel;
		MQEnvironment.properties.put(MQConstants.TRANSPORT_PROPERTY,MQConstants.TRANSPORT_MQSERIES);
		if ((qmgr == null) || !qmgr.isConnected()) {
			 qmgr = new MQQueueManager(this.queueManager);
		}
		return qmgr;
	 }
	
	
	/*
	 * Send an MQ message
	 */
	public void sendMessage(MQMessage sendMsg) throws Exception{
		try{
						
			outMsg=sendMsg;	
			outMsg.messageType = MQConstants.MQMT_DATAGRAM;
			
			int openOptions = MQConstants.MQOO_OUTPUT | MQConstants.MQOO_FAIL_IF_QUIESCING;
			outQueue = getQueueManager().accessQueue(this.requestQueue, openOptions );
			MQPutMessageOptions pmo = new MQPutMessageOptions();
			
			outQueue.put(outMsg, pmo);			
			outQueue.close();
			qmgr.disconnect();
			
		}catch (MQException e) {
			logger.error("An MQ error occured: Completion code " + e.completionCode + " Reason code " + e.reasonCode);			
			logger.error("Cause exception:", e );
			disconnect();
			throw new Exception ("MQException", e);
		}catch (Exception e) {
			logger.error("An error occured writing to the message buffer ", e);
			disconnect();
			throw new Exception ("Exception", e);
		}
	}
		
    /*
     * Disconnect from the Queue Manager
     */
	private void disconnect() {
		try {			
			if(outQueue!=null)
				if(outQueue.isOpen())outQueue.close();
			if(qmgr != null) {
				if(qmgr.isConnected())
					qmgr.close();
					qmgr.disconnect();
			}			
		 }catch (MQException e) {
			 qmgr = null;
			 logger.error("Error disconnect:", e);
		 }
	}	
		
	public static String GenerarUID(){
		UUID idOne = UUID.randomUUID();
		return idOne.toString().replace("-", "")+" "; 
	}
	
	


}
