package com.bolivariano.microservice.comprobantecvms.dao;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Service;

import com.bolivariano.microservice.comprobantecvms.bean.PrestamoSaldo;
import com.bolivariano.microservice.comprobantecvms.beantrn.Catalog;
import com.bolivariano.microservice.comprobantecvms.beantrn.Client;
import com.bolivariano.microservice.comprobantecvms.beantrn.Company;
import com.bolivariano.microservice.comprobantecvms.beantrn.PayCard;
import com.bolivariano.microservice.comprobantecvms.beantrn.PayService;
import com.bolivariano.microservice.comprobantecvms.beantrn.Session;
import com.bolivariano.microservice.comprobantecvms.beantrn.Transaction;
import com.bolivariano.microservice.comprobantecvms.helper.Helper;

@Service
public class TransactionDAO {

	@Autowired
	StoredProcedureUtils storedProcedureUtils;

	private  static final Logger logger2 = LoggerFactory.getLogger(TransactionDAO.class);
	
	public Map<?, ?> getStatCreditCard(String ct) {
		HashMap<String, Object> inParams = new HashMap<>();

		inParams.put("e_ct", ct);
		SqlParameter sqlParameters[] = { new SqlParameter("e_ct", Types.VARCHAR) };
		return storedProcedureUtils.callStoredProcedureSql("ATVDB", "pa_vci_cescta_xct", inParams, sqlParameters);
	}

	public Map<?, ?> guardarTransaccionDeposito(Transaction trx) {
		HashMap<String, Object> inParams = new HashMap<>();

		inParams.put("e_td_cod_trx", trx.getIdTransaction());
		inParams.put("e_td_ct", trx.getCtCode());
		inParams.put("e_td_uuid", trx.getSession().getUuId());
		inParams.put("e_td_ip", trx.getSession().getIp());
		inParams.put("e_td_cta_number", trx.getDeposit().getAccountNumber());
		inParams.put("e_td_cta_fullname", trx.getDeposit().getClient().getName());
		inParams.put("e_td_cta_type", trx.getDeposit().getAccountTypeCode());
		inParams.put("e_td_amount_cahsh", trx.getDeposit().getAmountCash());
		inParams.put("e_td_n_cheque", trx.getDeposit().getnCheck());
		inParams.put("e_td_amount_cheque", trx.getDeposit().getAmountCheck());
		inParams.put("e_td_funds_source", trx.getDeposit().getFundsSource());
		inParams.put("e_td_funds_destination", trx.getDeposit().getFundsDestination());
		inParams.put("e_td_depo_tp_dni", trx.getDepositor().getIdentificationType());
		inParams.put("e_td_depo_dni", trx.getDepositor().getIdentification());
		inParams.put("e_td_depo_name", trx.getDepositor().getName());
		inParams.put("e_td_depo_phone", trx.getDepositor().getPhone());
		inParams.put("e_td_depo_mail", trx.getDepositor().getMail());
		inParams.put("e_td_fecha_created", Helper.dateToGregorianCalendar(trx.getCreateDate()));
		inParams.put("e_td_time", trx.getMaxTime());
		inParams.put("e_td_tp_origen", trx.getAccessType());
		inParams.put("e_td_nemonico", trx.getTypeCode());
		inParams.put("e_td_estado", trx.getCheck() ? "1" : "0");
		inParams.put("s_codigo_retorno", null);
		SqlParameter sqlParameters[] = { new SqlParameter("e_td_cod_trx", Types.INTEGER),
				new SqlParameter("e_td_ct", Types.VARCHAR), new SqlParameter("e_td_uuid", Types.VARCHAR),
				new SqlParameter("e_td_ip", Types.VARCHAR), new SqlParameter("e_td_cta_number", Types.VARCHAR),
				new SqlParameter("e_td_cta_fullname", Types.VARCHAR), new SqlParameter("e_td_cta_type", Types.VARCHAR),
				new SqlParameter("e_td_amount_cahsh", Types.DECIMAL), new SqlParameter("e_td_n_cheque", Types.INTEGER),
				new SqlParameter("e_td_amount_cheque", Types.DECIMAL),
				new SqlParameter("e_td_funds_source", Types.VARCHAR),
				new SqlParameter("e_td_funds_destination", Types.VARCHAR),
				new SqlParameter("e_td_depo_tp_dni", Types.VARCHAR), new SqlParameter("e_td_depo_dni", Types.VARCHAR),
				new SqlParameter("e_td_depo_name", Types.VARCHAR), new SqlParameter("e_td_depo_phone", Types.VARCHAR),
				new SqlParameter("e_td_depo_mail", Types.VARCHAR),
				new SqlParameter("e_td_fecha_created", Types.TIMESTAMP), new SqlParameter("e_td_time", Types.INTEGER),
				new SqlParameter("e_td_tp_origen", Types.VARCHAR), new SqlParameter("e_td_nemonico", Types.VARCHAR),
				new SqlParameter("e_td_estado", Types.VARCHAR),
				new SqlOutParameter("s_codigo_retorno", Types.INTEGER) };
		return storedProcedureUtils.callStoredProcedureSybase("cob_cuentas", "pa_cv_itransaccion_dep", inParams,
				sqlParameters);
	}

	public Map<?, ?> guardarTransaccionTarjeta(Transaction trx) {
		HashMap<String, Object> inParams = new HashMap<>();

		Client depositor = trx.getDepositor();
		PayCard payCard = trx.getPayCard();
		Session session = trx.getSession();

		inParams.put("e_tt_cod_trx", trx.getIdTransaction());
		inParams.put("e_tt_ct_key", trx.getCtCode());
		inParams.put("e_tt_uuid", session == null ? null : session.getUuId());
		inParams.put("e_tt_ip", session == null ? null : session.getIp());
		inParams.put("e_tt_card_dni", payCard.getClient().getIdentification());
		inParams.put("e_tt_card_number", payCard.getCardNumber());
		inParams.put("e_tt_card_key", payCard.getCardKey());
		inParams.put("e_tt_card_name", payCard.getClient().getName());
		inParams.put("e_tt_card_type", payCard.getCardType());
		inParams.put("e_tt_card_brand", payCard.getCardBrand());
		inParams.put("e_tt_amount_cash", payCard.getAmountCash());
		inParams.put("e_tt_n_check", payCard.getnCheck());
		inParams.put("e_tt_amount_check_bb", payCard.getAmountCheckBb());
		inParams.put("e_tt_amount_check_ob", payCard.getAmountCheckOb());
		inParams.put("e_tt_amount_check_miami", payCard.getAmountCheckMi());
		inParams.put("e_tt_amount_check_newyork", payCard.getAmountCheckNy());
		inParams.put("e_tt_amount_check_op", payCard.getAmountCheckOp());
		inParams.put("e_tt_total_amount", payCard.getTotalAmount());
		inParams.put("e_tt_min_value", payCard.getMinValue());
		inParams.put("e_tt_cash_value", payCard.getCashValue());
		inParams.put("e_tt_funds_source", payCard.getFundsSource());
		inParams.put("e_tt_funds_destination", payCard.getFundsDestination());
		inParams.put("e_tt_depositor_tp_dni", depositor == null ? null : depositor.getIdentificationType());
		inParams.put("e_tt_depositor_dni", depositor == null ? null : depositor.getIdentification());
		inParams.put("e_tt_depositor_name", depositor == null ? null : depositor.getName());
		inParams.put("e_tt_depositor_phone", depositor == null ? null : depositor.getPhone());
		inParams.put("e_tt_depositor_mail", depositor == null ? null : depositor.getMail());
		inParams.put("e_tt_fecha_created", Helper.dateToGregorianCalendar(trx.getCreateDate()));
		inParams.put("e_tt_time", trx.getMaxTime());
		inParams.put("e_tt_tp_origen", trx.getAccessType());
		inParams.put("e_tt_mnemonic", trx.getTypeCode());
		inParams.put("e_tt_state", trx.getCheck() ? "1" : "0");
		inParams.put("s_codigo_retorno", null);

		SqlParameter sqlParameters[] = { new SqlParameter("e_tt_cod_trx", Types.INTEGER),
				new SqlParameter("e_tt_ct_key", Types.VARCHAR), new SqlParameter("e_tt_uuid", Types.VARCHAR),
				new SqlParameter("e_tt_ip", Types.VARCHAR), new SqlParameter("e_tt_card_dni", Types.VARCHAR),
				new SqlParameter("e_tt_card_number", Types.VARCHAR), new SqlParameter("e_tt_card_key", Types.VARCHAR),
				new SqlParameter("e_tt_card_name", Types.VARCHAR), new SqlParameter("e_tt_card_type", Types.VARCHAR),
				new SqlParameter("e_tt_card_brand", Types.VARCHAR), new SqlParameter("e_tt_amount_cash", Types.DECIMAL),
				new SqlParameter("e_tt_n_check", Types.INTEGER),
				new SqlParameter("e_tt_amount_check_bb", Types.DECIMAL),
				new SqlParameter("e_tt_amount_check_ob", Types.DECIMAL),
				new SqlParameter("e_tt_amount_check_miami", Types.DECIMAL),
				new SqlParameter("e_tt_amount_check_newyork", Types.DECIMAL),
				new SqlParameter("e_tt_amount_check_op", Types.DECIMAL),
				new SqlParameter("e_tt_total_amount", Types.DECIMAL), new SqlParameter("e_tt_min_value", Types.DECIMAL),
				new SqlParameter("e_tt_cash_value", Types.DECIMAL),
				new SqlParameter("e_tt_funds_source", Types.VARCHAR),
				new SqlParameter("e_tt_funds_destination", Types.VARCHAR),
				new SqlParameter("e_tt_depositor_tp_dni", Types.VARCHAR),
				new SqlParameter("e_tt_depositor_dni", Types.VARCHAR),
				new SqlParameter("e_tt_depositor_name", Types.VARCHAR),
				new SqlParameter("e_tt_depositor_phone", Types.VARCHAR),
				new SqlParameter("e_tt_depositor_mail", Types.VARCHAR),
				new SqlParameter("e_tt_fecha_created", Types.TIMESTAMP), new SqlParameter("e_tt_time", Types.INTEGER),
				new SqlParameter("e_tt_tp_origen", Types.VARCHAR), new SqlParameter("e_tt_mnemonic", Types.VARCHAR),
				new SqlParameter("e_tt_state", Types.VARCHAR), new SqlParameter("e_tt_state", Types.VARCHAR),
				new SqlOutParameter("s_codigo_retorno", Types.INTEGER)

		};
		return storedProcedureUtils.callStoredProcedureSybase("cob_cuentas", "pa_cv_itransaccion_pgt", inParams,
				sqlParameters);
	}

	public Map<?, ?> guardarTransaccionServicio(Transaction transaccion) {
		HashMap<String, Object> inParams = new HashMap<>();

		Client depositor = transaccion.getDepositor();
		PayService payService = transaccion.getPayService();
		Session session = transaccion.getSession();
		Company company = payService.getCompany();

		inParams.put("e_ts_cod_trx", transaccion.getIdTransaction());
		inParams.put("e_ts_ct_key", transaccion.getCtCode());
		inParams.put("e_ts_uuid", session.getUuId());
		inParams.put("e_ts_ip", session.getIp());
		inParams.put("e_ts_service_p", company.getIdService());
		inParams.put("e_ts_company_p", company.getIdCompany());
		String tipo = null;
		String tipAreaReg = null;
		if (1 == company.getIdService()) {
			tipo = getCatalog(company.getType()).get("clave");
			tipAreaReg = getCatalog(company.getArea()).get("clave");
			tipAreaReg = tipAreaReg == null ? getCatalog(company.getRegion()).get("clave") : tipAreaReg;
		} else {
			tipAreaReg = getCatalog(company.getType()).get("clave");
			tipAreaReg = tipAreaReg == null ? getCatalog(company.getRegion()).get("clave") : tipAreaReg;
			tipAreaReg = tipAreaReg == null ? getCatalog(company.getArea()).get("clave") : tipAreaReg;
		}
		inParams.put("e_ts_tp", tipo);
		inParams.put("e_ts_ar_tp_reg", tipAreaReg);
		inParams.put("e_ts_service_dni", payService.getClient().getIdentification());
		inParams.put("e_ts_service_code", payService.getServiceCode());
		inParams.put("e_ts_amount_cash", payService.getAmountCash());
		inParams.put("e_ts_n_check", payService.getnCheck());
		inParams.put("e_ts_amount_check", payService.getAmountCheck());
		inParams.put("e_ts_bill", payService.getBill() ? 1 : 0);
		inParams.put("e_ts_amount_commission", payService.getCommission());
		inParams.put("e_ts_total_amount", payService.getTotalAmount());
		inParams.put("e_ts_funds_source", payService.getFundsSource());
		inParams.put("e_ts_funds_destination", payService.getFundsDestination());
		inParams.put("e_ts_depositor_tp_dni", depositor.getIdentificationType());
		inParams.put("e_ts_depositor_dni", depositor.getIdentification());
		inParams.put("e_ts_depositor_name", depositor.getName());
		inParams.put("e_ts_depositor_phone", depositor.getPhone());
		inParams.put("e_ts_depositor_mail", depositor.getMail());
		inParams.put("e_ts_fecha_created", Helper.dateToGregorianCalendar(transaccion.getCreateDate()));
		inParams.put("e_ts_time", transaccion.getMaxTime());
		inParams.put("e_ts_tp_origen", transaccion.getAccessType());
		inParams.put("e_ts_mnemonic", String.valueOf(transaccion.getTypeCode()));
		inParams.put("e_ts_state", transaccion.getCheck() ? "1" : "0");
		inParams.put("s_codigo_retorno", null);

		SqlParameter sqlParameters[] = { new SqlParameter("e_ts_cod_trx", Types.INTEGER),
				new SqlParameter("e_ts_ct_key", Types.VARCHAR), 
				new SqlParameter("e_ts_uuid", Types.VARCHAR),
				new SqlParameter("e_ts_ip", Types.VARCHAR),
				new SqlParameter("e_ts_service_p", Types.INTEGER),
				new SqlParameter("e_ts_company_p", Types.INTEGER), 
				new SqlParameter("e_ts_tp", Types.VARCHAR),
				new SqlParameter("e_ts_ar_tp_reg", Types.VARCHAR), 
				new SqlParameter("e_ts_service_dni", Types.VARCHAR),
				new SqlParameter("e_ts_service_code", Types.VARCHAR),
				new SqlParameter("e_ts_amount_cash", Types.DECIMAL), 
				new SqlParameter("e_ts_n_check", Types.INTEGER),
				new SqlParameter("e_ts_amount_check", Types.DECIMAL), 
				new SqlParameter("e_ts_bill", Types.VARCHAR),
				 new SqlParameter("e_ts_amount_commission", Types.DECIMAL),				
				new SqlParameter("e_ts_total_amount", Types.DECIMAL),
				new SqlParameter("e_ts_funds_source", Types.VARCHAR),
				new SqlParameter("e_ts_funds_destination", Types.VARCHAR),
				new SqlParameter("e_ts_depositor_tp_dni", Types.VARCHAR),
				new SqlParameter("e_ts_depositor_dni", Types.VARCHAR),
				new SqlParameter("e_ts_depositor_name", Types.VARCHAR),
				new SqlParameter("e_ts_depositor_phone", Types.VARCHAR),
				new SqlParameter("e_ts_depositor_mail", Types.VARCHAR),
				new SqlParameter("e_ts_fecha_created", Types.TIMESTAMP), 
				new SqlParameter("e_ts_time", Types.INTEGER),
				new SqlParameter("e_ts_tp_origen", Types.VARCHAR), 
				new SqlParameter("e_ts_mnemonic", Types.VARCHAR),
				new SqlParameter("e_ts_state", Types.VARCHAR), 
				new SqlOutParameter("s_codigo_retorno", Types.INTEGER) };
		return storedProcedureUtils.callStoredProcedureSybase("cob_cuentas", "pa_cv_itransaccion_psb", inParams,
				sqlParameters);
	}

	public Map<?, ?> consultarDatosTarjeta(String numTarjeta, Integer cuenta) {
		HashMap<String, Object> inParams = new HashMap<>();

		inParams.put("e_nutarj", numTarjeta);
		inParams.put("e_cnta", cuenta);

		SqlParameter sqlParameters[] = { new SqlParameter("e_nutarj", Types.VARCHAR),
				new SqlParameter("e_cnta", Types.INTEGER) };
		return storedProcedureUtils.callStoredProcedureSybase("cob_cuentas", "pa_cv_ctarjeta_credito", inParams,
				sqlParameters);
	}

	private Map<String, String> getCatalog(List<Catalog> cat) {
		Map<String, String> ret = new HashMap<>();
		if (cat != null && cat.size() > 0) {
			ret.put("clave", cat.get(0).getKey());
		}
		return ret;
	}

	public Map<String, Object> grabaSaldoPrestamo(PrestamoSaldo ps) {
    //amejiaf CF-AP-SGC00044179-SGC00044608
		HashMap<String, Object> inParams = new HashMap<>();
		logger2.info("rrhh ingresa grabaSaldoPrestamo");			
		
		inParams.put("e_cedula", ps.getCedula());
		inParams.put("e_op_banco", ps.getOpbanco());
		inParams.put("e_monto", BigDecimal.valueOf(Double.valueOf(ps.getMonto())));		
		inParams.put("e_saldo", BigDecimal.valueOf(Double.valueOf(ps.getSaldo())));
		inParams.put("e_fecha_ini", ps.getFechaini());
		inParams.put("e_fecha_fin", ps.getFechafin());
		inParams.put("o_msgerr", ps.getmsgerror());
		
		SqlParameter[] sqlParameters = { new SqlParameter("e_cedula", Types.VARCHAR),
				new SqlParameter("e_op_banco", Types.VARCHAR),
				new SqlParameter("e_monto", Types.DECIMAL),
				new SqlParameter("e_saldo", Types.DECIMAL),
				new SqlParameter("e_fecha_ini", Types.DATE),
				new SqlParameter("e_fecha_fin", Types.DATE),
				new SqlOutParameter("o_msgerr", Types.VARCHAR)
				};
		return storedProcedureUtils.callStoredProcedureSqlRH("db_rrhh_bb", "pa_rhh_isaldo_prestamo", inParams,
				sqlParameters);
	}
}
