package com.bolivariano.microservice.comprobantecvms.beantrn;

import java.io.Serializable;
import java.math.BigDecimal;

import com.bolivariano.microservice.comprobantecvms.utils.ComprobanteUtils;

public class PayCard implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1948989373875586143L;

	private String cardNumber;
	private String cardKey;
	private String cardType;
	private String cardBrand;
	private BigDecimal amountCash;
	private Integer nCheck;
	private BigDecimal amountCheckBb;
	private BigDecimal amountCheckOb;
	private BigDecimal amountTotalCheckEx;
	private BigDecimal amountCheckMi;
	private BigDecimal amountCheckNy;
	private BigDecimal amountCheckOp;
	private BigDecimal totalAmount;	
	private String fundsSource;
	private String fundsDestination;
	
	private BigDecimal minValue;
	private BigDecimal cashValue;
	private String cardNumberMaskZero;
	
	public String getFundsSource() {
		return fundsSource;
	}
	public void setFundsSource(String fundsSource) {
		this.fundsSource = fundsSource;
	}
	public String getFundsDestination() {
		return fundsDestination;
	}
	public void setFundsDestination(String fundsDestination) {
		this.fundsDestination = fundsDestination;
	}
	private Client client;
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getCardKey() {
		return cardKey;
	}
	public void setCardKey(String cardKey) {
		this.cardKey = cardKey;
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public String getCardBrand() {
		return cardBrand;
	}
	public void setCardBrand(String cardBrand) {
		this.cardBrand = cardBrand;
	}
	public BigDecimal getAmountCash() {
		return amountCash;
	}
	public void setAmountCash(BigDecimal amountCash) {
		this.amountCash = ComprobanteUtils.getRoundVal(amountCash);
	}
	public Integer getnCheck() {
		return nCheck;
	}
	public void setnCheck(Integer nCheck) {
		this.nCheck = nCheck;
	}
	public BigDecimal getAmountCheckBb() {
		return amountCheckBb;
	}
	public void setAmountCheckBb(BigDecimal amountCheckBb) {
		this.amountCheckBb = ComprobanteUtils.getRoundVal(amountCheckBb);
	}
	public BigDecimal getAmountCheckOb() {
		return amountCheckOb;
	}
	public void setAmountCheckOb(BigDecimal amountCheckOb) {
		this.amountCheckOb = ComprobanteUtils.getRoundVal(amountCheckOb);
	}
	public BigDecimal getAmountTotalCheckEx() {
		return amountTotalCheckEx;
	}
	public void setAmountTotalCheckEx(BigDecimal amountTotalCheckEx) {
		this.amountTotalCheckEx = ComprobanteUtils.getRoundVal(amountTotalCheckEx);
	}
	public BigDecimal getAmountCheckMi() {
		return amountCheckMi;
	}
	public void setAmountCheckMi(BigDecimal amountCheckMi) {
		this.amountCheckMi = ComprobanteUtils.getRoundVal(amountCheckMi);
	}
	public BigDecimal getAmountCheckNy() {
		return amountCheckNy;
	}
	public void setAmountCheckNy(BigDecimal amountCheckNy) {
		this.amountCheckNy = ComprobanteUtils.getRoundVal(amountCheckNy);
	}
	public BigDecimal getAmountCheckOp() {
		return amountCheckOp;
	}
	public void setAmountCheckOp(BigDecimal amountCheckOp) {
		this.amountCheckOp = ComprobanteUtils.getRoundVal(amountCheckOp);
	}
	public BigDecimal getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = ComprobanteUtils.getRoundVal(totalAmount);
	}
	public Client getClient() {
		return client;
	}
	public void setClient(Client client) {
		this.client = client;
	}
	public BigDecimal getMinValue() {
		return minValue;
	}
	public void setMinValue(BigDecimal minValue) {
		this.minValue = ComprobanteUtils.getRoundVal(minValue);
	}
	public BigDecimal getCashValue() {
		return cashValue;
	}
	public void setCashValue(BigDecimal cashValue) {
		this.cashValue = ComprobanteUtils.getRoundVal(cashValue);
	}
	public String getCardNumberMaskZero() {
		return cardNumberMaskZero;
	}
	public void setCardNumberMaskZero(String cardNumberMaskZero) {
		this.cardNumberMaskZero = cardNumberMaskZero;
	}
	
	
}
