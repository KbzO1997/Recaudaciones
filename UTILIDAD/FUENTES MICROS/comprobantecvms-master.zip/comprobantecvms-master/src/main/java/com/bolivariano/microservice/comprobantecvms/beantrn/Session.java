package com.bolivariano.microservice.comprobantecvms.beantrn;

import java.io.Serializable;

public class Session extends Device implements Serializable {

	private static final long serialVersionUID = 2L;

	private Integer sessionId;
	private Integer ipAgency;
	private String ip;

	public Integer getSessionId() {
		return sessionId;
	}

	public void setSessionId(Integer sessionId) {
		this.sessionId = sessionId;
	}

	public Integer getIpAgency() {
		return ipAgency;
	}

	public void setIpAgency(Integer ipAgency) {
		this.ipAgency = ipAgency;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

//	@Override
//	public String toString() {
//		String response = "";
//		response = "Respuesta Sesion [sessionID=" + this.sessionID + ", sessionIPAgency=" + this.sessionIPAgency
//				+ ", setTimeLive=" + this.setTimeLive + ", setCanTransactions=" + this.setCanTransactions
//				+ ", setLegalInformation=" + this.setLegalInformation + ", setMaxAmmount=" + this.setMaxAmmount + "]\n";
//		return response;
//	}

}
