package com.bolivariano.microservice.comprobantecvms.beantrn;

import java.io.Serializable;

public class Service  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -734363527567655759L;
	private Integer idService;
	private String nameService;	

	
	public Integer getIdService() {
		return idService;
	}
	public void setIdService(Integer idService) {
		this.idService = idService;
	}
	public String getNameService() {
		return nameService;
	}
	public void setNameService(String nameService) {
		this.nameService = nameService;
	}
	
	

}
