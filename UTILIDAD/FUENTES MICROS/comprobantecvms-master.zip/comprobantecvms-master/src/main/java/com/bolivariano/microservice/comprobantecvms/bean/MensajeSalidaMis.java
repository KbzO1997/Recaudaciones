package com.bolivariano.microservice.comprobantecvms.bean;


public class MensajeSalidaMis {
	
	private String codigo_mis;
	private String mensaje_ejecucion;
	private String mensaje_error;
	private String codigo_respuesta;
	
	
   public String getCodigo_mis() {
	        return codigo_mis;
	}

   public void setCodigo_mis(String value) {
	     this.codigo_mis = value;
	}
	
   public String getMensaje_ejecucion() {
        return mensaje_ejecucion;
   }

   public void setMensaje_ejecucion(String value) {
     this.mensaje_ejecucion = value;
    }
   
  public String getMensaje_error() {
       return mensaje_error;
  }

  public void setMensaje_error(String value) {
    this.mensaje_error = value;
   }
  
  public String getCodigo_respuesta() {
      return codigo_respuesta;
 }

 public void setCodigo_respuesta(String value) {
   this.codigo_respuesta = value;
  }

}
