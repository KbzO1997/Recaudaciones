package com.bolivariano.microservice.comprobantecvms.business;

import java.io.StringReader;
import java.util.UUID;

import javax.jms.JMSException;
import javax.jms.TextMessage;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.bolivariano.microservice.comprobantecvms.bean.MensajeRptaCola;
import com.bolivariano.microservice.comprobantecvms.helper.MQUtil;
import com.bolivariano.microservice.comprobantecvms.service.NotificacionesService;
import com.ibm.mq.constants.MQConstants;
import com.ibm.mq.MQMessage;
import com.bolivariano.microservice.comprobantecvms.bean.MensajeSalidaMis;

@Service
public class mainNotificaciones {
	private static final Logger logger = LoggerFactory.getLogger(mainCajaVerde.class);
	
	@Value("${comprobanteCV.mq.outcoming-queue}")
	String destinationQueue;
	
	@Value("${comprobanteCV.mq.outcoming-queue1}")
	String destinationQueue1;
	
	@Value("${comprobanteCV.mq.incoming-queue}")
	String incomingQueue;
	
	@Value("${comprobanteCV.mq.queue-manager}")
    private String queue_Manager;
	@Value("${comprobanteCV.mq.incoming-queue}")
	private String inQueue;
	@Value("${comprobanteCV.mq.outcoming-queue}")
	private String outQueue;
	@Value("${comprobanteCV.mq.outcoming-queue1}")
	private String outQueue1;
	@Value("${comprobanteCV.mq.host}")
	private String hostname;
	@Value("${comprobanteCV.mq.port}")
	private int port_number;
	@Value("${comprobanteCV.mq.channel}")
	private String channel;
	//LLANCHIP
	@Autowired
	NotificacionesService misService;
		
	 public void execute(TextMessage message)
	    {
		 logger.info("Tipo de Transaccion Notificaciones MIS/VREFEREN");
	    	String mensaje = "", response = "";
	    	String idTrx = "";
	    	
	    	try
	    	{   	    		
	    		mensaje = message.getText();
	    		logger.info("Mensaje: "+mensaje);
	    		
	    		MQMessage mqmessage = new MQMessage();
	    		UUID idUUID = UUID.randomUUID();
				idTrx = "("+idUUID.toString().replace("-", "")+")";
				
	    		Document doc = convertStringToDocument(mensaje);	

				MensajeSalidaMis MsjSalidaMis = new MensajeSalidaMis();				
				MsjSalidaMis = misService.ParametrosMIS(doc);
	    		
				MensajeRptaCola responseToqueue = (MensajeRptaCola)getMsgQueueFromDocument(doc);    		
	    		{
	    			responseToqueue.setCodRpta(MsjSalidaMis.getCodigo_respuesta());
	    			responseToqueue.setMensajeRpta(MsjSalidaMis.getMensaje_ejecucion());
	    			
	    			response = misService.respuestaColaMis(responseToqueue, MsjSalidaMis);
	    			
	    			mqmessage.correlationId = message.getJMSMessageID().getBytes();
	        		mqmessage.messageType=MQConstants.MQMT_DATAGRAM;
	    			mqmessage.format=MQConstants.MQFMT_STRING;
	    				    			
	    			mqmessage.writeString(response);
					logger.info(idTrx + "<<***RESPONSE:" + mqmessage);
					logger.info(idTrx + "<<***RESPONSE:" + response);
	    			
	    			MQUtil sender = new MQUtil(hostname,channel,port_number,queue_Manager,outQueue);
	    			sender.sendMessage(mqmessage);
	    		}
	    	}
	    		
	    	catch (JMSException e) {
	        	logger.error("JMSException error in class mainNotificaciones.java. Detail: ", message, e.getMessage());
	        }
	    	catch (Exception ex) {
	    		logger.error("Error Method: execute in class mainNotificaciones.java. Detail: " + ExceptionUtils.getStackTrace(ex));
	        }
	    	
	    }
		
	 private Document convertStringToDocument(String xmlStr) 
	    {
	        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();  
	        DocumentBuilder builder;  
	        try  
	        {  
	            builder = factory.newDocumentBuilder();  
	            Document doc = builder.parse( new InputSource(new StringReader(xmlStr))); 
	            return doc;
	        } catch (Exception e) {  
	            e.printStackTrace();  
	        } 
	        return null;
	    }
	 
	public String respuestaColaMis(MensajeRptaCola queue_data, MensajeSalidaMis datosMis)
	{
		String xmlColaSalida;
		xmlColaSalida = "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?><CTSMessage>" + 
				"<CTSHeader>" + 
				"<Field name=\"kernelHeader\" type=\"S\">" + queue_data.getKernelHeader() + "</Field>" + 
				"<Field name=\"fromServer\" type=\"S\">" + queue_data.getFromServer() + "</Field>" + 
				"<Field name=\"srv\" type=\"S\">" + queue_data.getSrv() + "</Field>" + 
				"<Field name=\"sesn\" type=\"N\">" + queue_data.getSesn() + "</Field>" + 
				"<Field name=\"transaccion\" type=\"N\">" + queue_data.getTransaccion() + "</Field>" + 
				"<Field name=\"usuario\" type=\"N\">" + queue_data.getUsuario() + "</Field>" + 
				"<Field name=\"secuencial\" type=\"N\">" + queue_data.getSecuencial() + "</Field>" + 
				"<Field name=\"terminal\" type=\"N\">" + queue_data.getTerminal() + "</Field>" + 
				"</CTSHeader>" + 
				"<Data>" + 
				"<ProcedureResponse>" ;//+ 

		if (queue_data.getCodRpta().equals("0")) {
			xmlColaSalida = xmlColaSalida + "<ResultSet>" +
					"<Header>" +
					"<col name=\"ClaseMedio\" type=\"39\" len=\"20\" />" +
					"<col name=\"TipoMedio\" type=\"39\" len=\"20\" />" +
					"<col name=\"ValorMedio\" type=\"39\" len=\"20\" />" +
					"</Header>";

			xmlColaSalida = xmlColaSalida + "</ResultSet>";
			xmlColaSalida = xmlColaSalida + "<return>" + queue_data.getCodRpta() + "</return>" ;
		}
		else
		{
			xmlColaSalida = xmlColaSalida + "<Message msgNo=\"0\" type=\"3\">" + queue_data.getMensajeRpta() + "</Message>";
			xmlColaSalida = xmlColaSalida + "<return>" +  datosMis.getMensaje_error() + "</return>" ;
		}

		xmlColaSalida = xmlColaSalida +  "</ProcedureResponse></Data></CTSMessage>"; 
		return xmlColaSalida;
	}

	private MensajeRptaCola getMsgQueueFromDocument(Document doc)
    {
    	MensajeRptaCola rpt = new MensajeRptaCola();
    	
    	NodeList fields = doc.getFirstChild().getFirstChild().getChildNodes();//Fields
        NodeList params = doc.getFirstChild().getLastChild().getFirstChild().getChildNodes();//Params
           
        for (int i = 0; i < fields.getLength(); i++)//iterando sobre Fields
        {
        	String node = fields.item(i).getFirstChild().getTextContent();
        	String node_name_attribute = fields.item(i).getAttributes().getNamedItem("name").getTextContent();
        	
        	if(node_name_attribute.equals("kernelHeader") ||
        			node_name_attribute.equals("fromServer") ||
        			node_name_attribute.equals("srv") ||
        			node_name_attribute.equals("sesn"))
        	{
        		if(node_name_attribute.equals("kernelHeader"))
            	{
            		rpt.setKernelHeader(node);
            		continue;
            	}
            	else if(node_name_attribute.equals("fromServer"))
            	{
            		rpt.setFromServer(node);
            		continue;
            	}
            	else if(node_name_attribute.equals("srv"))
            	{
            		rpt.setSrv(node);
            		continue;
            	}
            	else if(node_name_attribute.equals("sesn"))
            	{
            		rpt.setSesn(node);
            		continue;
            	}
        	}
        	else
        		continue;
		}   
        for (int i = 1; i < params.getLength(); i++)//iterando sobre Params
        {
        	String node = params.item(i).getFirstChild().getTextContent();
        	String node_name_attribute = params.item(i).getAttributes().getNamedItem("name").getTextContent();
        	
        	if(node_name_attribute.equals("@t_trn") ||
        			node_name_attribute.equals("@s_user") ||
        			node_name_attribute.equals("@s_ssn") ||
        			node_name_attribute.equals("@s_term"))
        	{
        		if(node_name_attribute.equals("@t_trn"))
            	{
            		rpt.setTransaccion(node);
            		continue;
            	}
            	else if(node_name_attribute.equals("@s_user"))
            	{
            		rpt.setUsuario(node);
            		continue;
            	}
            	else if(node_name_attribute.equals("@s_ssn"))
            	{
            		rpt.setSecuencial(node);
            		continue;
            	}
            	else if(node_name_attribute.equals("@s_term"))
            	{
            		rpt.setTerminal(node);
            		continue;
            	}
        	}
        	else
        		continue;
		}
        return rpt;
    }
	
	
}

