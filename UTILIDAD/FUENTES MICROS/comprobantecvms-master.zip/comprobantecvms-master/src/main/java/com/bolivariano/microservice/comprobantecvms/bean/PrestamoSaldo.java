package com.bolivariano.microservice.comprobantecvms.bean;

public class PrestamoSaldo {
	
	String cedula;
	String opbanco;
	String monto;
	String saldo;
    String fechaini;
    String fechafin;
    String msgerror;
    
    //Métodos GET
	//**************************************

    public String getCedula() {
    	return cedula;
	}
	
	public String getOpbanco() {
		return opbanco;
	}
	
	public String getMonto() {
	    return monto;
	}
	
	public String getSaldo() {
	    return saldo;
	}
	
	public String getFechaini() {
	    return fechaini;
	}
	
	public String getFechafin() {
	    return fechafin;
	}
	
	public String getmsgerror() {
	    return msgerror;
	}
	
    //**************************************	
	//Métodos SET
	//**************************************
	
	public void setCedula(String value) {
	     this.cedula = value;
	}
	
	public void setOpbanco(String value) {
	     this.opbanco = value;
	}	  
	
	public void setMonto(String value) {
	     this.monto = value;
	}
	
	public void setSaldo(String value) {
	     this.saldo = value;
	}
	
	public void setFechaini(String value) {
	     this.fechaini = value;
	}
	
	public void setFechafin(String value) {
	     this.fechafin = value;
	}
	
	public void setMsgerror(String value) {
	     this.msgerror= value;
	}

}