package com.bolivariano.microservice.comprobantecvms.utils;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.Hashtable;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import com.bolivariano.microservice.comprobantecvms.bean.Comprobante;
import com.bolivariano.microservice.comprobantecvms.helper.Helper;
import com.bolivariano.microservice.comprobantecvms.service.ComprobanteService;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.itextpdf.html2pdf.ConverterProperties;
import com.itextpdf.html2pdf.HtmlConverter;

@Repository
public class ComprobanteUtils implements IComprobanteUtils {

	private static final Logger logger = LoggerFactory.getLogger(ComprobanteService.class);
	
	@Value("${comprobante.folder}")
	private String COMPROBANTE_FOLDER;
	
	@Value("${comprobante.pngQr}")
	private String QR_CODE_IMAGE_NAME;
	@Value("${comprobante.pngLogo}")
	private String LOGO_BB_PATH;	
	@Value("${comprobante.htmlStruct}")
	private String HTML_STRUCT_PATH;
	@Value("${comprobante.pdfFile}")
	private String PDF_FILE_PATH;
	@Value("${comprobante.textohtml}") //12-10-2021 - Se realizó la configuración del valor desde application.yml
	private String HTML_FILE_PATH;
	//private final String HTML_FILE_PATH ="TextToHTML.html";
	//private final String QR_CODE_IMAGE_NAME = "QRcode.png";
	//private final String LOGO_BB_PATH = "logo_bb.png";
	//private final String HTML_FILE_PATH = "comprobante/TextToHTML.html";
	//private final String HTML_STRUCT_PATH = "comprobante/comprobante.html";
	//private final String PDF_FILE_PATH = "comprobante/CompFile.pdf";

	@Override
	public void registrarComprobante(Comprobante c) {
		try {
			// generar comprobante
			generarComprobante(c);

			try {
				// exportar .pdf el comprobante
				exportPDFFile();
			} catch (FileNotFoundException e) {
				logger.error("Could not export PDF File - FileNotFoundException", e.getMessage());
			}
		} catch (Exception e) {
			logger.error("Could not export PDF File - Exception", e.getMessage());
		}
	}

	private void generarComprobante(Comprobante comp) {
		try {
			// String data = generateData(comp);
			// generateQRCodeImage(data, 100, 100, QR_CODE_IMAGE_NAME);

			File qrFile = new File(COMPROBANTE_FOLDER + QR_CODE_IMAGE_NAME);

			try {
				generateQR(qrFile, comp.getCodCt(), 125, "png");
			} catch (WriterException e) {
				logger.error("Could not generate QR Code, WriterException :", e.getMessage());
			}

			try {
				generateFile(comp);
			} catch (IOException e) {
				logger.error("Could not generate File, IOException : ", e.getMessage());
			}
		} catch (Exception e) {
			logger.error("Ocurrrio un error de Exception :", e.getMessage());
		}
	}

	private String generateData(Comprobante comp) {
		String result = "";

		result += comp.getBenfNameAccount() + "-" + comp.getBenfNumberAccount() + "-" + comp.getBenfTypeAccount() + "-"

				+ comp.getUniqueTransCode() + "-"// +comp.getUNIQUETRANSCODE()+"-"
				+ comp.getCurrency() + "-" + comp.getDateTrans() + "-" + comp.getIpAgency() + "-"// +comp.getIPAgency()+"-"
				+ comp.getOfficeCode() + "-" + comp.getOfficeHours() + "-" + comp.getOfficeUser() + "-" + comp.getSec()
				+ "-"// +comp.getSEC()+"-"
				+ comp.getTransCode() + "-"// +comp.getTRANSCODE()+"-"
				+ comp.getTransDescripction() + "-"// +comp.getTRANSDESCRIPTION()+"-"
				+ comp.getEfectivo() + "-" + comp.getEfeCheque() + "-" + comp.getCantcheques() + "-" + comp.getTotal();
		return result;
	}

	private void generateQR(File qrFile, String qrCodeText, int size, String fileType)
			throws WriterException, IOException {
		// Create the ByteMatrix for the QR-Code that encodes the given String
		Hashtable<EncodeHintType, ErrorCorrectionLevel> hintMap = new Hashtable<>();
		hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);

		QRCodeWriter qrCodeWriter = new QRCodeWriter();
		BitMatrix byteMatrix = qrCodeWriter.encode(qrCodeText, BarcodeFormat.QR_CODE, size, size, hintMap);
		// Make the BufferedImage that are to hold the QRCode
		int matrixWidth = byteMatrix.getWidth();
		BufferedImage image = new BufferedImage(matrixWidth, matrixWidth, BufferedImage.TYPE_INT_RGB);
		image.createGraphics();

		Graphics2D graphics = (Graphics2D) image.getGraphics();
		graphics.setColor(Color.WHITE);
		graphics.fillRect(0, 0, matrixWidth, matrixWidth);
		// Paint and save the image using the ByteMatrix
		graphics.setColor(new Color(146, 199, 64));// Color.BLUE

		for (int i = 0; i < matrixWidth; i++) {
			for (int j = 0; j < matrixWidth; j++) {
				if (byteMatrix.get(i, j)) {
					graphics.fillRect(i, j, 1, 1);
				}
			}
		}
		ImageIO.write(image, fileType, qrFile);
	}

	private void generateFile(Comprobante comp) throws IOException {
		OutputStreamWriter out = null;
		try {
			String office_User = Helper.replaceSpecialCharacter(comp.getOfficeUser());
			String benf_Name_Account = Helper.replaceSpecialCharacter(comp.getBenfNameAccount());
			String currency = Helper.replaceSpecialCharacter(comp.getCurrency());
			byte[] fileContent = FileUtils.readFileToByteArray(new File(COMPROBANTE_FOLDER + LOGO_BB_PATH));
			String img1 = Base64.getEncoder().encodeToString(fileContent);

			byte[] fileContent1 = FileUtils.readFileToByteArray(new File(COMPROBANTE_FOLDER + QR_CODE_IMAGE_NAME));
			String img2 = Base64.getEncoder().encodeToString(fileContent1);

			String htmlStruct = new String(Files.readAllBytes(Paths.get(COMPROBANTE_FOLDER+HTML_STRUCT_PATH)), StandardCharsets.UTF_8);
			htmlStruct = StringUtils.replace(htmlStruct, "${img1}", img1);
			htmlStruct = StringUtils.replace(htmlStruct, "${img2}", img2);

			htmlStruct = StringUtils.replace(htmlStruct, "${nombreBeneficiario}", benf_Name_Account);
			String account = comp.getBenfNumberAccount();
			account = comp.isDeposit() ? account + " - " + comp.getBenfTypeAccount()
					: comp.isPayCard() ? comp.getBenfTypeAccount() + " - " + account
							: "Pago de " + comp.getTransDescripction();
			htmlStruct = StringUtils.replace(htmlStruct, "${numeroCuenta}", account);
			htmlStruct = StringUtils.replace(htmlStruct, "${fechaTransaccion}", comp.getDateTrans());

			// Servicio Empresa --> (361 Interagua - 897688)
			String nombreEmpresa = comp.getCompanyId() + " " + comp.getCompanyName();
			htmlStruct = StringUtils.replace(htmlStruct, "${displayNombreEmpresa}",
					comp.isPayService() ? "visible" : "none");
			htmlStruct = StringUtils.replace(htmlStruct, "${nombreEmpresa}", nombreEmpresa);
			htmlStruct = StringUtils.replace(htmlStruct, "${direccion}", comp.getDirection());
			htmlStruct = StringUtils.replace(htmlStruct, "${displayDireccion}",
					comp.isPayService() && this.valString(comp.getDirection()) != null ? "visible" : "none");
			htmlStruct = StringUtils.replace(htmlStruct, "${rucEmpresa}", comp.getRucCompanyVal());
			htmlStruct = StringUtils.replace(htmlStruct, "${displayRucEmpresa}",
					comp.isPayService() && this.valString(comp.getRucCompanyVal()) != null ? "visible" : "none");

			// Servicio (Categoría)
			htmlStruct = StringUtils.replace(htmlStruct, "${categoria}", comp.getCategory());
			htmlStruct = StringUtils.replace(htmlStruct, "${idCategoria}", comp.getCategoryId());
			htmlStruct = StringUtils.replace(htmlStruct, "${displayCategoria}",
					comp.isPayService() && valString(comp.getCategory()) != null ? "visible" : "none");

			// Servicio (Tipo)
			htmlStruct = StringUtils.replace(htmlStruct, "${tipoServicio}", comp.getTypeService());
			htmlStruct = StringUtils.replace(htmlStruct, "${displayTipoServicio}",
					comp.isPayService() && valString(comp.getTypeService()) != null ? "visible" : "none");

			// Servicio (Mes impago)
			htmlStruct = StringUtils.replace(htmlStruct, "${mesImpago}", comp.getUnpaidMonth());
			htmlStruct = StringUtils.replace(htmlStruct, "${displayMesImpago}",
					comp.isPayService() && valString(comp.getUnpaidMonth()) != null ? "visible" : "none");
						
			// Servicio y tarjeta
			htmlStruct = StringUtils.replace(htmlStruct, "${fechaProceso}", comp.getClosingDate());
			htmlStruct = StringUtils.replace(htmlStruct, "${displayFechaProceso}",
					!comp.isDeposit() ? "visible" : "none");

			boolean currencyShow = !StringUtils.isNumeric(currency);
			String montoValor = currencyShow ? currency+" " + comp.getAmountVal():comp.getAmountVal();
			
			// Servicio
			htmlStruct = StringUtils.replace(htmlStruct, "${montoValor}", montoValor);
			htmlStruct = StringUtils.replace(htmlStruct, "${displayMontoValor}",
					comp.isPayService() && valString(comp.getAmountVal())!=null ? "visible" : "none");
			
			String montoefe = comp.getEfectivo();
			String chmi = comp.getAmountCheckMi();
			String chny = comp.getAmountCheckNy();
			String chob = comp.getAmountCheckOb();
			String chop = comp.getAmountCheckOp();
			
			BigDecimal montoEfectivo = new BigDecimal(0);
			BigDecimal chqMiami = new BigDecimal(0);
			BigDecimal chqNy = new BigDecimal(0);
			BigDecimal chqOb = new BigDecimal(0);
			BigDecimal chqOp = new BigDecimal(0);
			try {//14/10/2021 - Se corrigió la conversión de String a BigDecimal con formato miles
				//montoEfectivo = new BigDecimal(comp.getEfectivo());
				montoEfectivo = new BigDecimal(montoefe.replaceAll(",", ""));
				montoEfectivo.setScale(2, RoundingMode.HALF_UP);
			} catch (Exception e) {
				logger.error("Error al convertir " + comp.getEfectivo() + " a Decimal");
			}
			if(comp.isPayCard()) {
			try {
				//14/10/2021 - Se corrigió la conversión de String a BigDecimal con formato miles
				//chqMiami = new BigDecimal(comp.getAmountCheckMi());
				chqMiami = new BigDecimal(chmi.replaceAll(",", ""));
			} catch (Exception e) {
				logger.error("Error al convertir " + comp.getAmountCheckMi() + " a Decimal");
			}
			try {
				//14/10/2021 - Se corrigió la conversión de String a BigDecimal con formato miles
				//chqNy = new BigDecimal(comp.getAmountCheckNy());
				chqNy = new BigDecimal(chny.replaceAll(",", ""));
			} catch (Exception e) {
				logger.error("Error al convertir " + comp.getAmountCheckNy() + " a Decimal");
			}
			try {
				//14/10/2021 - Se corrigió la conversión de String a BigDecimal con formato miles
				//chqOb = new BigDecimal(comp.getAmountCheckOb());
				chqOb = new BigDecimal(chob.replaceAll(",", ""));
			} catch (Exception e) {
				logger.error("Error al convertir " + comp.getAmountCheckOb() + " a Decimal");
			}
			try {
				//14/10/2021 - Se corrigió la conversión de String a BigDecimal con formato miles
				//chqOp = new BigDecimal(comp.getAmountCheckOp());
				chqOp = new BigDecimal(chop.replaceAll(",", ""));
			} catch (Exception e) {
				logger.error("Error al convertir " + comp.getAmountCheckOp() + " a Decimal");
			}
			}
			
			
			
			
			String montoEfectivoStr = !comp.isDeposit() && currencyShow ? currency+" " + montoEfectivo: ""+montoEfectivo;
			boolean muestraMontoEfectivo = comp.isPayCard() ? !montoEfectivo.equals(BigDecimal.ZERO) ? true : false : true;
			htmlStruct = StringUtils.replace(htmlStruct, "${montoEfectivo}", montoEfectivoStr);
			htmlStruct = StringUtils.replace(htmlStruct, "${displayMontoEfectivo}",
					muestraMontoEfectivo ? "visible" : "none");

			Integer nCheque = valString(comp.getCantcheques()) != null
					? StringUtils.isNumeric(comp.getCantcheques()) ? Integer.valueOf(comp.getCantcheques()) : 0
					: 0;
			
			htmlStruct = StringUtils.replace(htmlStruct, "${montoDebito}", comp.getAmountDebit());
			htmlStruct = StringUtils.replace(htmlStruct, "${displayMontoDebito}",
					comp.isPayCard() && nCheque==0  ? "visible" : "none");

			
			htmlStruct = StringUtils.replace(htmlStruct, "${nCheque}", comp.getCantcheques());
			htmlStruct = StringUtils.replace(htmlStruct, "${displayNCheque}",
					comp.isPayCard() ? nCheque > 0 ? "visible" : "none" : "visible");

			// MONTO CHEQUE SÓLO SI ES DIFERENTE DE PAGO DE TARJETA
			String efeChequeStr = comp.isPayService() && currencyShow?currency+" " +comp.getEfeCheque():comp.getEfeCheque();
			htmlStruct = StringUtils.replace(htmlStruct, "${montoCheque}", efeChequeStr);
			htmlStruct = StringUtils.replace(htmlStruct, "${displayMontoCheque}",
					!comp.isPayCard() ? "visible" : "none");

			boolean muestraChequesTC = comp.isPayCard() && (chqOb.compareTo(BigDecimal.ZERO)!=0);
			htmlStruct = StringUtils.replace(htmlStruct, "${montoChequeLocal}",currency+" " + chqOb);
			htmlStruct = StringUtils.replace(htmlStruct, "${displayMontoChequeLocal}",
					muestraChequesTC ? "visible" : "none");
			logger.info("Cheque lOcal"+chqOb);

			boolean muestraChequeOp = comp.isPayCard() && (chqMiami.compareTo(BigDecimal.ZERO)!=0
					|| chqNy.compareTo(BigDecimal.ZERO) !=0 || chqOp.compareTo(BigDecimal.ZERO)!=0);
			htmlStruct = StringUtils.replace(htmlStruct, "${montoChequeMiami}", currency+" " +chqMiami);
			htmlStruct = StringUtils.replace(htmlStruct, "${displayMontoChequeMi}",
					muestraChequeOp ? "visible" : "none");
			htmlStruct = StringUtils.replace(htmlStruct, "${montoChequeNewyork}", currency+" " +chqNy);
			htmlStruct = StringUtils.replace(htmlStruct, "${displayMontoChequeNew}",
					muestraChequeOp ? "visible" : "none");
			htmlStruct = StringUtils.replace(htmlStruct, "${montoChequeOp}", currency+" " +chqOp);
			htmlStruct = StringUtils.replace(htmlStruct, "${displayMontoChequeOp}",
					muestraChequeOp ? "visible" : "none");

			String total = !comp.isDeposit()  && currencyShow? currency+" " + comp.getTotal() : comp.getTotal();
			htmlStruct = StringUtils.replace(htmlStruct, "${montoTotal}", total);
			htmlStruct = StringUtils.replace(htmlStruct, "${moneda}", currency);
			htmlStruct = StringUtils.replace(htmlStruct, "${displayMoneda}", comp.isDeposit() ? "visible" : "none");

			htmlStruct = StringUtils.replace(htmlStruct, "${saldoALaFecha}", comp.getAmountToDate());
			htmlStruct = StringUtils.replace(htmlStruct, "${displaySaldoALaFecha}",
					comp.isPayService() && valString(comp.getAmountToDate())!=null ? "visible" : "none");
			htmlStruct = StringUtils.replace(htmlStruct, "${comision}", currency+" " +comp.getCommission());
			htmlStruct = StringUtils.replace(htmlStruct, "${displayComision}",
					comp.isPayService() && this.valString(comp.getCommission())!=null ? "visible" : "none");

			String codigoUnico = comp.isDeposit() ? comp.getUniqueTransCode() :comp.isPayService() ?comp.getBenfNumberAccount():comp.getCodeRec();
			String nemo = comp.isPayCard() ? "Compr.: " : "";
			if(comp.getCodeRec()==null){
				codigoUnico = nemo+" "+codigoUnico;			
				codigoUnico = comp.isPayService() ? codigoUnico +"" : codigoUnico;
			}else {
				codigoUnico = nemo+" "+codigoUnico;			
				codigoUnico = comp.isPayService() ? codigoUnico +comp.getCodeRec() : codigoUnico;
			}
			
			htmlStruct = StringUtils.replace(htmlStruct, "${codigoUnicoTransaccion}", codigoUnico);
			htmlStruct = StringUtils.replace(htmlStruct, "${agenciaIp}", comp.getIpAgency());
			htmlStruct = StringUtils.replace(htmlStruct, "${usuario}", office_User);
			htmlStruct = StringUtils.replace(htmlStruct, "${secuencial}", comp.getSec());
			htmlStruct = StringUtils.replace(htmlStruct, "${codigoTransaccion}", comp.getTransCode());
			htmlStruct = StringUtils.replace(htmlStruct, "${descripcion}", comp.getTransDescripction());
			htmlStruct = StringUtils.replace(htmlStruct, "${horarioOficina}", comp.getOfficeHours());

			htmlStruct = StringUtils.replace(htmlStruct, "${claveAcceso}", comp.getAccesKey());
			htmlStruct = StringUtils.replace(htmlStruct, "${displayClaveAcceso}",
					comp.isPayService() ? "visible" : "none");

			htmlStruct = StringUtils.replace(htmlStruct, "${displayFirma}", comp.isDeposit() ? "visible" : "none");
			htmlStruct = StringUtils.replace(htmlStruct, "${firma}", comp.getSign());
			
			
			
			htmlStruct = StringUtils.replace(htmlStruct, "${displayFactura}", this.valString(comp.getBill())!=null && comp.isPayService() ? "visible" : "none");
			htmlStruct = StringUtils.replace(htmlStruct, "${factura}", comp.getBill());
			htmlStruct = StringUtils.replace(htmlStruct, "${fechaEmision}", comp.getStartDate());
			htmlStruct = StringUtils.replace(htmlStruct, "${mesFacturacion}", comp.getBillDate());
			
			FileOutputStream fs = new FileOutputStream(COMPROBANTE_FOLDER+HTML_FILE_PATH);
			out = new OutputStreamWriter(fs);
			out.write(htmlStruct);
		} finally {
			if (out != null)
				out.close();
		}

	}
	
	private String valString(String ret) {
		if (ret != null) {
			ret = ret.trim().isEmpty() ? null : ret;
		}
		return ret;
	}

	

	private void exportPDFFile() throws FileNotFoundException {
		try {
			File htmlSource = new File(COMPROBANTE_FOLDER+HTML_FILE_PATH);
			File pdfDest = new File(COMPROBANTE_FOLDER+PDF_FILE_PATH);

			if (htmlSource.exists()) {
				ConverterProperties converterProperties = new ConverterProperties();
				converterProperties.setCharset("utf-8");
				HtmlConverter.convertToPdf(new FileInputStream(htmlSource), new FileOutputStream(pdfDest),
						converterProperties);
			} else {
				logger.error("The html file does not exits, could not export PDF File - FileNotFoundException");
				throw new FileNotFoundException("The html file does not exits, could not export PDF File");
			}
		} catch (FileNotFoundException e) {
			logger.error("Could not export PDF File - FileNotFoundException", e.getMessage());
		} catch (IOException e) {
			logger.error("Could not export PDF File - IOException", e.getMessage());
		}
	}
	
	public static BigDecimal getRoundVal(BigDecimal val) {
		if (val != null)
			val = val.setScale(2, RoundingMode.HALF_UP);

		return val;
	}

}