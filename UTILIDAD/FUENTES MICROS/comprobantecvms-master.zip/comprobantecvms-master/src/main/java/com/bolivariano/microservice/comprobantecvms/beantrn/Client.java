package com.bolivariano.microservice.comprobantecvms.beantrn;

import java.io.Serializable;

public class Client  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -734363527567655759L;
	private String identification;
	private String identificationType;
	private String name;
	private String entMis;
	private String mail;
	private String phone;
	public String getIdentification() {
		return identification;
	}
	public void setIdentification(String identification) {
		this.identification = identification;
	}
	public String getIdentificationType() {
		return identificationType;
	}
	public void setIdentificationType(String identificationType) {
		this.identificationType = identificationType;
	}
	public String getEntMis() {
		return entMis;
	}
	public void setEntMis(String entMis) {
		this.entMis = entMis;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	

}
