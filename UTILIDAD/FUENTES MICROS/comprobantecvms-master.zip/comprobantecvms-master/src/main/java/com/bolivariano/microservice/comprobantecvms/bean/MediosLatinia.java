package com.bolivariano.microservice.comprobantecvms.bean;

public class MediosLatinia {
	
	 String clase_medio;
	 String tipo_medio;
	 String valor_medio;
     
     public String getClase_medio() {
   	        return clase_medio;
   	}

     public void setClase_medio(String value) {
   	     this.clase_medio = value;
   	}
     
     public String getTipo_medio() {
	        return tipo_medio;
	}

     public void setTipo_medio(String value) {
	     this.tipo_medio = value;
	}
     
     public String getValor_medio() {
	        return valor_medio;
	}

    public void setValor_medio(String value) {
	     this.valor_medio = value;
	}

}
