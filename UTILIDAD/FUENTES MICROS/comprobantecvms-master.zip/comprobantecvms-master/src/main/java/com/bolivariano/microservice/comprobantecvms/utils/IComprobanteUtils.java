package com.bolivariano.microservice.comprobantecvms.utils;

import com.bolivariano.microservice.comprobantecvms.bean.Comprobante;

public interface IComprobanteUtils {
	void registrarComprobante(Comprobante c);
}
