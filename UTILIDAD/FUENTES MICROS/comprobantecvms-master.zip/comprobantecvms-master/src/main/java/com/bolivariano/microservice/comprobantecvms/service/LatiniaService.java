package com.bolivariano.microservice.comprobantecvms.service;

import latinia.com.lsubscribers.provisioner.*;
import latinia.com.lsubscribers.provisioner.data.*;

import java.net.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.ws.BindingProvider;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import com.bolivariano.microservice.comprobantecvms.bean.MensajeSalidaLatinia;

//import Latina_Admin.latiniaAdminConsumos.consumoAdminLatinia;

import com.bolivariano.microservice.comprobantecvms.bean.Comprobante;
import com.bolivariano.microservice.comprobantecvms.bean.MediosLatinia;
import com.bolivariano.microservice.comprobantecvms.bean.MensajeEntradaLatinia; 
//--------------
import javax.annotation.PostConstruct;

@Service
public class LatiniaService {
	
	@Value("${latinia.servicioWeb.url_service}")
    private String urlUsers;
	@Value("${latinia.servicioWeb.url_admin}")
    private String urlAdmin;
	@Value("${latinia.servicioWeb.usuario_propiedad}")
    private String usuarioPropiedad;
	@Value("${latinia.servicioWeb.clave_propiedad}")
    private String clavePropiedad;
	@Value("${latinia.servicioWeb.empresa}")
    private String datEmpresa;
	@Value("${latinia.servicioWeb.empresa_id}")
    private Integer IDEmpresa;
	@Value("${latinia.servicioWeb.url_service_metodo}")
    private String UrlServicioMetodo;
	@Value("${latinia.servicioWeb.url_admin_metodo}")
    private String UrlAdminMetodo;
	
	@Value("${latinia.servicioWeb.conntimeout}")
    private int contTimeout;
	@Value("${latinia.servicioWeb.readtimeout}")
    private int readTimeout;

	private ProvisionerUser provisionerUser = null;
	private ProvisionerAdmin provisionerAdmin = null;
	private String validacion = "MICROSERVICIO";
	private int error_suscrito = 0;
	
	public ProvisionerAdmin getProvisionerAdmin() {
		if(provisionerAdmin == null) {
			try {
				ProvisionerAdminService serv_admin = new ProvisionerAdminService(new URL(urlAdmin));
				
				provisionerAdmin = serv_admin.getProvisionerAdminPort();
				((BindingProvider)provisionerAdmin).getRequestContext()
				   .put(BindingProvider.USERNAME_PROPERTY, usuarioPropiedad);

				((BindingProvider) provisionerAdmin).getRequestContext()
				   .put(BindingProvider.PASSWORD_PROPERTY, clavePropiedad);
				
				((BindingProvider) provisionerAdmin).getRequestContext()
				   .put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, UrlAdminMetodo);
				
				setTimeouts(((BindingProvider)provisionerAdmin), contTimeout, readTimeout);
				
			} catch (java.lang.Exception e) {
				e.printStackTrace();
				provisionerAdmin = null;
			}
			
		}
		return provisionerAdmin;	
	}
	
	
	public ProvisionerUser getProvisionerUser()
	{
		if(provisionerUser == null)
		{		
			try {
				ProvisionerUserService servicio = new ProvisionerUserService(new URL(urlUsers));									
				provisionerUser = servicio.getProvisionerUserPort();				
				
				((BindingProvider)provisionerUser).getRequestContext()
				   .put(BindingProvider.USERNAME_PROPERTY, usuarioPropiedad);

				((BindingProvider) provisionerUser).getRequestContext()
				   .put(BindingProvider.PASSWORD_PROPERTY, clavePropiedad);
				
				((BindingProvider) provisionerUser).getRequestContext()
				   .put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, UrlServicioMetodo);
				
				setTimeouts(((BindingProvider)provisionerUser), contTimeout, readTimeout);
				
			} catch (java.lang.Exception e) {
				e.printStackTrace();
				provisionerUser = null;
			}
		}
		return provisionerUser;		
	}
	
	private void setTimeouts(BindingProvider serviceClass, int connTimeout, int readTimeout) {
		Client cxfClient = ClientProxy.getClient(serviceClass);
		HTTPConduit httpConduit = (HTTPConduit) cxfClient.getConduit();
		HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
		httpClientPolicy.setConnectionTimeout(connTimeout);
		httpClientPolicy.setReceiveTimeout(readTimeout);
		httpConduit.setClient(httpClientPolicy);
	}
	
	public MensajeSalidaLatinia UsuariosLatinia(MensajeEntradaLatinia EntradaLatinia) {
		MensajeSalidaLatinia MensajeRespuesta = new MensajeSalidaLatinia();
		
		getProvisionerUser();
		
		if (EntradaLatinia.getCodigo_operacion().equals("C")) {
			MensajeRespuesta = consultaCliente(provisionerUser, EntradaLatinia);
		}
		
		if ((EntradaLatinia.getCodigo_operacion().equals("I"))||(EntradaLatinia.getCodigo_operacion().equals("M"))) {
			MensajeRespuesta = MantenimientoCliente(provisionerUser, EntradaLatinia);
		}
		
		return MensajeRespuesta;
	}
	
	
	public MensajeSalidaLatinia consultaCliente(ProvisionerUser provisioner, MensajeEntradaLatinia EntradaLatinia) {
		MensajeSalidaLatinia MensajeRespuesta = new MensajeSalidaLatinia();
		MensajeRespuesta.setCodigo_mis(EntradaLatinia.getCodigo_mis().toString());
		
		if(provisionerUser == null) {
			MensajeRespuesta.setMensaje_ejecucion("Error en comunicacion con LATINIA: No se pueden validar medios de Notificaciones ");
			MensajeRespuesta.setCodigo_respuesta("100");
			MensajeRespuesta.setMensaje_error("Error en consulta de cliente " );
			return MensajeRespuesta;	
		}
		
		//Validar si el cliente existe en Latinia
		int userId = -1;
		try {
			userId = provisioner.getUserId(validacion, datEmpresa, EntradaLatinia.getCodigo_mis().toString());
			if (userId == -1) {
				//Si el usuario no existe no se realiza consulta
				MensajeRespuesta.setMensaje_ejecucion("Cliente no se encuentra registrado en Latinia, Favor Actualizar");
				MensajeRespuesta.setCodigo_respuesta("100");
				MensajeRespuesta.setMensaje_error("Cliente no se encuentra registrado en Latinia, Favor Actualizar");
				return MensajeRespuesta;
			}
		} catch (Exception_Exception e) {
			MensajeRespuesta.setMensaje_ejecucion("Error en comunicacion con LATINIA: Error al consultar cliente en Latinia");
			MensajeRespuesta.setCodigo_respuesta("100");
			MensajeRespuesta.setMensaje_error("Error en consulta de cliente: " + e.getMessage());
			return MensajeRespuesta;
		}
		
		try {
			List valores; 
			List<MediosLatinia> valores_medios = new ArrayList();
			String cliente = EntradaLatinia.getCodigo_mis().toString();
			String registro = "";
			//Medios Universales
			valores = provisioner.getUserByRef(validacion, datEmpresa, cliente).getProps();
			for(int i= 0; i < valores.size(); i++) {				
				Property row = new Property(); 
				row = (Property) valores.get(i);
			    registro = row.getName().toString();
				if (registro.contentEquals("gsm")) {
					List telefonos;
					telefonos = row.getValues();
					for(int t= 0; t < telefonos.size(); t++) {
						MediosLatinia medios = new MediosLatinia();
						medios.setClase_medio("U");
						medios.setTipo_medio("gsm");
						medios.setValor_medio(telefonos.get(t).toString());
						valores_medios.add(medios);
					}
				} 
				if (registro.contentEquals("email")) {
					List mails;
					mails = row.getValues();
					for(int m= 0; m < mails.size(); m++) {
						MediosLatinia medios = new MediosLatinia();
						medios.setClase_medio("U");
						medios.setTipo_medio("mail");
						medios.setValor_medio(mails.get(m).toString());
						valores_medios.add(medios);
					}
				}
			}
			
			//Consultar los nemónicos de los servicios - ADMIN
			getProvisionerAdmin();
			
			if(provisionerAdmin == null) {
				MensajeRespuesta.setMensaje_ejecucion("Error en comunicacion con LATINIA: Servicio Inhabilitado ");
				MensajeRespuesta.setCodigo_respuesta("100");
				MensajeRespuesta.setMensaje_error("Error al instanciar el servicio");
				return MensajeRespuesta;	
			}
			error_suscrito = 0;
			List MediosSuscritos = new ArrayList();
			MediosSuscritos = ListaSuscritos(EntradaLatinia.getCodigo_mis().toString());
			
			if (error_suscrito == 1) {
				MensajeRespuesta.setMensaje_ejecucion("Error en comunicacion con LATINIA Suscritos: No se pueden validar medios de Notificaciones Suscritas");
				MensajeRespuesta.setCodigo_respuesta("100");
				MensajeRespuesta.setMensaje_error("Error en consulta de servicio Admin");
				return MensajeRespuesta;
			}
			
			for(int i= 0; i < MediosSuscritos.size(); i++) {
				//-------------------------------
				//Medios suscriptos
				List val_suscritos;
				val_suscritos = provisioner.getUserRules(validacion, datEmpresa, MediosSuscritos.get(i).toString(), cliente);
				for(int s= 0; s < val_suscritos.size(); s++) {				
					Rule row = new Rule(); 
					row = (Rule) val_suscritos.get(s);
					List ref_valSuscritos;
					ref_valSuscritos = row.getReferenceValues();
					for(int m= 0; m < ref_valSuscritos.size(); m++) {
						Property row_ref = new Property();
						row_ref = (Property) ref_valSuscritos.get(m);
					    registro = row_ref.getName().toString();
						if (registro.contentEquals("gsm")) {
							List telefonos;
							telefonos = row_ref.getValues();
							for(int f= 0; f < telefonos.size(); f++) {
								MediosLatinia medios = new MediosLatinia();
								medios.setClase_medio("S");
								medios.setTipo_medio("gsm");
								medios.setValor_medio(telefonos.get(f).toString());
								valores_medios.add(medios);
							}
						} 
						if (registro.contentEquals("email")) {
							List mails;
							mails = row_ref.getValues();
							for(int e= 0; e < mails.size(); e++) {
								MediosLatinia medios = new MediosLatinia();
								medios.setClase_medio("S");
								medios.setTipo_medio("mail");
								medios.setValor_medio(mails.get(e).toString());
								valores_medios.add(medios);
							}
						}	
					}
			   }
			}
			MensajeRespuesta.setMensaje_ejecucion("OK");
			MensajeRespuesta.setCodigo_respuesta("0");
			MensajeRespuesta.setLista_informacion(valores_medios);
			
			return MensajeRespuesta;
			
		} catch (Exception_Exception e) {
			MensajeRespuesta.setMensaje_ejecucion("Error en comunicacion con LATINIA: No se pueden validar medios de Notificaciones");
			MensajeRespuesta.setCodigo_respuesta("100");
			MensajeRespuesta.setMensaje_error("Error en consulta de usuario: " + e.getMessage());
			return MensajeRespuesta;
		}
		
	}
	
	public MensajeSalidaLatinia MantenimientoCliente(ProvisionerUser provisioner, MensajeEntradaLatinia EntradaLatinia) {
		MensajeSalidaLatinia MensajeRespuesta = new MensajeSalidaLatinia();
		
		if(provisionerUser == null) {
			MensajeRespuesta.setMensaje_ejecucion("Error en comunicacion con LATINIA: El cliente se actualizara en BATCH diario");
			MensajeRespuesta.setCodigo_respuesta("100");
			MensajeRespuesta.setMensaje_error("Error en consulta de cliente " );
			return MensajeRespuesta;	
		}
		
		String cod_mis = EntradaLatinia.getCodigo_mis().toString();
		MensajeRespuesta.setCodigo_mis(cod_mis);
		int userId = -1;
		try {
			//Identificador del usuario
			userId = provisioner.getUserId(validacion, datEmpresa, cod_mis);
			if (userId == -1) {
				//Si el usuario no existe se crea
				userId = provisioner.createUser(validacion, datEmpresa, cod_mis, "", "", "0");
			}
			//Creamos_Actualizamos propiedades
			if (EntradaLatinia.getIdentificacion_cliente() != null) {
				provisioner.setUserPropertyValue(validacion, datEmpresa, cod_mis, "identificacion", EntradaLatinia.getIdentificacion_cliente().toString());	
			}
			if (EntradaLatinia.getNombre_cliente() != null) {
				provisioner.setUserPropertyValue(validacion, datEmpresa, cod_mis, "nombres", EntradaLatinia.getNombre_cliente().toString());	
			}
			if (EntradaLatinia.getApellido_cliente() != null) {
				provisioner.setUserPropertyValue(validacion, datEmpresa, cod_mis, "apellidos", EntradaLatinia.getApellido_cliente().toString());	
			}
			if (EntradaLatinia.getDescripcion_ciudad() != null) {
				provisioner.setUserPropertyValue(validacion, datEmpresa, cod_mis, "ciudad", EntradaLatinia.getDescripcion_ciudad().toString());	
			}
			if (EntradaLatinia.getFecha_nacimiento() != null) {
				provisioner.setUserPropertyValue(validacion, datEmpresa, cod_mis, "fecha_nacimiento", EntradaLatinia.getFecha_nacimiento().toString());	
			}
			if (EntradaLatinia.getEstado_civil() != null) {
				provisioner.setUserPropertyValue(validacion, datEmpresa, cod_mis, "estado_civil", EntradaLatinia.getEstado_civil().toString());				
			}
            if (EntradaLatinia.getEstado_cliente() != null) {
            	provisioner.setUserPropertyValue(validacion, datEmpresa, cod_mis, "estado_cliente", EntradaLatinia.getEstado_cliente().toString());	
			}
            if (EntradaLatinia.getTipo_identificacion() != null) {
            	provisioner.setUserPropertyValue(validacion, datEmpresa, cod_mis, "tipo_identificacion", EntradaLatinia.getTipo_identificacion().toString());	
			}
            if (EntradaLatinia.getTipo_persona() != null) {
            	provisioner.setUserPropertyValue(validacion, datEmpresa, cod_mis, "tipo_persona", EntradaLatinia.getTipo_persona().toString());
			}
            MensajeRespuesta.setMensaje_ejecucion("OK");
            MensajeRespuesta.setCodigo_respuesta("0");
			
		} catch (Exception_Exception e) {
			MensajeRespuesta.setMensaje_ejecucion("Error en comunicacion con LATINIA: El cliente se actualizara en BATCH diario");
			MensajeRespuesta.setCodigo_respuesta("100");
			MensajeRespuesta.setMensaje_error("Error en creacion de usuario: " + e.getMessage());
			return MensajeRespuesta;
		}

		return MensajeRespuesta;
	}
	
	public MensajeSalidaLatinia InformacionCola(Document doc)
    {
		MensajeSalidaLatinia c = new MensajeSalidaLatinia();
		MensajeEntradaLatinia e = new MensajeEntradaLatinia();
    	
    	NodeList params = doc.getFirstChild().getLastChild().getFirstChild().getChildNodes();//Params
    	
    	for (int i = 1; i < params.getLength(); i++)//iterando sobre Params
        {
        	String node = params.item(i).getFirstChild().getTextContent();
        	String node_name_attribute = params.item(i).getAttributes().getNamedItem("name").getTextContent();
        	
        	if(node_name_attribute.equals("@i_cod_operacion") || 
        			node_name_attribute.equals("@i_cod_mis") ||
        			node_name_attribute.equals("@i_tipo_id") ||
        			node_name_attribute.equals("@i_id_cliente") ||
        			node_name_attribute.equals("@i_tipo_persona") ||
        			node_name_attribute.equals("@i_nom_cliente") ||
        			node_name_attribute.equals("@i_apel_cliente") ||
        			node_name_attribute.equals("@i_desc_ciudad") ||
        			node_name_attribute.equals("@i_fec_nacimiento") ||
        			node_name_attribute.equals("@i_est_civil") ||
        			node_name_attribute.equals("@i_est_cliente") )
        	{
        		if(node_name_attribute.equals("@i_cod_operacion"))
            	{
            		e.setCodigo_operacion(node);    
            		continue;
            	}
            	else if(node_name_attribute.equals("@i_cod_mis"))
            	{
            		e.setCodigo_mis(node);
            		continue;
            	}
            	else if(node_name_attribute.equals("@i_tipo_id"))
            	{
            		e.setTipo_identificacion(node);
            		continue;
            	}
            	else if(node_name_attribute.equals("@i_id_cliente"))
            	{
            		e.setIdentificacion_cliente(node);
            		continue;
            	}
            	else if(node_name_attribute.equals("@i_tipo_persona"))
            	{
            		e.setTipo_persona(node);
            		continue;
            	}
            	else if(node_name_attribute.equals("@i_nom_cliente"))
            	{
            		e.setNombre_cliente(node);
            		continue;
            	}
            	else if(node_name_attribute.equals("@i_apel_cliente"))
            	{
            		e.setApellido_cliente(node);
            		continue;
            	}        	
            	else if(node_name_attribute.equals("@i_desc_ciudad"))
            	{
            		e.setDescripcion_ciudad(node);
            		continue;
            	}
            	else if(node_name_attribute.equals("@i_fec_nacimiento"))
            	{
            		e.setFecha_nacimiento(node);
            		continue;
            	}
            	else if(node_name_attribute.equals("@i_est_civil"))
            	{
            		e.setEstado_civil(node);
            		continue;
            	}
            	else if(node_name_attribute.equals("@i_est_cliente"))
            	{
            		e.setEstado_cliente(node);
            		continue;
            	}
        	}
        	else
        		continue;
		}    
    	
    	c = UsuariosLatinia(e);
    	
    	return c;
    }
	
	//Obtención de servicios
	public List ListaSuscritos(String codigoMis) {
		List DatosSuscritos = new ArrayList();
		List DatosRegistros = new ArrayList();
		
		try {
			DatosSuscritos = provisionerAdmin.listUserRegisteredServices("", datEmpresa, codigoMis);
			//Integer Idcompania = provisionerAdmin.getCompany("", datEmpresa).getId();
			Integer SrvUsuario;
			String Servicio;
			for(int i= 0; i < DatosSuscritos.size(); i++) {
				SrvUsuario =  (Integer) DatosSuscritos.get(i);
				Servicio = provisionerAdmin.getServiceById("", IDEmpresa, SrvUsuario).getRefService();
				DatosRegistros.add(Servicio.toString());
			}
				
		} catch (Exception_Exception e) {
			e.printStackTrace();
			error_suscrito = 1;
		}
		return DatosRegistros;
	}
	
}
