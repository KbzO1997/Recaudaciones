package com.bolivariano.microservice.comprobantecvms.bean;


public class RespuestaPrestamo {

	private String mensajeEjec;
	private String mensajeError;
	private String codigoRespuesta;
		  
	
   public String getmensajeEjec() {
        return mensajeEjec;
   }

   public void setmensajeEjec(String value) {
     this.mensajeEjec = value;
    }
   
  public String getmensajeError() {
       return mensajeError;
  }

  public void setmensajeError(String value) {
    this.mensajeError = value;
   }
  
  public String getcodigoRespuesta() {
      return codigoRespuesta;
 }

 public void setcodigoRespuesta(String value) {
   this.codigoRespuesta = value;
  }

}
