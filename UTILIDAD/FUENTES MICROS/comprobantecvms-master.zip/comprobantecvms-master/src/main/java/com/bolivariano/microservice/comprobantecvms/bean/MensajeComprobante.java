package com.bolivariano.microservice.comprobantecvms.bean;

import java.io.Serializable;

public class MensajeComprobante implements Serializable{
	
	private static final long serialVersionUID = 1L;	

	private String uuid;
	private String uniqueTransCode;
	private String ipAgency;
	private String dateTrans;
	private String officeCode;
	private String officeUser;
	private String officeHours;
	private String currency;
	private String sec;
	private String transCode;
	private String transDescripction;
	private Boolean deposit;
	private Boolean payCard;
	private Boolean payService;
	
	
	private String codeRec;
	private String closingDate;
	private String rucCompanyVal;
	private String benfIdetification;
	private String amountVal;
	private String amountToDate;
	private String accesKey;
	private String benfNumberAccount;
	
	private String unpaidMonth;	
	private String bill;
	private String billDate;
	private String startDate;
	private String direction;
	
	
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getUniqueTransCode() {
		return uniqueTransCode;
	}
	public void setUniqueTransCode(String uniqueTransCode) {
		this.uniqueTransCode = uniqueTransCode;
	}
	public String getIpAgency() {
		return ipAgency;
	}
	public void setIpAgency(String ipAgency) {
		this.ipAgency = ipAgency;
	}
	public String getDateTrans() {
		return dateTrans;
	}
	public void setDateTrans(String dateTrans) {
		this.dateTrans = dateTrans;
	}
	public String getOfficeCode() {
		return officeCode;
	}
	public void setOfficeCode(String officeCode) {
		this.officeCode = officeCode;
	}
	public String getOfficeUser() {
		return officeUser;
	}
	public void setOfficeUser(String officeUser) {
		this.officeUser = officeUser;
	}
	public String getOfficeHours() {
		return officeHours;
	}
	public void setOfficeHours(String officeHours) {
		this.officeHours = officeHours;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getSec() {
		return sec;
	}
	public void setSec(String sec) {
		this.sec = sec;
	}
	public String getTransCode() {
		return transCode;
	}
	public void setTransCode(String transCode) {
		this.transCode = transCode;
	}
	public String getTransDescripction() {
		return transDescripction;
	}
	public void setTransDescripction(String transDescripction) {
		this.transDescripction = transDescripction;
	}
	public Boolean getDeposit() {
		return deposit;
	}
	public void setDeposit(Boolean deposit) {
		this.deposit = deposit;
	}
	public Boolean getPayCard() {
		return payCard;
	}
	public void setPayCard(Boolean payCard) {
		this.payCard = payCard;
	}
	public Boolean getPayService() {
		return payService;
	}
	public void setPayService(Boolean payService) {
		this.payService = payService;
	}
	public String getCodeRec() {
		return codeRec;
	}
	public void setCodeRec(String codeRec) {
		this.codeRec = codeRec;
	}
	public String getClosingDate() {
		return closingDate;
	}
	public void setClosingDate(String closingDate) {
		this.closingDate = closingDate;
	}
	public String getRucCompanyVal() {
		return rucCompanyVal;
	}
	public void setRucCompanyVal(String rucCompanyVal) {
		this.rucCompanyVal = rucCompanyVal;
	}
	public String getBenfIdetification() {
		return benfIdetification;
	}
	public void setBenfIdetification(String benfIdetification) {
		this.benfIdetification = benfIdetification;
	}
	public String getAmountVal() {
		return amountVal;
	}
	public void setAmountVal(String amountVal) {
		this.amountVal = amountVal;
	}
	public String getAmountToDate() {
		return amountToDate;
	}
	public void setAmountToDate(String amountToDate) {
		this.amountToDate = amountToDate;
	}
	public String getAccesKey() {
		return accesKey;
	}
	public void setAccesKey(String accesKey) {
		this.accesKey = accesKey;
	}
	public String getBenfNumberAccount() {
		return benfNumberAccount;
	}
	public void setBenfNumberAccount(String benfNumberAccount) {
		this.benfNumberAccount = benfNumberAccount;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public String getUnpaidMonth() {
		return unpaidMonth;
	}
	public void setUnpaidMonth(String unpaidMonth) {
		this.unpaidMonth = unpaidMonth;
	}
	public String getBill() {
		return bill;
	}
	public void setBill(String bill) {
		this.bill = bill;
	}
	public String getBillDate() {
		return billDate;
	}
	public void setBillDate(String billDate) {
		this.billDate = billDate;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}	
    
}
