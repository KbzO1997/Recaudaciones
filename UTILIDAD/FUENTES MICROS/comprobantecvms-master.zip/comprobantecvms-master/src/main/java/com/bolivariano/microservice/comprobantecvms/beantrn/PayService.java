package com.bolivariano.microservice.comprobantecvms.beantrn;

import java.io.Serializable;
import java.math.BigDecimal;

import com.bolivariano.microservice.comprobantecvms.utils.ComprobanteUtils;

public class PayService implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1948989373875586143L;

	private Company company;
	private Client client;
	private String serviceCode;
	private Integer nCheck;
	private Boolean bill;
	private BigDecimal commission;
	private BigDecimal amountCash;
	private BigDecimal amountCheck;
	private BigDecimal totalAmount;	
	private BigDecimal minAmount;	
	private BigDecimal totalDbt;
	private String fundsSource;
	private String fundsDestination;
	
	public Company getCompany() {
		return company;
	}
	public void setCompany(Company company) {
		this.company = company;
	}
	public Client getClient() {
		return client;
	}
	public void setClient(Client client) {
		this.client = client;
	}
	public String getServiceCode() {
		return serviceCode;
	}
	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}
	public Integer getnCheck() {
		return nCheck;
	}
	public void setnCheck(Integer nCheck) {
		this.nCheck = nCheck;
	}
	public Boolean getBill() {
		return bill;
	}
	public void setBill(Boolean bill) {
		this.bill = bill;
	}
	public BigDecimal getCommission() {
		return commission;
	}
	public void setCommission(BigDecimal commission) {
		this.commission = ComprobanteUtils.getRoundVal(commission);
	}
	public BigDecimal getAmountCash() {
		return amountCash;
	}
	public void setAmountCash(BigDecimal amountCash) {
		this.amountCash = ComprobanteUtils.getRoundVal(amountCash);
	}
	public BigDecimal getAmountCheck() {
		return amountCheck;
	}
	public void setAmountCheck(BigDecimal amountCheck) {
		this.amountCheck = ComprobanteUtils.getRoundVal(amountCheck);
	}
	public BigDecimal getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = ComprobanteUtils.getRoundVal(totalAmount);
	}
	public BigDecimal getMinAmount() {
		return minAmount;
	}
	public void setMinAmount(BigDecimal minAmount) {
		this.minAmount = ComprobanteUtils.getRoundVal(minAmount);
	}
	public BigDecimal getTotalDbt() {
		return totalDbt;
	}
	public void setTotalDbt(BigDecimal totalDbt) {
		this.totalDbt = ComprobanteUtils.getRoundVal(totalDbt);
	}	
	public String getFundsSource() {
		return fundsSource;
	}
	public void setFundsSource(String fundsSource) {
		this.fundsSource = fundsSource;
	}
	public String getFundsDestination() {
		return fundsDestination;
	}
	public void setFundsDestination(String fundsDestination) {
		this.fundsDestination = fundsDestination;
	}
}
