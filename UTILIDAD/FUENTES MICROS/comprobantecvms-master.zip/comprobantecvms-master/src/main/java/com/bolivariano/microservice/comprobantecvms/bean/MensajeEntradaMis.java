package com.bolivariano.microservice.comprobantecvms.bean;

public class MensajeEntradaMis {
	
	String codigo_operacion; //i_operacion
	String fecha;
    String hora;//
    String servicio_nemonico; //i_servicio
    String codigo_mis; //i_cliente
    String tipo_servicio;
    String identif_enmascarada;
    String medio;
    String canal;//i_canal
    String nombre_cliente; //i_nombre
    String mail_cliente; //i_mail
    String celular_cliente; //i_telefono
    String producto;//i_producto
    String cuenta;    //i_cuenta
  //ini: wlopezc TCRE-CC-SGC00041008
    String i_empresa;
    String i_cta_deb;
    String i_motivo;
    String i_cta;
    String i_cta_cre;
    String i_plantilla;
    String i_valor1;
    String i_valor2;
    String i_secuencial;
    String i_prod_deb;
    String i_desc_producto;
    String i_desc_canal;
    //fin: wlopezc
	//**************************************
    
    //Métodos GET
	//**************************************
    public String getCodigo_Operacion() {
    	return codigo_operacion;
	}
	
	public String getFecha() {
		return fecha;
	}
	
	public String getHora() {
	    return hora;
	}
	
	public String getServicio_Nemonico() {
	    return servicio_nemonico;
	}
	
	public String getCodigo_Mis() {
	    return codigo_mis;
	}
	
	public String getTipo_Servicio() {
	    return tipo_servicio;
	}
	
	public String getIdentificacion_Cliente() {
	    return identif_enmascarada;
	}
	
	public String getMedio() {
	    return medio;
	}
	
	public String getCanal() {
	    return canal;
	}
	
	public String getNombre_Cliente() {
        return nombre_cliente;
	}
	
	public String getMail() {
	    return mail_cliente;
	}
	
	public String getCelular() {
	    return celular_cliente;
	}
	
	public String getProducto() {
	    return producto;
	}
	
	public String getCuenta() {
	    return cuenta;
	}
	
	//ini: wlopezc
	public String getI_empresa() {
	    return i_empresa;
	}

	public String getI_cta_deb() {
	    return i_cta_deb;
	}

	public String getI_motivo() {
	    return i_motivo;
	}

	public String getI_Cta() {
	    return i_cta;
	}

	public String getI_cta_cre() {
	    return i_cta_cre;
	}

	public String getI_plantilla() {
	    return i_plantilla;
	}

	public String getI_valor1() {
	    return i_valor1;
	}

	public String getI_valor2() {
	    return i_valor2;
	}

	public String getI_secuencial() {
	    return i_secuencial;
	}

	public String getI_prod_deb() {
	    return i_prod_deb;
	}

	public String getI_desc_producto() {
	    return i_desc_producto;
	}

	public String getI_desc_canal() {
	    return i_desc_canal;
	}
	//fin: wlopezc

	//**************************************	
	//Métodos SET
	//**************************************
	
	public void setCodigo_operacion(String value) {
	     this.codigo_operacion = value;
	}
	
	public void setFecha(String value) {
	     this.fecha = value;
	}	  
	
	public void setHora(String value) {
	     this.hora = value;
	}
	
	public void setServicio_Nemonico(String value) {
	     this.servicio_nemonico = value;
	}
	
	public void setCodigo_Mis(String value) {
	     this.codigo_mis = value;
	}
	
	public void setTipo_Servicio(String value) {
	     this.tipo_servicio = value;
	}
	
	public void setIdentificacion_Cliente(String value) {
	     this.identif_enmascarada = value;
	}
	
	public void setMedio(String value) {
	     this.medio = value;
	}
	
	public void setCanal(String value) {
	     this.canal = value;
	}
	
	public void setNombre_Cliente(String value) {
		this.nombre_cliente = value;
	} 
	
	public void setMail(String value) {
	     this.mail_cliente = value;
	}
	
	public void setCelular(String value) {
	     this.celular_cliente = value;
	}
	
	public void setProducto(String value) {
	     this.producto = value;
	}
	
	public void setCuenta(String value) {
	     this.cuenta = value;
	}
	//ini: wlopezc
	public void setI_empresa(String value) {
		this.i_empresa = value;
	}

	public void setI_cta_deb(String value) {
		this.i_cta_deb = value;
	}

	public void setI_motivo(String value) {
		this.i_motivo = value;
	}

	public void setI_cta(String value) {
		this.i_cta = value;
	}

	public void setI_cta_cre(String value) {
		this.i_cta_cre = value;
	}

	public void setI_plantilla(String value) {
		this.i_plantilla = value;
	}

	public void setI_valor1(String value) {
		this.i_valor1 = value;
	}

	public void setI_valor2(String value) {
		this.i_valor2 = value;
	}

	public void setI_secuencial(String value) {
		this.i_secuencial = value;
	}

	public void setI_prod_deb(String value) {
		this.i_prod_deb = value;
	}

	public void setI_desc_producto(String value) {
		this.i_desc_producto = value;
	}
	
	public void setI_desc_canal(String value) {
		this.i_desc_canal = value;
	}

	//fin: wlopezc
	
}