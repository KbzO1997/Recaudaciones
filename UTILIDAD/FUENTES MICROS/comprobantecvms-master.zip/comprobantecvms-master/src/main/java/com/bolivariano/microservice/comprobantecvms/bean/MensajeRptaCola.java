package com.bolivariano.microservice.comprobantecvms.bean;

public class MensajeRptaCola 
{
	
	public String kernelHeader;
	public String fromServer;
	public String srv;
	public String sesn;
	public String transaccion;
	public String usuario;
	public String secuencial;
	public String terminal;
	public String codRpta;
	public String mensajeRpta;
	
	public MensajeRptaCola()
	{
		kernelHeader = "";
		fromServer = "";
		srv = "";
		sesn = "";
		transaccion = "";
		usuario = "";
		secuencial = "";
		terminal = "";
		codRpta = "";
		mensajeRpta = "";
	}	
	
	public String getKernelHeader() {
		return kernelHeader;
	}
	public void setKernelHeader(String kernelHeader) {
		this.kernelHeader = kernelHeader;
	}
	public String getFromServer() {
		return fromServer;
	}
	public void setFromServer(String fromServer) {
		this.fromServer = fromServer;
	}
	public String getSrv() {
		return srv;
	}
	public void setSrv(String srv) {
		this.srv = srv;
	}
	public String getSesn() {
		return sesn;
	}
	public void setSesn(String sesn) {
		this.sesn = sesn;
	}
	public String getTransaccion() {
		return transaccion;
	}
	public void setTransaccion(String transaccion) {
		this.transaccion = transaccion;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getSecuencial() {
		return secuencial;
	}
	public void setSecuencial(String secuencial) {
		this.secuencial = secuencial;
	}
	public String getTerminal() {
		return terminal;
	}
	public void setTerminal(String terminal) {
		this.terminal = terminal;
	}
	public String getCodRpta() {
		return codRpta;
	}
	public void setCodRpta(String codRpta) {
		this.codRpta = codRpta;
	}
	public String getMensajeRpta() {
		return mensajeRpta;
	}
	public void setMensajeRpta(String mensajeRpta) {
		this.mensajeRpta = mensajeRpta;
	}	
}
