package com.bolivariano.microservice.comprobantecvms.bean;

import java.util.ArrayList;
import java.util.List;

public class MensajeSalidaLatinia {

	private String codigo_mis;
	private String mensaje_ejecucion;
	private String mensaje_error;
	private String codiho_respuesta;
	private List<MediosLatinia> lista_informacion;
	
   public String getCodigo_mis() {
	        return codigo_mis;
	}

   public void setCodigo_mis(String value) {
	     this.codigo_mis = value;
	}
	
   public String getMensaje_ejecucion() {
        return mensaje_ejecucion;
   }

   public void setMensaje_ejecucion(String value) {
     this.mensaje_ejecucion = value;
    }
   
  public String getMensaje_error() {
       return mensaje_error;
  }

  public void setMensaje_error(String value) {
    this.mensaje_error = value;
   }
  
  public String getCodigo_respuesta() {
      return codiho_respuesta;
 }

 public void setCodigo_respuesta(String value) {
   this.codiho_respuesta = value;
  }
  
  public List<MediosLatinia> getLista_informacion() {
      if (lista_informacion == null) {
    	  lista_informacion = new ArrayList<MediosLatinia>();
      }
      return this.lista_informacion;
  }
  
  public void setLista_informacion(List<MediosLatinia> Value) {
      this.lista_informacion = Value;
  }
   
}
