package com.bolivariano.microservice.comprobantecvms.beantrn;

import java.io.Serializable;

public class OutMsgGetTransaction extends BasicResponse implements Serializable{

	private static final long serialVersionUID = 1L;
	Transaction transaction;
	public Transaction getTransaction() {
		return transaction;
	}
	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}	
}
