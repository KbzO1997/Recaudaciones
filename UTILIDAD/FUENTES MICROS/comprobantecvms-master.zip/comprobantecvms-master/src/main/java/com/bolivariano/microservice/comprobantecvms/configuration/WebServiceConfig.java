package com.bolivariano.microservice.comprobantecvms.configuration;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.xml.ws.BindingProvider;

import org.apache.cxf.Bus;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.jaxws.JaxWsClientProxy;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.apache.cxf.ws.policy.PolicyBuilder;
import org.apache.cxf.ws.policy.PolicyConstants;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.neethi.Policy;
import org.apache.wss4j.common.crypto.Merlin;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.DefaultUriTemplateHandler;

import com.bolivariano.ServiceSoap;
import com.bolivariano.microservice.notification_gateway.microservicio.notificationgateway.NotificacionesPortType;
import com.bolivariano.microservice.notification_gateway.microservicio.notificationgateway.NotificacionesSOAPService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class WebServiceConfig {

	Logger logger = LoggerFactory.getLogger(WebServiceConfig.class);

	@Value("${misNotificaciones.servicioWeb.url}")
	private String notURL;
	@Value("${misNotificaciones.servicioWeb.conntimeout}")
	private int notConntimeout;
	@Value("${misNotificaciones.servicioWeb.readtimeout}")
	private int notReadtimeout;

	@Value("${misNotificaciones.service.camel.username}")
	private String camelUsername;
	@Value("${misNotificaciones.service.camel.password}")
	private String camelPassword;
	@Value("${misNotificaciones.service.camel.encrypUsername}")
	private String encrypCamelUsername;

	@Value("${misNotificaciones.ssl.type}")
	private String camelType;
	@Value("${misNotificaciones.ssl.trustStore}")
	private String camelLocation;
	@Value("${misNotificaciones.ssl.trustStorePassword}")
	private String camelPasswordKey;

	@Value("${misNotificaciones.ssl.trustStore}")
	private String trustStore;
	@Value("${misNotificaciones.ssl.trustStorePassword}")
	private String trustStorePassword;

	@Value("${client.ws.address.transaccioncvpy.url}")
	private String transaccioncvpyURL;
	@Value("${client.ws.address.transaccioncvpy.conntimeout}")
	private int transaccioncvpyConntimeout;
	@Value("${client.ws.address.transaccioncvpy.readtimeout}")
	private int transaccioncvpyReadtimeout;
	@Value("${client.ws.address.transaccioncvpy.consultarTransaccion}")
	private String transaccioncvpyConsultarTransaccion;
	
	@Value("${client.ws.address.comprobantecvpy.url}")
	private String comprobantecvpyURL;
	@Value("${client.ws.address.comprobantecvpy.conntimeout}")
	private int comprobantecvpyConntimeout;
	@Value("${client.ws.address.comprobantecvpy.readtimeout}")
	private int comprobantecvpyReadtimeout;
	@Value("${client.ws.address.comprobantecvpy.consultarFirma}")
	private String comprobantecvpyConsultarFirma;
	@Value("${client.ws.address.comprobantecvpy.generarComprobante}")
	private String comprobantecvpyGenerarComprobante;
	
	
	@Value("${client.ws.address.vdtService.url}")
	private String vdtServiceURL;
	@Value("${client.ws.address.vdtService.conntimeout}")
	private int vdtServiceConntimeout;
	@Value("${client.ws.address.vdtService.readtimeout}")
	private int vdtServiceReadtimeout;


	private RestTemplate transaccionCvPY;
	private RestTemplate comprobanteCvPY;
	private NotificacionesPortType notificacionesPortType = null;
	
	private ServiceSoap vdtPortType = null;
	
	@PostConstruct
	private void setSSL() {
		System.setProperty("javax.net.ssl.trustStore", trustStore);
		System.setProperty("javax.net.ssl.trustStorePassword", trustStorePassword);
		try {
			clienteNotificacionMIS();
		} catch (Exception e) {
			logger.error("error cargando cliente notificacionMis", e);
		}
		try {
			getTransaccionCVPY();
		} catch (Exception e) {
			logger.error("error cargando cliente TransaccionCVPY", e);
		}
		try {
			getComprobanteCVPY();
		} catch (Exception e) {
			logger.error("error cargando cliente ComprobanteCVPY", e);
		}
		try {
			getClienteVDT();
		} catch (Exception e) {
			logger.error("error cargando cliente ClienteVDT", e);
		}

	}

	
	private void setSecurityCamel(BindingProvider bindingProvider) throws Exception {
		Map<String, Object> reqContext = bindingProvider.getRequestContext();
		InputStream is = null;
		try {
			reqContext.put("security.encryption.username", encrypCamelUsername);
			reqContext.put("ws-security.username", camelUsername);
			reqContext.put("ws-security.password", camelPassword);
			InvocationHandler invocationHandler = Proxy.getInvocationHandler(bindingProvider);
			Bus bus = ((JaxWsClientProxy) invocationHandler).getClient().getBus();
			is = this.getClass().getResourceAsStream("/oswm-wss11-policy.xml");
			PolicyBuilder builder = bus.getExtension(org.apache.cxf.ws.policy.PolicyBuilder.class);
			Policy wsSecuritypolicy = null;
			wsSecuritypolicy = builder.getPolicy(is);
			reqContext.put(PolicyConstants.POLICY_OVERRIDE, wsSecuritypolicy);
		} finally {
			if (is != null)
				is.close();
			is = null;
		}
	}

	private void setBindingProviderSecurity(BindingProvider bindingProvider, String address) throws Exception {
		InputStream input = null;
		try {
			Map<String, Object> reqContext = bindingProvider.getRequestContext();
			reqContext.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, address);
			Merlin issuerCrypto = new Merlin();
			KeyStore keyStore = KeyStore.getInstance("JKS");
			File keyStoreFile = new File(trustStore);
			input = new FileInputStream(keyStoreFile);
			keyStore.load(input, trustStorePassword.toCharArray());
			issuerCrypto.setKeyStore(keyStore);
			reqContext.put("security.signature.crypto", issuerCrypto);
			reqContext.put("security.encryption.crypto", issuerCrypto);

		} catch (IOException | KeyStoreException | NoSuchAlgorithmException | CertificateException e) {
			logger.error("error cargando el certificado de encriptacion o la politica de seguridad del servicio", e);
			throw e;
		} finally {
			if (input != null)
				input.close();
			input = null;
		}
	}

	@HystrixCommand(fallbackMethod = "pingFallbackClienteNotificaciones")
	public NotificacionesPortType clienteNotificacionMIS() throws Exception {
		if (notificacionesPortType == null) {
			NotificacionesSOAPService notService = new NotificacionesSOAPService(new URL(notURL));
			notificacionesPortType = notService.getNotificacionesSOAP11BindingQSPort();
			setSecurityCamel((BindingProvider) notificacionesPortType);
			setBindingProviderSecurity((BindingProvider) notificacionesPortType, notURL);
			setTimeouts((BindingProvider) notificacionesPortType, notConntimeout, notReadtimeout);
		}
		return notificacionesPortType;
	}

	private void setTimeouts(BindingProvider serviceClass, int connTimeout, int readTimeout) {
		Client cxfClient = ClientProxy.getClient(serviceClass);
		HTTPConduit httpConduit = (HTTPConduit) cxfClient.getConduit();
		HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
		httpClientPolicy.setConnectionTimeout(connTimeout);
		httpClientPolicy.setReceiveTimeout(readTimeout);
		httpConduit.setClient(httpClientPolicy);
	}

	private void setTimeouts(RestTemplate restTemplate, int connTimeout, int readTimeout) {
		RequestConfig requestConfig = RequestConfig.custom().setConnectionRequestTimeout(readTimeout)
				.setConnectTimeout(connTimeout).setSocketTimeout(readTimeout).build();
		CloseableHttpClient httpClient = HttpClients.custom().setDefaultRequestConfig(requestConfig).build();
		HttpComponentsClientHttpRequestFactory clientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory();
		clientHttpRequestFactory.setHttpClient(httpClient);
		restTemplate.setRequestFactory(clientHttpRequestFactory);
	}

	@HystrixCommand(fallbackMethod = "pingFallbackTransaccionCVPY")
	public RestTemplate getTransaccionCVPY() throws Exception {
		if (transaccionCvPY == null) {
			transaccionCvPY = new RestTemplate();
			DefaultUriTemplateHandler handler = new DefaultUriTemplateHandler();
			handler.setBaseUrl(transaccioncvpyURL);
			transaccionCvPY.setUriTemplateHandler(handler);
			setTimeouts(transaccionCvPY, transaccioncvpyConntimeout, transaccioncvpyReadtimeout);
		}
		return transaccionCvPY;
	}
	
	@HystrixCommand(fallbackMethod = "pingFallbackComprobanteCVPY")
	public RestTemplate getComprobanteCVPY() throws Exception {
		if (comprobanteCvPY == null) {
			comprobanteCvPY = new RestTemplate();
			DefaultUriTemplateHandler handler = new DefaultUriTemplateHandler();
			handler.setBaseUrl(comprobantecvpyURL);
			comprobanteCvPY.setUriTemplateHandler(handler);
			setTimeouts(comprobanteCvPY, comprobantecvpyConntimeout, comprobantecvpyReadtimeout);
		}
		return comprobanteCvPY;
	}
	
	@HystrixCommand(fallbackMethod = "pingFallbackclienteVDT")
	public ServiceSoap getClienteVDT() throws MalformedURLException {
		if (vdtPortType == null) {
			com.bolivariano.Service servc = new com.bolivariano.Service(new URL(vdtServiceURL));
			vdtPortType = servc.getServiceSoap();
			setTimeouts((BindingProvider) vdtPortType, vdtServiceConntimeout, vdtServiceReadtimeout);

		}
		return vdtPortType;
	}

	public RestTemplate pingFallbackTransaccionCVPY() throws Exception {
		logger.error("TransaccionCvPY está fuera de servicio");
		throw new Exception("TransaccionCvPY está fuera de servicio");
	}
	public RestTemplate pingFallbackComprobanteCVPY() throws Exception {
		logger.error("ComprobanteCvPY está fuera de servicio");
		throw new Exception("ComprobanteCvPY está fuera de servicio");
	}
	public NotificacionesPortType pingFallbackClienteNotificaciones() throws Exception {
		logger.error("Avisos24GatewayMS está fuera de servicio");
		throw new Exception("Avisos24GatewayMS está fuera de servicio");
	}
	public ServiceSoap pingFallbackclienteVDT() throws Exception {
		logger.error("vdtService está fuera de servicio");
		throw new Exception("vdtService está fuera de servicio");
	}


	public String getUrlConsultarTransaccion() {
		return this.transaccioncvpyURL + this.transaccioncvpyConsultarTransaccion;
	}
	public String getUrlConsultarFirma() {
		return this.comprobantecvpyURL + this.comprobantecvpyConsultarFirma;
	}
	public String getUrlGenerarComprobante() {
		return this.comprobantecvpyURL + this.comprobantecvpyGenerarComprobante;
	}

}
