package com.bolivariano.microservice.comprobantecvms.service;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Base64;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.Holder;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.bolivariano.ServiceSoap;
import com.bolivariano.microservice.comprobantecvms.bean.Comprobante;
import com.bolivariano.microservice.comprobantecvms.bean.MensajeComprobante;
import com.bolivariano.microservice.comprobantecvms.bean.MensajeService;
import com.bolivariano.microservice.comprobantecvms.beantrn.OutMsgGetTransaction;
import com.bolivariano.microservice.comprobantecvms.configuration.WebServiceConfig;
import com.bolivariano.microservice.comprobantecvms.helper.Helper;
import com.bolivariano.microservice.comprobantecvms.utils.IComprobanteUtils;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.rendering.PDFRenderer;

@Service
public class ComprobanteService {
	/*
	 * @Autowired private MQGateway mg;
	 */
	@Autowired
	private IComprobanteUtils utils;

	@Autowired
	public JmsTemplate jmsTemplate;

	@Autowired
	NotificacionesService notificacionesService;

	@Autowired
	WebServiceConfig config;
	
	@Value("${comprobante.folder}")
	private String COMPROBANTE_FOLDER;
	@Value("${comprobante.pdfFile}")
	private String PDF_FILE_PATH;

	@Bean
	public Comprobante comp() {
		Comprobante comprobante = new Comprobante();
		return comprobante;
	}



	@Value("${client.ws.address.vdtService.codigoDocumento}")
	private String codigoDoc;

	private static final Logger logger = LoggerFactory.getLogger(ComprobanteService.class);


	/*
	 * @PostConstruct private void probando() {
	 * 
	 * mg.onMessage(null); }
	 */
	public void registrarComprobante(Comprobante c) {
		try {
			// generar comprobante
			utils.registrarComprobante(c);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Cannot consume message - Exception error ", e.getMessage());
		}
	}


	public MensajeService connectMSVDT(Comprobante compb) {
		String mensajeRespt = "";
		int guardarDocRes = 0;

		Holder<String> mensajeRespuesta = new Holder<String>(mensajeRespt);
		Holder<Integer> guardarDocumentoResult = new Holder<Integer>(guardarDocRes);

		MensajeService result = new MensajeService();
		boolean existePdf = false;
		byte[] imagenDocumento = null;
		try {
			File pdfDest = new File(COMPROBANTE_FOLDER+PDF_FILE_PATH);
			existePdf = pdfDest.exists();
			if (existePdf) {
				imagenDocumento = Helper.encodeFileBase64(COMPROBANTE_FOLDER+PDF_FILE_PATH);
				Date temp = new Date(compb.getDateTrans());

				GregorianCalendar gcal = new GregorianCalendar(temp.getYear() + 1900, temp.getMonth(), temp.getDate(),
						temp.getHours(), temp.getMinutes(), temp.getSeconds());
				XMLGregorianCalendar fecha = DatatypeFactory.newInstance().newXMLGregorianCalendar(gcal);
				ServiceSoap consumer = config.getClienteVDT();
				//com.bolivariano.Service servc = new com.bolivariano.Service(new URL(domVDT));
				//ServiceSoap consumer = servc.getServiceSoap();

				logger.info("Informacion que viaja al ServiceSoap guardarDocumento");
				logger.info("codigoDoc: " + codigoDoc + " OfficeUser: " + compb.getOfficeUser() + " BenfNumberAccount: "
						+ compb.getBenfNumberAccount() + " fecha: " + fecha + " Sec: " + compb.getSec()
						+ " Ruta de la imagen documento: " +COMPROBANTE_FOLDER+ PDF_FILE_PATH);

				consumer.guardarDocumento(codigoDoc, compb.getOfficeUser(), compb.getBenfNumberAccount(), fecha,
						compb.getSec(), imagenDocumento, mensajeRespuesta, guardarDocumentoResult);

				result.setCode(guardarDocumentoResult.value);
				result.setMessage(mensajeRespuesta.value);

				if (guardarDocumentoResult.value != 0) {
					logger.error("Error connecting to Web Service VDT. Details: " + result.getMessage());
				}
			}
			else
			{
				logger.error("No existe PDF y no se envió a VDT");
			}
		} catch (Exception e) {
			result.setMessage(e.getMessage());
			result.setCode(601);
			logger.error("Error connecting to Web Service VDT " + mensajeRespuesta, e.getMessage());
		} finally {
			if (existePdf) {
				int height = compb.getBillDate() != null ? 120 : 280;
				notificacionesService.enviarComprobanteDeposito(compb, pdfToImgBase64(COMPROBANTE_FOLDER+PDF_FILE_PATH, height));
			}
		}

		return result;
	}


	private String pdfToImgBase64(String pathPdf, int height) {
		String ret = "";
		try {
			File sourceFile = new File(pathPdf);
			if (sourceFile.exists()) {
				PDDocument document = PDDocument.load(sourceFile);
				PDFRenderer pdfRenderer = new PDFRenderer(document);
				BufferedImage bim = pdfRenderer.renderImage(0);
				BufferedImage bim2 = bim.getSubimage(90, 70, bim.getWidth()-170, bim.getHeight()-height);
				byte[] by = Helper.toByteArray(bim2, "png");
				ret = Base64.getEncoder().encodeToString(by);
				document.close();
			} else {
				logger.error("PDF no existe: " + sourceFile.getName());
			}
		} catch (Exception e) {
			logger.error("Error al convertir PDF a imagen", e);
		}
		return ret;
	}


	public MensajeService consultarFirma(String ct) {

		MensajeService result = new MensajeService();
		try {
			RestTemplate restTemplate = config.getComprobanteCVPY();
			Map<String, Object> parameters = new HashMap<>();
			parameters.put("ct", ct);
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			//RestTemplate restTemplate = new RestTemplate();

			Map<String, Object> response = restTemplate.postForObject(config.getUrlConsultarFirma(), parameters, Map.class);
			if (response != null) {
				Integer codError = (Integer) response.get("code");
				result.setCode(codError != null ? codError : -1);
				if (codError == 0)
					result.setMessage((String) response.get("sign"));
				else
					logger.error("Error al consultar firma: " + (String) response.get("message"));
			}
		}

		catch (Exception e) {
			result.setCode(-1);
			result.setMessage(e.getMessage());
			logger.error("Error connecting MS Comprobante AWS (consultarFirmia)- Exception exception ", e);
		}
		return result;
	}


	public OutMsgGetTransaction consultarTransaccion(String ct) {
		OutMsgGetTransaction response = null;
		try {
			RestTemplate trxPy = config.getTransaccionCVPY();
			Map<String, Object> parameters = new HashMap<>();
			parameters.put("ctCode", ct);
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			response = trxPy.postForObject(config.getUrlConsultarTransaccion(), parameters, OutMsgGetTransaction.class);
		} catch (Exception e) {
			logger.error("Error en TransaccionCVPY", e);
			response = new OutMsgGetTransaction();
			response.setErrorCode("9999");
			response.setUserMessage("Error al consultar TransaccionCVPY");
			response.setSystemMessage(e.getMessage());
		}
		return response;
	}



	public MensajeService connectMSComprb(Comprobante compb) {
		String answerMessage = "Not found";
		int status_response = 404;
		MensajeService result = null;

		try {
			result = new MensajeService(status_response, answerMessage);

			ModelMapper modelMapper = new ModelMapper();
			MensajeComprobante data = modelMapper.map(compb, MensajeComprobante.class);
			status_response = requestServiceComp(data);
			answerMessage = Helper.answerMessage(status_response).getMensaje();// mensaje de respuesta

			if (status_response != 0)// hubo error de conexion
			{
				logger.error("Error connecting MS Comprobante AWS:"+ answerMessage);
			}

			result.setCode(status_response);
			result.setMessage(answerMessage);
		} catch (ResourceAccessException e) {
			// e.printStackTrace();
			answerMessage = e.getMessage();
			status_response = 401;

			result.setCode(status_response);
			result.setMessage(answerMessage);

			logger.error("Error connecting MS Comprobante AWS - Exception exception " + answerMessage, e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			answerMessage = e.getMessage();
			status_response = 601;

			result.setCode(status_response);
			result.setMessage(answerMessage);

			logger.error("Error connecting MS Comprobante AWS - Exception exception " + answerMessage, e.getMessage());
		}
		return result;
	}


	// consumir servicio del Comprobante en la Nube
	private int requestServiceComp(MensajeComprobante msg) {
		int status_response = 0;
		HttpHeaders headers = new HttpHeaders();
		try {
			RestTemplate restTemplate = config.getComprobanteCVPY();
			headers.setContentType(MediaType.APPLICATION_JSON);
			//RestTemplate restTemplate = new RestTemplate();
			ResponseEntity<String> response = restTemplate.postForEntity(config.getUrlGenerarComprobante(), msg, String.class);
			JSONParser parser = new JSONParser();

			Object object = parser.parse(response.getBody());
			JSONObject jsonObject = (JSONObject) object;
			String code = jsonObject.get("code").toString();
			status_response = Integer.parseInt(code);
		} catch (Exception e) {
			logger.error(
					"Exception error: " + ExceptionUtils.getMessage(e) + " Detail: " + ExceptionUtils.getStackTrace(e));
		}
		return status_response;
	}

}