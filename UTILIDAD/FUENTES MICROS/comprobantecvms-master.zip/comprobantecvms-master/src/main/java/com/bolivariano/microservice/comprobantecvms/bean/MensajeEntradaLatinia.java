package com.bolivariano.microservice.comprobantecvms.bean;

public class MensajeEntradaLatinia {
            String codigo_operacion;
            String codigo_mis;
            String identificacion_cliente;
            String nombre_cliente;
            String apellido_cliente;
            String descripcion_ciudad;
            String fecha_nacimiento;
            String estado_civil;
            String estado_cliente;
            String tipo_identificacion;
            String tipo_persona;
            
            
      public String getCodigo_operacion() {
    	        return codigo_operacion;
    	}

      public void setCodigo_operacion(String value) {
    	     this.codigo_operacion = value;
    	}
       
      public String getCodigo_mis() {
	        return codigo_mis;
       }

	  public void setCodigo_mis(String value) {
		     this.codigo_mis = value;
		}
       
     public String getIdentificacion_cliente() {
	        return identificacion_cliente;
      }

	  public void setIdentificacion_cliente(String value) {
		     this.identificacion_cliente = value;
		}	  
	  
	  public String getNombre_cliente() {
		        return nombre_cliente;
	     }

	  public void setNombre_cliente(String value) {
			     this.nombre_cliente = value;
			}
	  
	  public String getApellido_cliente() {
	        return apellido_cliente;
	  }

	  public void setApellido_cliente(String value) {
		     this.apellido_cliente = value;
		}

	  public String getDescripcion_ciudad() {
	        return descripcion_ciudad;
	  }

	  public void setDescripcion_ciudad(String value) {
		     this.descripcion_ciudad = value;
		}
	  
	  public String getFecha_nacimiento() {
	        return fecha_nacimiento;
	  }

	  public void setFecha_nacimiento(String value) {
		     this.fecha_nacimiento = value;
		}
	  
	  public String getEstado_civil() {
	        return estado_civil;
	  }

	  public void setEstado_civil(String value) {
		     this.estado_civil = value;
		}
	  
	  public String getEstado_cliente() {
	        return estado_cliente;
	  }

	  public void setEstado_cliente(String value) {
		     this.estado_cliente = value;
		}
	  
	  
	  public String getTipo_identificacion() {
	        return tipo_identificacion;
	  }

	  public void setTipo_identificacion(String value) {
		     this.tipo_identificacion = value;
		}
	  
	  public String getTipo_persona() {
	        return tipo_persona;
	  }

	  public void setTipo_persona(String value) {
		     this.tipo_persona = value;
		}

}
