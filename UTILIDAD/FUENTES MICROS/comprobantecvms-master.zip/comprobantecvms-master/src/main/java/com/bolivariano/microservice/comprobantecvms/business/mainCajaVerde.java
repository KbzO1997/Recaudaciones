package com.bolivariano.microservice.comprobantecvms.business;

import java.io.StringReader;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.jms.JMSException;
import javax.jms.TextMessage;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.bolivariano.microservice.comprobantecvms.bean.Comprobante;
import com.bolivariano.microservice.comprobantecvms.bean.CustomExcepcion;
import com.bolivariano.microservice.comprobantecvms.bean.MensajeRptaCola;
import com.bolivariano.microservice.comprobantecvms.bean.MensajeService;
import com.bolivariano.microservice.comprobantecvms.beantrn.Client;
import com.bolivariano.microservice.comprobantecvms.beantrn.OutMsgGetTransaction;
import com.bolivariano.microservice.comprobantecvms.beantrn.PayCard;
import com.bolivariano.microservice.comprobantecvms.beantrn.Transaction;
import com.bolivariano.microservice.comprobantecvms.dao.TransactionDAO;
import com.bolivariano.microservice.comprobantecvms.helper.Helper;
import com.bolivariano.microservice.comprobantecvms.helper.MQUtil;
import com.bolivariano.microservice.comprobantecvms.service.ComprobanteService;
import com.ibm.mq.MQMessage;
import com.ibm.mq.constants.MQConstants;

@Service
public class mainCajaVerde {

	private static final Logger logger = LoggerFactory.getLogger(mainCajaVerde.class);

	@Autowired
	private ComprobanteService comprobanteService;

	@Autowired
	private TransactionDAO transactionDao;

	@Value("${comprobanteCV.mq.host}")
	private String hostname;
	@Value("${comprobanteCV.mq.port}")
	private int port_number;
	@Value("${comprobanteCV.mq.channel}")
	private String channel;
	@Value("${comprobanteCV.mq.queue-manager}")
	private String queue_Manager;
	@Value("${comprobanteCV.mq.outcoming-queue}")
	private String outQueue;

	public void execute(TextMessage textMessage) {

		logger.info("Tipo de Transaccion Caja Verde");

		String answerMsgComprp = "", message = "", response = "";
		String idTrx = "";

		MensajeService answerMsgVDT = new MensajeService(), answerMsgComprob = new MensajeService();

		answerMsgComprob.setCode(404);// default code value

		try {
			message = textMessage.getText();
			logger.info("Mensaje :" + message);

			MQMessage mqmessage = new MQMessage();
			UUID idUUID = UUID.randomUUID();
			idTrx = "(" + idUUID.toString().replace("-", "") + ")";

			Document doc = convertStringToDocument(message);
			MensajeRptaCola responseToqueue = (MensajeRptaCola) getMsgQueueFromDocument(doc);

			responseToqueue.setCodRpta("0");
			responseToqueue.setMensajeRpta("Comprobante digital Caja Verde, generado exitosamente!");

			response = getQueueMessage(responseToqueue);
			mqmessage.correlationId = textMessage.getJMSMessageID().getBytes();
			mqmessage.messageType = MQConstants.MQMT_DATAGRAM;
			mqmessage.format = MQConstants.MQFMT_STRING;

			mqmessage.writeString(response);
			logger.info(idTrx + "<<***RESPONSE:" + mqmessage);

			logger.info("hostname: " + hostname + " channel: " + channel + " port_number: " + port_number
					+ " queue_Manager" + queue_Manager + " outQueue " + outQueue);
			MQUtil sender = new MQUtil(hostname, channel, port_number, queue_Manager, outQueue);
			sender.sendMessage(mqmessage);

			Comprobante c = (Comprobante) processMsgFromQueue(doc);
			
			c.setCurrency("DOLARES USD");

			LogModel(c);
			if (c.getTransactionType() != null && !c.getTransactionType().isEmpty()) {
				// Obtener Firma
				if (c.isDeposit()) {
					try {
					answerMsgVDT = comprobanteService.consultarFirma(c.getCodCt());
					if(answerMsgVDT.getCode()==0)
					c.setSign(answerMsgVDT.getMessage());
					//c.setSign("iVBORw0KGgoAAAANSUhEUgAAAOIAAADfCAMAAADcKv+WAAAAkFBMVEX////u7u7t7e3z8/P7+/v39/f19fUAAAD5+fnn5+eVlZXg4ODQ0NDf39/p6enV1dWurq6GhobAwMB5eXlnZ2ehoaFVVVVvb29FRUW6urrKysqSkpJdXV0+Pj4zMzMuLi4jIyOenp59fX1MTEwcHBw5OTmDg4MVFRWpqalJSUkpKSlhYWEYGBhra2tBQUENDQ0+GmxOAAAcnElEQVR4nN2da4OqLBeGUVCoNM1KUzvZ+TBN///fvYCiqFhWzn7nGT/tzSh3lxzWAhYIgLhMXcuuPAmKFJgniRTdyJPEczoSKShPym8i9aR/JFjk3kKR/HlEfe/9dcQI/3nEKdb/OuICd6H4qxHx7K8jWjj57yNml6QokpjilPU2QBNJkqK4JEVxSYq1pGeCGeLngqa4DCKuepJhmuCAHfoXIiVlVz3pUVbtkh7l/qpg8UrIw7ekQX/V06S3ZLxWBmY998eCtWJ5W7Co65Kiqq4P8RXJdd14rSVJiC0Fq43rbcG2iCTChz+OCEbYJX8ccY6H5p9G1Iw9Bt0o/lZE6Nx9lv6HEY2Q+jZPEbMk/Z8hthLM07RcEeVJuSJBJxwapeyN/K48yay/1Pw9F4rtBOu5vy1YXI/9qRu2eFJukv+VA9eh4EOv2AT4O80vrwhduOG63iT470capoavHSlKLzXP7jcgkhD3u0a0kiOO0W9B1FHMR1IdIg79++zkZoy/AZH2NnqniC4ObIBAuNN/CaKmL1awS8QpDrlgb+3BX4Jo4UNXiizJ5RaIChqX8N8iNpopOpJKhGIHZsphZcgFwdI1f35iA4rLQOLKk0iWAPo4JGlSfpOR35UnmSLFrGdV5G4a6w3IksDeBSpBROq5vy3Yzkc9417qD77sMoqkwp9ChyW/kwtSRKXg+z5qXbAdIr6ANooPWlKhaOGIN/suEFsJtkKEeJsldqC4vYJCcB/+EkSP+jZdIdq0zueCZPlbEPvYIl0pBkH285kgXHm/BHGM7a4UB3wKSAgOVtbvQNSW28KV+1BxsxdpTNDaD38HYg/fRFpdUX+pD0dHL3+QCoYLpeBDxNcE+W01W1mY3dQSg4j2Nm9aYrOcO3CXupQE3D1QCH5i+iuCXDS/Gh04EKcOV/aWPvGnUDAuFE0dnc5A6TF268BJig11HWxxUYnzev2WVwyxU1QgUwejtAVUBNWN6ydHGmCPi7s+UiQeNqX5Mx3NR78CETr3WUeI4HpA8vQUWp7Qb0A083mbzxWXoVlCxA75DYjkhMOij/hEEUZHOmApBDWEe2Zd8N8jotvdKbL/QFEH/W8gz6NCHfcUgv8e0djtYX26/i3EVQzk2XDDwsN/jKi0ixDiOehk/l0D2DZLiOFKUxlivd2EvwFa2kXB2riKYuNxR6sodBwFSss2caAS5D+whaA1zh98vGyTV4QmH5VNCL42z9DkFcdXJOdOwC1WCabF8lyw74Mngm0Rb1jryPEfx6XcCZj0P0Ec3zpCJD6G3SCa2/IQn4Cr+wEi3MWKivoOYm/lk24Q06YoIRrb6APEHg8h6QLRwpuORqgWruRur+0PED1s5z3QZ4gennaEeLpXcrcw/ABxhJGiC38HMWCDxU4Qr/0aokqwLaKPVVZKhZhbyIaou/W911HU3cUr504riEowQ3wmaC79wlt5HOZnPLwIwDtAHt/T7qI5RaiUAvqLJ+oPLhThuOXTBavSgTNtNtffxTwDtNa2VkoCwRi8UA/KgjDEJ9TSgZMQ641LN1w8oU2lA6/YdL9hOQmcT9mzheCDxlUS5BNKRhcjDRbA2O8GkUznoIKII+OFDquMiBbYgp0gkhsOSSdjGxTfUBXRehsRInzpad2MF2fYhp0gGn5cQTSxoxBsh2jYeG90gzjAfDmjA0S4Ckk5yb7bdcGWiCTEdJzRBSJxWH3oZhCOB2Y5KVwo3mk7RB1scNANIu1ttuzBzxHBAJNKj5r4pCYonnsmaM7x4X1E2UyBOb7Rx1XLIq8iRtioJMWT9NGW6zAlwcGamsW2iLmFVDpwq+MhzaLZnyqSHhlu4s0quYPRWCGY/+bHgg5mI7MO9mkAbbnbNLylF91wlIzLuetgPKoJtnbDwxTxgWBbxOjb7wgxn8TIczf96fuIB/+ud4N4mqe16WNEjXlrldzX3vuION4a3SD2g7gzRFfKnfZgWg877yMe4wnqAlEjvtsVIlmEUu6E/r5hsaT3MqLnB4fHgm0RIba7qqiDVSRyN4kejX1/i8cReRMxGfMJyw4QTYw6QoTOyhZpUYDxOHFHOMZ4it5CPIxeQXxgFw2nQGw2U60GtDBaZomDxXpim3Q0G84ACpfrHnjVLmoA7r2J+1hQRnywyxOc9uAwBp9sK82z8lYsH/r+8WZACWhKcgMmgDfa6Zgv5k56WP8O0UNBCadgNXXe0cn+1DwGcc2B4zdVvGLeR5arWZqa3xSu6H0owue8Gw02gJXICDvFAi0UeT0UNCw82DnmY0EiNoE8dsOpce7Pibquv+ijukvu1Mcwbw+zNHQQbFavjjRQPOfBgh2MNLRZBKZn2Ani9BvAK46kVeKVi1KY/eRFRHCeOljrBDG695C71DtBHF3N5V6XN3kuvRQI2sc8cqkdorb2HLabsgNEbw1IuO5mSHzwtz4ypdYCV1EWlwri3WuI1nIYdYR48IFJW3YniAG+paNBkeRcnAwImjvhv7ZDPH2DrhC3UwB73czd9HCAYCkpWvXETeS0MF9BnGzYWkEniNghGmLTZB9PbAy+sCWCibMkavkLHhFH+GhbaSFITSlF1Fsj5iGNppZGOVLFNIFgG1J1x2CxAeIuEQupGVkSQJpIIvUkxJLAcL2hiGlipghOZ1AIjhaA3whF0iPBIdYRK8VmQf7rRRJsduAMd8lHZhb4cGIDopUP8KCcO+pviwoEmQ1o68CRvs9CZB8IVh24vCJU3XA04vaK16FP3HCItksgI6b5bObFb9ANv4+etOZcEPmJWHH+cKQh5lYuyWeIOjgcB8RI1/mlF3jLJ6doEupfSVtEfR91hKhp6U6YSfARos62uSGzV0UkKze/iQ4hh3xdoQ0i5HTdINpp3eovHiMWTqdSkVj4hNgShF7O3SimNVgSWPXRky7SyCpXsuwIUaejAh5jFt4fv1RtJIbzKkXTwBtalIb1pcm5s5WlvHGyHghMZ88MnUC8xF0hssEiU+R9VzMiGGMx2FUpggnf4kHCSxmR1tySIIx28IlfbYh343SGOB+liMeHiiYerR4gnnCPPUvcPZRzZ1HiWkmwt/JaIZoRL/6XEBvsogawyxeanfWjiA10mp9mwu+om6kBdvmj5HQ2S4KoPzNLgmB2MtrYxcyUUUOqFFTaxYatHkDfWdyzoK/XKLZ6VHeugHEcB2LrZ76RRCSg7S3zZRJfZJ96N2AzAiVBNluu2ltSEQSEWkXqt9h321AISttUis0sBWtlZSpcDrnLCBcns9llHOLBpC+8z0o1o81ZhEeBZC4W2rJioURlwXgL2viotA2zem1/WdWJjUq9buGGJ/O0roNtgpoVbQzmrtjKVlGETrFLZ3RD5R8xn1YELbbf5flIg46FedO9eObHI43DjSvqdOjyAPG0gN9OAyKYFT7aaFxGhDO3IqjjJ4sUqeDITzusRWh8iojYGgRTRIc5aUZcuRaGUIWoIxcP8+cOB/Er0h9hXwYVQcg6kOeI6zCN2KC906eIEGeLW6y/b1ZcRdE935BYVtTXCckVN6Py9kBmbauCTgtEuLTScIZ5Qj5FHIimQX2vZkVr1dtM8h9fUgSjIyj2nWziZ4jkO2yBGO6NNJzhxvZDfIbYn2WLW1DHOmxSdM/g4iIVIrSxRwqrNq4guttay2CxnE8RY9a8GWJAa/6H4Qx8UZdPThuYmqBCUS8pXgF2oAJRB6MZ/ynZFcTlthiMalYq2LQIZ9ieMsTDuH0pijUAVCwCIIKoswEISlcJ7idAk7K7iiUGehf6dmkTEg9SS5zdRCAZ0iEUzJMoIoDZXSyFuk6AyIJUcTwGRe5qQdpgITPqJgTJBJUEa7/BEEmm2oGjLmMExVuiI0a1P6WZeBAu1CtTm2tWBulTwUjKnXmHllHxGNE4QM8cOBJiUejhHH02sQG9YzGhnmwbvGKT9knxrchKakn2PZJyLyNq7EG76vcjtu3isRtOO5kNyhqXdYGfjTSQuyqGb6dzAyJK9gZt9irE0becO/UfYpnHCPf6G4gaOp+MDHEojNqbiDrY3Ip5Sm9hNigGY33tKkf9laOq0KTY5cmsGm1J7yA6R0ucAEQ+jLvRARsECURn7QB1vZmfqNtV5FWcxpVsSSl3UEYEY7a2WEEMxo8jvgzqL6VuBv/vp6FFiG/zyBTNtadE1PR9yFaIaoiauU3KuZN5CdHcnki1FMnkKSIYX9MlSY4YfYRoRHx7qFBchmpEZ9frL+uI7BynSu6gjDhgb7CKOI+fINJ+2Ct2Vy+SjxDJtDStOR8rEQ0PAz9WlCKY3Cq5oxKiSYdgsIpoLt0niDCdicwQWeDNBxMbaHxIbVX6/9MOqMwUml6o4y9t8c7MlDbE+aRcZqZKiMy8gfpMCo6Mx3bRmM5gkZRcW9vF/Mp352h89oD/5rQIPMXRBZrBHE8jc/zTFyd+oPtdGeIzf1BOCm4VQSANbRqKhQqON9kbYfXanX0UVUzbioRIDbV6u/TFi5Y9BeKtMnKqIaYz4dXBlPk4qpiYs1OBCENquT9AdLJiE/3Hl3SMiISIbTrSqCPS8jCrimXENIaxjOg8m9ggA3kXGfR2g08Qw3sJ0fQL30RCpB4qn/GrIrrLfF+hGnHw3asjnpZPQhPBaS0j2pePtqJMAhmRDowCFWK0GvquAnEe1zvgEqI7Q3XEzQQ8QZyJEF3+nLEMP0G8e6VSNE5+vgotIfavBh7WEfWF9QRx6lcFAQ9jehLRehQhuunk17dLin36LyJCIDp9UVH5jHgNcbQBfE66gujtFIolxMlIgcj7kkexkNFFxELymSFw66O3EU3rWy8hsgV/BWIQR2wmpYo4nigUAwmRZCc7lxBtfpZYM6IOEl8kcUQUz99AzC5jKjITphXc8/XOYleCsXXHfIdDbqVTRFoF6oY76OexAWzoXhZkP8LbyYIKW05ueZ+XirmYtNy/qNi1uQlANWVbu4/0sHad1pKRjgf1Xau0VuV3AgvD+g10UPpwKykxsVPaxEqNN2q6uZJ33YEzLyciFwvgc4LVt4RsbHzXTzclzMuqlYE8JCaxT8qCbPS26AP94cqUg6FWFDp7CA/ymvHqxIaWHbQjTalZeAgrdZ1qDnYOlOs6Xx9gQ8FqSypNbID5CJUF2QMsjOnh3G98ReXGZXyHbx9dQP2MUv9Br+EyNKuI04WFixFqhqjpy9B4jAgX6TpPafTmHYfaY8TttIIIRqO3D6A47VEVEVxjsaCWX+NNuC9GqALRZkFCDxHttQWriGAzfhJ3Q3vcvLvNkvr5PPzLiL7wTiTEeIKqpeiHk6SKyIMg6oolxOhIKoK0Fe5d4zGid5ecgPRyty8dQGGiYul9EdZW02h/o1cRVxb2iKTIEcHhW7W7Gm0KRHeXxS4ViIaFUVmwhjgqDrcRgvZRbNRtg2g4Qa7orEWVkBSN7IRUCXEXyoNwgbhPniGOzlVEBCbbzJ43IuIQ1Ww5tsSIpk0pLoowGG9VX00jKKu9BeJwNTnDkiJbkUg3stcqqox4T2qlOMDpMmwzokGtbQ1xn4iSfY5oeHiVDwmT7/w+CXGaphaIznI/BmVEU4PazlEpyog4yjrsAjGYo4pg3ldmgrTd1Y+jovWhsRRrnwzx49MkM+5gJvXvhWm1sg1BeUq03IuToyQHzlvoQGW4R+MsTQqbEg4civKkphPEQDBGtRMvUDHR1+IACuy4IshXcrlLXnFWzCLFcLH4YbIbnrq3CsMdiNi3aC0SMzcc9lY3laBcLMN1aNTDmO08dvC5G+4ch846jUY3h3wMWFfMgivzrE5YdVpNf6JWTDKjo5H+XNTG9PRwCLYYI4WghGg6GMA6IjyLQfJzxCRgU6/8PjLdFnnJik76O3KcKZ5XFBlicGhA9MV+8LH44IHJ5tMhBAG+P0HUQXwBimB0FIi8niNuNrRBp7YVBZv8Lu50En5gJP33xS2VYozdiiJFzDZi1hVP5+o8kMeqLjIpofu0FMGyr0IsiuMposYOKNfv3KvtHT25FOmw7JSdd8OX2YvOdpzPB0uIMK3ldUV3L1Iu2WPjG4Cgj/ESJusniNCmRkWBaELRGJ8iDvj8REz9IRYDLB3AyA0dNlKn07nbEiLxF7CiSBG19MjfuqJ3yZLETCGiQ39tg/H6atJiFPZDjWi436Zq14SWz8C0QOTZ4wTQLr2PZFtuWhh7WQzc0ZUQ4T2oKlJEvQkx+so6VDFFa2MynGE80o678zBdUvbcBkS+9KjaGMIOeGiH6F7SN43dwWSvl9wV1J+fk2x05LLI1J7BbZdm8kVSe2qU7KKdVrnMTGlF3I2Nh3ywirKT0kD/6t3xgqLtryaLZKAp9/W42LVaINIfxJY7VCdBgXCNgCTYYBdZn3ZjIZEGO/KA2joiH+MNDiPqmPDIR4MFi1vHTRpsaWObGuMF2wlVnNkN3CUxi1BLAERAJunhXpp0C3j4JdcaaYAAVvu9y5C+YK/HDrjMHiRF9CXVMuRg0uKQcDJYe6ScpDo3nBYa7SvTpXc0qNY8dD2FM3ZgoQ71yO+TdX+XtvARpm96urOlODcKO7ry8Lc0abjDgY0y4yc6hp3Lgwa9AI8ll37rD3cJQGF2l4e3plYMbSbcJKtOfwfb9GN7ijCdko9Kdh7Uqst9onHtBgbWWV2nXSi+6hgE6ZLLDEPN/J6y8GpJMZiZZt6SglvvurOyj2UJV+grAqSXLO5XWzqW3bSXRx+xYSWPUHawuxYrPzo78c2VEeWGhJIVqTXdOiIcLpnrrEZkPdGZRTpRXa+PR5c4PSrSwxgSD0PgyttkwQ0X+3IHbC4xxhovV5CtdQ1WVjLBq/6Q+jbygubQNdj5T2h1pYzbgI5PtXyyKFqbTYhQx5rZAjHa642IJ8yGw1fHnmIKuv864jW/5X69Q/B9AJAID4BWcgjm49VBjPoTtsGDBCsLsK8as+6d2NEEH88jh4BqtYHZiUbaFgerPQRkG4tNP2CculHKM2eJz4v7CaJ5mqFGxC2rhxato/hEIBhtBzFOTL0X+NERsVGeTq03z0y/4Smt1q5Fu4y0afDNOqYR4E040HrfQRz4GO+2DgKG1vxOTW/ssvYXZmGuerYxrQmxPzOeliKfSdfVitRWelIqjGhfEy4orz8Mv8GBf6gYUQ/M80Y4CPF8QouUHSSY7gxgIxaahzXe0yeO680hoYZsBMRm9IffCyJgccjG4NNs/4MSEfaOjvqEM7kUqVeKmhCjWdrtIY3/MJN5etDuDQg4+fqSb+k24Wl9/LpaCPQ245VrAm+3Ze1ues4UTaANBsN0oxtZRkXuDxFR+JVOmxjnLMBFvUmLbb5RHsUnIxrrUxMiEs6cmGGc59vVkjGba9NLfTjtKFxadXsBLdIw9a34kQbsV/EAfr6c0QoR6eg8AemgDTQj8qUN8PSTIebFNpS7LLjpL216oIYr29gB+gdqLipbI0wwox0j9SHszWqdADkrMF3Q/wMLG0DKXSGY77IgA1rrIbGFO9DwyRBzgCPy5GthQATOtPk0KVsLSH21vn/PRxqFA3fOD7UZoPIxmuwACh3FC6NIeiboUkbnayI8saajPNlqZQffQhWIREzEoQSXlvuyajYLs2qWt+YckX1vDPh03NdeMFzjXZzHVDTtz2bTGx8cdVdFZMeRp5mfsOJwLPTdiOhdWNexd40XEMHQGRZxKo1b0Glhd4noHNNzFKlnk0/xtEK0LgOo2RcPvoLILpHSjJhcOkUE2SS/ZhSTWJLiuRGRzbFD74to3SP2VpIl6gDRv9bmslshsmBz0N+DH0Bkk4NdIno4TVUrbhsR4T6EYFn+nkZXiAOx5tsN4kCcAapGdJsQmcnkx9r+ACKYb2pBd69+C1XyHghbTG00Uzli3Sadp6CHB9qPfCPcW/dgVfCVT4bw+/MkEF/TGxXLlyY4nyoj1GJl15+C6ZZ5VS8K5kkqQZGwimuCr34oVKp54hAClctIi0qa2CjlzkKnN5tS7i0Fc0SVj5o95lUjtV//FqqsmM1dKhHnMSq/5zx3NNogv/zh0w4Q8yLbivmVThAPfjPiJB3kqRDdwE4nN34AkQXc9zpE9C7NiMGtsRTDSfV7Gh2WIgTf8w4Rh+n3S9UTYn4TIrHOh9sPIlrZ9EcniMAfNSkS78toQrSPX94PIoLRtkNEj8/qqxQNB5sNiMYQ352fRCTHfhNibiEbPhmSKUq2HPJpX9XJmnCI+ZKHIurO0LCP3hQUiI89hZD3ZqowvzbnYpZP3WSrLKqDOGmShnVSSipu0vAGtD6IU537k5+1wQZS5S6xtvKnNHbu1r7sMhZlYFychjIgOt8+rb/swLX+RokGz2OkdOAkxYd1XSjyPeKeatGWrfKk23RUbriTjTR/wg1Pz0ogA5zk93ww0uA/8jZXLb0zxdGtCTFmBzT9JKLGvgdU7Jn5DJFt3tPUism8ARGdcfLDiCxEvgga+giRHRDTJ2pFdoSMEjG6+KOfRqQZJXmQRYZovIeog9g31Yoa728UiMk5Gf88IkR9UVfTrwSbkflmKaLMXaor8reoQFy70+q3bX4AkWbl4pFANIC3x/A9RB0E1wbE+UaJ2MN6cq2Ee/4EIs3dma3dtLVEcxxoZcQ2Zir7fyQd41YyU2F6plrVJsVX1hO9YxfzrFp/uwudMA5Gh2CHAwfRHN/1p+YjkVb6gRqLb6gbbm1xAtN5JfeOHbhckP7dSQ6jJG9LeUV4zSuOxM6NajVbnOqHHJkWNsV+t59ywyVB2gplt+1dRGmbuKyo8zizKiLwAwBO2XEGP4/In/toMJVe0V0cp1xSNHv8bNxS7tBmHXA4g/8xRLAIgEoR3GNQqTeo7yMThAv9v4Y4yM5KqGwoQuFdOnaD67NBhgmi/xyiAQ7f1U0MqdxSOtyVPzLFSDOBtez91xBplRzVt4Xx1dXyh+Hh2kVU0V5WIuz+GeL7ZooOOKza/kVqo4xLERfH1jDiBWKKg0t5G8SP2cX0Un4ypNjx2S7JAKM9n+Fg/9M9kN1lUJvpAJ7I/oR6mP6JGKS3ttnT5vuC+XRGPUlcZj3p2bdQm98SexItD1kZQAsnxdbeEYZmXgZzHn5MoP3llIM4Op7YqBT6RxMbaV1PT/NjA4u0Wz1Ju5fJ2TdJ5nNnMXIEDr6ccuP6ITc8R6zl/p7iFPfS8QOxJURAvtcDtj9AA142Dv/vIoLNsse6Orb+Je1Bh1qAY40gY5qPUP+7iMDfQ8JOEBxN5JMEIHB3eD7e5ZGQFHFt/0cRjWBlAw2SZeXIC0IGh7Gb/y4Cnf8sIiA+PtFO9EurHj9joKJcKWK0GvxGxCzp8Rc8gLvG+GiR2pxfqQ83vf3wOWIrwfcR629QERsgUqR5VI3otqMbT+ITDHdRUXxfUFwtIzA+9qek8KGH/lQ+JP5XgrVX8uNecTKv5P77RxqvKvYnfx4xDv44opEfrvn3ECH/hJZumOIDtn8P0dnz2Q1DE3MBfxARD9j8qjEUG4b/SxMb2fV4QKvZdzb7oZNw/28EFXYx37Gh2OVZ/4KHaquHaiNJvmsE2HeHf+vssKnuXPkZwVruBb7yY/YduIz2MQ2U34oDUn5aMLu6HGk8W+5Lg/u0+ulVv2Ok0YFiFr8Y7ezqGWR/DdFdguqP+DOI2aE0h2x/x19EzMK2WXjY30Z0cK9I+r8jdtyHp4iHsUj7PxgNha3s1PTzDwAOd15+2w8LKkz/TztwFjtd5rArasu/d+DyivBDXnFvPTUTZbDVXxlp6OSE93wh/M8i0j9H4RBpfxpRgyaUm8ZfRKwo/nPE/wFr1OIXAscK/AAAAABJRU5ErkJggg==");
				
					}
					catch (Exception e) {
						logger.info("Error al consultar Firma", e);
					}
				}

				// Generar comprobante
				comprobanteService.registrarComprobante(c);
				// Enviar a py
				answerMsgComprob = comprobanteService.connectMSComprb(c);

				// Envio exitoso de datos
				if (answerMsgComprob.getCode() != 0) {
					logger.error("Error connecting MS-Comprobante AWS, "+ answerMsgComprob.getMessage());
				} else {
					logger.info("Connecction Successfull to MS-Comprobante AWS", answerMsgComprob);
				}

				// Conexion a servicio de VDT OnPremisse
				answerMsgVDT = comprobanteService.connectMSVDT(c);
				if (answerMsgVDT.getCode() != 0) {
					logger.error("Error connecting to Web Service VDT. Details: " + answerMsgVDT.getMessage());
				} else {
					logger.info("Connecction Successfull to Service VDT", answerMsgComprob);
				}
			} else {
				logger.info("No existe un tipo de transacción especificado");
			}

		} catch (Exception ex) {
			logger.error(
					"Error Method: execute in class mainCajaVerde.java. Detail: " + ExceptionUtils.getStackTrace(ex));
		}
	}

	public void executeTrx(TextMessage textMessage) {
		String code = "", msg = "";
		try {
			String message = textMessage.getText();
			logger.info("Mensaje :" + message);
			Map<String, String> outValTrx = getValTrx(message);
			String ctType = outValTrx.get("ctType");
			String ctCode = outValTrx.get("ctCode");

			if (ctType == null || ctCode == null) {
				throw new CustomExcepcion(Helper.codErrorGeneral, "No existe configuración para transacción",
						Helper.msjErrorGeneral);
			} else {
				Transaction trx = null;
				Map<?, ?> out = null;
				if (ctType.equals("1")) {
					OutMsgGetTransaction outTrx = comprobanteService.consultarTransaccion(ctCode);

					if ("0".equals(outTrx.getErrorCode())) {
						trx = outTrx.getTransaction();
						Helper.validaParametro(trx, "Transaccion");
						Helper.validaParametro(trx.getTypeNemonic(), "tipoTransaccion");

						switch (trx.getTypeNemonic()) {
						case "DP":
							out = transactionDao.guardarTransaccionDeposito(trx);
							break;
						case "TC":
							out = transactionDao.guardarTransaccionTarjeta(trx);
							break;
						case "PS":
							out = transactionDao.guardarTransaccionServicio(trx);
							break;

						default:
							throw new CustomExcepcion(Helper.codErrorGeneral, "No existe tipo de transaccion",
									Helper.msjErrorGeneral);
						}

						if (getValidate(out)) {
							code = "0";
							msg = "Ingreso correcto de transaccion";
							logger.info(msg);
						}

					} else {
						int err = outTrx.getErrorCode() != null ? Integer.valueOf(outTrx.getErrorCode())
								: Helper.codErrorGeneral;
						throw new CustomExcepcion(err, outTrx.getSystemMessage(), outTrx.getUserMessage());
					}

				} else if (ctType.equals("0")) {

					// Obtener de SQLServer
					out = transactionDao.getStatCreditCard(ctCode);
					trx = getTransaction(out);
					if (trx != null) {
						trx.setCtCode(ctCode);
						trx.setPayCard(consultarDatosTarjeta(trx.getPayCard()));
						out = transactionDao.guardarTransaccionTarjeta(trx);
						if (getValidate(out)) {
							code = "0";
							msg = "Ingreso correcto de transaccion (Estado de Cuenta)";
							logger.info(msg);
						}
					}
					else
					{
						throw new CustomExcepcion(Helper.codErrorGeneral,
								"No existe información de la transacción", Helper.msjErrorGeneral);					
					}

				} else {
					throw new CustomExcepcion(Helper.codErrorGeneral,
							"No existe configuración para transacción --> " + ctType, Helper.msjErrorGeneral);
				}
			}

		} catch (CustomExcepcion e) {
			code = Helper.codErrorGeneral.toString();
			msg = e.getMensaje() + ": " + e.getMessage();
			logger.error(msg, e);
		} catch (Exception e) {
			code =Helper.codErrorGeneral.toString();
			msg = "Error al Obtener Transacción: " + e.getMessage();
			logger.error(msg, e);
		} finally {
			try {
				senQueue(textMessage, code, msg);
			} catch (Exception e) {
				logger.error("Error al responder a la cola", e);
			}
		}

	}

	private Transaction getTransaction(Map<?, ?> in) {
		Transaction trx = null;
		List<Map<String, Object>> outList = (List<Map<String, Object>>) in.get("#result-set-1");
		if (outList != null && outList.size() > 0) {
			trx = new Transaction();
			Map<String, Object> rs = outList.get(0);
			PayCard payCard = new PayCard();
			Client cli = new Client();
			cli.setIdentification((String) rs.get("NUMERO_IDENTIFICACION"));
			cli.setName((String) rs.get("NOMBRE_CLIENTE"));
			payCard.setClient(cli);
			payCard.setCardNumber((String) rs.get("NUMERO_TARJETA_ENMASCARADO"));
			payCard.setCardNumberMaskZero((String) rs.get("NUMERO_TARJETA"));
			payCard.setCardKey((String) rs.get("CA_CUENTA"));
			payCard.setMinValue((BigDecimal) rs.get("PAGO_MINIMO"));
			payCard.setCashValue((BigDecimal) rs.get("PAGO_CONTADO"));
			payCard.setCardType((String) rs.get("TIPO_TARJETA"));
			payCard.setCardBrand((String) rs.get("MARCA_TARJETA"));
			trx.setPayCard(payCard);
			trx.setCreateDate((Date) rs.get("FECHA_CORTE"));
			trx.setCheck(false);
			trx.setMaxTime((Integer) rs.get("VIGENCIA_EN_HORAS"));
			trx.setTypeCode(86);
			trx.setAccessType("B");
		}
		if(trx!=null && trx.getPayCard()!=null && trx.getPayCard().getCardNumber()==null)
			trx = null;

		return trx;
	}
	
	private PayCard consultarDatosTarjeta(PayCard payCard) {
		Map<?, ?> out = transactionDao.consultarDatosTarjeta(payCard.getCardNumberMaskZero(),
				Integer.parseInt(payCard.getCardKey()));
		List<Map<String, Object>> outList = (List<Map<String, Object>>) out.get("#result-set-1");
		if (outList != null && outList.size() > 0) {
			Map<String, Object> rs = outList.get(0);
			payCard.setCardKey((String) rs.get("clave_unica"));
			payCard.setCardBrand((String) rs.get("marca"));
		}
		return payCard;
	}

	private boolean getValidate(Map<?, ?> out) throws CustomExcepcion {
		if (out == null || (Integer) out.get("s_codigo_retorno") != 0) {
			throw new CustomExcepcion(Helper.codErrorGeneral, "Error al ingresar Trasaccion en BD",
					Helper.msjErrorGeneral);
		}
		return true;
	}

	private void senQueue(TextMessage textMessage, String code, String msg) throws Exception {
		String message = textMessage.getText();
		MQMessage mqmessage = new MQMessage();
		UUID idUUID = UUID.randomUUID();
		String idTrx = "(" + idUUID.toString().replace("-", "") + ")";
		Document doc = convertStringToDocument(message);
		MensajeRptaCola responseToqueue = (MensajeRptaCola) getMsgQueueFromDocument(doc);
		responseToqueue.setCodRpta(code);
		responseToqueue.setMensajeRpta(msg);

		String response = getQueueMessage(responseToqueue);
		mqmessage.correlationId = textMessage.getJMSMessageID().getBytes();
		mqmessage.messageType = MQConstants.MQMT_DATAGRAM;
		mqmessage.format = MQConstants.MQFMT_STRING;

		mqmessage.writeString(response);
		logger.info(idTrx + "<<***RESPONSE:" + mqmessage);

		MQUtil sender = new MQUtil(hostname, channel, port_number, queue_Manager, outQueue);
		sender.sendMessage(mqmessage);
	}

	private Map<String, String> getValTrx(String message) {
		XPathFactory factory = XPathFactory.newInstance();
		XPath xPath = factory.newXPath();
		Document doc = convertStringToDocument(message);
		Map<String, String> ret = new HashMap<>();
		try {
			String ctCode = (String) xPath.evaluate("//Param[@name='@i_cod_ct']", doc.getDocumentElement(),
					XPathConstants.STRING);
			String ctType = (String) xPath.evaluate("//Param[@name='@i_tpct']", doc.getDocumentElement(),
					XPathConstants.STRING);
			ret.put("ctCode", ctCode);
			ret.put("ctType", ctType);
		} catch (XPathExpressionException e) {
			logger.error("Error al obtener valores de XML", e);
		}

		return ret;
	}

	private void LogModel(Comprobante comprobante) {
		logger.info("BenfNameAccount: " + comprobante.getBenfNameAccount() + "\n" + "BenfNumberAccount: "
				+ comprobante.getBenfNumberAccount() + "\n" + "BenfTypeAccount: " + comprobante.getBenfTypeAccount()
				+ "\n" + "Cantcheques: " + comprobante.getCantcheques() + "\n" + "Currency: "
				+ comprobante.getCurrency() + "\n" + "DateTrans: " + comprobante.getDateTrans() + "\n" + "EfeCheque: "
				+ comprobante.getEfeCheque() + "\n" + "Efectivo: " + comprobante.getEfectivo() + "\n" + "IpAgency: "
				+ comprobante.getIpAgency() + "\n" + "OfficeCode: " + comprobante.getOfficeCode() + "\n"
				+ "OfficeHours: " + comprobante.getOfficeHours() + "\n" + "OfficeUser: " + comprobante.getOfficeUser()
				+ "\n" + "Sec: " + comprobante.getSec() + "\n" + "ChequeLocal: " + comprobante.getAmountCheckOb() + "\n" + "\n" + "Total: " + comprobante.getTotal() + "\n"
				+ "TransCode: " + comprobante.getTransCode() + "\n" + "TransDescripction: "
				+ comprobante.getTransDescripction() + "\n" + "UniqueTransCode: " + comprobante.getUniqueTransCode()
				+ "\n" + "Uuid: " + comprobante.getUuid() + "\n");
	}

	private String getQueueMessage(MensajeRptaCola queue_data) {
		final String xmlColaSalida = "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?><CTSMessage>" + "<CTSHeader>"
				+ "<Field name=\"kernelHeader\" type=\"S\">" + queue_data.getKernelHeader() + "</Field>"
				+ "<Field name=\"fromServer\" type=\"S\">" + queue_data.getFromServer() + "</Field>"
				+ "<Field name=\"srv\" type=\"S\">" + queue_data.getSrv() + "</Field>"
				+ "<Field name=\"sesn\" type=\"N\">" + queue_data.getSesn() + "</Field>"
				+ "<Field name=\"o_error\" type=\"S\">" + queue_data.getCodRpta() + "</Field>"
				+ "<Field name=\"transaccion\" type=\"N\">" + queue_data.getTransaccion() + "</Field>"
				+ "<Field name=\"usuario\" type=\"N\">" + queue_data.getUsuario() + "</Field>"
				+ "<Field name=\"secuencial\" type=\"N\">" + queue_data.getSecuencial() + "</Field>"
				+ "<Field name=\"terminal\" type=\"N\">" + queue_data.getTerminal() + "</Field>" + "</CTSHeader>"
				+ "<Data>" + "<ProcedureResponse>" + "<Message msgNo=\"0\" type=\"3\">" + queue_data.getMensajeRpta()
				+ "</Message>" + "<return>" + queue_data.getCodRpta() + "</return>"
				+ "</ProcedureResponse></Data></CTSMessage>";

		return xmlColaSalida;
	}

	private Comprobante processMsgFromQueue(Document doc) {
		Comprobante c = new Comprobante();

		Node nodeList = doc.getFirstChild().getLastChild().getFirstChild();
		if(nodeList!=null)
		{
		NodeList params =nodeList.getChildNodes();// Params

		for (int i = 1; i < params.getLength(); i++)// iterando sobre Params
		{
			Node node = params.item(i).getFirstChild();
			if(node!=null) {
			String nodeString = node.getTextContent();
			String node_name_attribute = params.item(i).getAttributes().getNamedItem("name").getTextContent();

			if (node_name_attribute.equals("@i_nombre") || node_name_attribute.equals("@i_tipo_cta")
					|| node_name_attribute.equals("@i_nro_cuenta") || node_name_attribute.equals("@i_comprobante")
					|| node_name_attribute.equals("@i_moneda") || node_name_attribute.equals("@i_fecha_hora")
					|| node_name_attribute.equals("@i_ip") || node_name_attribute.equals("@i_oficina")
					|| node_name_attribute.equals("@i_usuario") || node_name_attribute.equals("@i_horario")
					|| node_name_attribute.equals("@i_secuencial") || node_name_attribute.equals("@i_cod_trx")
					|| node_name_attribute.equals("@i_desc_trx") || node_name_attribute.equals("@i_efectivo")
					|| node_name_attribute.equals("@i_nro_cheque") || node_name_attribute.equals("@i_cheque")
					|| node_name_attribute.equals("@i_total") || node_name_attribute.equals("@i_cod_ct")
					|| node_name_attribute.equals("@i_mail") || node_name_attribute.equals("@i_transaction_type")
					|| node_name_attribute.equals("@i_fecha_corte") || node_name_attribute.equals("@i_comprobanter")
					|| node_name_attribute.equals("@i_val_cheqob") || node_name_attribute.equals("@i_val_cheqmi")
					|| node_name_attribute.equals("@i_val_cheqny") || node_name_attribute.equals("@i_val_cheqop")
					|| node_name_attribute.equals("@i_debito") || node_name_attribute.equals("@i_ruc")
					|| node_name_attribute.equals("@i_ident_benef") || node_name_attribute.equals("@i_total_serv")
					|| node_name_attribute.equals("@i_saldo_fec") || node_name_attribute.equals("@i_clave_acceso")
					|| node_name_attribute.equals("@i_compañia") || node_name_attribute.equals("@i_num_compañia")
					|| node_name_attribute.equals("@i_tpcodserv") || node_name_attribute.equals("@i_num_categoria")
					|| node_name_attribute.equals("@i_categoria") || node_name_attribute.equals("@i_tp_servicio")
					|| node_name_attribute.equals("@i_mes_impago") || node_name_attribute.equals("@i_factura")
					|| node_name_attribute.equals("@i_mes_fact") || node_name_attribute.equals("@i_fecemi")
					|| node_name_attribute.equals("@i_comision") || node_name_attribute.equals("@i_direccion")) {
				if (node_name_attribute.equals("@i_nombre")) {
					c.setBenfNameAccount(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_tipo_cta")) {
					c.setBenfTypeAccount(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_nro_cuenta") || node_name_attribute.equals("@i_tpcodserv")) {
					c.setBenfNumberAccount(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_comprobante")) {
					// c.setUUID(node);
					c.setUuid(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_moneda")) {
					c.setCurrency(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_fecha_hora")) {
					c.setDateTrans(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_ip")) {
					// c.setIPAgency(node);
					c.setIpAgency(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_oficina")) {
					c.setOfficeCode(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_usuario")) {
					c.setOfficeUser(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_horario")) {
					c.setOfficeHours(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_secuencial")) {
					// c.setSEC(node);
					c.setSec(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_cod_trx")) {
					// c.setTRANSCODE(node);
					c.setTransCode(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_desc_trx")) {
					// c.setTRANSDESCRIPTION(node);
					c.setTransDescripction(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_efectivo")) {
					c.setEfectivo(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_nro_cheque")) {
					c.setCantcheques(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_cheque")) {
					c.setEfeCheque(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_total")) {
					c.setTotal(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_cod_ct")) {
					c.setCodCt(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_mail")) {
					c.setMail(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_transaction_type")) {
					c.setTransactionType(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_fecha_corte")) {
					c.setClosingDate(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_comprobanter")) {
					c.setCodeRec(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_debito")) {
					c.setAmountDebit(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_val_cheqob")) {
					c.setAmountCheckOb(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_val_cheqmi")) {
					c.setAmountCheckMi(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_val_cheqny")) {
					c.setAmountCheckNy(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_val_cheqop")) {
					c.setAmountCheckOp(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_ruc")) {
					c.setRucCompanyVal(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_ident_benef")) {
					c.setBenfIdetification(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_total_serv")) {
					c.setAmountVal(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_saldo_fec")) {
					c.setAmountToDate(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_clave_acceso")) {
					c.setAccesKey(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_compañia")) {
					c.setCompanyName(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_num_compañia")) {
					c.setCompanyId(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_categoria")) {
					c.setCategory(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_num_categoria")) {
					c.setCategoryId(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_tp_servicio")) {
					c.setTypeService(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_mes_impago")) {
					c.setUnpaidMonth(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_factura")) {
					c.setBill(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_mes_fact")) {
					c.setBillDate(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_fecemi")) {
					c.setStartDate(nodeString);
					continue;
				} else if (node_name_attribute.equals("@i_comision")) {
					c.setCommission(nodeString);
					continue;
				}
				else if (node_name_attribute.equals("@i_direccion")) {
					c.setDirection(nodeString);
					continue;
				}

			} else
				continue;
		}
		}
		}
		return c;
	}

	private MensajeRptaCola getMsgQueueFromDocument(Document doc) {
		MensajeRptaCola rpt = new MensajeRptaCola();

		
		
		Node nodeFields = doc.getFirstChild().getFirstChild();
		if(nodeFields!=null) {
		NodeList fields = nodeFields.getChildNodes();// Fields
		for (int i = 0; i < fields.getLength(); i++)// iterando sobre Fields
		{
			Node node = fields.item(i).getFirstChild();
			if(node!=null)
			{
			String nodeString = node.getTextContent();
			String node_name_attribute = fields.item(i).getAttributes().getNamedItem("name").getTextContent();

			if (node_name_attribute.equals("kernelHeader") || node_name_attribute.equals("fromServer")
					|| node_name_attribute.equals("srv") || node_name_attribute.equals("sesn")) {
				if (node_name_attribute.equals("kernelHeader")) {
					rpt.setKernelHeader(nodeString);
					continue;
				} else if (node_name_attribute.equals("fromServer")) {
					rpt.setFromServer(nodeString);
					continue;
				} else if (node_name_attribute.equals("srv")) {
					rpt.setSrv(nodeString);
					continue;
				} else if (node_name_attribute.equals("sesn")) {
					rpt.setSesn(nodeString);
					continue;
				}
			} else
				continue;
			}
		}
		}
		
		Node nodeParams = doc.getFirstChild().getLastChild().getFirstChild();
		if(nodeParams!=null) {
		NodeList params = nodeParams.getChildNodes();// Params

		for (int i = 1; i < params.getLength(); i++)// iterando sobre Params
		{
			Node node = params.item(i).getFirstChild();
			if(node!=null)
			{
			String nodeString = node.getTextContent();
			String node_name_attribute = params.item(i).getAttributes().getNamedItem("name").getTextContent();

			if (node_name_attribute.equals("@t_trn") || node_name_attribute.equals("@s_user")
					|| node_name_attribute.equals("@s_ssn") || node_name_attribute.equals("@s_term")) {

				if (node_name_attribute.equals("@t_trn")) {
					/*
					 * if(!node.equals(transCode)) { return null; }
					 */

					rpt.setTransaccion(nodeString);
					continue;
				} else if (node_name_attribute.equals("@s_user")) {
					rpt.setUsuario(nodeString);
					continue;
				} else if (node_name_attribute.equals("@s_ssn")) {
					rpt.setSecuencial(nodeString);
					continue;
				} else if (node_name_attribute.equals("@s_term")) {
					rpt.setTerminal(nodeString);
					continue;
				}
			} else
				continue;
		}
		}
		}
		return rpt;
	}

	private Document convertStringToDocument(String xmlStr) {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder;
		StringReader sr = null;
		Document doc = null;
		try {
			builder = factory.newDocumentBuilder();
			sr = new StringReader(xmlStr);
			InputSource is = new InputSource(sr);
			is.setEncoding("UTF-8");
			doc = builder.parse(is);			
			return doc;
		} catch (Exception e) {
			logger.error("Error", e);
		}
		finally {
			if (sr != null) {
				sr.close();
			}

		}
		return doc;
	}

}
