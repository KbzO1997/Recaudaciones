package com.bolivariano.microservice.comprobantecvms.business;
import java.io.StringReader;
import java.util.Map;
import java.util.UUID;

import javax.jms.TextMessage;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.bolivariano.microservice.comprobantecvms.bean.CustomExcepcion;
import com.bolivariano.microservice.comprobantecvms.bean.MensajeRptaCola;
import com.bolivariano.microservice.comprobantecvms.bean.PrestamoSaldo;
import com.bolivariano.microservice.comprobantecvms.bean.RespuestaPrestamo;
import com.bolivariano.microservice.comprobantecvms.dao.TransactionDAO;
import com.bolivariano.microservice.comprobantecvms.helper.MQUtil;
import com.ibm.mq.MQMessage;
import com.ibm.mq.constants.MQConstants;

@Service
public class MainPrestamosRH {

	private static final Logger logger = LoggerFactory.getLogger(MainPrestamosRH.class);

	@Autowired
	private TransactionDAO transactionDao;

	@Value("${comprobanteCV.mq.host}")
	private String hostname;
	@Value("${comprobanteCV.mq.port}")
	private int portNumber;
	@Value("${comprobanteCV.mq.channel}")
	private String channel;
	@Value("${comprobanteCV.mq.queue-manager}")
	private String queueManager;
	@Value("${comprobanteCV.mq.outcoming-queue}")
	private String outQueue;


	public void executeSaldo(TextMessage message)
	    {
		 logger.info("Tipo de Transaccion Prestamos");
	    	String mensaje = ""; 
	        String response = "";
	    	String idTrx = "";
	    	String respuesta = "";
	    	Map<?, ?> out = null;
	    	
	    	try
	    	{   	    		
	    		mensaje = message.getText();
	    		logger.info("Mensaje: "+mensaje);
	    		
	    		MQMessage mqmessage = new MQMessage();
	    		UUID idUUID = UUID.randomUUID();
				idTrx = "("+idUUID.toString().replace("-", "")+")";
				
	    		Document doc = convertStringToDocument(mensaje);	

				RespuestaPrestamo rptPrestamo = new RespuestaPrestamo();
				PrestamoSaldo ps = getparamSaldo(doc);

    			out = transactionDao.grabaSaldoPrestamo(ps);
				respuesta = getRespuesta(out);
				logger.info("o_msgerr {}",out.get("o_msgerr"));
					
				if (respuesta.compareTo("OK") == 0) 
				{						
					rptPrestamo.setcodigoRespuesta("0");					
					rptPrestamo.setmensajeError("PROCESO CORRECTO");
				}
				else
				{
					rptPrestamo.setcodigoRespuesta("999");				
					rptPrestamo.setmensajeError("ERROR");
				}
				rptPrestamo.setmensajeEjec(respuesta);	    			

				MensajeRptaCola responseToqueue = (MensajeRptaCola) getMensajeDoc(doc);    		
	    		
	    		responseToqueue.setCodRpta(rptPrestamo.getcodigoRespuesta());
	    		responseToqueue.setMensajeRpta(rptPrestamo.getmensajeEjec());
	    				    			
	    		response = respuestaColaPrestamo(responseToqueue);
	    			
	    		mqmessage.correlationId = message.getJMSMessageID().getBytes();
	        	mqmessage.messageType=MQConstants.MQMT_DATAGRAM;
	    		mqmessage.format=MQConstants.MQFMT_STRING;
	    				    			
	    		mqmessage.writeString(response);
				logger.info(idTrx + "<<***RESPONSE:" + mqmessage);
				logger.info(idTrx + "<<***RESPONSE:" + response);
	    			
	    		MQUtil sender = new MQUtil(hostname, channel, portNumber, queueManager, outQueue);
	    		sender.sendMessage(mqmessage);
	    		
	    	}	    		
	    	catch (Exception ex) 
	    	{
	    		logger.error("Error Method: execute in class MainPrestamosRH. Detail: " + ExceptionUtils.getStackTrace(ex));
	        }	    	
	    }
		
	private String getRespuesta(Map<?, ?> out) throws CustomExcepcion {
		return ((String) out.get("o_msgerr"));
	}
	
	private Document convertStringToDocument(String xmlStr) 
    {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, ""); // Compliant
        factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, ""); // compliant
        try  
        {  
        	DocumentBuilder builder = factory.newDocumentBuilder();
        	return builder.parse( new InputSource(new StringReader(xmlStr)));        	
        	
        } 
        catch (Exception e) 
        {  
            e.printStackTrace();  
        } 
        return null;
    }
	
	private PrestamoSaldo getparamSaldo(Document doc) {
		PrestamoSaldo psaldo = new PrestamoSaldo();

		Node nodeList = doc.getFirstChild().getLastChild().getFirstChild();
		if(nodeList!=null)
		{
		   NodeList params =nodeList.getChildNodes();// Params

		   for (int i = 1; i < params.getLength(); i++)// iterando sobre Params
		   {
			  Node node = params.item(i).getFirstChild();
			  if(node!=null) {
			    String nodeString = node.getTextContent();			
			    String nodeNameAttrib = params.item(i).getAttributes().getNamedItem("name").getTextContent();
			    switch (nodeNameAttrib) {
			    	case "@e_cedula": 
			    		psaldo.setCedula(nodeString);
			    		break;
			    	case "@e_op_banco":
			    		psaldo.setOpbanco(nodeString);
			    		break;
			    	case "@e_monto":
			    		psaldo.setMonto(nodeString);
			    		break;
			    	case "@e_saldo":
			    		psaldo.setSaldo(nodeString);
			    		break;
			    	case "@e_fecha_ini":
			    		psaldo.setFechaini(nodeString);
			    		break;
			    	case "@e_fecha_fin":
			    		psaldo.setFechafin(nodeString);
			    		break;
			    	case "@o_msgerr":
			    		psaldo.setMsgerror(nodeString);
			    		break;
			    	default:			    		
			    		break;
			    }
			  }
	       }
	}
    return psaldo;
}

	public String respuestaColaPrestamo(MensajeRptaCola queuDdata)
	{
		String xmlColaSalida;
		xmlColaSalida = "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?><CTSMessage>" + 
				"<CTSHeader>" + 
				"<Field name=\"kernelHeader\" type=\"S\">" + queuDdata.getKernelHeader()  + 
				"</Field> <Field name=\"fromServer\" type=\"S\">" + queuDdata.getFromServer() + 
				"</Field> <Field name=\"srv\" type=\"S\">" + queuDdata.getSrv() + 
				"</Field> <Field name=\"sesn\" type=\"N\">" + queuDdata.getSesn() +  
				"</Field> <Field name=\"transaccion\" type=\"N\">" + queuDdata.getTransaccion() +  
				"</Field> <Field name=\"usuario\" type=\"N\">" + queuDdata.getUsuario() +  
				"</Field> <Field name=\"secuencial\" type=\"N\">" + queuDdata.getSecuencial() +  
				"</Field> <Field name=\"terminal\" type=\"N\">" + queuDdata.getTerminal() + 
				"</Field> </CTSHeader>" + 
				"<Data>" + 	
				"<ProcedureResponse>" ; 

		xmlColaSalida = xmlColaSalida + "<ResultSet>" +
					"<Header>" +
					"<col name=\"CodigoRespuesta\" type=\"39\" len=\"20\" />" +
					"<col name=\"MensajeRespuesta\" type=\"39\" len=\"60\" />" +					
					"</Header>";
			xmlColaSalida = xmlColaSalida + 
					"<rw>" +
			        "<cd>" + queuDdata.getCodRpta() + "</cd>" + 
			        "<cd>" + queuDdata.getMensajeRpta() + "</cd>" + 
			        "</rw>";
			xmlColaSalida = xmlColaSalida + "</ResultSet>";
			xmlColaSalida = xmlColaSalida + "<return>" + queuDdata.getCodRpta() + "</return>" ;
    		xmlColaSalida = xmlColaSalida +  "</ProcedureResponse></Data></CTSMessage>"; 
		return xmlColaSalida;
	}
	
	private MensajeRptaCola getMensajeDoc(Document doc) {
		MensajeRptaCola rpt = new MensajeRptaCola();

		Node nodeFields = doc.getFirstChild().getFirstChild();
		if (nodeFields != null) {
			NodeList fields = nodeFields.getChildNodes();// Fields			
			rpt = extraFields(fields);			
		}
		
		Node nodeParams = doc.getFirstChild().getLastChild().getFirstChild();
		if(nodeParams!=null) {
		NodeList params = nodeParams.getChildNodes();// Params

		for (int i = 1; i < params.getLength(); i++)// iterando sobre Params
		{
			Node node = params.item(i).getFirstChild();
			if(node!=null)
			{
			String nodeString = node.getTextContent();
			String nodeNameAttrib = params.item(i).getAttributes().getNamedItem("name").getTextContent();
			switch (nodeNameAttrib) {
				case "@t_trn": 
					rpt.setTransaccion(nodeString);
					break;
				case "@s_user":
					rpt.setUsuario(nodeString);
					break;
				case "@s_ssn":
					rpt.setSecuencial(nodeString);
					break;
				case "@s_term":
					rpt.setTerminal(nodeString);
					break;
				default:					
					break;
				}		
			}
		}
		}
		return rpt;
	}

	private MensajeRptaCola extraFields(NodeList fields) {
		MensajeRptaCola rpt = new MensajeRptaCola();
		
		for (int i = 0; i < fields.getLength(); i++)// iterando sobre Fields
		{
			Node node = fields.item(i).getFirstChild();
			if (node != null) 
			{				
				String nodeString = node.getTextContent();
				String nodeNameAttrib = fields.item(i).getAttributes().getNamedItem("name").getTextContent();
				
				switch (nodeNameAttrib) {
					case "kernelHeader":
						rpt.setKernelHeader(nodeString);						
						break;
					case "fromServer":
						rpt.setFromServer(nodeString);						
						break;
					case "srv":
						rpt.setSrv(nodeString);						
						break;
					case "sesn":
						rpt.setSesn(nodeString);						
						break;
					default:				
						break;
				}
			}
		}
		return rpt;
	}

}
