package com.bolivariano.microservice.comprobantecvms.dao;

import java.util.Map;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;
import com.bolivariano.microservice.comprobantecvms.configuration.DataSourceManager;

@Component
public class StoredProcedureUtils {
	private  static final Logger logger = LoggerFactory.getLogger(StoredProcedureUtils.class);
	
	@Autowired
    private DataSourceManager dataSourceManager;
  
    public Map<?, ?> callStoredProcedureSybase(String schemaName, String procedureName, Map<String, Object> parameters, SqlParameter[] sqlParameters){
    	DataSource sybaseDataSource = dataSourceManager.sybaseDataSource();
    	SimpleJdbcCall simpleJdbcCall = dataSourceManager.sybaseSimpleJdbcCall(sybaseDataSource);
		simpleJdbcCall.withCatalogName(schemaName);
		simpleJdbcCall.withSchemaName("dbo");
		simpleJdbcCall.withProcedureName(procedureName);
		simpleJdbcCall.declareParameters(sqlParameters);
		simpleJdbcCall.withoutProcedureColumnMetaDataAccess();
		simpleJdbcCall.compile();
		MapSqlParameterSource inParams = new MapSqlParameterSource();
        if(null!=parameters) {
            for (Map.Entry<String, Object> parameter : parameters.entrySet()) {
                inParams.addValue(parameter.getKey(), parameter.getValue());
            }
        }
        logger.debug("PROCEDURE {} IS CALLED",procedureName);
        return simpleJdbcCall.execute(inParams);
    } 
    
    public Map<?, ?> callStoredProcedureSql(String schemaName, String procedureName, Map<String, Object> parameters, SqlParameter[] sqlParameters){
    	DataSource sqlDataSource = dataSourceManager.sqlDataSource();
    	SimpleJdbcCall simpleJdbcCall = dataSourceManager.sqlSimpleJdbcCall(sqlDataSource);
		simpleJdbcCall.withCatalogName(schemaName);
		simpleJdbcCall.withSchemaName("dbo");
		simpleJdbcCall.withProcedureName(procedureName);
		simpleJdbcCall.declareParameters(sqlParameters);
		simpleJdbcCall.withoutProcedureColumnMetaDataAccess();
		simpleJdbcCall.compile();
		MapSqlParameterSource inParams = new MapSqlParameterSource();
        if(null!=parameters) {
            for (Map.Entry<String, Object> parameter : parameters.entrySet()) {
                inParams.addValue(parameter.getKey(), parameter.getValue());
            }
        }
        logger.debug("PROCEDURE {} IS CALLED",procedureName);
        return simpleJdbcCall.execute(inParams);
    } 

  public Map<String, Object> callStoredProcedureSqlRH(String schemaName, String procedureName, Map<String, Object> parameters, SqlParameter[] sqlParameters)
  {
  //amejiaf CF-AP-SGC00044179-SGC00044608
	    DataSource sqlRHDataSourceExe = dataSourceManager.sqlRHDataSource();
	    logger.info("ConexionRRHH");         
        SimpleJdbcCall simpleJdbcCall = paramConexSqlRH(schemaName, procedureName, sqlParameters, dataSourceManager.sqlRHSimpleJdbcCall(sqlRHDataSourceExe));        
        simpleJdbcCall.compile();
		MapSqlParameterSource inParams = new MapSqlParameterSource();
        if(null!=parameters) {
          for (Map.Entry<String, Object> parameter : parameters.entrySet()) {
              inParams.addValue(parameter.getKey(), parameter.getValue());
          }
      }
      logger.info("Procedimiento ejecutado",procedureName);
      return simpleJdbcCall.execute(inParams);	  
  }

 private SimpleJdbcCall paramConexSqlRH(String schemaName, String procedureName, SqlParameter[] sqlParameters, SimpleJdbcCall paramJdbcCall) 
 {
	paramJdbcCall.withCatalogName(schemaName);
	paramJdbcCall.withSchemaName("dbo");
	paramJdbcCall.withProcedureName(procedureName);
	paramJdbcCall.declareParameters(sqlParameters);
	paramJdbcCall.withoutProcedureColumnMetaDataAccess();
	return (paramJdbcCall);
 }
}
