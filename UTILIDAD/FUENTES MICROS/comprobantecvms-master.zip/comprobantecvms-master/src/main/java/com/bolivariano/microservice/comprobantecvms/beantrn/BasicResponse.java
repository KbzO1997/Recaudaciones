package com.bolivariano.microservice.comprobantecvms.beantrn;

import java.io.Serializable;

public class BasicResponse implements Serializable{

	private static final long serialVersionUID = 5L;	

	private String errorCode;
	private String userMessage;
	private String systemMessage;
	
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getUserMessage() {
		return userMessage;
	}
	public void setUserMessage(String userMessage) {
		this.userMessage = userMessage;
	}
	public String getSystemMessage() {
		return systemMessage;
	}
	public void setSystemMessage(String systemMessage) {
		this.systemMessage = systemMessage;
	}
	
}
