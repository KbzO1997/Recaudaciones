package com.bolivariano.microservice.comprobantecvms.bean;

public class CustomExcepcion extends Exception
{
	private static final long serialVersionUID = 1L;
	public int codError;
	public String mensaje;
	
	public CustomExcepcion()
	{
		super();
	}	
	
	public CustomExcepcion(int errorcode, String message)
	{
		super();
		codError = errorcode;
		mensaje = message;
	}
	
	public CustomExcepcion(int errorcode, String systemMessage, String message)
	{
		super(systemMessage);
		codError = errorcode;
		mensaje = message;
	}
	
	
	
	public int getCodError() {
		return codError;
	}
	public void setCodError(int codError) {
		this.codError = codError;
	}
	public String getMensaje() {
		return mensaje;
	}
	public void setMensajeError(String mensajeError) {
		this.mensaje = mensajeError;
	}
}
