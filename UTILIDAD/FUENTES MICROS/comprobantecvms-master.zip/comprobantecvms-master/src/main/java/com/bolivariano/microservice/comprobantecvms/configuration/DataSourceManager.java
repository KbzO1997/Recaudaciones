package com.bolivariano.microservice.comprobantecvms.configuration;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

@Configuration
public class DataSourceManager {	
	
	/* SYBASE */
	@Primary
	@Bean(name = "sybaseDataSource")
	@ConfigurationProperties("spring.sybase.datasource")
	public DataSource sybaseDataSource() {
		return DataSourceBuilder.create().build();
	}

	public JdbcTemplate sybaseJdbcTemplate(@Qualifier("sybaseDataSource") DataSource sybaseDataSource) {
		return new JdbcTemplate(sybaseDataSource);
	}

	public SimpleJdbcCall sybaseSimpleJdbcCall(@Qualifier("sybaseDataSource") DataSource sybaseDataSource) {
		return new SimpleJdbcCall(sybaseDataSource);
	}
	
	@Bean(name = "sqlDataSource")
	@ConfigurationProperties("spring.sqlCardStatus.datasource")
	public DataSource sqlDataSource() {
		return DataSourceBuilder.create().build();
	}

	public JdbcTemplate sqlJdbcTemplate(@Qualifier("sqlDataSource") DataSource sqlDataSource) {
		return new JdbcTemplate(sqlDataSource);
	}

	public SimpleJdbcCall sqlSimpleJdbcCall(@Qualifier("sqlDataSource") DataSource sqlDataSource) {
		return new SimpleJdbcCall(sqlDataSource);
	}

	@Bean(name = "sqlRHDataSource")
	@ConfigurationProperties("spring.sqlPrestamos.datasource")
	public DataSource sqlRHDataSource() {
		return DataSourceBuilder.create().build();
	}

	public JdbcTemplate sqlRHJdbcTemplate(@Qualifier("sqlRHDataSource") DataSource sqlRHDataSource) {
		return new JdbcTemplate(sqlRHDataSource);
	}

	public SimpleJdbcCall sqlRHSimpleJdbcCall(@Qualifier("sqlRHDataSource") DataSource sqlRHDataSource) {
		return new SimpleJdbcCall(sqlRHDataSource);
	}
}
