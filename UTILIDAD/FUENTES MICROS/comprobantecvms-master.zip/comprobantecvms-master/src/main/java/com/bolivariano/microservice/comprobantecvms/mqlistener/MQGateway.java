package com.bolivariano.microservice.comprobantecvms.mqlistener;

import java.io.StringReader;

import javax.inject.Named;
import javax.jms.TextMessage;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.transaction.annotation.Transactional;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.bolivariano.microservice.comprobantecvms.bean.Configuration;
import com.bolivariano.microservice.comprobantecvms.bean.MensajeRptaCola;
import com.bolivariano.microservice.comprobantecvms.bean.MensajeSalidaMis;
import com.bolivariano.microservice.comprobantecvms.business.mainCajaVerde;
import com.bolivariano.microservice.comprobantecvms.business.mainLatina;
import com.bolivariano.microservice.comprobantecvms.business.mainNotificaciones;
import com.bolivariano.microservice.comprobantecvms.business.MainPrestamosRH;
import com.bolivariano.microservice.comprobantecvms.helper.Helper;

@Named
@Transactional
public class MQGateway {
	
	private static final Logger logger = LoggerFactory.getLogger(MQGateway.class);
	
	@Value("${package.business}")
	private String packageBusiness;
	
	@Autowired
	private mainCajaVerde cajaVerde;
	
	//NPME-AP-SGC00035818-SGC00037579 - fmirandg
	@Autowired
	private mainLatina Latinia;
	
	//NPME-AP-SGC00035818-SGC00037402 - llanchip
	@Autowired
	private mainNotificaciones misNotificaciones;
	
	// wlopezc - TCRE-CC-SGC00041008
	//@Autowired
	//private mainNotificaciones misNotiVreferen;
		
    //amejiaf CF-AP-SGC00044179-SGC00044608
	@Autowired
	private MainPrestamosRH prestamosRH;

    @JmsListener(destination = "${comprobanteCV.mq.incoming-queue}",
    			 containerFactory = "defaultJmsListenerContainerFactory", concurrency="1-5")
    public void onMessage(TextMessage message)
    {
    	mainComprobante(message);
    }
    
    private void mainComprobante(TextMessage message) {
    	String _message = "";
    	Helper helper = new Helper();
    	MensajeSalidaMis msgError = new MensajeSalidaMis();
		try 
		{
			_message = message.getText();
			Document doc = convertStringToDocument(_message);	
			MensajeRptaCola responseToqueue = (MensajeRptaCola)getMsgQueueFromDocument(doc);
			
			Configuration configuration =  helper.readJsonFileConfiguration(responseToqueue.getTransaccion());
			
			if(configuration.getCode() == 0) {
				switch(configuration.getIdtransaction()) {
					case "62677":
						cajaVerde.execute(message);
					break;
					case "15501":
						Latinia.execute(message);;
					break;
					case "15502": //NPME-AP-SGC00035818-SGC00037402 - llanchip
						misNotificaciones.execute(message);
					break;
					//case "15503": //wlopezc TCRE-CC-SGC00041008
					//	misNotiVreferen.execute(message);
					//break;
					case "62682":
						cajaVerde.executeTrx(message);
					break;
					//amejiaf CF-AP-SGC00044179-SGC00044608 15504
					case "15504": 
						prestamosRH.executeSaldo(message);
					break;					
					default:
						logger.info("Objeto no existe");
						msgError.setMensaje_ejecucion("Error al enviar la notificacion");
						msgError.setCodigo_respuesta("800");
						msgError.setMensaje_error("Error en envio de notificación");
					break;
				}
			}
		}
		catch (Exception e) {
			logger.error("Exception error " + ExceptionUtils.getStackTrace(e));
			msgError.setMensaje_ejecucion("Error al enviar la notificacion");
			msgError.setCodigo_respuesta("900");
			msgError.setMensaje_error("Error en envio de notificación: " + e.getMessage());
		}
    }
    
    private MensajeRptaCola getMsgQueueFromDocument(Document doc)
    {
    	MensajeRptaCola rpt = new MensajeRptaCola();
    	
    	NodeList fields = doc.getFirstChild().getFirstChild().getChildNodes();//Fields
        NodeList params = doc.getFirstChild().getLastChild().getFirstChild().getChildNodes();//Params
           
        for (int i = 0; i < fields.getLength(); i++)//iterando sobre Fields
        {
        	String node = fields.item(i).getFirstChild().getTextContent();
        	String node_name_attribute = fields.item(i).getAttributes().getNamedItem("name").getTextContent();
        	
        	if(node_name_attribute.equals("kernelHeader") ||
        			node_name_attribute.equals("fromServer") ||
        			node_name_attribute.equals("srv") ||
        			node_name_attribute.equals("sesn"))
        	{
        		if(node_name_attribute.equals("kernelHeader"))
            	{
            		rpt.setKernelHeader(node);
            		continue;
            	}
            	else if(node_name_attribute.equals("fromServer"))
            	{
            		rpt.setFromServer(node);
            		continue;
            	}
            	else if(node_name_attribute.equals("srv"))
            	{
            		rpt.setSrv(node);
            		continue;
            	}
            	else if(node_name_attribute.equals("sesn"))
            	{
            		rpt.setSesn(node);
            		continue;
            	}
        	}
        	else
        		continue;
		}   
        for (int i = 1; i < params.getLength(); i++)//iterando sobre Params
        {
        	//String node = params.item(i).getFirstChild().getTextContent();
        	Node nodeAux = params.item(i).getFirstChild();
			if (nodeAux != null) {
        		String nodeString = nodeAux.getTextContent();
            	String node_name_attribute = params.item(i).getAttributes().getNamedItem("name").getTextContent();
            	
        	if(node_name_attribute.equals("@t_trn") ||
        			node_name_attribute.equals("@s_user") ||
        			node_name_attribute.equals("@s_ssn") ||
        			node_name_attribute.equals("@s_term"))
        	{
        		
        		if(node_name_attribute.equals("@t_trn"))
            	{
        			/*
        			if(!node.equals(transCode)) {
        				return null;
        			}
        			*/
        				
            		rpt.setTransaccion(nodeString);
            		continue;
            	}
            	else if(node_name_attribute.equals("@s_user"))
            	{
            		rpt.setUsuario(nodeString);
            		continue;
            	}
            	else if(node_name_attribute.equals("@s_ssn"))
            	{
            		rpt.setSecuencial(nodeString);
            		continue;
            	}
            	else if(node_name_attribute.equals("@s_term"))
            	{
            		rpt.setTerminal(nodeString);
            		continue;
            	}
        	}
        	else
        		continue;
        }
		}
        return rpt;
    }
    
    private Document convertStringToDocument(String xmlStr) 
    {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();  
        DocumentBuilder builder;  
        try  
        {  
            builder = factory.newDocumentBuilder();  
            Document doc = builder.parse( new InputSource(new StringReader(xmlStr))); 
            return doc;
        } catch (Exception e) {  
            e.printStackTrace();  
        } 
        return null;
    }
    
}