package com.bolivariano.microservice.comprobantecvms.beantrn;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class Transaction implements Serializable  {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6477464697527072041L;
	private Integer idTransaction;
	private String ctCode;
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "America/Guayaquil")
	private Date createDate;
	private Integer maxTime;
	private Integer maxTransaction;
	private String typeNemonic;
	private Integer typeCode;
	private String accessType;

	private Session session;
	private Client depositor;
	private Deposit deposit;
	private PayCard payCard;
	private PayService payService;

	private Boolean check;
	
	
	public Integer getMaxTransaction() {
		return maxTransaction;
	}

	public void setMaxTransaction(Integer maxTransaction) {
		this.maxTransaction = maxTransaction;
	}	

	public Integer getIdTransaction() {
		return idTransaction;
	}

	public void setIdTransaction(Integer idTransaction) {
		this.idTransaction = idTransaction;
	}

	public String getCtCode() {
		return ctCode;
	}

	public void setCtCode(String ctCode) {
		this.ctCode = ctCode;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Integer getMaxTime() {
		return maxTime;
	}

	public void setMaxTime(Integer maxTime) {
		this.maxTime = maxTime;
	}

	public String getTypeNemonic() {
		return typeNemonic;
	}

	public void setTypeNemonic(String typeNemonic) {
		this.typeNemonic = typeNemonic;
	}

	public Integer getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(Integer typeCode) {
		this.typeCode = typeCode;
	}

	public String getAccessType() {
		return accessType;
	}

	public void setAccessType(String accessType) {
		this.accessType = accessType;
	}

	public Session getSession() {
		return session;
	}

	public void setSession(Session session) {
		this.session = session;
	}

	public Client getDepositor() {
		return depositor;
	}

	public void setDepositor(Client depositor) {
		this.depositor = depositor;
	}

	public Deposit getDeposit() {
		return deposit;
	}

	public void setDeposit(Deposit deposit) {
		this.deposit = deposit;
	}

	public PayCard getPayCard() {
		return payCard;
	}

	public void setPayCard(PayCard payCard) {
		this.payCard = payCard;
	}

	public PayService getPayService() {
		return payService;
	}

	public void setPayService(PayService payService) {
		this.payService = payService;
	}
	
	public Boolean getCheck() {
		return check;
	}

	public void setCheck(Boolean check) {
		this.check = check;
	}
	// servicio

}
