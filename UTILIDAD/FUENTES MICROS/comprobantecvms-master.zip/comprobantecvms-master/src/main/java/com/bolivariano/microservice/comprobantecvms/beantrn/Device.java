package com.bolivariano.microservice.comprobantecvms.beantrn;

import java.io.Serializable;
public class Device  implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1461282265851019453L;
	private Integer deviceId;
	private String uuId;
	private String macAddress;
	private String operatingSystem;

	
	public String getUuId() {
		return uuId;
	}
	public void setUuId(String uuId) {
		this.uuId = uuId;
	}
	public Integer getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(Integer deviceId) {
		this.deviceId = deviceId;
	}
	public String getMacAddress() {
		return macAddress;
	}
	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}
	public String getOperatingSystem() {
		return operatingSystem;
	}
	public void setOperatingSystem(String operatingSystem) {
		this.operatingSystem = operatingSystem;
	}	
	
}
