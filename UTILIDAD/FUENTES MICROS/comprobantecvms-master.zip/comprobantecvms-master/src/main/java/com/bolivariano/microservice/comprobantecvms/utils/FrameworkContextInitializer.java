package com.bolivariano.microservice.comprobantecvms.utils;

import com.bolivariano.frameworkseguridadtypes.LoginAplicacionIn;
import com.bolivariano.frameworkseguridadtypes.LoginAplicacionOut;
import com.bolivariano.frameworkseguridadtypes.LoginAplicacionTypeIn;
import com.bolivariano.frameworkseguridadtypes.LoginAplicacionTypeOut2;
import com.oracle.xmlns.sca_bloqueologinusuario.frameworkseguridad.frameworkmediator.FrameworkMediatorEp;
import com.oracle.xmlns.sca_bloqueologinusuario.frameworkseguridad.frameworkmediator.FrameworkPtt;

import java.net.URL;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MapPropertySource;
import org.springframework.core.env.PropertySource;

public class FrameworkContextInitializer implements ApplicationContextInitializer<ConfigurableApplicationContext> {
	private static Logger logger = LoggerFactory.getLogger(FrameworkContextInitializer.class);
	
	public void initialize(ConfigurableApplicationContext applicationContext) {
		ConfigurableEnvironment environment = applicationContext.getEnvironment();
		PropertySource<?> propertySource= null;
		try{
			Iterator<PropertySource<?>> propertySourceIt= environment.getPropertySources().iterator();
			while(propertySourceIt.hasNext()) {
				PropertySource<?> propertySourceTmp= propertySourceIt.next();
				if(propertySourceTmp.getName().contains("applicationConfig")) {
					propertySource= propertySourceTmp;
					break;
				}
			}
			if(propertySource != null) {
				Map<String, Object> encryptedProperties = new LinkedHashMap<String, Object>();
				String prefix= propertySource.getProperty("client.ws.address.framework.prefix")!=null?propertySource.getProperty("client.ws.address.framework.prefix").toString():"";
				String cvPrefix= propertySource.getProperty("client.ws.address.framework.cvPrefix")!=null?propertySource.getProperty("client.ws.address.framework.cvPrefix").toString():"";
				String urlFramework = propertySource.getProperty("client.ws.address.framework.url")!=null?propertySource.getProperty("client.ws.address.framework.url").toString():"";
				String tipo = propertySource.getProperty("client.ws.address.framework.tipo")!=null?propertySource.getProperty("client.ws.address.framework.tipo").toString():"PY";
				if(prefix.isEmpty()) {
					logger.info("no se realizo la carga de propiedades del framework: falta propiedad client.ws.address.framework.prefix");
					return;
				}else if(urlFramework.isEmpty()) {
					logger.info("no se realizo la carga de propiedades del framework: falta propiedad client.ws.address.framework.url");
					return;
				}
				
				System.setProperty("javax.net.ssl.trustStore", propertySource.getProperty("client.ssl.trustStore") + "");
				//System.setProperty("javax.net.ssl.trustStorePassword", propertySource.getProperty("client.ssl.trustStorePassword") + "");
				
				FrameworkMediatorEp service = new  FrameworkMediatorEp(new URL(urlFramework));    	
		    	FrameworkPtt fmwSoap = service.getFrameworkPt();
		    	
		    	LoginAplicacionTypeOut2 out= loginFramework(fmwSoap, propertySource.getProperty("client.ws.address.framework.appId") + "", (String) propertySource.getProperty("client.ws.address.framework.appUser"));
		    	LoginAplicacionTypeOut2 out2= loginFramework(fmwSoap, propertySource.getProperty("client.ws.address.framework.cvAppId") + "", (String) propertySource.getProperty("client.ws.address.framework.cvAppUser"));
		    	out.getCampo().addAll(out2.getCampo());
		    	
		    	//		    	LoginAplicacionIn request= new LoginAplicacionIn();
//		    	LoginAplicacionTypeIn loginAplicacionTypeIn= new LoginAplicacionTypeIn();
//		    	loginAplicacionTypeIn.setIdAplicacion(propertySource.getProperty("client.ws.address.framework.appId") + "");
//		    	loginAplicacionTypeIn.setUsuario((String) propertySource.getProperty("client.ws.address.framework.appUser"));
//		    	request.setLoginAplicacionIn(loginAplicacionTypeIn);
//		    	
		    	//LoginAplicacionOut response= fmwSoap.loginAplicacion(request);
		    	//LoginAplicacionTypeOut2 out= response.getLoginAplicacionOut();
		    	
		    	//out.getCampo().addAll(out.getCampo());
		    	
		    	
		    	int length= prefix.length()+1;
		    	int cvLength= cvPrefix.length()+1;
		    	for(LoginAplicacionTypeOut2 .Campo campo:out.getCampo()){
		    		if(campo.getNombre().startsWith(prefix) || campo.getNombre().startsWith(cvPrefix)){
		    			int lengthAux = campo.getNombre().startsWith(prefix)?length:cvLength;
		    			String nombrePropiedad = campo.getNombre().substring(lengthAux);
		    			encryptedProperties.put(nombrePropiedad, campo.getValue());
		    			if(tipo.equals("PY") && (nombrePropiedad.contains("server") || nombrePropiedad.contains("datasource"))) {
		    				encryptedProperties.remove(nombrePropiedad);
		    			}
		    		} 
		    	}
		    	if (!encryptedProperties.isEmpty()) {
	                PropertySource<?> newProperties = new MapPropertySource("decoded"+propertySource.getName(), encryptedProperties);
	                environment.getPropertySources().addBefore(propertySource.getName(), newProperties);
	                logger.info("se cargaron las propiedades del framework con exito");
	            }else{
	            	logger.error("error al cargar propiedades del framework: no se encontro ninguna configuracion en el framework");
	            }
	    	}else{
            	logger.error("error al cargar propiedades del framework: no se encontro application properties");
            }
		}catch (Exception e) {
			logger.error("error al cargar propiedades del framework", e);
		}
		
	}
	private LoginAplicacionTypeOut2 loginFramework(FrameworkPtt fmwSoap , String appId, String appUser)
	{    	
    	LoginAplicacionIn request= new LoginAplicacionIn();
    	LoginAplicacionTypeIn loginAplicacionTypeIn= new LoginAplicacionTypeIn();
    	loginAplicacionTypeIn.setIdAplicacion(appId);
    	loginAplicacionTypeIn.setUsuario(appUser);
    	request.setLoginAplicacionIn(loginAplicacionTypeIn);
    	return fmwSoap.loginAplicacion(request).getLoginAplicacionOut();
	}

}
