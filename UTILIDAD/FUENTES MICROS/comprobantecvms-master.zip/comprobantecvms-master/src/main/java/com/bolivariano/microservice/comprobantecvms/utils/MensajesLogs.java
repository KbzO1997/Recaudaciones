package com.bolivariano.microservice.comprobantecvms.utils;

import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;

public class MensajesLogs {
	
	public static final String construirCabeceras(HttpServletRequest request) {
		String appHeaders = "\n[REQUEST]\n";
		Enumeration headerNames = request.getHeaderNames();
		while (headerNames.hasMoreElements()) {
			String key = (String) headerNames.nextElement();
			String value = request.getHeader(key);
			appHeaders+="["+key+": "+value+"]\n";
		}
		String clientIP = request.getRemoteAddr();
        String clientHost = request.getRemoteHost();
        appHeaders += "[client IP  : " + clientIP+"]\n"+"[client Host: " + clientHost+"]\n";
        return appHeaders;
	}
	
}
