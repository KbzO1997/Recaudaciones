package com.bolivariano.microservice.comprobantecvms.bean;

public class Configuration extends MensajeService {

	private String idtransaction;
	private String className;
	private String mainMethod;
	private String application;
	
	public String getIdtransaction() {
		return idtransaction;
	}
	public void setIdtransaction(String idtransaction) {
		this.idtransaction = idtransaction;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getMainMethod() {
		return mainMethod;
	}
	public void setMainMethod(String mainMethod) {
		this.mainMethod = mainMethod;
	}
	public String getApplication() {
		return application;
	}
	public void setApplication(String application) {
		this.application = application;
	}
	
	
	
}
