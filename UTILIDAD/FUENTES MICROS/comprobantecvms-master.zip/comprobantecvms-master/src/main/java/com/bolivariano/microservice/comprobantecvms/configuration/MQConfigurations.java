package com.bolivariano.microservice.comprobantecvms.configuration;

import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Session;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.connection.JmsTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import com.ibm.mq.jms.MQConnectionFactory;
import com.ibm.msg.client.wmq.WMQConstants;

@Configuration
@EnableJms
public class MQConfigurations 
{

	@Value("${comprobanteCV.mq.queue-manager}")
	private String queueManager;
	
	@Value("${comprobanteCV.mq.host}")
	private String host;
	
	@Value("${comprobanteCV.mq.port}")
	private Integer port;
	
	@Value("${comprobanteCV.mq.channel}")
	private String channel;

	@Bean
	public ConnectionFactory connectionFactory() {
		MQConnectionFactory factory = null;
		try {
			
			factory = new MQConnectionFactory();
			factory.setHostName(host);
			factory.setPort(port);
			factory.setQueueManager(queueManager);
			factory.setChannel(channel);
			factory.setTransportType(WMQConstants.WMQ_CM_CLIENT);
		}
		catch (JMSException e) {
			throw new RuntimeException(e);
		}
		return factory;
	}

	@Bean
	public PlatformTransactionManager transactionManager(ConnectionFactory connectionFactory) {
		return new JmsTransactionManager(connectionFactory);
	}

	@Bean
	public DefaultJmsListenerContainerFactory defaultJmsListenerContainerFactory(
			PlatformTransactionManager transactionManager, ConnectionFactory connectionFactory) 
	{
		DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
		factory.setConnectionFactory(connectionFactory);
		factory.setTransactionManager(transactionManager);
		factory.setConcurrency("5-10");
		factory.setSessionAcknowledgeMode(Session.CLIENT_ACKNOWLEDGE);
		// factory.setMessageConverter(jacksonJmsMessageConverter());
		factory.setSessionTransacted(false);
		return factory;
	}

	/*@Bean
	public JmsTemplate jmsTemplate(ConnectionFactory connectionFactory) {
		JmsTemplate jmsTemplate = new JmsTemplate(connectionFactory);
		//jmsTemplate.setMessageConverter(jacksonJmsMessageConverter());
		//jmsTemplate.setDefaultDestinationName(incomingQueue);
		return jmsTemplate;
	}*/

	/*
	 * @Bean public MessageConverter jacksonJmsMessageConverter() {
	 * MappingJackson2MessageConverter converter = new
	 * MappingJackson2MessageConverter(); converter.setTargetType(MessageType.TEXT);
	 * converter.setTypeIdPropertyName("_type"); return converter; }
	 */
}
