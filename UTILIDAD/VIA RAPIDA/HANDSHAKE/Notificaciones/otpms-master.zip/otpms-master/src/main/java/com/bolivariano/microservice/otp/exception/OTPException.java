package com.bolivariano.microservice.otp.exception;

import com.bolivariano.microservice.otp.dto.GenerarOTPMensajeResponse;
import com.bolivariano.microservice.otp.dto.ValidarOTPMensajeResponse;

public class OTPException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = -6991076445787084951L;
	

	public OTPException(Exception e) {
		super(e);
	}


	public static ValidarOTPMensajeResponse mensajeValidarOTP(Integer codigo, String mensaje) {
		ValidarOTPMensajeResponse validarOTPMensajeResponse = new ValidarOTPMensajeResponse();
		validarOTPMensajeResponse.setCodigoRespuesta(codigo);
		validarOTPMensajeResponse.setMensaje(mensaje);
		return validarOTPMensajeResponse;
	}
	
	public static GenerarOTPMensajeResponse mensajeGenerarOTP(Integer codigo, String mensaje, String otp) {
		GenerarOTPMensajeResponse generarOTPMensajeResponse = new GenerarOTPMensajeResponse();
		generarOTPMensajeResponse.setCodigoRespuesta(codigo);
		generarOTPMensajeResponse.setOtp(otp);
		generarOTPMensajeResponse.setMensaje(mensaje);
		return generarOTPMensajeResponse;
	}
	

}
