package com.bolivariano.microservice.otp.service;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.datacontract.schemas._2004._07.serviciootp.RespuestaGeneracion;
import org.datacontract.schemas._2004._07.serviciootp.RespuestaValidacion;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bolivariano.microservice.notification_gateway.estructura.ClaveValorNotificacion;
import com.bolivariano.microservice.notification_gateway.estructura.DatosAdicionalesNotificacion;
import com.bolivariano.microservice.notification_gateway.estructura.DatosComunNotificacion;
import com.bolivariano.microservice.notification_gateway.estructura.MedioEnvio;
import com.bolivariano.microservice.notification_gateway.estructura.MediosEnvio;
import com.bolivariano.microservice.notification_gateway.estructura.MensajeEntradaEnviarNotificacion;
import com.bolivariano.microservice.notification_gateway.estructura.MensajeSalidaEnviarNotificacion;
import com.bolivariano.microservice.notification_gateway.estructura.Notificacion;
import com.bolivariano.microservice.notification_gateway.estructura.TipoMedio;
import com.bolivariano.microservice.notification_gateway.microservicio.notificationgateway.NotificacionesPortType;
import com.bolivariano.microservice.otp.dao.OtpDAO;
import com.bolivariano.microservice.otp.dto.GenerarOTPMensajeRequest;
import com.bolivariano.microservice.otp.dto.GenerarOTPMensajeResponse;
import com.bolivariano.microservice.otp.dto.ValidarOTPMensajeRequest;
import com.bolivariano.microservice.otp.dto.ValidarOTPMensajeResponse;
import com.bolivariano.microservice.otp.exception.OTPException;
import com.bolivariano.microservice.otp.utils.CoreUtils;
import com.bolivariano.microservice.otp.utils.constant.Enums;
import com.bolivariano.microservice.otp.utils.constant.Procesos;
import com.bolivariano.utilitario.common.StopWatch;

import bolivariano.fin.ec.wsentrust.service.EntrustServicePortType;
import bolivariano.fin.ec.wsentrust.service.RespuestaOTP;
import ec.com.bolivariano.otp.manager.OTPManager;

@Service
public class OTPServiceCliente {
	private static final Logger logger = LoggerFactory.getLogger(OTPServiceCliente.class);

	@Autowired
	private WebServiceConfig webServiceConfig;

	@Autowired
	private OtpDAO cuposDAO;

	/* Mensajes Validar OTP */
	@Value("${mensaje.otpservice.validar.ok}")
	private String mensajeValidarOK;

	@Value("${mensaje.otpservice.validar.error}")
	private String mensajeValidarError;

	/* Mensajes Latinia */
	@Value("${notificacion.prefix}")
	private String prefix;
	@Value("${notificacion.compania}")
	private String compania;
	@Value("${notificacion.servicio}")
	private String servicio;
	@Value("${notificacion.datoscomunes.canal}")
	private String canal;
	@Value("${notificacion.datoscomunes.asunto}")
	private String asunto;
	@Value("${notificacion.otp.clave}")
	private String otpClave;
	@Value("${notificacion.cliente.clave}")
	private String clienteClave;

	private String celular = "";
	private String correo = "";

	/* OTP NO CLIENTE */
	public GenerarOTPMensajeResponse generarOTPNoCliente(GenerarOTPMensajeRequest request) {
		GenerarOTPMensajeResponse mensaje;

		String producto = request.getProducto();
		String medioNotificacion = request.getMedioNotificacion();
		String identificacionCliente = request.getIdentificacionCliente();
		celular = request.getCelular();
		correo = request.getCorreo();
		String otp = "";

		if (!Arrays.asList("A", "C", "M").contains(medioNotificacion.trim().toUpperCase())) {
			return OTPException.mensajeGenerarOTP(404, Enums.MENSAJE_MEDIOS_BAD, null);
		}

		mensaje = validarProductoNoProveedor(producto, medioNotificacion);
		if (mensaje != null) {
			return mensaje;
		}

		mensaje = validarProductoProveedor(producto, identificacionCliente, medioNotificacion);
		if (mensaje != null) {
			return mensaje;
		}

		otp = consumirServicioBayted(Procesos.GENERAR_OTP_NO_CLIENTE + "-" + Procesos.OBTENER_CODIGO_MIS,
				identificacionCliente, "CNB", "CNB", 10000L);

		if (otp == null) {
			return OTPException.mensajeGenerarOTP(404, Enums.MENSAJE_OTP_NULL, null);
		}

		boolean notificacionEnviada = enviarNotificacion(
				Procesos.GENERAR_OTP_NO_CLIENTE + "-" + Procesos.ENVIAR_NOTIFICACION, medioNotificacion, 0, otp,
				celular, correo);

		if (!notificacionEnviada) {
			return OTPException.mensajeGenerarOTP(500, Enums.MENSAJE_NOTIFICACION_NULL, null);
		}

		return OTPException.mensajeGenerarOTP(0, mensajeRespuestaMedios(medioNotificacion), otp);
	}

	private GenerarOTPMensajeResponse validarProductoNoProveedor(String producto, String medioNotificacion) {
		if (producto == null || producto.trim().equalsIgnoreCase("")) {
			if (medioNotificacion.trim().equalsIgnoreCase("A") && (correo == null || celular == null)) {
				return OTPException.mensajeGenerarOTP(404, String.format(Enums.MENSAJE_MEDIOS_NULL, "celular o correo"),
						null);
			}

			if (medioNotificacion.trim().equalsIgnoreCase("C")
					&& (celular == null || celular.trim().equalsIgnoreCase(""))) {
				return OTPException.mensajeGenerarOTP(404, String.format(Enums.MENSAJE_MEDIOS_NULL, "celular"), null);

			}

			if (medioNotificacion.trim().equalsIgnoreCase("M")
					&& (correo == null || correo.trim().equalsIgnoreCase(""))) {
				return OTPException.mensajeGenerarOTP(404, String.format(Enums.MENSAJE_MEDIOS_NULL, "correo"), null);
			}

		}

		return null;
	}

	private GenerarOTPMensajeResponse validarProductoProveedor(String producto, String identificacionCliente,
			String medioNotificacion) {
		GenerarOTPMensajeResponse mensaje = null;
		Map<String, Object> mediosEnvio = null;

		if (producto != null && !producto.trim().equalsIgnoreCase("")) {

			mediosEnvio = obtenerMediosEnvioProveedor(producto, identificacionCliente);

			if (mediosEnvio == null) {
				return OTPException.mensajeGenerarOTP(404, String.format(Enums.MENSAJE_MEDIOS_NULL, "celular o correo"),
						null);
			}

			if (mediosEnvio.get("s_celular") != null) {
				celular = mediosEnvio.get("s_celular").toString();
			}

			if (mediosEnvio.get("s_correo") != null) {
				correo = mediosEnvio.get("s_correo").toString();
			}

			mensaje = validarMediosEnvioProveedor(medioNotificacion);
			if (mensaje != null) {
				return mensaje;
			}
		}

		return mensaje;
	}

	private Map<String, Object> obtenerMediosEnvioProveedor(String producto, String identificacionCliente) {
		Map<String, Object> mediosEnvio = null;
		if (producto.equalsIgnoreCase(Enums.KEY_PROVEEDOR)) {
			mediosEnvio = cuposDAO.obtenerMediosDeEnvioBayted(
					Procesos.GENERAR_OTP_NO_CLIENTE + "-" + Procesos.OBTENER_MEDIOS_ENVIO, Enums.KEY_PROVEEDOR,
					identificacionCliente);
		}

		if (producto.equalsIgnoreCase(Enums.KEY_TERCERO)) {
			mediosEnvio = cuposDAO.obtenerMediosDeEnvioBayted(
					Procesos.GENERAR_OTP_NO_CLIENTE + "-" + Procesos.OBTENER_MEDIOS_ENVIO, Enums.KEY_TERCERO,
					identificacionCliente);
		}
		return mediosEnvio;
	}

	private GenerarOTPMensajeResponse validarMediosEnvioProveedor(String medioNotificacion) {
		boolean errorValidarMediosProveedor = false;
		String mensajeError = "";
		if (celular == null && correo == null) {
			errorValidarMediosProveedor = true;
			mensajeError = String.format(Enums.MENSAJE_MEDIOS_NULL, "celular/correo");
		}

		if (celular == null && medioNotificacion.trim().equalsIgnoreCase("C")) {
			errorValidarMediosProveedor = true;
			mensajeError = String.format(Enums.MENSAJE_MEDIOS_NULL, "celular");
		}

		if (correo == null && medioNotificacion.trim().equalsIgnoreCase("M")) {
			errorValidarMediosProveedor = true;
			mensajeError = String.format(Enums.MENSAJE_MEDIOS_NULL, "correo");
		}
		return errorValidarMediosProveedor ? OTPException.mensajeGenerarOTP(404, mensajeError, null) : null;
	}

	public String consumirServicioBayted(String proceso, String identificacion, String tipoTransaccion,
			String aplicacion, Long timestamp) {
		String otp = null;
		OTPManager otpManager = null;
		try {
			otpManager = webServiceConfig.clientebayted(proceso);
			RespuestaGeneracion resGeneracion = otpManager.generarOTP(identificacion, tipoTransaccion, aplicacion,
					timestamp);
			if (resGeneracion.getCodigoRespuesta() != 0) {
				return null;
			}
			otp = resGeneracion.getOTP().getValue();
		} catch (Exception ex) {
			logger.error("Error al conectar al servicio bayted: " + ex.getMessage());
		} finally {
			webServiceConfig.returnObject(otpManager);
		}
		return otp;
	}

	/* OTP CLIENTE */
	public GenerarOTPMensajeResponse generarOTPCliente(GenerarOTPMensajeRequest request) {

		String medioNotificacion = request.getMedioNotificacion();
		String identificacionCliente = request.getIdentificacionCliente();
		Integer mis = 0;
		String otp = "";

		if (!Arrays.asList("A", "C", "M").contains(medioNotificacion.trim().toUpperCase())) {
			return OTPException.mensajeGenerarOTP(404, Enums.MENSAJE_MEDIOS_BAD, null);
		}

		mis = obtenerCodigoMis(identificacionCliente);

		if (mis == null || mis == 0) {
			return OTPException.mensajeGenerarOTP(404, Enums.MENSAJE_MIS_NULL, null);
		}

		Map<String, Object> out = cuposDAO
				.obtenerMediosDeEnvio(Procesos.GENERAR_OTP_CLIENTE + "-" + Procesos.OBTENER_MEDIOS_ENVIO, mis);

		if (out == null) {
			return OTPException.mensajeGenerarOTP(404, String.format(Enums.MENSAJE_MEDIOS_NULL, " medio de envio "),
					null);
		}

		celular = "";
		correo = "";

		if (out.get("o_celular") != null) {
			celular = out.get("o_celular").toString();
		}

		if (out.get("o_correo") != null) {
			correo = out.get("o_correo").toString();
		}

		if (celular.trim().equalsIgnoreCase("") && medioNotificacion.trim().equalsIgnoreCase("C")) {
			return OTPException.mensajeGenerarOTP(404, String.format(Enums.MENSAJE_MEDIOS_NULL, " celular "), null);
		} else if (correo.trim().equalsIgnoreCase("") && medioNotificacion.trim().equalsIgnoreCase("M")) {
			return OTPException.mensajeGenerarOTP(404, String.format(Enums.MENSAJE_MEDIOS_NULL, " correo "), null);
		} else if (celular.equalsIgnoreCase("") && correo.equalsIgnoreCase("")) {
			return OTPException.mensajeGenerarOTP(404, String.format(Enums.MENSAJE_MEDIOS_NULL, " correo/celular "),
					null);
		}

		otp = consumirServicioEntrust(Procesos.GENERAR_OTP_CLIENTE + "-" + Procesos.OBTENER_CODIGO_OTP,
				identificacionCliente);

		if (otp == null) {
			return OTPException.mensajeGenerarOTP(500, Enums.MENSAJE_OTP_NULL, null);
		}

		boolean notificacionEnviada = enviarNotificacion(
				Procesos.GENERAR_OTP_CLIENTE + "-" + Procesos.ENVIAR_NOTIFICACION, medioNotificacion, mis, otp, celular,
				correo);
		if (!notificacionEnviada) {
			return OTPException.mensajeGenerarOTP(500, Enums.MENSAJE_NOTIFICACION_NULL, null);
		}

		//return OTPException.mensajeGenerarOTP(0, mensajeRespuestaMedios(medioNotificacion), CoreUtils.encodeOTP(otp));
		return OTPException.mensajeGenerarOTP(0, mensajeRespuestaMedios(medioNotificacion), otp);
	}

	private String mensajeRespuestaMedios(String medioNotificacion) {
		String vMensajeGenerarOK = "";
		switch (medioNotificacion) {
		case "A":
			vMensajeGenerarOK = String.format(Enums.MENSAJE_GENERAR_OK, celular.concat("/").concat(correo));
			break;
		case "M":
			vMensajeGenerarOK = String.format(Enums.MENSAJE_GENERAR_OK, "correo ".concat(correo));
			break;
		case "C":
			vMensajeGenerarOK = String.format(Enums.MENSAJE_GENERAR_OK, "celular ".concat(celular));
			break;
		default:
			break;
		}
		return vMensajeGenerarOK;
	}

	private Integer obtenerCodigoMis(String identificacionCliente) {
		Integer mis = 0;
		/* Si es con cedula */
		mis = cuposDAO.obtenerCodigoMIS(Procesos.GENERAR_OTP_CLIENTE + "-" + Procesos.OBTENER_CODIGO_MIS,
				identificacionCliente, "C");
		/* Si es con pasaporte */
		if (mis == null || mis == 0) {
			mis = cuposDAO.obtenerCodigoMIS(Procesos.GENERAR_OTP_CLIENTE + "-" + Procesos.OBTENER_CODIGO_MIS,
					identificacionCliente, "P");
		}
		return mis;
	}

	private String consumirServicioEntrust(String proceso, String identificacionCliente) {
		String codigoOTP = null;
		EntrustServicePortType entrustService = null;
		try {
			entrustService = webServiceConfig.clienteEntrustUtil(proceso);
			RespuestaOTP respuestaOtp = entrustService.getOTP(identificacionCliente);
			if (respuestaOtp == null) {
				logger.error("No hay respuesta del servicio Entrust getOTP");
				return null;
			}
			codigoOTP = respuestaOtp.getOtp();

			if (respuestaOtp.getCodigoRespuesta() != 0) {
				logger.error("Codigo respuesta servicio getOP: " + respuestaOtp.getMensajeSistema());
				codigoOTP = null;
			}

		} catch (Exception e) {
			logger.error("Error al invocar servicio getOP: ", e);
			codigoOTP = null;
		} finally {
			webServiceConfig.returnObject(entrustService);
		}
		return codigoOTP;
	}

	/* VALIDAR OTP */
	public boolean enviarNotificacion(String proceso, String medioNotificacion, Integer mis, String otp,
			String telefono, String mail) {
		return generaNotificacion24(proceso, medioNotificacion, mis, otp, telefono, mail);
	}

	public ValidarOTPMensajeResponse validarOTP(String proceso, ValidarOTPMensajeRequest request) {

		String otp = request.getOtp();
		String identificacionCliente = request.getIdentificacionCliente();

		ValidarOTPMensajeResponse validarOTPMensajeResponse;
		try {
			if (proceso.equals(Procesos.VALIDAR_OTP_NO_CLIENTE)) {
				return validarOTPNoCliente(proceso, otp, identificacionCliente);
			} else {
				return validarOTPCliente(proceso, otp, identificacionCliente);
			}

		} catch (Exception e) {
			validarOTPMensajeResponse = new ValidarOTPMensajeResponse();
			logger.error("Error al conectar al servicio validateOTP: " + e.getMessage());
			validarOTPMensajeResponse.setCodigoRespuesta(500);
			validarOTPMensajeResponse.setMensaje(mensajeValidarError);
			return validarOTPMensajeResponse;
		}

	}

	public ValidarOTPMensajeResponse validarOTPCliente(String proceso, String otp, String identificacionCliente) {

		EntrustServicePortType entrustService = null;
		try {
			entrustService = webServiceConfig.clienteEntrustUtil(proceso);
			RespuestaOTP respuestaOtp = entrustService.validateOTP(otp, identificacionCliente);
			Integer valido = respuestaOtp.getCodigoRespuesta();

			webServiceConfig.returnObject(entrustService);

			if (valido != 0) {
				return OTPException.mensajeValidarOTP(404, mensajeValidarError);
			}
		} catch (Exception e) {
			return OTPException.mensajeValidarOTP(404, mensajeValidarError);
		}
		return OTPException.mensajeValidarOTP(0, mensajeValidarOK);
	}

	public ValidarOTPMensajeResponse validarOTPNoCliente(String proceso, String otp, String identificacionCliente) {

		OTPManager otpManager = null;
		try {
			otpManager = webServiceConfig.clientebayted(proceso);
			RespuestaValidacion respuestaOtp = otpManager.validarOTP(identificacionCliente, "CNB", "CNB", 10000L, otp);
			Integer valido = respuestaOtp.getCodigoRespuesta();
			webServiceConfig.returnObject(otpManager);
			if (valido != 0) {
				return OTPException.mensajeValidarOTP(404, mensajeValidarError);
			}
		} catch (Exception e) {
			return OTPException.mensajeValidarOTP(404, mensajeValidarError);
		}
		return OTPException.mensajeValidarOTP(0, mensajeValidarOK);
	}

	public GenerarOTPMensajeResponse generarOTPGenerico(GenerarOTPMensajeRequest request) {
		GenerarOTPMensajeResponse mensaje;

		Integer mis = 0;
		String identificacionCliente = request.getIdentificacionCliente();
		mis = cuposDAO.obtenerCodigoMIS(Procesos.GENERAR_OTP_CLIENTE + "-" + Procesos.OBTENER_CODIGO_MIS,
				identificacionCliente, "C");
		if (mis == null || mis == 0) {
			mis = cuposDAO.obtenerCodigoMIS(Procesos.GENERAR_OTP_CLIENTE + "-" + Procesos.OBTENER_CODIGO_MIS,
					identificacionCliente, "P");
		}

		if (mis == null || mis == 0) {
			mensaje = generarOTPNoCliente(request);
			return mensaje;
		}

		mensaje = generarOTPCliente(request);
		return mensaje;
	}

	public ValidarOTPMensajeResponse validarOTPGenerico(ValidarOTPMensajeRequest request) {
		ValidarOTPMensajeResponse mensaje;

		Integer mis = 0;
		String identificacionCliente = request.getIdentificacionCliente();
		mis = cuposDAO.obtenerCodigoMIS(Procesos.VALIDAR_OTP_CLIENTE + "-" + Procesos.OBTENER_CODIGO_MIS,
				identificacionCliente, "C");

		if (mis == null || mis == 0) {
			mis = cuposDAO.obtenerCodigoMIS(Procesos.VALIDAR_OTP_CLIENTE + "-" + Procesos.OBTENER_CODIGO_MIS,
					identificacionCliente, "P");
		}

		if (mis == null || mis == 0) {
			mensaje = validarOTP(Procesos.VALIDAR_OTP_NO_CLIENTE, request);
			return mensaje;
		}

		mensaje = validarOTP(Procesos.VALIDAR_OTP_CLIENTE, request);
		return mensaje;
	}

	/* NOTIFICACION LATINIA */
	public boolean generaNotificacion24(String proceso, String medioNotificacion, Integer mis, String otp,
			String telefono, String mail) {

		HashMap<String, String> cliente = obtenerDatosCliente(mis);

		Date date = new Date();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		String timestamp = simpleDateFormat.format(date);
		simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd");
		String fechaIngreso = simpleDateFormat.format(date);
		simpleDateFormat = new SimpleDateFormat("HH:mm:ss");
		String horaIngreso = simpleDateFormat.format(date);

		MensajeEntradaEnviarNotificacion mensajeEntrada = new MensajeEntradaEnviarNotificacion();
		/* Cabecera */
		Notificacion notificacion = new Notificacion();
		notificacion.setIdRequerimiento(prefix.concat(timestamp));
		notificacion.setRefCompania(compania);
		notificacion.setCodEnte(mis.toString());
		notificacion.setRefServicio(servicio);

		/* Datos Comunes */
		DatosComunNotificacion datosComunes = new DatosComunNotificacion();
		datosComunes.setCanal(canal);
		datosComunes.setAsunto(asunto);
		datosComunes.setFechaIngreso(fechaIngreso);
		datosComunes.setHoraIngreso(horaIngreso);

		/* Datos Adicionales */
		DatosAdicionalesNotificacion datosAdicionales = new DatosAdicionalesNotificacion();
		ClaveValorNotificacion parametros = null;
		parametros = new ClaveValorNotificacion();
		parametros.setClave(otpClave);
		parametros.setValor(otp);
		datosAdicionales.getParametrosNotificacion().add(parametros);

		if (medioNotificacion.trim().equalsIgnoreCase("M") || medioNotificacion.trim().equalsIgnoreCase("A")) {
			String nombreCliente = "nombreCliente";
			if (cliente.get(nombreCliente).trim().length() == 0) {
				return false;

			}
			parametros = new ClaveValorNotificacion();
			parametros.setClave(clienteClave);
			parametros.setValor(cliente.get(nombreCliente));
			datosAdicionales.getParametrosNotificacion().add(parametros);
		}

		// Medios Envio
		MediosEnvio mediosEnvio = new MediosEnvio();
		MedioEnvio meCelular = new MedioEnvio();
		MedioEnvio meCorreo = new MedioEnvio();
		meCelular.setTipo(TipoMedio.C);
		meCelular.setValor(telefono);
		meCorreo.setTipo(TipoMedio.M);
		meCorreo.setValor(mail);

		if (medioNotificacion.trim().equalsIgnoreCase("C") || medioNotificacion.trim().equalsIgnoreCase("A")) {
			mediosEnvio.getMedioEnvio().add(meCelular);
		}
		if (medioNotificacion.trim().equalsIgnoreCase("M") || medioNotificacion.trim().equalsIgnoreCase("A")) {
			mediosEnvio.getMedioEnvio().add(meCorreo);
		}

		mensajeEntrada.setNotificacion(notificacion);
		mensajeEntrada.setDatosComunNotificacion(datosComunes);
		mensajeEntrada.setAdicionalesNotificacion(datosAdicionales);
		mensajeEntrada.setMediosEnvio(mediosEnvio);

		NotificacionesPortType notificacionSoap = null;
		try {
			notificacionSoap = webServiceConfig.clienteLatinia(proceso);
			MensajeSalidaEnviarNotificacion mensajeSalidaEnviarNotificacion = notificacionSoap
					.enviarNotificacion(mensajeEntrada);

			if (mensajeSalidaEnviarNotificacion.getCodigoError() == null) {
				return false;
			}

			if (Integer.valueOf(mensajeSalidaEnviarNotificacion.getCodigoError()) != 0) {
				return false;
			}

		} catch (Exception e) {
			webServiceConfig.returnObject(notificacionSoap);
			return false;
		} finally {
			webServiceConfig.returnObject(notificacionSoap);
		}
		return true;

	}

	private HashMap<String, String> obtenerDatosCliente(Integer mis) {
		HashMap<String, String> resultado = new HashMap<>();
		StopWatch elapsedTime = new StopWatch();
		String codigoEnte = "";
		String nombreCliente = "";

		try {
			elapsedTime.start();
			Map<String, String> detalleCliente = cuposDAO.obtenerDetalleUsuarioVal(Procesos.OBTENER_DETALLE_CLIENTE,
					mis);
			elapsedTime.stop();

			codigoEnte = detalleCliente.get("codigoMis");
			nombreCliente = detalleCliente.get("nombre");
		} catch (Exception e) {
			codigoEnte = "";
			nombreCliente = "";
		}

		resultado.put("codigoEnte", codigoEnte);
		resultado.put("nombreCliente", nombreCliente);
		return resultado;
	}

}
