package com.bolivariano.microservice.otp.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bolivariano.microservice.otp.dto.GenerarOTPMensajeRequest;
import com.bolivariano.microservice.otp.dto.GenerarOTPMensajeResponse;
import com.bolivariano.microservice.otp.dto.ValidarOTPMensajeRequest;
import com.bolivariano.microservice.otp.dto.ValidarOTPMensajeResponse;
import com.bolivariano.microservice.otp.service.OTPServiceCliente;
import com.bolivariano.microservice.otp.utils.constant.Enums;
import com.bolivariano.microservice.otp.utils.constant.Procesos;

@RestController
@RequestMapping("/otp")
public class RestControllerOTP {

	@Autowired
	private OTPServiceCliente otpServiceCliente;

	
    /*Generar OTP para cliente o no cliente*/
	@PostMapping("/generarOTP")
	public ResponseEntity<GenerarOTPMensajeResponse> generarOTP(@RequestBody GenerarOTPMensajeRequest request) {
		if (request.getIdentificacionCliente() == null || request.getMedioNotificacion() == null) {
			GenerarOTPMensajeResponse response = new GenerarOTPMensajeResponse(400, Enums.PARAMETROS_INCORRECTOS, null);
			return new ResponseEntity(response, HttpStatus.OK);
		}

		if (request.getIdentificacionCliente().trim().equalsIgnoreCase("")
				|| request.getMedioNotificacion().trim().equalsIgnoreCase("")) {
			GenerarOTPMensajeResponse response = new GenerarOTPMensajeResponse(400, Enums.PARAMETROS_INCORRECTOS, null);
			return new ResponseEntity(response, HttpStatus.OK);
		}

		GenerarOTPMensajeResponse response = otpServiceCliente.generarOTPGenerico(request);

		return new ResponseEntity(response, HttpStatus.OK);
	}

	/*Validar OTP para cliente o no cliente*/ 
	@PostMapping("/validarOTP")
	public ResponseEntity<ValidarOTPMensajeResponse> validarOTP(@RequestBody ValidarOTPMensajeRequest request) {
		if (request.getIdentificacionCliente() == null || request.getOtp() == null) {
			ValidarOTPMensajeResponse response = new ValidarOTPMensajeResponse(400, Enums.PARAMETROS_INCORRECTOS);
			return new ResponseEntity(response, HttpStatus.OK);
		}

		if (request.getIdentificacionCliente().trim().equalsIgnoreCase("")
				|| request.getOtp().trim().equalsIgnoreCase("")) {
			ValidarOTPMensajeResponse response = new ValidarOTPMensajeResponse(400, Enums.PARAMETROS_INCORRECTOS);
			return new ResponseEntity(response, HttpStatus.OK);
		}

		ValidarOTPMensajeResponse response = otpServiceCliente.validarOTPGenerico(request);

		return new ResponseEntity(response, HttpStatus.OK);
	}
	
     /*Generar OTP para cliente registrado en DB BB*/
	/* C -> CELULAR, M -> CORREO, A -> CELULAR y CORREO */
	@PostMapping("/generarOTPCliente")
	public ResponseEntity<GenerarOTPMensajeResponse> generarOTPCliente(@RequestBody GenerarOTPMensajeRequest request) {
		if (request.getIdentificacionCliente() == null || request.getMedioNotificacion() == null) {
			GenerarOTPMensajeResponse response = new GenerarOTPMensajeResponse(400, Enums.PARAMETROS_INCORRECTOS, null);
			return new ResponseEntity(response, HttpStatus.OK);
		}

		if (request.getIdentificacionCliente().trim().equalsIgnoreCase("")
				|| request.getMedioNotificacion().trim().equalsIgnoreCase("")) {
			GenerarOTPMensajeResponse response = new GenerarOTPMensajeResponse(400, Enums.PARAMETROS_INCORRECTOS, null);
			return new ResponseEntity(response, HttpStatus.OK);
		}

		GenerarOTPMensajeResponse response = otpServiceCliente.generarOTPCliente(request);
		return new ResponseEntity(response, HttpStatus.OK);
	}

	/*Validar OTP par cliente registrado dn DB BB*/
	@PostMapping("/validarOTPCliente")
	public ResponseEntity<ValidarOTPMensajeResponse> validarOTPCliente(@RequestBody ValidarOTPMensajeRequest request) {
		
		//return new ResponseEntity(new ValidarOTPMensajeResponse(0,"Transacción Exitosa"), HttpStatus.OK);
		
		
		if (request.getIdentificacionCliente() == null || request.getOtp() == null) {
			ValidarOTPMensajeResponse response = new ValidarOTPMensajeResponse(400, Enums.PARAMETROS_INCORRECTOS);
			return new ResponseEntity(response, HttpStatus.OK);
		}

		if (request.getIdentificacionCliente().trim().equalsIgnoreCase("")
				|| request.getOtp().trim().equalsIgnoreCase("")) {
			ValidarOTPMensajeResponse response = new ValidarOTPMensajeResponse(400, Enums.PARAMETROS_INCORRECTOS);
			return new ResponseEntity(response, HttpStatus.OK);
		}

		ValidarOTPMensajeResponse response = otpServiceCliente.validarOTP(Procesos.VALIDAR_OTP_CLIENTE,request);
		return new ResponseEntity(response, HttpStatus.OK);
	}
	
     /*Generar OTP para cliente no registrado en DB BB*/
	/* C -> CELULAR, M -> CORREO, A -> CELULAR y CORREO */
	@PostMapping("/generarOTPNoCliente")
	public ResponseEntity<GenerarOTPMensajeResponse> generarOTPNoCliente(
			@RequestBody GenerarOTPMensajeRequest request) {

		if (request.getIdentificacionCliente() == null || request.getMedioNotificacion() == null) {
			GenerarOTPMensajeResponse response = new GenerarOTPMensajeResponse(400, Enums.PARAMETROS_INCORRECTOS, null);
			return new ResponseEntity(response, HttpStatus.OK);
		}

		if (request.getIdentificacionCliente().trim().equalsIgnoreCase("")
				|| request.getMedioNotificacion().trim().equalsIgnoreCase("")) {
			GenerarOTPMensajeResponse response = new GenerarOTPMensajeResponse(400, Enums.PARAMETROS_INCORRECTOS, null);
			return new ResponseEntity(response, HttpStatus.OK);
		}

		GenerarOTPMensajeResponse response = otpServiceCliente.generarOTPNoCliente(request);

		return new ResponseEntity(response, HttpStatus.OK);
	}
	/*Validar OTP para cliente no registrado en DB BB*/
	@PostMapping("/validarOTPNoCliente")
	public ResponseEntity<ValidarOTPMensajeResponse> validarOTPNoCliente(
			@RequestBody ValidarOTPMensajeRequest request) {
		if (request.getIdentificacionCliente() == null || request.getOtp() == null) {
			ValidarOTPMensajeResponse response = new ValidarOTPMensajeResponse(400, Enums.PARAMETROS_INCORRECTOS);
			return new ResponseEntity(response, HttpStatus.OK);
		}

		if (request.getIdentificacionCliente().trim().equalsIgnoreCase("")
				|| request.getOtp().trim().equalsIgnoreCase("")) {
			ValidarOTPMensajeResponse response = new ValidarOTPMensajeResponse(400, Enums.PARAMETROS_INCORRECTOS);
			return new ResponseEntity(response, HttpStatus.OK);
		}

		ValidarOTPMensajeResponse response = otpServiceCliente.validarOTP(Procesos.VALIDAR_OTP_NO_CLIENTE, request);

		return new ResponseEntity(response, HttpStatus.OK);
	}
}
