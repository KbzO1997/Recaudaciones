package com.bolivariano.microservice.otp.utils.constant;

public class Procesos {
	/*Constructor vacio debido a requerimientos de sonarqu*/
	Procesos() {
	}
	
	public static final String GENERAR_OTP_CLIENTE = "GENERAR OTP CLIENTE";
	public static final String VALIDAR_OTP_CLIENTE = "VALIDAR OTP CLIENTE";
	public static final String GENERAR_OTP_NO_CLIENTE = "GENERAR OTP NO CLIENTE";
	public static final String VALIDAR_OTP_NO_CLIENTE = "VALIDAR OTP NO CLIENTE";
	public static final String OBTENER_CODIGO_MIS = "OBTENER CODIGO MIS";
	public static final String OBTENER_MEDIOS_ENVIO = "OBTENER MEDIOS DE ENVIO";
	public static final String OBTENER_DETALLE_CLIENTE = "OBTENER DETALLES CLIENTE";
	public static final String ENVIAR_NOTIFICACION = "ENVIAR NOTIFICACION";
	public static final String OBTENER_CODIGO_OTP = "OBTENER CODIGO OTP";
}
