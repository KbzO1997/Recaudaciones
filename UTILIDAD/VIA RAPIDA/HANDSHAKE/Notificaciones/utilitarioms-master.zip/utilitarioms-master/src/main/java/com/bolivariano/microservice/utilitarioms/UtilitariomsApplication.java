package com.bolivariano.microservice.utilitarioms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UtilitariomsApplication {

	public static void main(String[] args) {
		SpringApplication.run(UtilitariomsApplication.class, args);
	}
}
