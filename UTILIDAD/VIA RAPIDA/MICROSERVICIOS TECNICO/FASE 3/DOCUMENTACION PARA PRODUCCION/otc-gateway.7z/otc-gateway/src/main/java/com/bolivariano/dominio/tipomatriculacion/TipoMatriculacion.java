
package com.bolivariano.dominio.tipomatriculacion;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para tipoMatriculacion.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * <p>
 * <pre>
 * &lt;simpleType name="tipoMatriculacion">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="MATRICULABLE"/>
 *     &lt;enumeration value="NO_MATRICULABLE"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "tipoMatriculacion", namespace = "http://www.bolivariano.com/dominio/TipoMatriculacion")
@XmlEnum
public enum TipoMatriculacion {

    MATRICULABLE,
    NO_MATRICULABLE;

    public String value() {
        return name();
    }

    public static TipoMatriculacion fromValue(String v) {
        return valueOf(v);
    }

}
