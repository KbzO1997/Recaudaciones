
package com.bolivariano.ws.otcservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;
import com.bolivariano.mensaje.mensajeotc.MensajeEntradaConsultarDeuda;
import com.bolivariano.mensaje.mensajeotc.MensajeEntradaConsultarEmpresa;
import com.bolivariano.mensaje.mensajeotc.MensajeEntradaEjecutarPago;
import com.bolivariano.mensaje.mensajeotc.MensajeEntradaEjecutarReverso;
import com.bolivariano.mensaje.mensajeotc.MensajeSalidaConsultarDeuda;
import com.bolivariano.mensaje.mensajeotc.MensajeSalidaConsultarEmpresa;
import com.bolivariano.mensaje.mensajeotc.MensajeSalidaEjecutarPago;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.bolivariano.ws.otcservice package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _SalidaConsultarEmpresa_QNAME = new QName("http://www.bolivariano.com/ws/OTCService", "salidaConsultarEmpresa");
    private final static QName _EntradaConsultarDeuda_QNAME = new QName("http://www.bolivariano.com/ws/OTCService", "entradaConsultarDeuda");
    private final static QName _SalidaConsultarDeuda_QNAME = new QName("http://www.bolivariano.com/ws/OTCService", "salidaConsultarDeuda");
    private final static QName _EntradaEjecutarPago_QNAME = new QName("http://www.bolivariano.com/ws/OTCService", "entradaEjecutarPago");
    private final static QName _EntradaEjecutarReverso_QNAME = new QName("http://www.bolivariano.com/ws/OTCService", "entradaEjecutarReverso");
    private final static QName _EntradaConsultarEmpresa_QNAME = new QName("http://www.bolivariano.com/ws/OTCService", "entradaConsultarEmpresa");
    private final static QName _SalidaEjecutarPago_QNAME = new QName("http://www.bolivariano.com/ws/OTCService", "salidaEjecutarPago");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.bolivariano.ws.otcservice
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MensajeSalidaConsultarEmpresa }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.bolivariano.com/ws/OTCService", name = "salidaConsultarEmpresa")
    public JAXBElement<MensajeSalidaConsultarEmpresa> createSalidaConsultarEmpresa(MensajeSalidaConsultarEmpresa value) {
        return new JAXBElement<MensajeSalidaConsultarEmpresa>(_SalidaConsultarEmpresa_QNAME, MensajeSalidaConsultarEmpresa.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MensajeEntradaConsultarDeuda }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.bolivariano.com/ws/OTCService", name = "entradaConsultarDeuda")
    public JAXBElement<MensajeEntradaConsultarDeuda> createEntradaConsultarDeuda(MensajeEntradaConsultarDeuda value) {
        return new JAXBElement<MensajeEntradaConsultarDeuda>(_EntradaConsultarDeuda_QNAME, MensajeEntradaConsultarDeuda.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MensajeSalidaConsultarDeuda }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.bolivariano.com/ws/OTCService", name = "salidaConsultarDeuda")
    public JAXBElement<MensajeSalidaConsultarDeuda> createSalidaConsultarDeuda(MensajeSalidaConsultarDeuda value) {
        return new JAXBElement<MensajeSalidaConsultarDeuda>(_SalidaConsultarDeuda_QNAME, MensajeSalidaConsultarDeuda.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MensajeEntradaEjecutarPago }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.bolivariano.com/ws/OTCService", name = "entradaEjecutarPago")
    public JAXBElement<MensajeEntradaEjecutarPago> createEntradaEjecutarPago(MensajeEntradaEjecutarPago value) {
        return new JAXBElement<MensajeEntradaEjecutarPago>(_EntradaEjecutarPago_QNAME, MensajeEntradaEjecutarPago.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MensajeEntradaEjecutarReverso }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.bolivariano.com/ws/OTCService", name = "entradaEjecutarReverso")
    public JAXBElement<MensajeEntradaEjecutarReverso> createEntradaEjecutarReverso(MensajeEntradaEjecutarReverso value) {
        return new JAXBElement<MensajeEntradaEjecutarReverso>(_EntradaEjecutarReverso_QNAME, MensajeEntradaEjecutarReverso.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MensajeEntradaConsultarEmpresa }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.bolivariano.com/ws/OTCService", name = "entradaConsultarEmpresa")
    public JAXBElement<MensajeEntradaConsultarEmpresa> createEntradaConsultarEmpresa(MensajeEntradaConsultarEmpresa value) {
        return new JAXBElement<MensajeEntradaConsultarEmpresa>(_EntradaConsultarEmpresa_QNAME, MensajeEntradaConsultarEmpresa.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MensajeSalidaEjecutarPago }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.bolivariano.com/ws/OTCService", name = "salidaEjecutarPago")
    public JAXBElement<MensajeSalidaEjecutarPago> createSalidaEjecutarPago(MensajeSalidaEjecutarPago value) {
        return new JAXBElement<MensajeSalidaEjecutarPago>(_SalidaEjecutarPago_QNAME, MensajeSalidaEjecutarPago.class, null, value);
    }

}
