package com.bolivariano.otc.web.rest.client.message;


import com.bolivariano.mensaje.mensajeotc.MensajeEntradaConsultarDeuda;
import com.bolivariano.mensaje.mensajeotc.MensajeEntradaEjecutarPago;
import com.bolivariano.mensaje.mensajeotc.MensajeEntradaEjecutarReverso;
import com.bolivariano.otc.enumeration.TipoFlujo;
import com.bolivariano.otc.web.rest.client.domain.Flujo;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class MensajeEntradaProcesar implements Serializable {

    private Flujo flujo;
    private TipoFlujo tipoFlujo;
    private MensajeEntradaEjecutarReverso mensajeEntradaEjecutarReverso;
    private MensajeEntradaEjecutarPago mensajeEntradaEjecutarPago;
    private MensajeEntradaConsultarDeuda mensajeEntradaConsultarDeuda;

    public MensajeEntradaProcesar() {
    }

    public Flujo getFlujo() {
        return flujo;
    }

    public void setFlujo(Flujo flujo) {
        this.flujo = flujo;
    }

    public TipoFlujo getTipoFlujo() {
        return tipoFlujo;
    }

    public void setTipoFlujo(TipoFlujo tipoFlujo) {
        this.tipoFlujo = tipoFlujo;
    }

    public MensajeEntradaEjecutarReverso getMensajeEntradaEjecutarReverso() {
        return mensajeEntradaEjecutarReverso;
    }

    public void setMensajeEntradaEjecutarReverso(MensajeEntradaEjecutarReverso mensajeEntradaEjecutarReverso) {
        this.mensajeEntradaEjecutarReverso = mensajeEntradaEjecutarReverso;
    }

    public MensajeEntradaEjecutarPago getMensajeEntradaEjecutarPago() {
        return mensajeEntradaEjecutarPago;
    }

    public void setMensajeEntradaEjecutarPago(MensajeEntradaEjecutarPago mensajeEntradaEjecutarPago) {
        this.mensajeEntradaEjecutarPago = mensajeEntradaEjecutarPago;
    }

    public MensajeEntradaConsultarDeuda getMensajeEntradaConsultarDeuda() {
        return mensajeEntradaConsultarDeuda;
    }

    public void setMensajeEntradaConsultarDeuda(MensajeEntradaConsultarDeuda mensajeEntradaConsultarDeuda) {
        this.mensajeEntradaConsultarDeuda = mensajeEntradaConsultarDeuda;
    }

    @Override
    public String toString() {
        return "MensajeEntradaProcesar{" +
                "flujo=" + flujo +
                ", tipoFlujo=" + tipoFlujo +
                ", mensajeEntradaEjecutarReverso=" + mensajeEntradaEjecutarReverso +
                ", mensajeEntradaEjecutarPago=" + mensajeEntradaEjecutarPago +
                ", mensajeEntradaConsultarDeuda=" + mensajeEntradaConsultarDeuda +
                '}';
    }
}
