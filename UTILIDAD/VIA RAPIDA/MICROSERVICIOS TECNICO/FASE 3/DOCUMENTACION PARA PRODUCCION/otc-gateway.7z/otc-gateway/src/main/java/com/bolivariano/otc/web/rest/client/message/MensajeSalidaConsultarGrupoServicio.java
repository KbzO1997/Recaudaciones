package com.bolivariano.otc.web.rest.client.message;

import com.bolivariano.otc.web.rest.client.domain.GrupoServicio;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import java.io.Serializable;
import java.util.List;

@JsonInclude(Include.NON_NULL)
public class MensajeSalidaConsultarGrupoServicio implements Serializable {

    private static final long serialVersionUID = -4723237529017319717L;

    private String codigo;
    private String mensajeUsuario;
    private String estado;
    private List<GrupoServicio> mensaje;

    public List<GrupoServicio> getMensaje() {
        return mensaje;
    }

    public void setMensaje(List<GrupoServicio> mensaje) {
        this.mensaje = mensaje;
    }

    public MensajeSalidaConsultarGrupoServicio() {

    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getMensajeUsuario() {
        return mensajeUsuario;
    }

    public void setMensajeUsuario(String mensajeUsuario) {
        this.mensajeUsuario = mensajeUsuario;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }


    @Override
    public String toString() {
        return "MensajeSalidaBase{" +
                "codigo=" + codigo +
                ", mensajeUsuario='" + mensajeUsuario + '\'' +
                ", estado='" + estado + '\'' +
                ", mensaje=" + mensaje +
                '}';
    }
}
