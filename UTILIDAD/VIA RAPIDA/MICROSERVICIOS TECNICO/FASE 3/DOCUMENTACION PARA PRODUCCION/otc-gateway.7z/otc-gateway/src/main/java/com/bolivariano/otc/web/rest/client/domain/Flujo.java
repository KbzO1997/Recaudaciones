package com.bolivariano.otc.web.rest.client.domain;

import java.io.Serializable;
import java.util.List;


/**
 * The persistent class for the OTC_M_FLUJO database table.
 */

public class Flujo implements Serializable {
    private static final long serialVersionUID = 1L;


    private Long id;

    private Catalogo operacion;

    private List<ServicioEnriquecimiento> servicioEnriquecimiento;

    private PuntoFinal puntoFinal;

    private Convenio convenio;


    public Flujo() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Catalogo getOperacion() {
        return operacion;
    }

    public void setOperacion(Catalogo operacion) {
        this.operacion = operacion;
    }

    public List<ServicioEnriquecimiento> getServicioEnriquecimiento() {
        return servicioEnriquecimiento;
    }

    public void setServicioEnriquecimiento(List<ServicioEnriquecimiento> servicioEnriquecimiento) {
        this.servicioEnriquecimiento = servicioEnriquecimiento;
    }

    public PuntoFinal getPuntoFinal() {
        return puntoFinal;
    }

    public void setPuntoFinal(PuntoFinal puntoFinal) {
        this.puntoFinal = puntoFinal;
    }

    public Convenio getConvenio() {
        return convenio;
    }

    public void setConvenio(Convenio convenio) {
        this.convenio = convenio;
    }

    @Override
    public String toString() {
        return "Flujo{" +
                "id=" + id +
                ", operacion=" + operacion +
                ", servicioEnriquecimiento=" + servicioEnriquecimiento +
                ", puntoFinal=" + puntoFinal +
                ", convenio=" + convenio +
                '}';
    }
}