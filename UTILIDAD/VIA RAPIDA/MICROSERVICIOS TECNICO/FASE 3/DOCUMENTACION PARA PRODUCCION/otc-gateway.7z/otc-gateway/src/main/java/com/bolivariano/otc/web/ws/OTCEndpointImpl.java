package com.bolivariano.otc.web.ws;

import com.bolivariano.dominio.convenio.Convenio;
import com.bolivariano.dominio.datoadicional.DatoAdicional;
import com.bolivariano.dominio.empresa.Empresa;
import com.bolivariano.dominio.listaseleccion.ListaSeleccion;
import com.bolivariano.dominio.tipoidentificador.TipoIdentificador;
import com.bolivariano.mensaje.mensajeotc.*;
import com.bolivariano.otc.enumeration.TipoFlujo;
import com.bolivariano.otc.web.rest.client.CoreServicioProxy;
import com.bolivariano.otc.web.rest.client.GrupoServicioProxy;
import com.bolivariano.otc.web.rest.client.domain.Flujo;
import com.bolivariano.otc.web.rest.client.domain.FormaPago;
import com.bolivariano.otc.web.rest.client.domain.GrupoServicio;
import com.bolivariano.otc.web.rest.client.domain.Servicio;
import com.bolivariano.otc.web.rest.client.message.MensajeEntradaConsultarGrupoServicio;
import com.bolivariano.otc.web.rest.client.message.MensajeEntradaProcesar;
import com.bolivariano.otc.web.rest.client.message.MensajeSalidaConsultarGrupoServicio;
import com.bolivariano.otc.web.rest.client.message.MensajeSalidaProcesar;
import com.bolivariano.ws.otcservice.OTCEndpoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class OTCEndpointImpl implements OTCEndpoint {

    private static final Logger log = LoggerFactory.getLogger(OTCEndpointImpl.class);

    @Autowired
    private GrupoServicioProxy proxyAdmin;

    @Autowired
    private CoreServicioProxy proxyCore;

    public MensajeSalidaEjecutarPago ejecutarPago(MensajeEntradaEjecutarPago peticion) {
        MensajeSalidaEjecutarPago respuesta = new MensajeSalidaEjecutarPago();

        try {
            MensajeEntradaProcesar peticionObj = new MensajeEntradaProcesar();
            peticionObj.setTipoFlujo(TipoFlujo.PAGO);

            com.bolivariano.dominio.servicio.Servicio servicio = peticion.getServicio();
            Flujo flujo = obtenerFlujo(servicio.getCodigoConvenio(), servicio.getCodigoEmpresa(), servicio.getCodTipoServicio(), servicio.getCodigoTipoBanca(), "PAGO");
            peticionObj.setFlujo(flujo);

            if (peticionObj.getFlujo() == null) {
                respuesta.setCodigoError("OTC_GTW_02");
                respuesta.setMensajeUsuario("Error: No existe flujo parametrizado para el mensaje enviado.");
                return respuesta;
            }

            log.info("CANAL: " + peticion.getCanal());

            //Remueve Metodos de Pago en NULL o vacios como campos adicionales
            if (peticion.getDatosAdicionales() != null && peticion.getDatosAdicionales().getDatoAdicional() != null && !peticion.getDatosAdicionales().getDatoAdicional().isEmpty()){
                DatoAdicional datoAdicionalObj = null;
                for (DatoAdicional datoAdicional:peticion.getDatosAdicionales().getDatoAdicional()){
                    if (datoAdicional.getCodigo() != null && datoAdicional.getCodigo().length() >= 3 && "MPA".equals(datoAdicional.getCodigo().substring(0, 3))) {
                        if (datoAdicional.getValor() == null || datoAdicional.getValor().isEmpty()){
                            datoAdicionalObj = datoAdicional;
                        }
                    }
                }
                if (datoAdicionalObj != null){
                    peticion.getDatosAdicionales().getDatoAdicional().remove(datoAdicionalObj);
                }

            }

            peticionObj.setMensajeEntradaEjecutarPago(peticion);

            MensajeSalidaProcesar respuestaObj = proxyCore.procesar(peticionObj);
            respuesta = respuestaObj.getMensajeSalidaEjecutarPago();

            if (respuesta == null) {
                respuesta = new MensajeSalidaEjecutarPago();
                respuesta.setCodigoError("OTC_GTW_03");
                respuesta.setMensajeUsuario("Mensaje no procesado");
                return respuesta;
            }

            if (respuesta.getCodigoError() == null) {
                respuesta.setCodigoError("0");

            }
            if (respuesta.getMensajeUsuario() == null) {
                respuesta.setMensajeUsuario("Mensaje Procesado");

            } else {
                byte[] ptext = respuesta.getMensajeUsuario().getBytes("UTF-8");
                String value = new String(ptext, "UTF-8");
                respuesta.setMensajeUsuario(value);
            }

            log.info("FECHA DEBITO --> " + respuesta.getFechaDebito());
            log.info("FECHA PAGO --> " + respuesta.getFechaPago());
            log.info("MENSAJE SALIDA --> " + respuesta);
            log.info("MENSAJE RESPUESTA --> " + respuesta.getMensajeUsuario());
            log.info("MENSAJE CODIGO --> " + respuesta.getCodigoError());

        } catch (Exception e) {
            log.error("Error en el proceso" + e.getMessage(), e);
            respuesta.setCodigoError("OTC_GTW_01");
            respuesta.setMensajeUsuario("Error no controlado: " + e.getMessage());
        }

        return respuesta;
    }

    public void ejecutarReverso(MensajeEntradaEjecutarReverso peticion) {
        try {

            MensajeEntradaProcesar peticionObj = new MensajeEntradaProcesar();
            peticionObj.setTipoFlujo(TipoFlujo.REVERSO);

            com.bolivariano.dominio.servicio.Servicio servicio = peticion.getServicio();
            peticionObj.setFlujo(obtenerFlujo(servicio.getCodigoConvenio(), servicio.getCodigoEmpresa(), servicio.getCodTipoServicio(), servicio.getCodigoTipoBanca(), "REVERSO"));

            peticionObj.setMensajeEntradaEjecutarReverso(peticion);

            proxyCore.procesar(peticionObj);


        } catch (Exception e) {
            log.error("Error en el proceso" + e.getMessage(), e);
        }


    }

    public MensajeSalidaConsultarEmpresa consultarEmpresa(MensajeEntradaConsultarEmpresa peticion) {
        MensajeSalidaConsultarEmpresa respuesta = new MensajeSalidaConsultarEmpresa();
        //String pattern = "yyyy-MM-ddHH:mm:ss";
        //SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

        //String dateStr = simpleDateFormat.format(new Date());
        //System.out.println(dateStr);

        try {

            respuesta.setCodigoError("0");
            respuesta.setMensajeUsuario("Transacion Exitosa");

            MensajeEntradaConsultarGrupoServicio peticionObj = new MensajeEntradaConsultarGrupoServicio();
            peticionObj.setTipoBanca(peticion.getTipoBanca());
            peticionObj.setTipoServicio(peticion.getTipoServicio());

            MensajeSalidaConsultarGrupoServicio respuestaObj = proxyAdmin.consultarGrupoServicios(peticionObj);

            respuesta.setMensajeUsuario(respuestaObj.getMensajeUsuario());
            respuesta.setCodigoError(respuestaObj.getCodigo());

            List<GrupoServicio> grupoServicios = respuestaObj.getMensaje();

            if (grupoServicios != null && !grupoServicios.isEmpty()) {
                MensajeSalidaConsultarEmpresa.Empresas empresas = new MensajeSalidaConsultarEmpresa.Empresas();
                Empresa empresa = null;
                Empresa.Convenios convenios = null;
                Convenio convenio = null;
                Convenio.TipoIdentificadores tipoIdentificadores = null;
                TipoIdentificador tipoIdentificador = null;
                TipoIdentificador.DatosAdicionales datosAdicionales = null;
                TipoIdentificador.DatosAdicionales datosAdicionalesFormaPago = null;
                DatoAdicional datoAdicional = null;
                FormaPago formaPago = null;

                TipoIdentificador.RegionalAreas regionalAreas = null;
                com.bolivariano.dominio.regionalarea.RegionalArea regionalArea = null;
                DatoAdicional.ListasSeleccion listasSeleccion = null;
                ListaSeleccion listaSeleccion = null;

                for (GrupoServicio grupoServicio : grupoServicios) {
                    //setea datos de Empresa
                    empresa = new Empresa();
                    ///BeanUtils.copyProperties(empresa, grupoServicio.getEmpresa());
                    ///s BeanUtils.copyProperties(empresa, grupoServicio);
                    com.bolivariano.otc.web.rest.client.domain.Empresa emp = grupoServicio.getEmpresa();
                    empresa.setCodigoEmpresa(emp.getCodigo());
                    empresa.setMatriculable(grupoServicio.getMatriculable());
                    empresa.setMatriculacionMultiple(grupoServicio.getMatriculacionMultiple());
                    empresa.setValidable(grupoServicio.getValidable());
                    empresa.setEtiquetaEmpresa(emp.getNombre());
                    empresa.setConvenioVisible(grupoServicio.getConvenioVisible());

                    if (grupoServicio.getServicios() != null && !grupoServicio.getServicios().isEmpty()) {
                        //setea datos de convenios
                        convenios = new Empresa.Convenios();
                        convenio = null;
                        for (Servicio servicio : grupoServicio.getServicios()) {
                            //setea convenio
                            convenio = new Convenio();
                            //   BeanUtils.copyProperties(convenio, servicio.getConvenio());
                            if (servicio.getConvenio() != null) {
                                //	BeanUtils.copyProperties(convenio, servicio.getConvenio());
                                convenio.setCodigo(servicio.getConvenio().getCodigo());
                                convenio.setEtiquetaCodigo(servicio.getConvenio().getEtiquetaCodigo());
                                convenio.setVisible(servicio.getConvenio().getVisible());

                                tipoIdentificadores = null;
                                if (servicio.getConvenio().getTipoIdentificadores() != null
                                        && !servicio.getConvenio().getTipoIdentificadores().isEmpty()) {
                                    //setea tipoIdentificadores
                                    tipoIdentificadores = new Convenio.TipoIdentificadores();
                                    tipoIdentificador = null;
                                    for (com.bolivariano.otc.web.rest.client.domain.TipoIdentificador tipoIdentificadorObj : servicio.getConvenio().getTipoIdentificadores()) {
                                        //setea tipoIdentificador
                                        tipoIdentificador = new TipoIdentificador();
                                        // BeanUtils.copyProperties(tipoIdentificador, tipoIdentificadorObj);
                                        tipoIdentificador.setCodigo(tipoIdentificadorObj.getCodigo());
                                        tipoIdentificador.setConcatenadorRegionalArea(tipoIdentificadorObj.getConcatenadorRegionalArea());
                                        tipoIdentificador.setEtiquetaCodigo(tipoIdentificadorObj.getEtiquetaCodigo());
                                        tipoIdentificador.setFlujoAyuda(tipoIdentificadorObj.getFlujoAyuda());
                                        tipoIdentificador.setMascara(tipoIdentificadorObj.getMascara());
                                        tipoIdentificador.setMatriculable(tipoIdentificadorObj.getMatriculable());
                                        tipoIdentificador.setRegexp(tipoIdentificadorObj.getRegexp());
                                        tipoIdentificador.setTextoAyuda(tipoIdentificadorObj.getTextoAyuda());
                                        tipoIdentificador.setProgramable(tipoIdentificadorObj.getProgramable());

                                        if (tipoIdentificadorObj.getDatoAdicionales() != null && !tipoIdentificadorObj.getDatoAdicionales().isEmpty()) {
                                            //setea datos adicionales
                                            datosAdicionales = new TipoIdentificador.DatosAdicionales();
                                            datoAdicional = null;

                                            for (com.bolivariano.otc.web.rest.client.domain.DatoAdicional datoAdicionalObj : tipoIdentificadorObj.getDatoAdicionales()) {
                                                //setea dato adicional
                                                datoAdicional = new DatoAdicional();
                                                //BeanUtils.copyProperties(datoAdicional, datoAdicionalObj);

                                                datoAdicional.setCodigo(datoAdicionalObj.getCodigo());
                                                datoAdicional.setEditable(datoAdicionalObj.getEditable());
                                                datoAdicional.setFormato(datoAdicionalObj.getFormato());
                                                datoAdicional.setLongitud(datoAdicionalObj.getLongitud());
                                                datoAdicional.setMascara(datoAdicionalObj.getMascara());
                                                datoAdicional.setRegexp(datoAdicionalObj.getRegexp());
                                                datoAdicional.setTipo(datoAdicionalObj.getTipo());
                                                datoAdicional.setValor(datoAdicionalObj.getValor());
                                                datoAdicional.setVisible(datoAdicionalObj.getVisible());
                                                datoAdicional.setEtiqueta(datoAdicionalObj.getEtiqueta());

                                                if (datoAdicionalObj.getListasSeleccion() != null && !datoAdicionalObj.getListasSeleccion().isEmpty()) {
                                                    //setea listas selecion
                                                    listasSeleccion = new DatoAdicional.ListasSeleccion();

                                                    for (com.bolivariano.otc.web.rest.client.domain.ListaSeleccion listaSeleccionObj : datoAdicionalObj.getListasSeleccion()) {
                                                        //setea lista seleccioj
                                                        listaSeleccion = new com.bolivariano.dominio.listaseleccion.ListaSeleccion();
                                                        // BeanUtils.copyProperties(listaSeleccion, listaSeleccionObj);
                                                        listaSeleccion.setCodigo(listaSeleccionObj.getCodigo());
                                                        listaSeleccion.setEtiqueta(listaSeleccionObj.getEtiqueta());

                                                        listasSeleccion.getListaSeleccion().add(listaSeleccion);
                                                    }

                                                    datoAdicional.setListasSeleccion(listasSeleccion);
                                                }

                                                datosAdicionales.getDatoAdicional().add(datoAdicional);
                                            }

                                            tipoIdentificador.setDatosAdicionales(datosAdicionales);
                                        }

                                        //NEW SOLICITA METODO DE PAGO
                                        if (tipoIdentificadorObj.getFormaPagos() != null && !tipoIdentificadorObj.getFormaPagos().isEmpty()) {
                                            datosAdicionalesFormaPago = new TipoIdentificador.DatosAdicionales();
                                            DatoAdicional datoAdicionalMPA = null;
                                            List<String> formaPagoStr = new ArrayList<String>();
                                            String codigo = null;
                                            for (FormaPago formaPagoObj : tipoIdentificadorObj.getFormaPagos()) {

                                                if (convenio.getCodigo().equals(formaPagoObj.getConvenio().getCodigo())) {
                                                    codigo = "FPA_".concat(formaPagoObj.getMedio());
                                                    if (!formaPagoStr.contains(codigo)) {
                                                        formaPagoStr.add("FPA_".concat(formaPagoObj.getMedio()));

                                                        datoAdicional = new DatoAdicional();

                                                        datoAdicional.setCodigo(codigo);
                                                        datoAdicional.setEditable(false);
                                                        datoAdicional.setVisible(false);
                                                        datoAdicional.setEtiqueta("Forma de Pago");

                                                        datoAdicionalMPA = new DatoAdicional();

                                                        datoAdicionalMPA.setCodigo("MPA_".concat(formaPagoObj.getMedio()));
                                                        datoAdicionalMPA.setEditable(false);
                                                        datoAdicionalMPA.setVisible(false);
                                                        datoAdicionalMPA.setEtiqueta("Medio de Pago");

                                                        datosAdicionalesFormaPago.getDatoAdicional().add(datoAdicional);
                                                        datosAdicionalesFormaPago.getDatoAdicional().add(datoAdicionalMPA);
                                                    }
                                                }

                                            }

                                            for (DatoAdicional datoAdicionalObj : datosAdicionalesFormaPago.getDatoAdicional()) {
                                                listasSeleccion = new DatoAdicional.ListasSeleccion();
                                                for (FormaPago formaPagoObj : tipoIdentificadorObj.getFormaPagos()) {
                                                    codigo = "FPA_".concat(formaPagoObj.getMedio());
                                                    if (codigo.equals(datoAdicionalObj.getCodigo())) {
                                                        listaSeleccion = new com.bolivariano.dominio.listaseleccion.ListaSeleccion();

                                                        listaSeleccion.setCodigo(formaPagoObj.getCuotas().toString());
                                                        listaSeleccion.setEtiqueta(formaPagoObj.getEtiqueta());

                                                        listasSeleccion.getListaSeleccion().add(listaSeleccion);

                                                    }

                                                }
                                                datoAdicionalObj.setListasSeleccion(listasSeleccion);
                                            }

                                            tipoIdentificador.setDatosAdicionales(datosAdicionalesFormaPago);
                                        }

                                        if (tipoIdentificadorObj.getRegionalAreas() != null && !tipoIdentificadorObj.getRegionalAreas().isEmpty()) {
                                            //setea regionales area
                                            regionalAreas = new TipoIdentificador.RegionalAreas();
                                            regionalArea = null;

                                            for (com.bolivariano.otc.web.rest.client.domain.RegionalArea regionalArealObj : tipoIdentificadorObj.getRegionalAreas()) {
                                                //setea regional area
                                                regionalArea = new com.bolivariano.dominio.regionalarea.RegionalArea();
                                                //BeanUtils.copyProperties(regionalArea, regionalArealObj);
                                                regionalArea.setCodigo(regionalArealObj.getCodigo());

                                                regionalAreas.getRegionalArea().add(regionalArea);
                                            }

                                            tipoIdentificador.setRegionalAreas(regionalAreas);
                                        }

                                        tipoIdentificadores.getTipoIdentificador().add(tipoIdentificador);
                                    }
                                }

                                convenio.setTipoIdentificadores(tipoIdentificadores);
                                convenios.getConvenio().add(convenio);
                            }
                        }
                        empresa.setConvenios(convenios);
                    }

                    empresas.getEmpresa().add(empresa);
                }


                respuesta.setEmpresas(empresas);

            } else {
                log.info("No existe empresa para los datos enviados");
                respuesta.setCodigoError("OTC_GTW_03");
                respuesta.setMensajeUsuario("No existe empresas para la petición enviada");
                return respuesta;
            }

        } catch (Exception e) {
            respuesta.setCodigoError("1");
            respuesta.setMensajeUsuario("Error no controlado: " + e.getMessage());
            log.error("Error en el proceso" + e.getMessage(), e);
            respuesta.setCodigoError("OTC_GTW_01");
            e.printStackTrace();
        }


        return respuesta;
    }

    public MensajeSalidaConsultarDeuda consultarDeuda(MensajeEntradaConsultarDeuda peticion) {
        MensajeSalidaConsultarDeuda respuesta = new MensajeSalidaConsultarDeuda();

        try {
            MensajeEntradaProcesar peticionObj = new MensajeEntradaProcesar();
            peticionObj.setTipoFlujo(TipoFlujo.CONSULTA);

            com.bolivariano.dominio.servicio.Servicio servicio = peticion.getServicio();
            com.bolivariano.dominio.servicio.Servicio.DatosAdicionales datosAdicionales = servicio.getDatosAdicionales();

            Flujo flujo = obtenerFlujo(servicio.getCodigoConvenio(), servicio.getCodigoEmpresa(), servicio.getCodTipoServicio(), servicio.getCodigoTipoBanca(), "CONSULTA");
            peticionObj.setFlujo(flujo);

            if (peticionObj.getFlujo() == null) {
                respuesta.setCodigoError("OTC_GWT_02");
                respuesta.setMensajeUsuario("Error: No existe flujo parametrizado para el mensaje enviado.");
                return respuesta;
            }

            peticionObj.setMensajeEntradaConsultarDeuda(peticion);

            MensajeSalidaProcesar respuestaObj = proxyCore.procesar(peticionObj);
            respuesta = respuestaObj.getMensajeSalidaConsultarDeuda();

            if (respuesta == null) {
                respuesta = new MensajeSalidaConsultarDeuda();
                respuesta.setCodigoError("OTC_GTW_03");
                respuesta.setMensajeUsuario("Mensaje no procesado");
                return respuesta;
            }

            if (respuesta.getCodigoError() == null) {
                respuesta.setCodigoError("0");

            }
            if (respuesta.getMensajeUsuario() == null) {
                respuesta.setMensajeUsuario("Mensaje Procesado");

            } else {
                byte[] ptext = respuesta.getMensajeUsuario().getBytes("UTF-8");
                String value = new String(ptext, "UTF-8");
                respuesta.setMensajeUsuario(value);
            }


            if (respuesta.getDatosAdicionales() == null) {
                respuesta.setDatosAdicionales(new MensajeSalidaConsultarDeuda.DatosAdicionales());
            }

            if (respuesta.getMontoTotal() != null && respuesta.getMontoTotal().doubleValue() > 0d){
                boolean tieneFormaPago = false;
                if (datosAdicionales != null && datosAdicionales.getDatoAdicional() != null && !datosAdicionales.getDatoAdicional().isEmpty()) {
                    for (com.bolivariano.dominio.datoadicional.DatoAdicional datoAdicional : datosAdicionales.getDatoAdicional()) {
                        if (datoAdicional.getCodigo() != null && datoAdicional.getCodigo().length() >= 3 && "FPA".equals(datoAdicional.getCodigo().substring(0, 3))) {
                            tieneFormaPago = true;
                            break;
                        }

                        if (datoAdicional.getCodigo() != null && datoAdicional.getCodigo().length() >= 3 && "MPA".equals(datoAdicional.getCodigo().substring(0, 3))) {
                            tieneFormaPago = true;
                            break;
                        }

                    }


                }

                if (tieneFormaPago) {
                    List<FormaPago> formasPago = obtenerFormaPago(servicio.getCodigoConvenio(), servicio.getCodigoEmpresa(), servicio.getCodTipoServicio(), servicio.getCodigoTipoBanca(), servicio.getCodigoTipoIdentificador());

                    if (formasPago != null && !formasPago.isEmpty()) {
                        MensajeSalidaConsultarDeuda.DatosAdicionales datosAdicionalesFormaPago = new  MensajeSalidaConsultarDeuda.DatosAdicionales();
                        com.bolivariano.dominio.listaseleccion.ListaSeleccion listaSeleccion = null;
                        com.bolivariano.dominio.datoadicional.DatoAdicional datoAdicionalMPA = null;
                        com.bolivariano.dominio.datoadicional.DatoAdicional.ListasSeleccion listasSeleccion = null;
                        List<String> formaPagoStr = new ArrayList<String>();
                        String codigo = null;
                        com.bolivariano.dominio.datoadicional.DatoAdicional datoAdicional = null;
                        for (FormaPago formaPagoObj : formasPago) {
                            codigo = "FPA_".concat(formaPagoObj.getMedio());
                            if (!formaPagoStr.contains(codigo)) {
                                formaPagoStr.add("FPA_".concat(formaPagoObj.getMedio()));
                                datoAdicional = new DatoAdicional();
                                datoAdicional.setCodigo(codigo);
                                datoAdicional.setEditable(false);
                                datoAdicional.setVisible(false);
                                datoAdicional.setEtiqueta("Forma de Pago");
                                datoAdicionalMPA = new DatoAdicional();

                                datoAdicionalMPA.setCodigo("MPA_".concat(formaPagoObj.getMedio()));
                                datoAdicionalMPA.setEditable(false);
                                datoAdicionalMPA.setVisible(false);
                                datoAdicionalMPA.setEtiqueta("Medio de Pago");

                                datosAdicionalesFormaPago.getDatoAdicional().add(datoAdicional);
                                datosAdicionalesFormaPago.getDatoAdicional().add(datoAdicionalMPA);
                            }

                        }

                        for (DatoAdicional datoAdicionalObj : datosAdicionalesFormaPago.getDatoAdicional()) {
                            listasSeleccion = new DatoAdicional.ListasSeleccion();
                            for (FormaPago formaPagoObj : formasPago) {
                                codigo = "FPA_".concat(formaPagoObj.getMedio());
                                if (codigo.equals(datoAdicionalObj.getCodigo())) {


                                    listaSeleccion = formaPagoListaSeleccion(formaPagoObj, respuesta.getMontoTotal());
                                    listasSeleccion.getListaSeleccion().add(listaSeleccion);

                                }

                            }
                            datoAdicionalObj.setListasSeleccion(listasSeleccion);
                        }


                        respuesta.getDatosAdicionales().getDatoAdicional().addAll(datosAdicionalesFormaPago.getDatoAdicional());
                    }

                }
            }



        } catch (Exception e) {
            e.printStackTrace();
            log.error("Error en el proceso" + e.getMessage(), e);
            respuesta.setCodigoError("OTC_GTW_01");
            respuesta.setMensajeUsuario("Error no controlado: " + e.getMessage());

        }

        return respuesta;
    }


    private ListaSeleccion formaPagoListaSeleccion(FormaPago formaPagoObj, Double montoDiferir) {

        Integer plazo = formaPagoObj.getCuotas();
        Double interesObj = formaPagoObj.getInteres();
        Double tasaInteres = interesObj / 100;
        Double montoCuotas = 0.0;
        Double interes = tasaInteres / 12;

        montoCuotas = montoDiferir * ((Math.pow((1 + interes), Integer.valueOf(plazo)) * interes) / (Math.pow((1 + interes), Integer.valueOf(plazo)) - 1));
        BigDecimal bd = new BigDecimal(montoCuotas).setScale(2, RoundingMode.HALF_UP);
        montoCuotas = bd.doubleValue();

        String etiqueta = formaPagoObj.getEtiqueta().replace("#vc#", String.format("%.2f", montoCuotas.doubleValue()));

        ListaSeleccion listaSeleccion = new ListaSeleccion();
        listaSeleccion.setCodigo(formaPagoObj.getCuotas().toString());
        listaSeleccion.setEtiqueta(etiqueta);

        return listaSeleccion;
    }

    private Flujo obtenerFlujo(String convenio, String codigoEmpresa, String tipoServicio, String tipoBanca, String tipoFlujo) throws Exception {
        MensajeEntradaConsultarGrupoServicio peticionObj = new MensajeEntradaConsultarGrupoServicio();
        peticionObj.setTipoServicio(tipoServicio);
        peticionObj.setTipoBanca(tipoBanca);
        peticionObj.setCodigoEmpresa(codigoEmpresa);
        log.info("CONVENIO: " + convenio);

        MensajeSalidaConsultarGrupoServicio respuestaObj = proxyAdmin.consultarGrupoServicios(peticionObj);
        List<GrupoServicio> grupoServicios = respuestaObj.getMensaje();
        Flujo flujoObj = null;

        log.info("RESPUESTA FLUJO: " + respuestaObj);
        log.info("GRUPOS FLUJO: " + grupoServicios);
        if (grupoServicios != null && !grupoServicios.isEmpty()) {
            for (GrupoServicio grupoServicio : grupoServicios) {
                log.info("GRUPO FLUJO: " + grupoServicio);
                if (grupoServicio.getServicios() != null && !grupoServicio.getServicios().isEmpty()) {
                    for (Servicio servicio : grupoServicio.getServicios()) {
                        log.info("SERVICIO FLUJO: " + servicio);
                        if (servicio.getConvenio() != null && servicio.getConvenio().getFlujos() != null && !servicio.getConvenio().getFlujos().isEmpty() && convenio.equals(servicio.getConvenio().getCodigo())) {
                            log.info("CONVENIO FLUJO: " + servicio.getConvenio());
                            for (Flujo flujo : servicio.getConvenio().getFlujos()) {
                                log.info(" FLUJO: " + flujo);
                                log.info(" FLUJO: " + flujo.getOperacion() != null ? flujo.getOperacion().getCodigo() : "NULL");
                                if (flujo.getOperacion() != null && tipoFlujo.equals(flujo.getOperacion().getCodigo())) {
                                    log.info(" FLUJO_1: " + flujo);
                                    flujoObj = flujo;
                                    break;
                                }
                            }
                            if (flujoObj != null) {
                                break;
                            }
                        }
                    }
                    if (flujoObj != null) {
                        break;
                    }
                }
            }
        }

        return flujoObj;
    }

    private List<FormaPago> obtenerFormaPago(String convenio, String codigoEmpresa, String tipoServicio, String tipoBanca, String codigoTipoIdentificador) throws Exception {
        MensajeEntradaConsultarGrupoServicio peticionObj = new MensajeEntradaConsultarGrupoServicio();
        peticionObj.setTipoServicio(tipoServicio);
        peticionObj.setTipoBanca(tipoBanca);
        peticionObj.setCodigoEmpresa(codigoEmpresa);
        log.info("CONVENIO: " + convenio);

        MensajeSalidaConsultarGrupoServicio respuestaObj = proxyAdmin.consultarGrupoServicios(peticionObj);
        List<GrupoServicio> grupoServicios = respuestaObj.getMensaje();
        List<FormaPago> formaPagos = null;

        log.info("RESPUESTA FORMA PAGO: " + respuestaObj);
        log.info("GRUPOS FORMA PAGO: " + grupoServicios);
        if (grupoServicios != null && !grupoServicios.isEmpty()) {
            for (GrupoServicio grupoServicio : grupoServicios) {
                log.info("GRUPO FORMA PAGO: " + grupoServicio);
                if (grupoServicio.getServicios() != null && !grupoServicio.getServicios().isEmpty()) {
                    for (Servicio servicio : grupoServicio.getServicios()) {
                        log.info("SERVICIO FORMA PAGO: " + servicio);
                        if (servicio.getConvenio() != null && servicio.getConvenio().getTipoIdentificadores() != null && !servicio.getConvenio().getTipoIdentificadores().isEmpty() && convenio.equals(servicio.getConvenio().getCodigo())) {
                            log.info("CONVENIO FORMA PAGO: " + servicio.getConvenio());

                            for (com.bolivariano.otc.web.rest.client.domain.TipoIdentificador tipoIdentificador : servicio.getConvenio().getTipoIdentificadores()) {
                                log.info(" TI FORMA PAGO: " + tipoIdentificador);
                                if (codigoTipoIdentificador.equals(tipoIdentificador.getCodigo())) {
                                    formaPagos = tipoIdentificador.getFormaPagos();
                                    break;
                                }
                            }
                            if (formaPagos != null) {
                                break;
                            }
                        }
                    }
                    if (formaPagos != null) {
                        break;
                    }
                }
            }
        }

        return formaPagos;
    }


}
