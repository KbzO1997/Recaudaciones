package com.bolivariano.otc.web.rest.client.domain;

import java.io.Serializable;


public class Canal implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long id;

	private String codigo;

	private String descripcion;

	private Catalogo medioAcceso;

	private String nombre;

	public Canal() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Catalogo getMedioAcceso() {
		return medioAcceso;
	}

	public void setMedioAcceso(Catalogo medioAcceso) {
		this.medioAcceso = medioAcceso;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public String toString() {
		return "Canal{" +
				"id=" + id +
				", codigo='" + codigo + '\'' +
				", descripcion='" + descripcion + '\'' +
				", medioAcceso=" + medioAcceso +
				", nombre='" + nombre + '\'' +
				'}';
	}
}