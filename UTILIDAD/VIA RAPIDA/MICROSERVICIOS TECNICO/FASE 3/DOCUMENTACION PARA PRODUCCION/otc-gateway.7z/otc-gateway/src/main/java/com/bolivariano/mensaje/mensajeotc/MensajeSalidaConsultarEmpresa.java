
package com.bolivariano.mensaje.mensajeotc;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.bolivariano.dominio.empresa.Empresa;


/**
 * <p>Clase Java para mensajeSalidaConsultarEmpresa complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="mensajeSalidaConsultarEmpresa">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codigoError" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="empresas" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="empresa" type="{http://www.bolivariano.com/dominio/Empresa}empresa" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="mensajeUsuario" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "mensajeSalidaConsultarEmpresa", propOrder = {
    "codigoError",
    "empresas",
    "mensajeUsuario"
})
public class MensajeSalidaConsultarEmpresa {

    protected String codigoError;
    protected MensajeSalidaConsultarEmpresa.Empresas empresas;
    protected String mensajeUsuario;

    /**
     * Obtiene el valor de la propiedad codigoError.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigoError() {
        return codigoError;
    }

    /**
     * Define el valor de la propiedad codigoError.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigoError(String value) {
        this.codigoError = value;
    }

    /**
     * Obtiene el valor de la propiedad empresas.
     * 
     * @return
     *     possible object is
     *     {@link MensajeSalidaConsultarEmpresa.Empresas }
     *     
     */
    public MensajeSalidaConsultarEmpresa.Empresas getEmpresas() {
        return empresas;
    }

    /**
     * Define el valor de la propiedad empresas.
     * 
     * @param value
     *     allowed object is
     *     {@link MensajeSalidaConsultarEmpresa.Empresas }
     *     
     */
    public void setEmpresas(MensajeSalidaConsultarEmpresa.Empresas value) {
        this.empresas = value;
    }

    /**
     * Obtiene el valor de la propiedad mensajeUsuario.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMensajeUsuario() {
        return mensajeUsuario;
    }

    /**
     * Define el valor de la propiedad mensajeUsuario.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMensajeUsuario(String value) {
        this.mensajeUsuario = value;
    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="empresa" type="{http://www.bolivariano.com/dominio/Empresa}empresa" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "empresa"
    })
    public static class Empresas {

        @XmlElement(nillable = true)
        protected List<Empresa> empresa;

        /**
         * Gets the value of the empresa property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the empresa property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getEmpresa().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link Empresa }
         * 
         * 
         */
        public List<Empresa> getEmpresa() {
            if (empresa == null) {
                empresa = new ArrayList<Empresa>();
            }
            return this.empresa;
        }

    }

}
