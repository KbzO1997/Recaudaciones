package com.bolivariano.otc.web.rest.client;

import com.bolivariano.otc.service.CacheService;
import com.bolivariano.otc.web.rest.client.message.MensajeEntradaConsultarGrupoServicio;
import com.bolivariano.otc.web.rest.client.message.MensajeSalidaConsultarGrupoServicio;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

@Service
public class GrupoServicioProxy {
    //@Autowired
    // RestTemplate restTemplate;

    @Value("${otc.endpoint.admin}")
    private String endpoint;

    @Autowired
    CacheService cacheService;

    public GrupoServicioProxy() {

    }

    private ClientHttpRequestFactory getClientHttpRequestFactory() {
        int timeout = 5000;
        HttpComponentsClientHttpRequestFactory clientHttpRequestFactory
                = new HttpComponentsClientHttpRequestFactory();
        clientHttpRequestFactory.setConnectTimeout(timeout);
        return clientHttpRequestFactory;
    }

    public MensajeSalidaConsultarGrupoServicio consultarGrupoServicios(MensajeEntradaConsultarGrupoServicio peticionObj)
            throws IOException {
        MensajeSalidaConsultarGrupoServicio mscgs = null;
        ObjectMapper mapper = new ObjectMapper();

        StringBuilder cacheKey = new StringBuilder();
        if (peticionObj.getCodigoEmpresa() != null) {
            cacheKey.append(peticionObj.getCodigoEmpresa());
        } else {
            cacheKey.append(peticionObj.getNombreEmpresa());
        }
        cacheKey.append(peticionObj.getTipoBanca());
        cacheKey.append(peticionObj.getTipoServicio());
        cacheKey.append(peticionObj.getMatriculable());

        String mscgsJson = cacheService.get(cacheKey.toString());
        if (mscgsJson != null) {
            mscgs = mapper.readValue(mscgsJson, MensajeSalidaConsultarGrupoServicio.class);
        }

        if (mscgs == null || mscgs.getCodigo() == null || mscgs.getCodigo().isEmpty()) {
            RestTemplate restTemplate = new RestTemplate(getClientHttpRequestFactory());
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            HttpEntity<String> peticion = new HttpEntity<String>(mapper.writeValueAsString(peticionObj), headers);

            mscgs = restTemplate.postForObject(endpoint, peticion, MensajeSalidaConsultarGrupoServicio.class);
            cacheService.setex(cacheKey.toString(), mapper.writeValueAsString(mscgs));
        }


        return mscgs;
    }

}
