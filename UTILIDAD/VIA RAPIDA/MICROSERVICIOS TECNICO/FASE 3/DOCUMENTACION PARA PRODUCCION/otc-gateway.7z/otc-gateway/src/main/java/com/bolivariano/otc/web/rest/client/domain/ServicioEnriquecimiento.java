package com.bolivariano.otc.web.rest.client.domain;

import java.io.Serializable;
import java.util.List;


/**
 * The persistent class for the OTC_M_SERV_ENRIQUECIMIENTO database table.
 * 
 */
public class ServicioEnriquecimiento implements Serializable {
	private static final long serialVersionUID = 1L;

	
	private Long id;

	private String descripcion;

	private String puntoFinal;

	private String estado;

	private String fechaRegistro;

	private String nombre;

	private String operacion;

	private List<ServicioEnriquecimientoParam> parametros;

	private String peticion;

	public ServicioEnriquecimiento() {
	}

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getPuntoFinal() {
		return this.puntoFinal;
	}

	public void setPuntoFinal(String puntoFinal) {
		this.puntoFinal = puntoFinal;
	}

	public String getEstado() {
		return this.estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getFechaRegistro() {
		return this.fechaRegistro;
	}

	public void setFechaRegistro(String fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getOperacion() {
		return this.operacion;
	}

	public void setOperacion(String operacion) {
		this.operacion = operacion;
	}

	public List<ServicioEnriquecimientoParam> getParametros() {
		return parametros;
	}

	public void setParametros(List<ServicioEnriquecimientoParam> parametros) {
		this.parametros = parametros;
	}

	public String getPeticion() {
		return this.peticion;
	}

	public void setPeticion(String peticion) {
		this.peticion = peticion;
	}

	@Override
	public String toString() {
		return "ServicioEnriquecimiento{" +
				"id=" + id +
				", descripcion='" + descripcion + '\'' +
				", puntoFinal='" + puntoFinal + '\'' +
				", estado='" + estado + '\'' +
				", fechaRegistro='" + fechaRegistro + '\'' +
				", nombre='" + nombre + '\'' +
				", operacion='" + operacion + '\'' +
				", parametros=" + parametros +
				", peticion='" + peticion + '\'' +
				'}';
	}
}