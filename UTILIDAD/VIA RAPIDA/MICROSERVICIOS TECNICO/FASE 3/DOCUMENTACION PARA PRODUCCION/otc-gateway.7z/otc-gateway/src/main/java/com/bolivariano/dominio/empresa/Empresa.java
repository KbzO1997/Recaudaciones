
package com.bolivariano.dominio.empresa;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.bolivariano.dominio.convenio.Convenio;


/**
 * <p>Clase Java para empresa complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="empresa">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codigoEmpresa" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="etiquetaEmpresa" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="convenioVisible" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="convenios" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="convenio" type="{http://www.bolivariano.com/dominio/Convenio}convenio" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="matriculable" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="matriculacionMultiple" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="validable" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "empresa", propOrder = {
    "codigoEmpresa",
    "etiquetaEmpresa",
    "convenioVisible",
    "convenios",
    "matriculable",
    "matriculacionMultiple",
    "validable"
})
public class Empresa {

    protected String codigoEmpresa;
    protected String etiquetaEmpresa;
    protected Boolean convenioVisible;
    protected Empresa.Convenios convenios;
    protected Boolean matriculable;
    protected Boolean matriculacionMultiple;
    protected Boolean validable;

    /**
     * Obtiene el valor de la propiedad codigoEmpresa.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigoEmpresa() {
        return codigoEmpresa;
    }

    /**
     * Define el valor de la propiedad codigoEmpresa.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigoEmpresa(String value) {
        this.codigoEmpresa = value;
    }

    /**
     * Obtiene el valor de la propiedad etiquetaEmpresa.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEtiquetaEmpresa() {
        return etiquetaEmpresa;
    }

    /**
     * Define el valor de la propiedad etiquetaEmpresa.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEtiquetaEmpresa(String value) {
        this.etiquetaEmpresa = value;
    }

    /**
     * Obtiene el valor de la propiedad convenioVisible.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isConvenioVisible() {
        return convenioVisible;
    }

    /**
     * Define el valor de la propiedad convenioVisible.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setConvenioVisible(Boolean value) {
        this.convenioVisible = value;
    }

    /**
     * Obtiene el valor de la propiedad convenios.
     * 
     * @return
     *     possible object is
     *     {@link Empresa.Convenios }
     *     
     */
    public Empresa.Convenios getConvenios() {
        return convenios;
    }

    /**
     * Define el valor de la propiedad convenios.
     * 
     * @param value
     *     allowed object is
     *     {@link Empresa.Convenios }
     *     
     */
    public void setConvenios(Empresa.Convenios value) {
        this.convenios = value;
    }

    /**
     * Obtiene el valor de la propiedad matriculable.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isMatriculable() {
        return matriculable;
    }

    /**
     * Define el valor de la propiedad matriculable.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setMatriculable(Boolean value) {
        this.matriculable = value;
    }

    /**
     * Obtiene el valor de la propiedad matriculacionMultiple.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isMatriculacionMultiple() {
        return matriculacionMultiple;
    }

    /**
     * Define el valor de la propiedad matriculacionMultiple.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setMatriculacionMultiple(Boolean value) {
        this.matriculacionMultiple = value;
    }

    /**
     * Obtiene el valor de la propiedad validable.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isValidable() {
        return validable;
    }

    /**
     * Define el valor de la propiedad validable.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setValidable(Boolean value) {
        this.validable = value;
    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="convenio" type="{http://www.bolivariano.com/dominio/Convenio}convenio" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "convenio"
    })
    public static class Convenios {

        @XmlElement(nillable = true)
        protected List<Convenio> convenio;

        /**
         * Gets the value of the convenio property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the convenio property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getConvenio().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link Convenio }
         * 
         * 
         */
        public List<Convenio> getConvenio() {
            if (convenio == null) {
                convenio = new ArrayList<Convenio>();
            }
            return this.convenio;
        }

    }

}
