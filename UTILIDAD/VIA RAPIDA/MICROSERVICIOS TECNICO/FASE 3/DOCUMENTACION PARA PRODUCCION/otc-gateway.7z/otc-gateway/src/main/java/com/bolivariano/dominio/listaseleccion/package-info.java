@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.bolivariano.com/dominio/ListaSeleccion")
package com.bolivariano.dominio.listaseleccion;
