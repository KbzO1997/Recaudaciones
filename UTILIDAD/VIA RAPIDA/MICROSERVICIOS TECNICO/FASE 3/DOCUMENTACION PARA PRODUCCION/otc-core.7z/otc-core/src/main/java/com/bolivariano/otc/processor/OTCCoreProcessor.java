package com.bolivariano.otc.processor;

import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.util.List;
import java.util.UUID;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bolivariano.otc.domain.Flujo;
import com.bolivariano.otc.domain.PuntoFinal;
import com.bolivariano.otc.domain.ServicioEnriquecimiento;
import com.bolivariano.otc.enumeration.TipoFlujo;
import com.bolivariano.otc.exception.OTCCoreException;
import com.bolivariano.otc.jaxb.mensajeosb.MensajeEntradaGateway;
import com.bolivariano.otc.jaxb.mensajeosb.MensajeSalidaGateway;
import com.bolivariano.otc.jaxb.mensajeotc.MensajeEntradaConsultarDeuda;
import com.bolivariano.otc.jaxb.mensajeotc.MensajeEntradaEjecutarPago;
import com.bolivariano.otc.jaxb.mensajeotc.MensajeEntradaEjecutarReverso;
import com.bolivariano.otc.jaxb.mensajeotc.MensajeSalidaConsultarDeuda;
import com.bolivariano.otc.jaxb.mensajeotc.MensajeSalidaEjecutarPago;
import com.bolivariano.otc.jms.JmsConsumer;
import com.bolivariano.otc.jms.JmsProducer;
import com.bolivariano.otc.message.MensajeEntradaProcesar;
import com.bolivariano.otc.message.MensajeSalidaProcesar;
import com.bolivariano.otc.service.EnriquecimientoService;
import com.bolivariano.otc.util.XSLTransform;

public class OTCCoreProcessor implements Processor {

	private static final Logger log = LoggerFactory.getLogger(OTCCoreProcessor.class);
	private static final String UTF8_STR = "UTF-8";

	public void process(Exchange exchange) throws OTCCoreException {
		JmsProducer jmsProducer = (JmsProducer) exchange.getContext().getRegistry().lookupByName("jmsProducer");
		JmsConsumer jmsConsumer = (JmsConsumer) exchange.getContext().getRegistry().lookupByName("jmsConsumer");
		MensajeEntradaProcesar bodyIn = (MensajeEntradaProcesar) exchange.getIn().getBody();
		MensajeSalidaProcesar bodyOut = new MensajeSalidaProcesar();
		String userId = UUID.randomUUID().toString().replace("-", "").substring(0, 12);
		try {
			MensajeEntradaGateway mensajeEntradaGateway = new MensajeEntradaGateway();
			MensajeSalidaGateway mensajeSalidaGateway = null;
			TipoFlujo tipoFlujo = bodyIn.getTipoFlujo();
			Double valorTotal = 0D;

			Flujo flujo = bodyIn.getFlujo();
			if (flujo == null) {
				throw new OTCCoreException("Flujo no puede ser nulo. Posiblemente servicio no tiene parametrizado un Flujo.");
			}

			PuntoFinal puntoFinal = bodyIn.getFlujo().getPuntoFinal();
			if (puntoFinal == null) {
				throw new OTCCoreException("Punto final no puede se nulo.");

			}
			log.info("Punto FINAL: " + puntoFinal.getId());

			// Enriquecimiento
			List<ServicioEnriquecimiento> enriquecimientos = flujo.getServicioEnriquecimiento();
			if (enriquecimientos != null && !enriquecimientos.isEmpty()) {
				log.info("Existen enriquecimientos para flujo con id: " + flujo.getId());
				EnriquecimientoService enriquecimientoService = (EnriquecimientoService) exchange.getContext()
						.getRegistry().lookupByName("enriquecimientoService");

				for (ServicioEnriquecimiento enriquecimiento : enriquecimientos) {
					try {
						log.info("Existen enriquecimientos para flujo con id: " + flujo.getId());
						log.info("Enriquecimiento: " + enriquecimiento.getNombre());
						enriquecimientoService.enriquecer(bodyIn, enriquecimiento);
					} catch (Exception ex) {
						log.info("NO SE PUDO EJECUTAR ENRIQUECIMIENTO: " + ex.getMessage(), ex);
					}
				}
			} else {
				log.info("NO existen enriquecimientos para flujo con id: " + flujo.getId());

			}

			// atributos para JAXB
			StringWriter requestXml = new StringWriter();
			JAXBContext jaxbContext = null;
			Marshaller jaxbMarshaller = null;
			Unmarshaller jaxbUnmarshaller = null;
			Source xml = null;
			Double valorPago = null;
			Double valorComision = null;

				switch (tipoFlujo) {
				case PAGO:
					if (bodyIn.getMensajeEntradaEjecutarPago() == null) {
						throw new OTCCoreException("Mensaje PAGO de entrada no puede se nulo.");
					}

					log.info("CANAL: " + bodyIn.getMensajeEntradaEjecutarPago().getCanal());
					jaxbContext = JAXBContext.newInstance(MensajeEntradaEjecutarPago.class);
					jaxbMarshaller = jaxbContext.createMarshaller();
					jaxbMarshaller.setProperty(Marshaller.JAXB_ENCODING, UTF8_STR);
					jaxbMarshaller.marshal(bodyIn.getMensajeEntradaEjecutarPago(), requestXml);

					valorPago = bodyIn.getMensajeEntradaEjecutarPago().getValorPago();
					valorComision = bodyIn.getMensajeEntradaEjecutarPago().getValorComision();

					valorTotal = (valorPago != null ? valorPago.doubleValue() : 0D)
							+ (valorComision != null ? valorComision.doubleValue() : 0D);
					break;
				case REVERSO:
					if (bodyIn.getMensajeEntradaEjecutarReverso() == null) {
						throw new OTCCoreException("Mensaje REVERSO de entrada no puede se nulo.");
					}

					jaxbContext = JAXBContext.newInstance(MensajeEntradaEjecutarReverso.class);
					jaxbMarshaller = jaxbContext.createMarshaller();
					jaxbMarshaller.marshal(bodyIn.getMensajeEntradaEjecutarReverso(), requestXml);

					valorPago = bodyIn.getMensajeEntradaEjecutarReverso().getValorPago();
					valorComision = bodyIn.getMensajeEntradaEjecutarReverso().getValorComision();

					valorTotal = (valorPago != null ? valorPago.doubleValue() : 0D)
							+ (valorComision != null ? valorComision.doubleValue() : 0D);

					break;
				case CONSULTA:
					if (bodyIn.getMensajeEntradaConsultarDeuda() == null) {
						throw new OTCCoreException("Mensaje CONSULTA de entrada no puede se nulo.");
					}

					jaxbContext = JAXBContext.newInstance(MensajeEntradaConsultarDeuda.class);
					jaxbMarshaller = jaxbContext.createMarshaller();
					jaxbMarshaller.marshal(bodyIn.getMensajeEntradaConsultarDeuda(), requestXml);

					break;
				default:
					log.info("FLUJO NO SOPORTADO:" + tipoFlujo);
					throw new OTCCoreException("FLUJO NO SOPORTADO");
				}
				StringBuilder requestXslt = new StringBuilder();
				requestXslt.append("./xslt/");
				requestXslt.append(puntoFinal.getTransformacionPeticion());

				StringBuilder responseXslt = new StringBuilder();
				responseXslt.append("./xslt/");
				responseXslt.append(puntoFinal.getTransformacionRespuesta());

				log.info("REQUEST OTC:" + requestXml.toString());
				log.info("XSLT:" + requestXslt);

				StringBuilder mensajePeticionOSB = new StringBuilder();
				mensajePeticionOSB.append("<![CDATA[");
				mensajePeticionOSB
						.append(XSLTransform.transformFromFile(requestXslt.toString(), requestXml.toString()));
				mensajePeticionOSB.append("]]>");

				mensajeEntradaGateway.setMensaje("XML_DATA_FROM_OBJECT_OTC");
				mensajeEntradaGateway.setOperacion(puntoFinal.getOperacion());
				mensajeEntradaGateway.setPuntoFinal(puntoFinal.getPuntoFinal());
				mensajeEntradaGateway.setIdentificadorCorrelacion(userId);

				StringWriter mensajeJmsRequestWrite = new StringWriter();
				String mensajeJmsRequest = null;

				jaxbContext = JAXBContext.newInstance(MensajeEntradaGateway.class);
				jaxbMarshaller = jaxbContext.createMarshaller();
				jaxbMarshaller.marshal(mensajeEntradaGateway, mensajeJmsRequestWrite);

				if (mensajeJmsRequestWrite != null) {
					mensajeJmsRequest = mensajeJmsRequestWrite.toString();
					mensajeJmsRequest = mensajeJmsRequest.replace("XML_DATA_FROM_OBJECT_OTC",
							mensajePeticionOSB.toString());

				}

				String mensajeJmsRequestUTF8 = mensajeJmsRequest;
				byte[] ptext;
				ptext = mensajeJmsRequestUTF8.getBytes(StandardCharsets.UTF_8);
				mensajeJmsRequestUTF8 = new String(ptext, StandardCharsets.UTF_8);

				log.info("REQUEST OSB: " + mensajeJmsRequestUTF8);
				log.info("OPERACION OSB: " + mensajeEntradaGateway.getOperacion());
				log.info("PUNTO FINAL OSB: " + mensajeEntradaGateway.getPuntoFinal());

				// envia a OSB
				log.info("Inicio envio a MQ");
				jmsProducer.sendTextMessage(mensajeJmsRequestUTF8, userId, puntoFinal.getAmbiente(), tipoFlujo);
				log.info("Envio a MQ OK");
				log.info("USER ID:" + userId);

				if (!TipoFlujo.REVERSO.equals(tipoFlujo)) {
					log.info("Inicio recepcion a MQ");
					String respuesatMensajeJMS = jmsConsumer.receiveTextMessage(userId, puntoFinal.getAmbiente(),
							tipoFlujo);
					log.info("Recepcion a MQ OK");
					log.info("MENSAJE JMS:" + respuesatMensajeJMS);

					if (respuesatMensajeJMS == null) {
						throw new OTCCoreException("Mensaje de respuesta es vacio (NULL). Timeout!");
					}

					jaxbContext = JAXBContext.newInstance(MensajeSalidaGateway.class);
					jaxbUnmarshaller = jaxbContext.createUnmarshaller();
					xml = new StreamSource(new StringReader(respuesatMensajeJMS));
					mensajeSalidaGateway = (MensajeSalidaGateway) jaxbUnmarshaller.unmarshal(xml);

					if (mensajeSalidaGateway == null) {
						throw new OTCCoreException("Mensaje de respuesta es vacio (NULL).");
					}

					bodyOut.setCodigo(mensajeSalidaGateway.getCodigo());
					bodyOut.setEstado(mensajeSalidaGateway.getEstado());
					bodyOut.setMensajeUsuario(mensajeSalidaGateway.getMensajeUsuario());
				} else {
					// AG 2022: Cambio para reverso retorma mensaje de respuesta (usa timeout en
					// caso de no existir respuesta)
					log.info("Inicio recepcion a MQ");
					String respuesatMensajeJMS = jmsConsumer.receiveTextMessage(userId, puntoFinal.getAmbiente(),
							tipoFlujo);
					log.info("Recepcion a MQ OK");
					log.info("MENSAJE JMS:" + respuesatMensajeJMS);

					if (respuesatMensajeJMS == null || respuesatMensajeJMS.isEmpty()) {
						log.info("Mensaje de respuesta es vacio (NULL). Timeout! para REVERSO");
					} else {
						jaxbContext = JAXBContext.newInstance(MensajeSalidaGateway.class);
						jaxbUnmarshaller = jaxbContext.createUnmarshaller();
						xml = new StreamSource(new StringReader(respuesatMensajeJMS));
						mensajeSalidaGateway = (MensajeSalidaGateway) jaxbUnmarshaller.unmarshal(xml);

						if (mensajeSalidaGateway == null) {
							log.info("Mensaje de respuesta es vacio (NULL). para REVERSO");
						}

						bodyOut.setCodigo(mensajeSalidaGateway.getCodigo());
						bodyOut.setEstado(mensajeSalidaGateway.getEstado());
						bodyOut.setMensajeUsuario(mensajeSalidaGateway.getMensajeUsuario());
					}
				}

				if (bodyOut != null && "0".equals(bodyOut.getCodigo())) {
					String responseXml = mensajeSalidaGateway.getMensaje();
					log.info("RESPUESTA OSB: " + responseXml);

					if (responseXml == null) {
						throw new OTCCoreException("Mensaje de respuesta es vacio (NULL).");
					}

					String mensajeRespuestaXml = null;
					try {
						log.info("Transformacion XSLT de respuesta:" + responseXslt.toString());
						mensajeRespuestaXml = XSLTransform.transformFromFile(responseXslt.toString(), responseXml);
						log.info("Transformacion XSLT de respuesta OK");

					} catch (Exception exception) {
						bodyOut.setCodigo("3");
						bodyOut.setEstado("ERROR");
						bodyOut.setMensajeUsuario("Error al procesar mensaje: " + responseXml);
					}

					log.info("RESPUESTA XML: " + mensajeRespuestaXml);

					if (mensajeRespuestaXml != null) {
						mensajeRespuestaXml = mensajeRespuestaXml.replace("<![CDATA[", "").replace("]]>", "");
						log.info("RESPUESTA_FINAL: " + mensajeRespuestaXml);
						switch (tipoFlujo) {
						case PAGO:
							jaxbContext = JAXBContext.newInstance(MensajeSalidaEjecutarPago.class);
							jaxbUnmarshaller = jaxbContext.createUnmarshaller();
							xml = new StreamSource(new StringReader(mensajeRespuestaXml));

							bodyOut.setMensajeSalidaEjecutarPago(
									(MensajeSalidaEjecutarPago) jaxbUnmarshaller.unmarshal(xml));
							log.info("VALOR TOTAL INICIAL" + bodyOut.getMensajeSalidaEjecutarPago().getMontoTotal());
							if (bodyOut.getMensajeSalidaEjecutarPago() != null
									&& bodyOut.getMensajeSalidaEjecutarPago().getMontoTotal() == null
									&& valorTotal != null) {
								DecimalFormat df = new DecimalFormat("#.00");
								bodyOut.getMensajeSalidaEjecutarPago()
										.setMontoTotal(Double.valueOf(df.format(valorTotal)));
							}
							log.info("VALOR TOTAL FINAL" + bodyOut.getMensajeSalidaEjecutarPago().getMontoTotal());
							log.info("FECHA PAGO" + bodyOut.getMensajeSalidaEjecutarPago().getFechaPago());
							log.info("FECHA DEBITO" + bodyOut.getMensajeSalidaEjecutarPago().getFechaDebito());
							break;
						case REVERSO:
							if (mensajeRespuestaXml != null && !mensajeRespuestaXml.isEmpty()) {
								jaxbContext = JAXBContext.newInstance(MensajeSalidaEjecutarPago.class);
								jaxbUnmarshaller = jaxbContext.createUnmarshaller();
								xml = new StreamSource(new StringReader(mensajeRespuestaXml));

								bodyOut.setMensajeSalidaEjecutarPago(
										(MensajeSalidaEjecutarPago) jaxbUnmarshaller.unmarshal(xml));
								log.info(
										"VALOR TOTAL INICIAL" + bodyOut.getMensajeSalidaEjecutarPago().getMontoTotal());
								if (bodyOut.getMensajeSalidaEjecutarPago() != null
										&& bodyOut.getMensajeSalidaEjecutarPago().getMontoTotal() == null
										&& valorTotal != null) {
									DecimalFormat df = new DecimalFormat("#.00");
									bodyOut.getMensajeSalidaEjecutarPago()
											.setMontoTotal(Double.valueOf(df.format(valorTotal)));
								}
								log.info("VALOR TOTAL FINAL" + bodyOut.getMensajeSalidaEjecutarPago().getMontoTotal());
								log.info("FECHA PAGO" + bodyOut.getMensajeSalidaEjecutarPago().getFechaPago());
								log.info("FECHA DEBITO" + bodyOut.getMensajeSalidaEjecutarPago().getFechaDebito());
							}

							break;
						case CONSULTA:
							jaxbContext = JAXBContext.newInstance(MensajeSalidaConsultarDeuda.class);
							jaxbUnmarshaller = jaxbContext.createUnmarshaller();
							xml = new StreamSource(new StringReader(mensajeRespuestaXml));

							bodyOut.setMensajeSalidaConsultarDeuda(
									(MensajeSalidaConsultarDeuda) jaxbUnmarshaller.unmarshal(xml));
							break;
						default:
							log.info("FLUJO NO SOPORTADO:" + tipoFlujo);
							throw new OTCCoreException("FLUJO NO SOPORTADO");
						}
					}

				}

				if (mensajeSalidaGateway != null && !"0".equals(bodyOut.getCodigo())) {
					bodyOut.setMensajeUsuario(mensajeSalidaGateway.getMensajeUsuario());
				}

		} catch (Exception ex) {
			log.error("Error al ejecutar servicio: " + ex.getMessage(), ex);
			bodyOut.setCodigo("OTC_CORE02");
			bodyOut.setEstado("ERROR");
			bodyOut.setMensajeUsuario("Error al procesar mensaje (OTC Core): " + ex.getMessage());

		}
		exchange.getIn().setBody(bodyIn);
		exchange.getOut().setBody(bodyOut);
	}
}
