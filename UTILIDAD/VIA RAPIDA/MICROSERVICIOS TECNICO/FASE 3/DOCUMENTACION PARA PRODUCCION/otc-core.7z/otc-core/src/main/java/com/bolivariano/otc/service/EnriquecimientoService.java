package com.bolivariano.otc.service;

import com.bolivariano.otc.domain.ServicioEnriquecimiento;
import com.bolivariano.otc.exception.OTCCoreException;
import com.bolivariano.otc.jaxb.dominio.datoadicional.DatoAdicional;
import com.bolivariano.otc.jaxb.dominio.servicio.Servicio;
import com.bolivariano.otc.jaxb.mensajeotc.MensajeEntradaEjecutarPago;
import com.bolivariano.otc.jaxb.mensajeotc.MensajeEntradaEjecutarReverso;
import com.bolivariano.otc.message.MensajeEntradaProcesar;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.*;
import javax.xml.xpath.*;
import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import com.sun.net.ssl.internal.ssl.Provider;
import java.security.SecureRandom;
import java.security.Security;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.List;

@Service
public class EnriquecimientoService extends WebServiceGatewaySupport {

    @Autowired
    CacheService cacheService;

    private static final Logger log = LoggerFactory.getLogger(EnriquecimientoService.class);
    private static final String ERROR_XPATH = "Ocurrio un error mientras consultaba xpath: ";

    @Value("${otc-core.web.consumer.ssl.jks-path}")
    private String jksPath;

    @Value("${otc-core.web.consumer.ssl.password}")
    private String passwordSSL;

    public void enriquecer(MensajeEntradaProcesar bodyIn, ServicioEnriquecimiento enriquecimiento) {
        List<DatoAdicional> datosAdicionales = new ArrayList<>();
        String canal = "RQ";

        switch (bodyIn.getTipoFlujo()) {
            case PAGO:
                canal = bodyIn.getMensajeEntradaEjecutarPago().getCanal();
                break;
            case REVERSO:
                canal = bodyIn.getMensajeEntradaEjecutarReverso().getCanal();
                break;
            case CONSULTA:
                canal = bodyIn.getMensajeEntradaConsultarDeuda().getCanal();
                break;
            default:
            	break;
        }

        String url = enriquecimiento.getPuntoFinal();
        if (url == null || url.isEmpty()){
            url = "https://soa.bolivariano.fin.ec:4443/Genericos/proxy/SecuencialReverso";
        }
        String operation = "SecuencialReverso";
        String strRequest = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:sec=\"http://xmlns.oracle.com/pcbpel/adapter/db/sp/SecuencialReverso\">\r\n" +
                "   <soapenv:Header/>\r\n" +
                "   <soapenv:Body>\r\n" +
                "      <sec:InputParameters>\r\n" +
                "         <sec:i_canal>"+ canal +"</sec:i_canal>\r\n" +
                "      </sec:InputParameters>\r\n" +
                "   </soapenv:Body>\r\n" +
                "</soapenv:Envelope>";

        log.info("ENRIQUECIMIENTO: Se ejecutara con los siguientes datos: \n-URL: " + url + " \n-REQUEST: " + strRequest + "\n-OPERACION: " + operation);
        String ssnReverse = null;

        try {
            String response = executeSoapSaaj(url, "1.1", strRequest);
            if (response != null) {
                log.info("RESPUESTA ENRIQUECIMIENTO: " + response);
                String value = null;
                value = getValueByXPath(response, "//s_ssn/text()");
                if (value != null) {
                    DatoAdicional ssn = new DatoAdicional();
                    ssn.setCodigo("s_ssn");
                    ssn.setValor(value);
                    datosAdicionales.add(ssn);
                    ssnReverse = value;

                }
                value = getValueByXPath(response, "//s_user/text()");
                if (value != null) {
                    DatoAdicional ssn = new DatoAdicional();
                    ssn.setCodigo("s_user");
                    ssn.setValor(value);
                    datosAdicionales.add(ssn);

                }
                value = getValueByXPath(response, "//s_sesn/text()");
                if (value != null) {
                    DatoAdicional sesn = new DatoAdicional();
                    sesn.setCodigo("s_sesn");
                    sesn.setValor(value);
                    datosAdicionales.add(sesn);

                }
                value = getValueByXPath(response, "//s_term/text()");
                if (value != null) {
                    DatoAdicional tern = new DatoAdicional();
                    tern.setCodigo("s_term");
                    tern.setValor(value);
                    datosAdicionales.add(tern);

                }
                value = getValueByXPath(response, "//s_ofi/text()");
                if (value != null) {
                    DatoAdicional ofi = new DatoAdicional();
                    ofi.setCodigo("s_ofi");
                    ofi.setValor(value);
                    datosAdicionales.add(ofi);

                }
                value = getValueByXPath(response, "//s_rol/text()");
                if (value != null) {
                    DatoAdicional rol = new DatoAdicional();
                    rol.setCodigo("s_rol");
                    rol.setValor(value);
                    datosAdicionales.add(rol);

                }

                value = getValueByXPath(response, "//s_date/text()");
                if (value != null) {
                    DatoAdicional sDate = new DatoAdicional();
                    sDate.setCodigo("s_date");
                    sDate.setValor(value);
                    datosAdicionales.add(sDate);

                }
                value = getValueByXPath(response, "//s_srv/text()");
                if (value != null) {
                    DatoAdicional sSrv = new DatoAdicional();
                    sSrv.setCodigo("s_srv");
                    sSrv.setValor(value);
                    datosAdicionales.add(sSrv);

                }
                value = getValueByXPath(response, "//s_lsrv/text()");
                if (value != null) {
                    DatoAdicional sLsrv = new DatoAdicional();
                    sLsrv.setCodigo("s_lsrv");
                    sLsrv.setValor(value);
                    datosAdicionales.add(sLsrv);

                }
                value = getValueByXPath(response, "//s_org_err/text()");
                if (value != null) {
                    DatoAdicional sOrgErr = new DatoAdicional();
                    sOrgErr.setCodigo("s_org_err");
                    sOrgErr.setValor(value);
                    datosAdicionales.add(sOrgErr);

                }
                value = getValueByXPath(response, "//s_org/text()");
                if (value != null) {
                    DatoAdicional sOrg = new DatoAdicional();
                    sOrg.setCodigo("s_org");
                    sOrg.setValor(value);
                    datosAdicionales.add(sOrg);

                }
                value = getValueByXPath(response, "//s_error/text()");
                if (value != null) {
                    DatoAdicional sError = new DatoAdicional();
                    sError.setCodigo("s_error");
                    sError.setValor(value);
                    datosAdicionales.add(sError);

                }
                value = getValueByXPath(response, "//s_sev/text()");
                if (value != null) {
                    DatoAdicional sSev = new DatoAdicional();
                    sSev.setCodigo("s_sev");
                    sSev.setValor(value);
                    datosAdicionales.add(sSev);

                }
                value = getValueByXPath(response, "//s_msg/text()");
                if (value != null) {
                    DatoAdicional sMsg = new DatoAdicional();
                    sMsg.setCodigo("s_msg");
                    sMsg.setValor(value);
                    datosAdicionales.add(sMsg);

                }
                value = getValueByXPath(response, "//t_debug/text()");
                if (value != null) {
                    DatoAdicional tDebug = new DatoAdicional();
                    tDebug.setCodigo("t_debug");
                    tDebug.setValor(value);
                    datosAdicionales.add(tDebug);

                }
                value = getValueByXPath(response, "//t_file/text()");
                if (value != null) {
                    DatoAdicional tFile = new DatoAdicional();
                    tFile.setCodigo("t_file");
                    tFile.setValor(value);
                    datosAdicionales.add(tFile);

                }
                value = getValueByXPath(response, "//t_from/text()");
                if (value != null) {
                    DatoAdicional tFrom = new DatoAdicional();
                    tFrom.setCodigo("t_from");
                    tFrom.setValor(value);
                    datosAdicionales.add(tFrom);

                }
                value = getValueByXPath(response, "//t_trn/text()");
                if (value != null) {
                    DatoAdicional tTrn = new DatoAdicional();
                    tTrn.setCodigo("t_trn");
                    tTrn.setValor(value);
                    datosAdicionales.add(tTrn);

                }
                value = getValueByXPath(response, "//o_msj_error/text()");
                if (value != null) {
                    DatoAdicional oMsjError = new DatoAdicional();
                    oMsjError.setCodigo("o_msj_error");
                    oMsjError.setValor(value);
                    datosAdicionales.add(oMsjError);

                }
            } else {
                log.info("Servicio de enriquecimiento devolvio null");

            }
        } catch (Exception e) {
            log.info("Error invocando enriquecimeinto: " + e.getMessage(), e);

        }

        log.info("FIN ENRIQUECIMIENTO: Proceso termina con los siguientes datos adicionales: " + datosAdicionales.size());

        switch (bodyIn.getTipoFlujo()) {
            case PAGO:

                if (bodyIn.getMensajeEntradaEjecutarPago().getDatosAdicionales() == null) {
                    MensajeEntradaEjecutarPago.DatosAdicionales value = new MensajeEntradaEjecutarPago.DatosAdicionales();
                    bodyIn.getMensajeEntradaEjecutarPago().setDatosAdicionales(value);
                }
                bodyIn.getMensajeEntradaEjecutarPago().getDatosAdicionales().getDatoAdicional().addAll(datosAdicionales);
                try {
                    cacheService.setex(bodyIn.getMensajeEntradaEjecutarPago().getSecuencial(), ssnReverse);
                } catch (Exception ex) {
                    log.error("Error al cacher SSN", ex);
                }
                break;
            case REVERSO:
                if (bodyIn.getMensajeEntradaEjecutarReverso().getDatosAdicionales() == null) {
                    MensajeEntradaEjecutarReverso.DatosAdicionales value = new MensajeEntradaEjecutarReverso.DatosAdicionales();
                    bodyIn.getMensajeEntradaEjecutarReverso().setDatosAdicionales(value);
                }

                try {
                    ssnReverse = cacheService.get(bodyIn.getMensajeEntradaEjecutarReverso().getSecuencial());
                    DatoAdicional ssn_reverse = new DatoAdicional();
                    ssn_reverse.setCodigo("s_ssn_reverse");
                    ssn_reverse.setValor(ssnReverse);
                    datosAdicionales.add(ssn_reverse);

                } catch (Exception ex) {
                    log.error("Error al obtener SSN REVERSE", ex);
                }
                bodyIn.getMensajeEntradaEjecutarReverso().getDatosAdicionales().getDatoAdicional().addAll(datosAdicionales);
                break;
            case CONSULTA:
                if (bodyIn.getMensajeEntradaConsultarDeuda().getServicio().getDatosAdicionales() == null) {
                    Servicio.DatosAdicionales value = new Servicio.DatosAdicionales();
                    bodyIn.getMensajeEntradaConsultarDeuda().getServicio().setDatosAdicionales(value);
                }
                bodyIn.getMensajeEntradaConsultarDeuda().getServicio().getDatosAdicionales().getDatoAdicional().addAll(datosAdicionales);
                break;
        }

    }

    private String executeSoapSaaj(String url, String soapVersion, String tramaRequest) throws OTCCoreException, NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, KeyStoreException, UnrecoverableKeyException, KeyManagementException, UnsupportedOperationException, SOAPException {
        log.info("Empieza servicio de invocacion de servicio, valores SSL definidos: " + jksPath + " - " + passwordSSL);
        System.setProperty("javax.net.ssl.trustStore", jksPath);
        System.setProperty("javax.net.ssl.trustStorePassword", passwordSSL);

        Security.addProvider(new Provider());

        KeyStore keyStore = KeyStore.getInstance("JKS");
        keyStore.load(new FileInputStream(jksPath), passwordSSL.toCharArray());

        KeyManagerFactory factory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        factory.init(keyStore, passwordSSL.toCharArray());

        SSLContext sc = SSLContext.getInstance("SSL");
        sc.init(factory.getKeyManagers(), null, new SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

        SOAPConnectionFactory soapConnFactory = SOAPConnectionFactory.newInstance();
        SOAPConnection connection = soapConnFactory.createConnection();

        URL endpoint = new URL(new URL(url),
                "",
                new URLStreamHandler() {
                    @Override
                    protected URLConnection openConnection(URL url) throws IOException {
                        URL target = new URL(url.toString());
                        URLConnection connection = target.openConnection();
                        connection.setConnectTimeout(1000 * 60);
                        connection.setReadTimeout(1000 * 60);
                        return (connection);

                    }
                }
        );
        MessageFactory messageFactory;
        MimeHeaders mimeHeaders = new MimeHeaders();
        mimeHeaders.addHeader("SOAPAction", "");
        if (!(soapVersion != null && soapVersion.equals("1.2"))) {
            messageFactory = MessageFactory.newInstance(SOAPConstants.SOAP_1_1_PROTOCOL);
            mimeHeaders.addHeader("Content-Type", SOAPConstants.SOAP_1_1_CONTENT_TYPE);
            mimeHeaders.addHeader("Accept", SOAPConstants.SOAP_1_1_CONTENT_TYPE);

        } else {
            messageFactory = MessageFactory.newInstance(SOAPConstants.SOAP_1_2_PROTOCOL);
            mimeHeaders.addHeader("Content-Type", SOAPConstants.SOAP_1_2_CONTENT_TYPE);
            mimeHeaders.addHeader("Accept", SOAPConstants.SOAP_1_2_CONTENT_TYPE);

        }
        // ARMA EL REQUEST
        ByteArrayInputStream is = new ByteArrayInputStream(tramaRequest.getBytes());
        SOAPMessage requestMessage = messageFactory.createMessage(mimeHeaders, is);
        // REALIZO INVOCACION
        log.info("Invocando el servicio");
        SOAPMessage responseMessage = connection.call(requestMessage, endpoint);
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        responseMessage.writeTo(os);

        return new String(os.toByteArray());
    }


    private String getValueByXPath(String xml, String expression) {
        String value = null;
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        Document doc = null;
        try {
            builder = factory.newDocumentBuilder();
            doc = builder.parse(new InputSource(new StringReader(xml)));
            // Create XPathFactory object
            XPathFactory xpathFactory = XPathFactory.newInstance();

            // Create XPath object
            XPath xpath = xpathFactory.newXPath();

            try {
                log.info("EXPRESSION XPATHQUERY: " + expression);
                XPathExpression expr = xpath.compile(expression);
                value = (String) expr.evaluate(doc, XPathConstants.STRING);
                log.info("Se encontro el siguiente valor para el nombre " + expression + ": " + value);

            } catch (XPathExpressionException e) {
                log.info(ERROR_XPATH + e.getMessage());

            }
        } catch (ParserConfigurationException e) {
            log.info(ERROR_XPATH + e.getMessage());

        } catch (SAXException e) {
            log.info(ERROR_XPATH + e.getMessage());

        } catch (IOException e) {
            log.info(ERROR_XPATH + e.getMessage());

        }
        return value;
    }
}
