package com.bolivariano.otc.jms;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;

import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.Message;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import com.bolivariano.otc.enumeration.TipoFlujo;
import com.bolivariano.otc.exception.OTCCoreException;

@Component
public class JmsConsumer {

    private static final Logger log = LoggerFactory.getLogger(JmsConsumer.class);

    @Autowired
    JmsTemplate jmsTemplate;

    @Value("${servers.mq.queue.replay}")
    String destinationQueue11g;

    @Value("${servers.mq.queue.replay12c}")
    String destinationQueue12c;

    @Value("${servers.mq.queue.replayMS}")
    String destinationQueueMS;
    
    @Value("${servers.mq.queue.consultaResp}")
    String consultaRespQueue;
    
   	@Value("${servers.mq.queue.pagoResp}")
    String pagoRespQueue;
    
    @Value("${servers.mq.queue.reversoResp}")
    String reversoRespQueue;    

    @Value("${servers.mq.timeout}")
    private long timeout;

    // Metodo serializa objeto automaticamente
    // Comentado en Refactory NO-USE

    public String receiveTextMessage(final String userId, final String ambiente, final TipoFlujo tipoFlujo) throws OTCCoreException, JMSException, UnsupportedEncodingException {
        String destinationQueue =null;
        StringBuilder selector = new StringBuilder();
        String result = null;

        if (ambiente != null && "12c".equals(ambiente)){
            selector.append("JMSXUserID='");
            selector.append(userId);
            selector.append("'");
            destinationQueue = destinationQueue12c;
        }else if (ambiente != null && "CLT".equals(ambiente)){
            selector.append("JMSCorrelationID='");
            selector.append(userId);
            selector.append("'");
            destinationQueue = destinationQueueMS;
        }else if (ambiente != null && "RMS".equals(ambiente)){
            selector.append("JMSCorrelationID='");
            selector.append(userId);
            selector.append("'");
            switch (tipoFlujo) {
			case CONSULTA:
				 destinationQueue = consultaRespQueue;
				break;
			case PAGO:
				 destinationQueue = pagoRespQueue;
				break;
			case REVERSO:
				 destinationQueue = reversoRespQueue;
				break;
			default:
				log.info("CORRELATION NO SOPORTADO:" + tipoFlujo);
				throw new OTCCoreException("CORRELATION NO SOPORTADO");
			}
        }else {
            selector.append("JMSXUserID='");
            selector.append(userId);
            selector.append("'");
            destinationQueue = destinationQueue11g;
        }

        log.info("JMSXUserID: " + userId);
        log.info("ambiente: " + ambiente);
        log.info("destinationQueue: " + destinationQueue);
        log.info("Selector: " + selector);
        log.info("SOBRE ESCRIBRE TIMEOUT: " + timeout);

        jmsTemplate.setReceiveTimeout(timeout);
        Message message = jmsTemplate.receiveSelected(destinationQueue, selector.toString());
        log.info("Mensaje JMS recibido: " + message);

        if (message instanceof BytesMessage) {
            log.info("JMSCorrelationID: " + message.getJMSCorrelationID() );
            BytesMessage byteMessage = (BytesMessage) message;
            byte[] byteData = new byte[(int) byteMessage.getBodyLength()];
            byteMessage.readBytes(byteData);
            byteMessage.reset();
            result = new String(byteData, StandardCharsets.UTF_8);
        }

        return result;

    }

}
