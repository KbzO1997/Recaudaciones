package com.bolivariano.otc.domain;

import java.io.Serializable;
import java.util.List;


/**
 * The persistent class for the OTC_M_IDENTIFICADOR database table.
 *
 */

public class TipoIdentificador implements Serializable {
    private static final long serialVersionUID = 1L;

    private Long id;

    private String codigo;

    private String etiquetaCodigo;

    private String concatenadorRegionalArea;

    private List<DatoAdicional> datoAdicionales;

    private String flujoAyuda;

    private String mascara;

    private Boolean matriculable;

    private Boolean programable;

    private String regexp;

    private List<RegionalArea> regionalAreas;

    private String textoAyuda;


    public TipoIdentificador() {
    	//Constructor vacio por sonarq
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getEtiquetaCodigo() {
        return etiquetaCodigo;
    }

    public void setEtiquetaCodigo(String etiquetaCodigo) {
        this.etiquetaCodigo = etiquetaCodigo;
    }

    public String getConcatenadorRegionalArea() {
        return concatenadorRegionalArea;
    }

    public void setConcatenadorRegionalArea(String concatenadorRegionalArea) {
        this.concatenadorRegionalArea = concatenadorRegionalArea;
    }

    public List<DatoAdicional> getDatoAdicionales() {
        return datoAdicionales;
    }

    public void setDatoAdicionales(List<DatoAdicional> datoAdicionales) {
        this.datoAdicionales = datoAdicionales;
    }

    public String getFlujoAyuda() {
        return flujoAyuda;
    }

    public void setFlujoAyuda(String flujoAyuda) {
        this.flujoAyuda = flujoAyuda;
    }

    public String getMascara() {
        return mascara;
    }

    public void setMascara(String mascara) {
        this.mascara = mascara;
    }

    public Boolean getMatriculable() {
        return matriculable;
    }

    public void setMatriculable(Boolean matriculable) {
        this.matriculable = matriculable;
    }

    public Boolean getProgramable() {
        return programable;
    }

    public void setProgramable(Boolean programable) {
        this.programable = programable;
    }

    public String getRegexp() {
        return regexp;
    }

    public void setRegexp(String regexp) {
        this.regexp = regexp;
    }

    public List<RegionalArea> getRegionalAreas() {
        return regionalAreas;
    }

    public void setRegionalAreas(List<RegionalArea> regionalAreas) {
        this.regionalAreas = regionalAreas;
    }

    public String getTextoAyuda() {
        return textoAyuda;
    }

    public void setTextoAyuda(String textoAyuda) {
        this.textoAyuda = textoAyuda;
    }


    @Override
    public String toString() {
        return "TipoIdentificador{" +
                "id=" + id +
                ", codigo='" + codigo + '\'' +
                ", etiquetaCodigo='" + etiquetaCodigo + '\'' +
                ", concatenadorRegionalArea='" + concatenadorRegionalArea + '\'' +
                ", datoAdicionales=" + datoAdicionales +
                ", flujoAyuda='" + flujoAyuda + '\'' +
                ", mascara='" + mascara + '\'' +
                ", matriculable=" + matriculable +
                ", programable=" + programable +
                ", regexp='" + regexp + '\'' +
                ", regionalAreas=" + regionalAreas +
                ", textoAyuda='" + textoAyuda + '\'' +
                '}';
    }
}