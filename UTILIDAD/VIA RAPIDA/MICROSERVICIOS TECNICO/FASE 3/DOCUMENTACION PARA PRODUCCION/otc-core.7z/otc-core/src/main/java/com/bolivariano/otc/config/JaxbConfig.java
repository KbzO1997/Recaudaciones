package com.bolivariano.otc.config;

import com.bolivariano.otc.web.SOAPConnector;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import javax.xml.bind.Marshaller;
import java.util.HashMap;
import java.util.Map;

@Configuration
public class JaxbConfig {

    @Bean
    public Jaxb2Marshaller marshaller() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        // this package must match the package in the <generatePackage> specified in
        // pom.xml
        Map<String,Object> properties = new HashMap<>();
        properties.put(Marshaller.JAXB_ENCODING, "UTF-8");
        marshaller.setMarshallerProperties(properties);
        marshaller.setContextPath("com.bolivariano.otc.web.wsclient");
        return marshaller;
    }

    @Bean
    public SOAPConnector soapConnector(Jaxb2Marshaller marshaller) {
        SOAPConnector client = new SOAPConnector();
        client.setDefaultUri("https://soavides.bolivariano.fin.ec:5554/Genericos/proxy/SecuencialReverso");
        client.setMarshaller(marshaller);
        client.setUnmarshaller(marshaller);
        return client;
    }
}
