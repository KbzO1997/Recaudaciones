package com.bolivariano.otc.message;

import com.bolivariano.otc.jaxb.mensajeotc.MensajeSalidaConsultarDeuda;
import com.bolivariano.otc.jaxb.mensajeotc.MensajeSalidaEjecutarPago;

import java.io.Serializable;

public class MensajeSalidaProcesar implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String codigo;
    private String mensajeUsuario;
    private String estado;
    private MensajeSalidaEjecutarPago mensajeSalidaEjecutarPago;
    private MensajeSalidaConsultarDeuda mensajeSalidaConsultarDeuda;

    public MensajeSalidaProcesar() {
    	//Constructor por sonarq
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getMensajeUsuario() {
        return mensajeUsuario;
    }

    public void setMensajeUsuario(String mensajeUsuario) {
        this.mensajeUsuario = mensajeUsuario;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public MensajeSalidaEjecutarPago getMensajeSalidaEjecutarPago() {
        return mensajeSalidaEjecutarPago;
    }

    public void setMensajeSalidaEjecutarPago(MensajeSalidaEjecutarPago mensajeSalidaEjecutarPago) {
        this.mensajeSalidaEjecutarPago = mensajeSalidaEjecutarPago;
    }

    public MensajeSalidaConsultarDeuda getMensajeSalidaConsultarDeuda() {
        return mensajeSalidaConsultarDeuda;
    }

    public void setMensajeSalidaConsultarDeuda(MensajeSalidaConsultarDeuda mensajeSalidaConsultarDeuda) {
        this.mensajeSalidaConsultarDeuda = mensajeSalidaConsultarDeuda;
    }

    @Override
    public String toString() {
        return "MensajeSalidaProcesar{" +
                "codigo='" + codigo + '\'' +
                ", mensajeUsuario='" + mensajeUsuario + '\'' +
                ", estado='" + estado + '\'' +
                ", mensajeSalidaEjecutarPago=" + mensajeSalidaEjecutarPago +
                ", mensajeSalidaConsultarDeuda=" + mensajeSalidaConsultarDeuda +
                '}';
    }
}
