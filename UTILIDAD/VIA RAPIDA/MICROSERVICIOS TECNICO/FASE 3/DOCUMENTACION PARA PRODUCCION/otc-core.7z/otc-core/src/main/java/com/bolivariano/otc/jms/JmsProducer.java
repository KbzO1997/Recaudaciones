package com.bolivariano.otc.jms;

import com.bolivariano.otc.enumeration.TipoFlujo;
import com.ibm.mq.jms.MQQueue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Service;

import javax.jms.*;

import static com.ibm.msg.client.jms.JmsConstants.JMS_IBM_CHARACTER_SET;

@Service
public class JmsProducer {

    private static final Logger log = LoggerFactory.getLogger(JmsProducer.class);

    @Autowired
    JmsTemplate jmsTemplate;

    @Value("${servers.mq.queue.request}")
    String destinationQueue11g;

    @Value("${servers.mq.queue.request12c}")
    String destinationQueue12c;

    @Value("${servers.mq.queue.requestMS}")
    String destinationQueueMS;

    @Value("${servers.mq.queue.replay}")
    String replayQueue11g;

    @Value("${servers.mq.queue.replay12c}")
    String replayQueue12c;

    @Value("${servers.mq.queue.replayMS}")
    String replayQueueMS;
    
    @Value("${servers.mq.queue.consultaReq}")
    String consultaReqQueue;    
    
    @Value("${servers.mq.queue.consultaResp}")
    String consultaRespQueue;
    
    @Value("${servers.mq.queue.pagoReq}")
    String pagoReqQueue;    
    
    @Value("${servers.mq.queue.pagoResp}")
    String pagoRespQueue;
    
    @Value("${servers.mq.queue.reversoReq}")
    String reversoReqQueue;    
    
    @Value("${servers.mq.queue.reversoResp}")
    String reversoRespQueue;    
    

    public void sendTextMessage(final String message, final String userId, final String ambiente, final TipoFlujo tipoFlujo) {
        log.info("JMS User ID: " + userId);
        log.info("AMBIENTE: " + ambiente);
        if (ambiente != null && "12c".equals(ambiente)){
            jmsTemplate.send(destinationQueue12c, new MessageCreator() {
                public Message createMessage(Session session) throws JMSException {
                    TextMessage m = session.createTextMessage();
                    m.setJMSCorrelationID(userId);
                    m.setJMSMessageID(userId);
                    m.setJMSExpiration(50000);
                    m.setIntProperty(JMS_IBM_CHARACTER_SET, 1208);
                    m.setJMSDestination(new MQQueue(destinationQueue12c));
                    m.setJMSReplyTo(new MQQueue(replayQueue12c));
                    m.setJMSDeliveryMode(DeliveryMode.NON_PERSISTENT);
                    m.setJMSPriority(Message.DEFAULT_PRIORITY);
                    m.setJMSTimestamp(System.nanoTime());
                    m.setText(message);

                    log.info("Mensaje JMS enviado 12c: " + m);
                    return m;
                }
            });
        }else if(ambiente != null && "CLT".equals(ambiente)){
            jmsTemplate.send(destinationQueueMS, new MessageCreator() {
                public Message createMessage(Session session) throws JMSException {
                    TextMessage m = session.createTextMessage();
                    m.setJMSCorrelationID(userId);
                    m.setJMSMessageID(userId);
                    m.setJMSExpiration(50000);
                    m.setIntProperty(JMS_IBM_CHARACTER_SET, 1208);
                    m.setJMSDestination(new MQQueue(destinationQueueMS));
                    m.setJMSReplyTo(new MQQueue(replayQueueMS));
                    m.setJMSDeliveryMode(DeliveryMode.NON_PERSISTENT);
                    m.setJMSPriority(Message.DEFAULT_PRIORITY);
                    m.setJMSTimestamp(System.nanoTime());
                    m.setText(message);

                    log.info("destinationQueue: " + destinationQueueMS);
                    log.info("replayQueue: " + replayQueueMS);
                    log.info("Mensaje JMS enviado CLT: " + m);
                    return m;
                }
            });
        }else if(ambiente != null && "RMS".equals(ambiente)){
        	
            jmsTemplate.send(this.getRequestQueue(tipoFlujo), new MessageCreator() {
                public Message createMessage(Session session) throws JMSException {
                	String requestQueue = getRequestQueue(tipoFlujo);
                	String responseQueue = getResponseQueue(tipoFlujo);
                	
                	TextMessage m = session.createTextMessage();
                    m.setJMSCorrelationID(userId);
                    m.setJMSMessageID(userId);
                    m.setJMSExpiration(50000);
                    m.setIntProperty(JMS_IBM_CHARACTER_SET, 1208);
                    m.setJMSDestination(new MQQueue(requestQueue));
    				m.setJMSReplyTo(new MQQueue(responseQueue));
                    
                    m.setJMSDeliveryMode(DeliveryMode.NON_PERSISTENT);
                    m.setJMSPriority(Message.DEFAULT_PRIORITY);
                    m.setJMSTimestamp(System.nanoTime());
                    m.setText(message);
                    log.info("requestQueue: " + requestQueue);
                    log.info("responseQueue: " + responseQueue);
                    log.info("Mensaje JMS enviado RMS: " + m);
                    return m;
                }
            });
        }else  {
                jmsTemplate.send(destinationQueue11g, new MessageCreator() {
                    public Message createMessage(Session session) throws JMSException {
                        TextMessage m = session.createTextMessage();
                        m.setJMSCorrelationID(userId);
                        m.setJMSMessageID(userId);
                        m.setJMSExpiration(50000);
                        m.setIntProperty(JMS_IBM_CHARACTER_SET, 1208);
                        m.setJMSDestination(new MQQueue(destinationQueue11g));
                        m.setJMSReplyTo(new MQQueue(replayQueue11g));
                        m.setJMSDeliveryMode(DeliveryMode.NON_PERSISTENT);
                        m.setJMSPriority(Message.DEFAULT_PRIORITY);
                        m.setJMSTimestamp(System.nanoTime());
                        m.setText(message);

                        log.info("Mensaje JMS enviado 11g: " + m);
                        return m;
                    }
                });
            }
        }
    
    
		private String getRequestQueue(TipoFlujo tipoFlujo) {
			switch (tipoFlujo) {
			case CONSULTA:
				return consultaReqQueue;
			case PAGO:
				return pagoReqQueue;
			case REVERSO:
				return reversoReqQueue;
			default:
				return null;
			}
    }
	
		private String getResponseQueue(TipoFlujo tipoFlujo) {
			switch (tipoFlujo) {
			case CONSULTA:
				return consultaRespQueue;
			case PAGO:
				return pagoRespQueue;
			case REVERSO:
				return reversoRespQueue;
			default:
				return null;
			}
    }
		
}
