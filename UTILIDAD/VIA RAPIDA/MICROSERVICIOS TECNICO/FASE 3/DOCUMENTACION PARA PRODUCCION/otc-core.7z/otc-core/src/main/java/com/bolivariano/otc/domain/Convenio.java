package com.bolivariano.otc.domain;

import java.io.Serializable;
import java.util.List;


/**
 * The persistent class for the OTC_M_CONVENIO database table.
 * 
 */

public class Convenio implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long id;

	private String codigo;

	private String etiquetaCodigo;

	private Boolean visible;

	private List<Flujo> flujos;

	private List<TipoIdentificador> tipoIdentificadores;


	public Convenio() {
		//Constructor vacio por sonarq
	}

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getEtiquetaCodigo() {
        return etiquetaCodigo;
    }

    public void setEtiquetaCodigo(String etiquetaCodigo) {
        this.etiquetaCodigo = etiquetaCodigo;
    }

    public Boolean getVisible() {
        return visible;
    }

    public void setVisible(Boolean visible) {
        this.visible = visible;
    }

    public List<Flujo> getFlujos() {
        return flujos;
    }

    public void setFlujos(List<Flujo> flujos) {
        this.flujos = flujos;
    }

    public List<TipoIdentificador> getTipoIdentificadores() {
        return tipoIdentificadores;
    }

    public void setTipoIdentificadores(List<TipoIdentificador> tipoIdentificadores) {
        this.tipoIdentificadores = tipoIdentificadores;
    }

    @Override
	public String toString() {
		return "Convenio{" +
				"id=" + id +
				", codigo='" + codigo + '\'' +
				", etiquetaCodigo='" + etiquetaCodigo + '\'' +
				", visible=" + visible +
				", flujos=" + flujos +
				", tipoIdentificadores=" + tipoIdentificadores +
				'}';
	}
}