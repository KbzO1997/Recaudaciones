package com.bolivariano.otc;


import com.bolivariano.otc.config.RedisConfig;
import org.apache.camel.component.servlet.CamelHttpTransportServlet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;


import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.util.TimeZone;

@SpringBootApplication
public class OTCCoreApplication {
    @Autowired
    private RedisConfig util;

    public static void main(String[] args) {
        System.setProperty("file.encoding", "UTF-8");
        SpringApplication.run(OTCCoreApplication.class, args);        
    }

    @Bean
    ServletRegistrationBean servletRegistrationBean() {
        ServletRegistrationBean servlet = new ServletRegistrationBean(new CamelHttpTransportServlet(), "/camel/*");
        servlet.setName("CamelServlet");
        return servlet;
    }

    /**
     * This method triggers initialization of the Jedis Pool. Only one Pool will be available
     * in the life of the running application.
     * Running this as @PostConstruct ensures that all the static variables
     * needed to initialize the pool are available.
     * Triggering the initialization from "main" method will result in Null Pointr
     * as the static variables would not have been initialized.
     */
    @PostConstruct
    private void initializeJedisPool() {
        TimeZone.setDefault(TimeZone.getTimeZone("America/Guayaquil"));
        util.initializeJedisPool();
    }

    /**
     * This method triggers the Jedis Pool closure.
     * Running this as @PreDestroy will ensure that the pool is closed after
     * the application is shut down.
     */
    @PreDestroy
    private void closeJedisPool() {
        util.destroyJedisPool();
    }
}
