package com.bolivariano.otc.enumeration;

public enum TipoFlujo {

    PAGO,
    CONSULTA,
    REVERSO;
}
