package com.bolivariano.otc.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bolivariano.otc.MapperUtil;
import com.bolivariano.otc.dto.ServicioEnriquecimiento;
import com.bolivariano.otc.exception.OTCAdminException;

import oracle.jdbc.OracleTypes;

@Repository
public class EnriquecimientoFlujoDAO {

    private static final Logger log = LoggerFactory.getLogger(EnriquecimientoFlujoDAO.class);

    @Autowired
    MapperUtil<ServicioEnriquecimiento> selectMapper;

    public List<ServicioEnriquecimiento> obtenerEnriquecimientoConvenio(Connection conn, Long idFlujo) throws OTCAdminException, SQLException {

        List<ServicioEnriquecimiento> enriq = null;
        StringBuilder sql = new StringBuilder();
        ResultSet rset = null;
        sql.append(" { call PA_OTC_CENRIQ_FLUJO(?,?) }");
        try (CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)){
            
            
            procStmt.setLong(1, idFlujo);
            procStmt.registerOutParameter(2, OracleTypes.CURSOR);
            procStmt.executeUpdate();
            rset = (ResultSet) procStmt.getObject(2);

            if (rset.isBeforeFirst()) {
                enriq = selectMapper.mapResultSetToObject(rset, ServicioEnriquecimiento.class);

            }


        } catch (Exception e) {
            log.error("Error en el proceso" + e.getMessage(), e);
        } finally {
            if (rset != null) {
                rset.close();
            }
        }

        return enriq;
    }
}
