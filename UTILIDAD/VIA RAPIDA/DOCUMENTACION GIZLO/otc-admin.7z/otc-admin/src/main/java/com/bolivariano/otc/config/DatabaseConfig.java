package com.bolivariano.otc.config;

import com.bolivariano.otc.exception.OTCAdminException;
import com.bolivariano.otc.web.ws.client.ConsumeWSSecurityFramework;
import com.bolivariano.otc.web.ws.client.SecurityFramework;
import org.apache.logging.log4j.LogManager;
import org.apache.tomcat.jdbc.pool.PoolProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;

@Configuration
@EnableTransactionManagement
public class DatabaseConfig {

    private static final org.apache.logging.log4j.Logger LOGGER = LogManager.getLogger(DatabaseConfig.class);

    @Autowired
    private ConsumeWSSecurityFramework consumeWSSecurityFramework;

    @Value("${otc.idApplication}")
    private String idApplication;

    @Value("${otc.userApplication}")
    private String userApplication;


    @Value("${otc.timeToRemoveSession}")
    private int timeToRemoveSession;

    @Bean
    @Qualifier("dataSource")
    @Primary
    public DataSource dataSource() {
        DataSource ds = null;
        try {

            PoolProperties poolProperties = new PoolProperties();
            poolProperties.setDriverClassName("oracle.jdbc.driver.OracleDriver");
            SecurityFramework objSecurity = consumeWSSecurityFramework.consumeWS(idApplication, userApplication);

            StringBuilder url = new StringBuilder();
            url.append("jdbc:oracle:thin:@");
            url.append(objSecurity.getServer());
            url.append(":");
            url.append(objSecurity.getPort());
            url.append("/");
            url.append(objSecurity.getDatabasename());

            LOGGER.info("URL: " + url.toString());

            poolProperties.setUrl(url.toString());
            poolProperties.setUsername(objSecurity.getUser());
            poolProperties.setPassword(objSecurity.getPassword());

            poolProperties.setInitialSize(2);
            poolProperties.setMaxIdle(10);
            poolProperties.setMinIdle(2);
            poolProperties.setRemoveAbandoned(true);
            poolProperties.setRemoveAbandonedTimeout(timeToRemoveSession);
            poolProperties.setValidationQuery("SELECT 1 FROM DUAL");
            poolProperties.setDefaultAutoCommit(false);

            ds = new org.apache.tomcat.jdbc.pool.DataSource(poolProperties);

        } catch (Exception ex) {
            LOGGER.error(ex.getMessage(), ex);
        }
        return ds;


    }

    @Bean
    public PlatformTransactionManager transactionManager(DataSource dataSource) throws OTCAdminException {
        DataSourceTransactionManager txManager = new DataSourceTransactionManager();
        txManager.setDataSource(dataSource);
        return txManager;
    }


}
