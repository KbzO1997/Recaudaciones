/*
 * Copyright (c) 2018. Banco Bolivariano.
 */

package com.bolivariano.otc.bean;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import java.io.Serializable;
import java.util.List;

/**
 * The type Paginated list wrapper.
 *
 * @param <T> the type parameter
 */
@JsonInclude(Include.NON_NULL)
public class PaginatedListServicioEnriquecimiento implements Serializable {
    /**
     *
     */
    private static final long serialVersionUID = 2004574174954910497L;
    private Integer recordsFiltered;
    private Long recordsTotal;
    private List<ServicioEnriquecimientoBean> data;

    /**
     * Gets records filtered.
     *
     * @return the records filtered
     */
    public Integer getRecordsFiltered() {
        return recordsFiltered;
    }

    /**
     * Sets records filtered.
     *
     * @param recordsFiltered the records filtered
     */
    public void setRecordsFiltered(Integer recordsFiltered) {
        this.recordsFiltered = recordsFiltered;
    }

    /**
     * Gets records total.
     *
     * @return the records total
     */
    public Long getRecordsTotal() {
        return recordsTotal;
    }

    /**
     * Sets records total.
     *
     * @param recordsTotal the records total
     */
    public void setRecordsTotal(Long recordsTotal) {
        this.recordsTotal = recordsTotal;
    }

    /**
     * Gets data.
     *
     * @return the data
     */
    public List<ServicioEnriquecimientoBean> getData() {
        return data;
    }

    /**
     * Sets data.
     *
     * @param data the data
     */
    public void setData(List<ServicioEnriquecimientoBean> data) {
        this.data = data;
    }

}