@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.bolivariano.com/MensajesFramework")
package com.bolivariano.mensajesframework;
