package com.bolivariano.otc.bean;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * The persistent class for the OTC_P_SERV_ENRIQ_PARAM database table.
 * 
 */

@JsonInclude(Include.NON_NULL)
public class ServicioEnriquecimientoParamBean implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long id;

	private Long enriquecimientoId;

	private String alias;

	private String estado;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/Guayaquil")
    private Date fechaRegistro;

	private String tipo;

	public ServicioEnriquecimientoParamBean() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getEnriquecimientoId() {
		return enriquecimientoId;
	}

	public void setEnriquecimientoId(Long enriquecimientoId) {
		this.enriquecimientoId = enriquecimientoId;
	}

	public String getAlias() {
		return alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public Date getFechaRegistro() {
		return fechaRegistro;
	}

	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	@Override
	public String toString() {
		return "ServicioEnriquecimientoParam [id=" + id + ", enriquecimientoId=" + enriquecimientoId + ", alias="
				+ alias + ", estado=" + estado + ", fechaRegistro=" + fechaRegistro + ", tipo=" + tipo + "]";
	}	
}