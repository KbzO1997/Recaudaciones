package com.bolivariano.otc.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.bolivariano.otc.bean.ConsultaFlujoBean;
import com.bolivariano.otc.bean.DatoAtxBean;
import com.bolivariano.otc.dao.ConsultaFlujoDAO;
import com.bolivariano.otc.exception.OTCAdminException;

@Service
public class ConsultaFlujoService {

	private static final Logger log = LoggerFactory.getLogger(ConsultaFlujoService.class);

    @Autowired
    ConsultaFlujoDAO consultaFlujoDAO;
    
    @Autowired
    JdbcTemplate jdbcTemplate;

    
    public ConsultaFlujoBean consultaFlujoPorTransaccion(Long transaccion) throws OTCAdminException {
    	ConsultaFlujoBean consultaFlujo = null;
        try {
            consultaFlujo = consultaFlujoDAO.consultaFlujoPorTransaccion(jdbcTemplate.getDataSource().getConnection(), transaccion);
            if (consultaFlujo != null) {
                return consultaFlujo;
            }
            return null;
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new OTCAdminException(ex.getMessage());
        }
        
    }
    
    
    public DatoAtxBean consultarDatosFlujo(Long idflujo,String banca) throws OTCAdminException {
    	
    	DatoAtxBean datosAtx = null;
        try {
            datosAtx = consultaFlujoDAO.getDatosFlujo(jdbcTemplate.getDataSource().getConnection(), idflujo, banca);
            if (datosAtx != null) {
                return datosAtx;
            }
            return null;
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new OTCAdminException(ex.getMessage());
        }
        
    }

}
