package com.bolivariano.otc.bean;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class EnriquecimientoBusqueda implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String operacion;
	private String nombre;
	public String getOperacion() {
		return operacion;
	}
	public void setOperacion(String operacion) {
		this.operacion = operacion;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	@Override
	public String toString() {
		return "EnriquecimientoBusqueda [operacion=" + operacion + ", nombre=" + nombre + "]";
	}
	
}
