package com.bolivariano.otc.service;

import com.bolivariano.otc.bean.*;
import com.bolivariano.otc.dao.*;
import com.bolivariano.otc.enumerators.RegisterStatus;
import com.bolivariano.otc.exception.OTCAdminException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class ConvenioService {

	private static final Logger log = LoggerFactory.getLogger(EmpresaService.class);
	private static final String ERROR_INSERTAR_FLUJOS   = "Error al insertar flujos: ";
	private static final String ERROR_ACTUALIZAR_FLUJOS = "Error al actualizar flujo: ";
	private static final String ERROR_INSERTAR_TIPO_IDS = "Error al insertar tipo ids: ";
	private static final String ERROR_ELIMINAR_TIPO_IDS = "Error al eliminar tipo ids: ";
	
	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	ConvenioDAO convenioDAO;

	@Autowired
	TipoIdentificadorDAO tipoIdentificadorDAO;

	@Autowired
	RegionalAreaDAO regionalAreaDAO;

	@Autowired
	DatosAdicionalesDAO datoAdicionalDAO;

	@Autowired
	FormaPagoDAO formaPagoDAO;

	@Autowired
	SeleccionDAO seleccionDAO;

	@Autowired
	FlujoDAO flujoDAO;

	@Autowired
	FlujoEnriquecimientoDAO flujoEnriquecimientoDAO;

	@Autowired
	ParametrosFlujoDAO parametrosFlujoDAO;

	@Transactional(readOnly = true)
	public List<SelectItemBean> findSelects() throws Exception {
		List<SelectItemBean> empresas = null;
		empresas = convenioDAO.findSelectConvenios(jdbcTemplate.getDataSource().getConnection());
		return empresas;
	}

	@Transactional(readOnly = true)
	public PaginatedListConvenio findAll(PaginationRequest pr) throws Exception {

		PaginatedListConvenio pagedConvenios = null;
		if (pr.getSortBy() == null || pr.getSortBy().isEmpty())
			pr.setSortBy("id");

		pagedConvenios = convenioDAO.findAll(pr, jdbcTemplate.getDataSource().getConnection());
		return pagedConvenios;

	}

	@Transactional(propagation = Propagation.REQUIRED)
	public DatabaseResponse insert(ConvenioBean convenio) throws Exception {
		DatabaseResponse dr = null;
		DatabaseResponse drFlujos = null;
		DatabaseResponse drFlujosEnr = null;
		DatabaseResponse drParamFlujo = null;

		DatabaseResponse drTipoId = null;
		DatabaseResponse drRegionalArea = null;
		DatabaseResponse drDatoAdicional = null;
		DatabaseResponse drFormaPago = null;
		DatabaseResponse drSeleccion = null;

		dr = convenioDAO.insert(jdbcTemplate, convenio);
		if (dr.getAffectedRows().intValue() == 0 || dr.getSequence().intValue() == 0
				|| dr.getSqlCode().intValue() != 0) {
			throw new OTCAdminException("Error al insertar convenio: " + dr.getMessage());
		}
		for (FlujoBean flujo : convenio.getFlujos()) {
			flujo.setConvenioId(dr.getSequence().longValue());
			drFlujos = flujoDAO.insert(jdbcTemplate, flujo);
			if (!(drFlujos.getAffectedRows().intValue() > 0 && drFlujos.getSequence().intValue() > 0
					&& drFlujos.getSqlCode().intValue() == 0)) {
				throw new OTCAdminException(ERROR_INSERTAR_FLUJOS + drFlujos.getMessage());
			}
			if (flujo.getEnriquecimientoId() != null && !flujo.getEnriquecimientoId().isEmpty()
					&& flujo.getEnriquecimientoId().size() > 0) {
				for (Long flujoEnr : flujo.getEnriquecimientoId()) {
					// flujoEnr.setFlujoId(drFlujos.getSequence().longValue());
					drFlujosEnr = flujoEnriquecimientoDAO.insert(jdbcTemplate,
							new FlujoEnriquecimientoBean(drFlujos.getSequence().longValue(), flujoEnr));
					if (!(drFlujosEnr.getAffectedRows().intValue() > 0 && drFlujosEnr.getSequence().intValue() > 0
							&& drFlujosEnr.getSqlCode().intValue() == 0)) {
						throw new OTCAdminException(ERROR_INSERTAR_FLUJOS + drFlujosEnr.getMessage());
					}
				}
			}
			if (flujo.getParametrosFlujo() != null) {
				for (ParametrosFlujoBean parametroFlujo : flujo.getParametrosFlujo()) {
					parametroFlujo.setIdFlujo(drFlujos.getSequence().longValue());
					drParamFlujo = parametrosFlujoDAO.insert(jdbcTemplate, parametroFlujo);
					if (!(drParamFlujo.getAffectedRows().intValue() > 0 && drParamFlujo.getSequence().intValue() > 0
							&& drParamFlujo.getSqlCode().intValue() == 0)) {
						throw new OTCAdminException(ERROR_INSERTAR_FLUJOS + drParamFlujo.getMessage());
					}
				}
			}
		}
		if (convenio.getTipoIdentificadores() != null && !convenio.getTipoIdentificadores().isEmpty()
				&& convenio.getTipoIdentificadores().size() > 0) {
			for (TipoIdentificadorBean detalle : convenio.getTipoIdentificadores()) {
				detalle.setConvenioId(dr.getSequence().longValue());
				drTipoId = tipoIdentificadorDAO.insert(jdbcTemplate, detalle);
				if (!(drTipoId.getAffectedRows().intValue() > 0 && drTipoId.getSequence().intValue() > 0
						&& drTipoId.getSqlCode().intValue() == 0)) {
					throw new OTCAdminException(ERROR_INSERTAR_TIPO_IDS + drTipoId.getMessage());
				}
				if (detalle.getRegionalAreasCodes() != null && !detalle.getRegionalAreasCodes().isEmpty()
						&& detalle.getRegionalAreasCodes().size() > 0) {
					for (String region : detalle.getRegionalAreasCodes()) {
						drRegionalArea = regionalAreaDAO.insert(jdbcTemplate,
								new RegionalAreaBean(drTipoId.getSequence().longValue(), region));
						if (!(drRegionalArea.getAffectedRows().intValue() > 0
								&& drRegionalArea.getSequence().intValue() > 0
								&& drRegionalArea.getSqlCode().intValue() == 0)) {
							throw new OTCAdminException("Error al insertar areas regionales: " + drTipoId.getMessage());
						}
					}
				}

				if (detalle.getDatoAdicionales() != null && !detalle.getDatoAdicionales().isEmpty()
						&& detalle.getDatoAdicionales().size() > 0) {
					for (DatoAdicionalBean datoAdic : detalle.getDatoAdicionales()) {
						datoAdic.setTipoIdentificadorId(drTipoId.getSequence().longValue());
						datoAdic.setConvenioId(dr.getSequence().longValue());
						drDatoAdicional = datoAdicionalDAO.insert(jdbcTemplate, datoAdic);
						if (!(drDatoAdicional.getAffectedRows().intValue() > 0
								&& drDatoAdicional.getSequence().intValue() > 0
								&& drDatoAdicional.getSqlCode().intValue() == 0)) {
							throw new OTCAdminException(
									"Error al insertar datos adic: " + drDatoAdicional.getMessage());
						}
						if (datoAdic.getListasSeleccion() != null && !datoAdic.getListasSeleccion().isEmpty()
								&& datoAdic.getListasSeleccion().size() > 0) {
							for (SeleccionBean seleccion : datoAdic.getListasSeleccion()) {
								seleccion.setDatoAdicionalId(drDatoAdicional.getSequence().longValue());
								// seleccion.setConvenioId(dr.getSequence().longValue());
								drSeleccion = seleccionDAO.insert(jdbcTemplate, seleccion);
								if (!(drSeleccion.getAffectedRows().intValue() > 0
										&& drSeleccion.getSequence().intValue() > 0
										&& drSeleccion.getSqlCode().intValue() == 0)) {
									throw new OTCAdminException(
											"Error al insertar selecciones " + drSeleccion.getMessage());
								}
							}
						}

					}
				}

				if (detalle.getFormaPagos() != null && !detalle.getFormaPagos().isEmpty()
						&& detalle.getFormaPagos().size() > 0) {
					for (FormaPagoBean formaPag : detalle.getFormaPagos()) {
						formaPag.setTipoId(drTipoId.getSequence().longValue());
						formaPag.setConvenioId(dr.getSequence().longValue());
						drFormaPago = formaPagoDAO.insert(jdbcTemplate, formaPag);
						if (!(drFormaPago.getAffectedRows().intValue() > 0 
						&& drFormaPago.getSequence().intValue() > 0
								&& drFormaPago.getSqlCode().intValue() == 0)) {
							throw new OTCAdminException(
									"Error al insertar forma pago: " + drFormaPago.getMessage());
						}

					}
				}

			}
		}
		return dr;

	}

	@Transactional(propagation = Propagation.REQUIRED)
	public DatabaseResponse update(ConvenioBean convenio) throws Exception {
		DatabaseResponse dr = null;
		DatabaseResponse drFlujos = null;
		DatabaseResponse drFlujosEnr = null;
		DatabaseResponse drParamFlujos = null;

		DatabaseResponse drTipoId = null;
		DatabaseResponse drRegionalArea = null;
		DatabaseResponse drDatoAdicional = null;
		DatabaseResponse drFormaPago = null;
		DatabaseResponse drSeleccion = null;
		Long enriquecimientoId = null;
		String regionalCode;

		dr = convenioDAO.update(jdbcTemplate, convenio);
		if (dr.getAffectedRows().intValue() == 0 || dr.getSqlCode().intValue() != 0) {
			throw new OTCAdminException("Error al actualizar convenio: " + dr.getMessage());
		}
		for (FlujoBean flujo : convenio.getFlujos()) {

			drFlujos = flujoDAO.update(jdbcTemplate, flujo);
			if (!(drFlujos.getAffectedRows().intValue() > 0 && drFlujos.getSqlCode().intValue() == 0)) {
				throw new OTCAdminException("Error al actualizar flujos: " + drFlujos.getMessage());
			}
			List<ParametrosFlujoBean> listaParam = flujo.getParametrosFlujo();

			if (flujo.getParametrosFlujo() != null) {

				
				for (ParametrosFlujoBean parametrosFlujo : listaParam) {
					drParamFlujos = parametrosFlujoDAO.update(jdbcTemplate, parametrosFlujo);
					if (!(drParamFlujos.getAffectedRows().intValue() > 0
							&& drParamFlujos.getSqlCode().intValue() == 0)) {
						if (parametrosFlujo != null) {
							drParamFlujos = parametrosFlujoDAO.insert(jdbcTemplate, parametrosFlujo);
							if (!(drParamFlujos.getAffectedRows().intValue() > 0
									&& drParamFlujos.getSqlCode().intValue() == 0)) {
								throw new OTCAdminException(ERROR_ACTUALIZAR_FLUJOS + drParamFlujos.getMessage());
							}
						} else {
							throw new OTCAdminException(ERROR_ACTUALIZAR_FLUJOS + drParamFlujos.getMessage());
						}
					}
				}

			} else {

			if ((flujo.getEnriquecimientoId() == null || flujo.getEnriquecimientoId().isEmpty()
					|| flujo.getEnriquecimientoId().size() == 0) && flujo.getFlujosEnriquecimiento() != null
					&& !flujo.getFlujosEnriquecimiento().isEmpty() && flujo.getFlujosEnriquecimiento().size() > 0) {
				for (FlujoEnriquecimientoBean flujoEnr : flujo.getFlujosEnriquecimiento()) {
					drFlujosEnr = flujoEnriquecimientoDAO.delete(jdbcTemplate, flujoEnr.getId());
					if (!(drFlujosEnr.getAffectedRows().intValue() > 0 
							&& drFlujosEnr.getSqlCode().intValue() == 0)) {
						throw new OTCAdminException(ERROR_ACTUALIZAR_FLUJOS + drFlujosEnr.getMessage());
					}
				}
			} else if ((flujo.getFlujosEnriquecimiento() == null || flujo.getFlujosEnriquecimiento().isEmpty()
					|| flujo.getFlujosEnriquecimiento().size() == 0) && flujo.getEnriquecimientoId() != null
					&& !flujo.getEnriquecimientoId().isEmpty() && flujo.getEnriquecimientoId().size() > 0) {
				for (Long flujoEnr : flujo.getEnriquecimientoId()) {
					drFlujosEnr = flujoEnriquecimientoDAO.insert(jdbcTemplate,
							new FlujoEnriquecimientoBean(flujo.getId(), flujoEnr));
					if (!(drFlujosEnr.getAffectedRows().intValue() > 0 
							&& drFlujosEnr.getSqlCode().intValue() == 0)) {
						throw new OTCAdminException(ERROR_ACTUALIZAR_FLUJOS + drFlujosEnr.getMessage());
					}
				}
			} else if (flujo.getEnriquecimientoId() != null && !flujo.getEnriquecimientoId().isEmpty()
					&& flujo.getEnriquecimientoId().size() > 0 && flujo.getFlujosEnriquecimiento() != null
					&& !flujo.getFlujosEnriquecimiento().isEmpty() && flujo.getFlujosEnriquecimiento().size() > 0) {
				for (FlujoEnriquecimientoBean flujoEnr : flujo.getFlujosEnriquecimiento()) {
					enriquecimientoId = flujo.getEnriquecimientoId().stream()
							.filter(x -> x.equals(flujoEnr.getEnriquecimientoId())).findFirst().orElse(null);
					if (enriquecimientoId == null) {
						drFlujosEnr = flujoEnriquecimientoDAO.delete(jdbcTemplate, flujoEnr.getId());
						if (!(drFlujosEnr.getAffectedRows().intValue() > 0
								&& drFlujosEnr.getSqlCode().intValue() == 0)) {
							throw new OTCAdminException(ERROR_ACTUALIZAR_FLUJOS + drFlujosEnr.getMessage());
						}
						// ejecutar eliminación
					} else {
						flujo.setEnriquecimientoId(flujo.getEnriquecimientoId().stream()
								.filter(x -> !x.equals(flujoEnr.getEnriquecimientoId()))
								.collect(Collectors.toList()));
					}

					}
					if (flujo.getEnriquecimientoId() != null && !flujo.getEnriquecimientoId().isEmpty()
							&& flujo.getEnriquecimientoId().size() > 0) {
						for (Long newCanal : flujo.getEnriquecimientoId()) {
							drFlujosEnr = flujoEnriquecimientoDAO.insert(jdbcTemplate,
									new FlujoEnriquecimientoBean(flujo.getId(), newCanal));
							if (!(drFlujosEnr.getAffectedRows().intValue() > 0
									&& drFlujosEnr.getSequence().intValue() > 0
									&& drFlujosEnr.getSqlCode().intValue() == 0)) {
								throw new OTCAdminException(ERROR_ACTUALIZAR_FLUJOS + drFlujosEnr.getMessage());
							}
						}
					}
				}
			}

		}

		if (convenio.getTipoIdentificadores() != null && !convenio.getTipoIdentificadores().isEmpty()
				&& convenio.getTipoIdentificadores().size() > 0) {
			for (TipoIdentificadorBean identificador : convenio.getTipoIdentificadores()) {
				if (identificador.getId() == null) {
					identificador.setConvenioId(convenio.getId());
					drTipoId = tipoIdentificadorDAO.insert(jdbcTemplate, identificador);
					if (!(drTipoId.getAffectedRows().intValue() > 0 && drTipoId.getSequence().intValue() > 0
							&& drTipoId.getSqlCode().intValue() == 0)) {
						throw new OTCAdminException(ERROR_INSERTAR_TIPO_IDS + drTipoId.getMessage());
					}

					if (identificador.getRegionalAreasCodes() != null
							&& !identificador.getRegionalAreasCodes().isEmpty()
							&& identificador.getRegionalAreasCodes().size() > 0) {
						for (String region : identificador.getRegionalAreasCodes()) {
							drRegionalArea = regionalAreaDAO.insert(jdbcTemplate,
									new RegionalAreaBean(drTipoId.getSequence().longValue(), region));
							if (!(drRegionalArea.getAffectedRows().intValue() > 0
									&& drRegionalArea.getSequence().intValue() > 0
									&& drRegionalArea.getSqlCode().intValue() == 0)) {
								throw new OTCAdminException(
										"Error al insertar areas regionales: " + drTipoId.getMessage());
							}
						}
					}
					if (identificador.getDatoAdicionales() != null && !identificador.getDatoAdicionales().isEmpty()
							&& identificador.getDatoAdicionales().size() > 0) {
						for (DatoAdicionalBean datoAdic : identificador.getDatoAdicionales()) {
							datoAdic.setTipoIdentificadorId(drTipoId.getSequence().longValue());
							datoAdic.setConvenioId(convenio.getId());
							drDatoAdicional = datoAdicionalDAO.insert(jdbcTemplate, datoAdic);
							if (!(drDatoAdicional.getAffectedRows().intValue() > 0
									&& drDatoAdicional.getSequence().intValue() > 0
									&& drDatoAdicional.getSqlCode().intValue() == 0)) {
								throw new OTCAdminException(
										"Error al insertar datos adic: " + drDatoAdicional.getMessage());
							}
							if (datoAdic.getListasSeleccion() != null && !datoAdic.getListasSeleccion().isEmpty()
									&& datoAdic.getListasSeleccion().size() > 0) {
								for (SeleccionBean seleccion : datoAdic.getListasSeleccion()) {
									seleccion.setDatoAdicionalId(drDatoAdicional.getSequence().longValue());
									// seleccion.setConvenioId(dr.getSequence().longValue());
									drSeleccion = seleccionDAO.insert(jdbcTemplate, seleccion);
									if (!(drSeleccion.getAffectedRows().intValue() > 0
											&& drSeleccion.getSequence().intValue() > 0
											&& drSeleccion.getSqlCode().intValue() == 0)) {
										throw new OTCAdminException(
												"Error al insertar selecciones " + drSeleccion.getMessage());
									}
								}
							}

						}
					}

					if (identificador.getFormaPagos() != null && !identificador.getFormaPagos().isEmpty()
							&& identificador.getFormaPagos().size() > 0) {
						for (FormaPagoBean formaPag : identificador.getFormaPagos()) {
							if (!"I".equals(formaPag.getEstado())) {
								formaPag.setTipoId(drTipoId.getSequence().longValue());
								formaPag.setConvenioId(convenio.getId());
								drFormaPago = formaPagoDAO.insert(jdbcTemplate, formaPag);
								if (!(drFormaPago.getAffectedRows().intValue() > 0
										&& drFormaPago.getSequence().intValue() > 0
										&& drFormaPago.getSqlCode().intValue() == 0)) {
									throw new OTCAdminException(
											"Error al insertar datos adic: " + drFormaPago.getMessage());
								}
							}			
						}
					}

				} else {
					if (identificador.getEstado() != null
							&& identificador.getEstado().equals(RegisterStatus.Inactivo.getValue())) {
						for (FormaPagoBean formaPago : identificador.getFormaPagos()) {
							drFormaPago = formaPagoDAO.delete(jdbcTemplate, formaPago.getId());
							if (!(drFormaPago.getAffectedRows().intValue() > 0 && drFormaPago.getSqlCode().intValue() == 0)) {
								throw new OTCAdminException("Error al eliminar formas de pago: " + drFormaPago.getMessage());
							}
						}
						drTipoId = tipoIdentificadorDAO.delete(jdbcTemplate, identificador.getId());
						if (!(drTipoId.getAffectedRows().intValue() > 0 && drTipoId.getSqlCode().intValue() == 0)) {
							throw new OTCAdminException(ERROR_ELIMINAR_TIPO_IDS + drTipoId.getMessage());
						}

					} else {

						drTipoId = tipoIdentificadorDAO.update(jdbcTemplate, identificador);
						if (!(drTipoId.getAffectedRows().intValue() > 0 && drTipoId.getSqlCode().intValue() == 0)) {
							throw new OTCAdminException(ERROR_INSERTAR_TIPO_IDS + drTipoId.getMessage());
						}
						if (identificador.getRegionalAreas() != null && !identificador.getRegionalAreas().isEmpty()
								&& identificador.getRegionalAreas().size() > 0
								&& (identificador.getRegionalAreasCodes() == null
										|| identificador.getRegionalAreasCodes().isEmpty()
										|| identificador.getRegionalAreasCodes().size() == 0)) {
							for (RegionalAreaBean regionalAreas : identificador.getRegionalAreas()) {
								drRegionalArea = regionalAreaDAO.delete(jdbcTemplate, regionalAreas.getId());
								if (!(drRegionalArea.getAffectedRows().intValue() > 0
										&& drRegionalArea.getSqlCode().intValue() == 0)) {
									throw new OTCAdminException(
											ERROR_ACTUALIZAR_FLUJOS + drRegionalArea.getMessage());
								}
							}
						} else if (identificador.getRegionalAreasCodes() != null
								&& !identificador.getRegionalAreasCodes().isEmpty()
								&& identificador.getRegionalAreasCodes().size() > 0
								&& (identificador.getRegionalAreas() == null
										|| identificador.getRegionalAreas().isEmpty()
										|| identificador.getRegionalAreas().size() == 0)) {
							for (String regionalAreas : identificador.getRegionalAreasCodes()) {
								drRegionalArea = regionalAreaDAO.insert(jdbcTemplate,
										new RegionalAreaBean(identificador.getId(), regionalAreas));
								if (!(drRegionalArea.getAffectedRows().intValue() > 0
										&& drRegionalArea.getSqlCode().intValue() == 0)) {
									throw new OTCAdminException(
											ERROR_ACTUALIZAR_FLUJOS + drRegionalArea.getMessage());
								}
							}
						} else if (identificador.getRegionalAreas() != null
								&& !identificador.getRegionalAreas().isEmpty()
								&& identificador.getRegionalAreas().size() > 0
								&& identificador.getRegionalAreasCodes() != null
								&& !identificador.getRegionalAreasCodes().isEmpty()
								&& identificador.getRegionalAreasCodes().size() > 0) {
							// log.info(servicio.getCanalesId().toString());
							for (RegionalAreaBean regionalAreas : identificador.getRegionalAreas()) {
								regionalCode = identificador.getRegionalAreasCodes().stream()
										.filter(x -> x.equals(regionalAreas.getCodigo())).findFirst().orElse(null);
								if (regionalCode == null) {
									drRegionalArea = regionalAreaDAO.delete(jdbcTemplate, regionalAreas.getId());
									if (!(drRegionalArea.getAffectedRows().intValue() > 0
											&& drRegionalArea.getSqlCode().intValue() == 0)) {
										throw new OTCAdminException(
												ERROR_ACTUALIZAR_FLUJOS + drRegionalArea.getMessage());
									}
									// ejecutar eliminación
								} else {
									identificador.setRegionalAreasCodes((identificador.getRegionalAreasCodes()
									.stream().filter(x -> !x.equals(regionalAreas.getCodigo())))
													.collect(Collectors.toList()));
								}

							}
							if (identificador.getRegionalAreasCodes() != null
									&& !identificador.getRegionalAreasCodes().isEmpty()
									&& identificador.getRegionalAreasCodes().size() > 0) {
								for (String newCanal : identificador.getRegionalAreasCodes()) {
									drRegionalArea = regionalAreaDAO.insert(jdbcTemplate,
											new RegionalAreaBean(identificador.getId(), newCanal));
									if (!(drRegionalArea.getAffectedRows().intValue() > 0
											&& drRegionalArea.getSequence().intValue() > 0
											&& drRegionalArea.getSqlCode().intValue() == 0)) {
										throw new OTCAdminException(
												"Error al actualizar regional area: " + drRegionalArea.getMessage());
									}
								}
							}

						}

						if (identificador.getDatoAdicionales() != null 
								&& !identificador.getDatoAdicionales().isEmpty()
								&& identificador.getDatoAdicionales().size() > 0) {
							for (DatoAdicionalBean datoAdic : identificador.getDatoAdicionales()) {
								if (datoAdic.getId() == null) {
									datoAdic.setTipoIdentificadorId(identificador.getId());
									datoAdic.setConvenioId(convenio.getId());
									drDatoAdicional = datoAdicionalDAO.insert(jdbcTemplate, datoAdic);
									if (!(drDatoAdicional.getAffectedRows().intValue() > 0
											&& drDatoAdicional.getSequence().intValue() > 0
											&& drDatoAdicional.getSqlCode().intValue() == 0)) {
										throw new OTCAdminException(
												"Error al insertar datos adic: " + drDatoAdicional.getMessage());
									}
									if (datoAdic.getListasSeleccion() != null
											&& !datoAdic.getListasSeleccion().isEmpty()
											&& datoAdic.getListasSeleccion().size() > 0) {
										for (SeleccionBean seleccion : datoAdic.getListasSeleccion()) {
											seleccion.setDatoAdicionalId(drDatoAdicional.getSequence().longValue());
											// seleccion.setConvenioId(dr.getSequence().longValue());
											drSeleccion = seleccionDAO.insert(jdbcTemplate, seleccion);
											if (!(drSeleccion.getAffectedRows().intValue() > 0
													&& drSeleccion.getSequence().intValue() > 0
													&& drSeleccion.getSqlCode().intValue() == 0)) {
												throw new OTCAdminException(
														"Error al insertar selecciones " + drSeleccion.getMessage());
											}
										}
									}

								} else {
									if (datoAdic.getEstado() != null
											&& datoAdic.getEstado().equals(RegisterStatus.Inactivo.getValue())) {
										drDatoAdicional = datoAdicionalDAO.delete(jdbcTemplate, datoAdic.getId());
										if (!(drDatoAdicional.getAffectedRows().intValue() > 0
												&& drDatoAdicional.getSqlCode().intValue() == 0)) {
											throw new OTCAdminException(
													ERROR_ELIMINAR_TIPO_IDS + drDatoAdicional.getMessage());
										}

									} else {
										drDatoAdicional = datoAdicionalDAO.update(jdbcTemplate, datoAdic);
										if (!(drDatoAdicional.getAffectedRows().intValue() > 0
												&& drDatoAdicional.getSqlCode().intValue() == 0)) {
											throw new OTCAdminException(
													"Error al insertar datos adic: " + drDatoAdicional.getMessage());
										}
										if (datoAdic.getListasSeleccion() != null
												&& !datoAdic.getListasSeleccion().isEmpty()
												&& datoAdic.getListasSeleccion().size() > 0) {

											for (SeleccionBean seleccion : datoAdic.getListasSeleccion()) {
												if (seleccion.getId() == null) {
													seleccion.setDatoAdicionalId(datoAdic.getId());
													// seleccion.setConvenioId(dr.getSequence().longValue());
													drSeleccion = seleccionDAO.insert(jdbcTemplate, seleccion);
													if (!(drSeleccion.getAffectedRows().intValue() > 0
															&& drSeleccion.getSequence().intValue() > 0
															&& drSeleccion.getSqlCode().intValue() == 0)) {
														throw new OTCAdminException("Error al insertar selecciones "
																+ drSeleccion.getMessage());
													}
												} else {
													if (seleccion.getEstado() != null && seleccion.getEstado()
															.equals(RegisterStatus.Inactivo.getValue())) {
														drSeleccion = seleccionDAO.delete(jdbcTemplate,
																seleccion.getId());
														if (!(drSeleccion.getAffectedRows().intValue() > 0
																&& drSeleccion.getSqlCode().intValue() == 0)) {
															throw new OTCAdminException("Error al insertar selecciones "
																	+ drSeleccion.getMessage());
														}
													} else {
														drSeleccion = seleccionDAO.update(jdbcTemplate, seleccion);
														if (!(drSeleccion.getAffectedRows().intValue() > 0
																&& drSeleccion.getSqlCode().intValue() == 0)) {
															throw new OTCAdminException("Error al insertar selecciones "
																	+ drSeleccion.getMessage());
														}
													}

												}

											}
										}

									}
								}

							}
						}

						if (identificador.getFormaPagos() != null && !identificador.getFormaPagos().isEmpty()
								&& identificador.getFormaPagos().size() > 0) {
							for (FormaPagoBean formaPag : identificador.getFormaPagos()) {
								if (formaPag.getId() == null) {
									formaPag.setTipoId(identificador.getId());
									formaPag.setConvenioId(convenio.getId());
									drFormaPago = formaPagoDAO.insert(jdbcTemplate, formaPag);
									if (!(drFormaPago.getAffectedRows().intValue() > 0
											&& drFormaPago.getSequence().intValue() > 0
											&& drFormaPago.getSqlCode().intValue() == 0)) {
										throw new OTCAdminException(
												"Error al insertar datos adic: " + drFormaPago.getMessage());
									}

								} else {
									if (formaPag.getEstado() != null
											&& formaPag.getEstado().equals(RegisterStatus.Inactivo.getValue())) {
										drFormaPago = formaPagoDAO.delete(jdbcTemplate, formaPag.getId());
										if (!(drFormaPago.getAffectedRows().intValue() > 0
												&& drFormaPago.getSqlCode().intValue() == 0)) {
											throw new OTCAdminException(
													ERROR_ELIMINAR_TIPO_IDS + drFormaPago.getMessage());
										}

									} else {

										drFormaPago = formaPagoDAO.update(jdbcTemplate, formaPag);
										if (!(drFormaPago.getAffectedRows().intValue() > 0
												&& drFormaPago.getSqlCode().intValue() == 0)) {
											throw new OTCAdminException(
													"Error al insertar datos adic: " + drFormaPago.getMessage());
										}

									}
								}

							}
						}

					}

				}
			}
		}

		return dr;

	}

	public ConvenioBean findById(Long id) throws Exception {
		ConvenioBean convenio = null;
		List<TipoIdentificadorBean> identificadores = null;

		convenio = convenioDAO.findById(jdbcTemplate.getDataSource().getConnection(), id);
		if (convenio == null) {
			return null;
		}
		log.info(convenio.toString());
		identificadores = tipoIdentificadorDAO.findByConvenioId(jdbcTemplate.getDataSource().getConnection(), id);
		convenio.setTipoIdentificadores(identificadores);
		// log.info(identificadores.toString());
		if (convenio.getTipoIdentificadores() != null && !convenio.getTipoIdentificadores().isEmpty()
				&& convenio.getTipoIdentificadores().size() > 0) {
			for (TipoIdentificadorBean identificador : convenio.getTipoIdentificadores()) {
				identificador.setRegionalAreas(regionalAreaDAO
						.findByTipoIdentificador(jdbcTemplate.getDataSource().getConnection(), identificador.getId()));
				identificador.setDatoAdicionales(datoAdicionalDAO
						.findByTipoId(jdbcTemplate.getDataSource().getConnection(), identificador.getId()));
				identificador.setFormaPagos(
						formaPagoDAO.findByTipoId(jdbcTemplate.getDataSource().getConnection(), identificador.getId()));
				log.info(" Consulta Identificador forma pago " + identificador.getFormaPagos());
				if (identificador.getDatoAdicionales() != null && !identificador.getDatoAdicionales().isEmpty()
						&& identificador.getDatoAdicionales().size() > 0) {
					for (DatoAdicionalBean dato : identificador.getDatoAdicionales()) {
						dato.setListasSeleccion(seleccionDAO
								.findByDatoAdic(jdbcTemplate.getDataSource().getConnection(), dato.getId()));
					}
				}
				log.info(convenio.getTipoIdentificadores().toString());
			}
		}

		convenio.setFlujos(flujoDAO.findByConvenio(jdbcTemplate.getDataSource().getConnection(), id));
		if (convenio.getFlujos() != null && !convenio.getFlujos().isEmpty() && convenio.getFlujos().size() > 0) {
			log.info("flujo"+convenio.getFlujos().toString());
			for (FlujoBean flujo : convenio.getFlujos()) {
				flujo.setFlujosEnriquecimiento(flujoEnriquecimientoDAO
						.findByFlujo(jdbcTemplate.getDataSource().getConnection(), flujo.getId()));
				flujo.setParametrosFlujo(
						parametrosFlujoDAO.findByFlujo(jdbcTemplate.getDataSource().getConnection(), flujo.getId()));
			}
		}

		return convenio;

	}

	public Integer countCode(String code) throws Exception {
		Integer count = null;
		// List<ServicioCanalBean> servicioCanales = null;
		count = convenioDAO.countCode(jdbcTemplate, code);
		return count;

	}

	@Transactional(propagation = Propagation.REQUIRED)
	public DatabaseResponse delete(Long convenioId) {
		DatabaseResponse dr = convenioDAO.delete(jdbcTemplate, convenioId);
		if (dr.getSqlCode().longValue() == 0L) {
			log.info(dr.getMessage());

		} else {
			log.error("Error en la transacción: " + dr.getMessage());
		}
		return dr;
	}

	public List<ConvenioBean> search(ConvenioBusqueda busqueda) throws Exception {
		List<ConvenioBean> cnvenios = null;
		cnvenios = convenioDAO.search(jdbcTemplate.getDataSource().getConnection(), busqueda);
		return cnvenios;

	}

	@Transactional(propagation = Propagation.REQUIRED)
	public List<DatabaseResponse> deleteMany(Long... ids) {
		List<DatabaseResponse> responses = new ArrayList<DatabaseResponse>();
		DatabaseResponse dr = null;
		for (Long id : ids) {
			dr = convenioDAO.delete(jdbcTemplate, id);
			dr.setSequence(new BigDecimal(id));
			responses.add(dr);

			if (dr.getSqlCode().longValue() == 0L) {
				log.info(dr.getMessage());

			} else {
				log.error("Error en la transacción: " + dr.getMessage());
			}
		}
		return responses;
	}
}
