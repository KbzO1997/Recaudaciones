package com.bolivariano.otc.bean;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * The persistent class for the OTC_M_CONVENIO database table.
 * 
 */
@JsonInclude(Include.NON_NULL)
public class ConvenioBean implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long id;

	private String codigo;

	private String etiquetaCodigo;

	private Byte visible;

	private List<FlujoBean> flujos;

	private List<TipoIdentificadorBean> tipoIdentificadores;

	public ConvenioBean() {
	}

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getEtiquetaCodigo() {
        return etiquetaCodigo;
    }

    public void setEtiquetaCodigo(String etiquetaCodigo) {
        this.etiquetaCodigo = etiquetaCodigo;
    }

    public Byte getVisible() {
        return visible;
    }

    public void setVisible(Byte visible) {
        this.visible = visible;
    }

    public List<FlujoBean> getFlujos() {
        return flujos;
    }

    public void setFlujos(List<FlujoBean> flujos) {
        this.flujos = flujos;
    }

    public List<TipoIdentificadorBean> getTipoIdentificadores() {
        return tipoIdentificadores;
    }

    public void setTipoIdentificadores(List<TipoIdentificadorBean> tipoIdentificadores) {
        this.tipoIdentificadores = tipoIdentificadores;
    }


    @Override
	public String toString() {
		return "Convenio{" +
				"id=" + id +
				", codigo='" + codigo + '\'' +
				", etiquetaCodigo='" + etiquetaCodigo + '\'' +
				", visible=" + visible +
				", flujos=" + flujos +
				", tipoIdentificadores=" + tipoIdentificadores +
				'}';
	}
}