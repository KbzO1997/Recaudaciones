package com.bolivariano.otc.dao;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.bolivariano.otc.MapperUtil;
import com.bolivariano.otc.bean.DatabaseResponse;
import com.bolivariano.otc.bean.GrupoServicioBean;
import com.bolivariano.otc.bean.GrupoServicioBusqueda;
import com.bolivariano.otc.bean.PaginatedListGrupoServicio;
import com.bolivariano.otc.bean.PaginationRequest;

import oracle.jdbc.OracleTypes;

@Repository
public class GrupoServicioDAO {

	@Autowired
	MapperUtil<GrupoServicioBean> grupoServicioBeanMapper;

	private static final Logger log = LoggerFactory.getLogger(GrupoServicioDAO.class);

	public DatabaseResponse insert(JdbcTemplate jdbcTemplate, GrupoServicioBean grupoServicio) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("pa_otc_igruposervicio")
					.declareParameters(new SqlParameter("e_empresaId", Types.NUMERIC),
							new SqlParameter("e_tipoBancaId", Types.NUMERIC),
							new SqlParameter("e_tipoServicio", Types.NUMERIC),
							new SqlParameter("e_convenvioVisible", Types.NUMERIC),
							new SqlParameter("e_matriculable", Types.NUMERIC),
							new SqlParameter("e_matriculableMult", Types.NUMERIC),
							new SqlParameter("e_validable", Types.NUMERIC),
							new SqlOutParameter("s_secuencia", Types.NUMERIC),
							new SqlOutParameter("s_afectados", Types.INTEGER),
							new SqlOutParameter("s_codigo_error", Types.NUMERIC),
							new SqlOutParameter("s_mensaje", Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_empresaId", grupoServicio.getEmpresaId());
			source.addValue("e_tipoBancaId", grupoServicio.getTipoBancaId());
			source.addValue("e_tipoServicio", grupoServicio.getTipoServicioId());
			source.addValue("e_convenvioVisible", grupoServicio.getConvenioVisible());
			source.addValue("e_matriculable", grupoServicio.getMatriculable());
			source.addValue("e_matriculableMult", grupoServicio.getMatriculacionMultiple());
			source.addValue("e_validable", grupoServicio.getValidable());
			Map<String, Object> out = simpleJdbcCall.execute(source);

			dr.setAffectedRows((Integer) out.get("s_afectados"));
			dr.setMessage((String) out.get("s_mensaje"));
			dr.setSequence((BigDecimal) out.get("s_secuencia"));
			dr.setSqlCode((BigDecimal) out.get("s_codigo_error"));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}

	public DatabaseResponse update(JdbcTemplate jdbcTemplate, GrupoServicioBean grupoServicio) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("pa_otc_agruposervicio")
					.declareParameters(new SqlParameter("e_GRP_ID", Types.NUMERIC),
							new SqlParameter("e_EMP_ID", Types.NUMERIC),
							new SqlParameter("e_CT_ID_TIPO_BANCA", Types.NUMERIC),
							new SqlParameter("e_CT_ID_TIPO_SERV", Types.NUMERIC),
							new SqlParameter("e_GRP_CONVENIO_VISIBLE", Types.NUMERIC),
							new SqlParameter("e_GRP_MATRICULABLE", Types.NUMERIC),
							new SqlParameter("e_GRP_MATRIC_MULTIPLE", Types.NUMERIC),
							new SqlParameter("e_GRP_VALIDABLE", Types.NUMERIC),
							new SqlOutParameter("s_afectados", Types.INTEGER),
							new SqlOutParameter("s_codigo_error", Types.NUMERIC),
							new SqlOutParameter("s_mensaje", Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_GRP_ID", grupoServicio.getId());
			source.addValue("e_EMP_ID", grupoServicio.getEmpresaId());
			source.addValue("e_CT_ID_TIPO_BANCA", grupoServicio.getTipoBancaId());
			source.addValue("e_CT_ID_TIPO_SERV", grupoServicio.getTipoServicioId());
			source.addValue("e_GRP_CONVENIO_VISIBLE", grupoServicio.getConvenioVisible());
			source.addValue("e_GRP_MATRICULABLE", grupoServicio.getMatriculable());
			source.addValue("e_GRP_MATRIC_MULTIPLE", grupoServicio.getMatriculacionMultiple());
			source.addValue("e_GRP_VALIDABLE", grupoServicio.getValidable());
			Map<String, Object> out = simpleJdbcCall.execute(source);
			dr.setAffectedRows((Integer) out.get("s_afectados"));
			dr.setMessage((String) out.get("s_mensaje"));
			dr.setSqlCode((BigDecimal) out.get("s_codigo_error"));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}

	public PaginatedListGrupoServicio findAll(PaginationRequest pr, Connection conn)
			throws SQLException, NoSuchMethodException {

		CallableStatement procStmt = null;
		StringBuilder SQL = new StringBuilder();
		ResultSet rs;
		List<GrupoServicioBean> empresas = null;
		PaginatedListGrupoServicio pagedEmpresas;

		try {
			SQL.append(" { call PA_OTC_GGRUPOSERVICIO(?,?,?,?,?) }");
			procStmt = conn.prepareCall(SQL.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
			procStmt.setInt("e_size", pr.getSize());
			procStmt.setInt("e_page", pr.getPage());
			procStmt.setString("e_sort", pr.getSortBy());
			procStmt.registerOutParameter("s_totalRecord", Types.NUMERIC);
			procStmt.registerOutParameter("s_result", OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rs = (ResultSet) procStmt.getObject("s_result");
			if (rs != null && rs.isBeforeFirst()) {
				empresas = grupoServicioBeanMapper.mapResultSetToObject(rs, GrupoServicioBean.class);
				pagedEmpresas = new PaginatedListGrupoServicio();
				pagedEmpresas.setRecordsFiltered(pr.getSize());
				pagedEmpresas.setRecordsTotal(procStmt.getBigDecimal("s_totalRecord").longValue());
				pagedEmpresas.setData(empresas);
				rs.close();
				procStmt.close();
				return pagedEmpresas;
			} else {
				return null;
			}

		} catch (SQLException e) {
			log.error("Error al consultar grupo servicios: " + e.getMessage(), e);
			throw new SQLException("Error al consultar servicios: " + e.getMessage(), e);
		} finally {
			if (procStmt != null)
				procStmt.close();
			if (conn != null)
				conn.close();
		}
	}

	public GrupoServicioBean findById(Connection conn, Long id) throws Exception {

		List<GrupoServicioBean> empresas = null;
		GrupoServicioBean grupoServicioBean = null;
		StringBuilder sql = new StringBuilder();
		ResultSet rset = null;
		sql.append(" { call PA_OTC_CGRUPOSERVICIO_ID(?,?) }");
		try (CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY,
				ResultSet.CONCUR_READ_ONLY)) {

			procStmt.setLong("e_id ", id);
			procStmt.registerOutParameter("S_RESPUESTA", OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject("S_RESPUESTA");
			if (rset.isBeforeFirst()) {
				empresas = grupoServicioBeanMapper.mapResultSetToObject(rset, GrupoServicioBean.class);
				return empresas.get(0);
			}
		} catch (Exception e) {
			log.error("Error en el proceso" + e.getMessage(), e);

		} finally {
			if (rset != null) {
				rset.close();
			}
		}
		return grupoServicioBean;
	}

	public DatabaseResponse delete(JdbcTemplate jdbcTemplate, Long grupoServicioId) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_EGRUPOSERVICIO")
					.declareParameters(new SqlParameter("e_grp_id", Types.NUMERIC),
							new SqlOutParameter("s_afectados", Types.INTEGER),
							new SqlOutParameter("s_codigo_error", Types.NUMERIC),
							new SqlOutParameter("s_mensaje", Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_grp_id", grupoServicioId);
			Map<String, Object> out = simpleJdbcCall.execute(source);
			dr.setAffectedRows((Integer) out.get("s_afectados"));
			dr.setMessage((String) out.get("s_mensaje"));
			dr.setSqlCode((BigDecimal) out.get("s_codigo_error"));
		} catch (Exception ex) {
			throw new RuntimeException(ex.getMessage(), ex);
		}
		return dr;
	}

	public List<GrupoServicioBean> search(Connection conn, GrupoServicioBusqueda busqueda) throws Exception {
		CallableStatement procStmt = null;
		StringBuilder SQL = new StringBuilder();
		ResultSet rset = null;
		List<GrupoServicioBean> canales = null;
		try {
			SQL.append(" { call pa_otc_cgruposervicio(?,?,?,?) }");
			log.info(busqueda.toString());
			procStmt = conn.prepareCall(SQL.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
			procStmt.setLong("e_empresa", busqueda.getEmpresa() != null ? busqueda.getEmpresa() : Long.valueOf(0));
			procStmt.setLong("e_tipoBanca",
					busqueda.getTipoBanca() != null ? busqueda.getTipoBanca() : Long.valueOf(0));
			procStmt.setLong("e_tipoServicio",
					busqueda.getTipoServicio() != null ? busqueda.getTipoServicio() : Long.valueOf(0));
			procStmt.registerOutParameter("s_result", OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject("s_result");
			// log.info(rset.toString());
			if (rset.isBeforeFirst()) {
				canales = grupoServicioBeanMapper.mapResultSetToObject(rset, GrupoServicioBean.class);
				rset.close();
				procStmt.close();
				return canales;
			} else {
				return null;
			}

		} catch (SQLException e) {
			log.error("Error al consultar gruposervicios: " + e.getMessage(), e);
			throw new SQLException("Error al consultar gruposervicios: " + e.getMessage(), e);
		} finally {
			if (procStmt != null)
				procStmt.close();
			if (conn != null)
				conn.close();
		}
	}

}
