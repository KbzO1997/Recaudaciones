package com.bolivariano.otc.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bolivariano.otc.MapperUtil;
import com.bolivariano.otc.dto.Flujo;
import com.bolivariano.otc.exception.OTCAdminException;

import oracle.jdbc.OracleTypes;

@Repository
public class FlujosConvenioDAO {

    private static final Logger log = LoggerFactory.getLogger(FlujosConvenioDAO.class);

    @Autowired
    MapperUtil<Flujo> selectMapper;

    public List<Flujo> obtenerFlujosConvenio(Connection conn, Long idConvenio) throws OTCAdminException, SQLException {

        List<Flujo> flujos = null;
        StringBuilder sql = new StringBuilder();
        ResultSet rset = null;
        sql.append(" { call PA_OTC_CFLUJOS_CONV(?,?) }");
        try (CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)){
            
            
            procStmt.setLong(1, idConvenio);
            procStmt.registerOutParameter(2, OracleTypes.CURSOR);
            procStmt.executeUpdate();
            rset = (ResultSet) procStmt.getObject(2);

            if (rset.isBeforeFirst()) {
                flujos = selectMapper.mapResultSetToObject(rset, Flujo.class);

            }

        } catch (Exception e) {
            log.error("Error en el proceso" + e.getMessage(),e);
        } finally {
            if (rset != null) {
                rset.close();
            }
        }

        return flujos;
    }
}
