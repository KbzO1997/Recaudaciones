package com.bolivariano.otc.web.rest;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bolivariano.otc.bean.SelectItemBean;
import com.bolivariano.otc.service.ServiceService;

@Component
@Path("/admin/v1/servicio")
public class ServicioRest {
	
    private static final Logger log = LoggerFactory.getLogger(ServicioRest.class);
    
    @Autowired
    ServiceService serviceService;
    
    @GET
	@Path("/select-servicios")
	@Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response findSelects() {
        log.info("getEmpresas: Petición Recibida");
        try {
        	List<SelectItemBean> servicios= this.serviceService.findSelects();
        	if(servicios == null) {
        		  return Response.status(Status.NO_CONTENT).entity(null).build();
        	}
            return Response.status(Status.OK).entity(servicios).build();
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }
}
