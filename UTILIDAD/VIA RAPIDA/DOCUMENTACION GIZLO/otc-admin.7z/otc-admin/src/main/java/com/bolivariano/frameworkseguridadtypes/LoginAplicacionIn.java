
package com.bolivariano.frameworkseguridadtypes;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="LoginAplicacion_in" type="{http://www.bolivariano.com/FrameworkSeguridadTypes}LoginAplicacionType_in"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "loginAplicacionIn"
})
@XmlRootElement(name = "LoginAplicacion_in")
public class LoginAplicacionIn {

    @XmlElement(name = "LoginAplicacion_in", required = true)
    protected LoginAplicacionTypeIn loginAplicacionIn;

    /**
     * Gets the value of the loginAplicacionIn property.
     * 
     * @return
     *     possible object is
     *     {@link LoginAplicacionTypeIn }
     *     
     */
    public LoginAplicacionTypeIn getLoginAplicacionIn() {
        return loginAplicacionIn;
    }

    /**
     * Sets the value of the loginAplicacionIn property.
     * 
     * @param value
     *     allowed object is
     *     {@link LoginAplicacionTypeIn }
     *     
     */
    public void setLoginAplicacionIn(LoginAplicacionTypeIn value) {
        this.loginAplicacionIn = value;
    }

}
