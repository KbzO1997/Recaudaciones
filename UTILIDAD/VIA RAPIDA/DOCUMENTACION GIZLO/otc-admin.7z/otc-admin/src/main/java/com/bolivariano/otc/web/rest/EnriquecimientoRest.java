package com.bolivariano.otc.web.rest;

import com.bolivariano.otc.bean.*;
import com.bolivariano.otc.service.EnriquecimientoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import java.math.BigDecimal;
import java.util.List;

@Component
@Path("/admin/v1/enriquecimiento")
public class EnriquecimientoRest {

    private static final Logger log = LoggerFactory.getLogger(EnriquecimientoRest.class);

    @Autowired
    EnriquecimientoService enriquecimientoService;


    @POST
    @Path("/save")
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response insert(ServicioEnriquecimientoBean servicioEnriquecimiento) {
        DatabaseResponse dr = new DatabaseResponse();
        try {
            log.info("insert: Peticion recibida");
            dr = enriquecimientoService.insert(servicioEnriquecimiento);
            if (dr.getSqlCode().intValue() == 0 && dr.getAffectedRows().intValue() > 0 && dr.getSequence().intValue() > 0) {
                return Response.status(Status.OK).entity(dr).build();
            } else {
                return Response.status(Status.ACCEPTED).entity(dr).build();
            }
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }

    }

    @POST
    @Path("/update")
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response update(ServicioEnriquecimientoBean servicioEnriquecimiento) {
        DatabaseResponse dr = new DatabaseResponse();
        try {
            log.info("update: Peticion recibida");
            dr = enriquecimientoService.update(servicioEnriquecimiento);
            log.info(dr.toString());
            if (dr.getSqlCode().intValue() == 0 && dr.getAffectedRows().intValue() > 0) {
                return Response.status(Status.OK).entity(dr).build();
            } else {
                return Response.status(Status.ACCEPTED).entity(dr).build();
            }
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }


    @POST
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response getServiciosEnriquecimiento(PaginationRequest pr) {
        log.info("getCatalogos: Petición Recibida");
        try {
            return Response.status(Status.OK).entity(this.enriquecimientoService.findAll(pr)).build();
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response findById(@PathParam("id") Long id) {
        log.info("findById: Petición Recibida");
        try {
            ServicioEnriquecimientoBean servicioEnriquecimientoBean = this.enriquecimientoService.findById(id);
            if (servicioEnriquecimientoBean == null) {
                return Response.status(Status.NO_CONTENT).entity(null).build();
            }
            return Response.status(Status.OK).entity(servicioEnriquecimientoBean).build();
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }

    @GET
    @Path("/select-enriquecimiento")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response findSelects() {
        log.info("getEmpresas: Petición Recibida");
        try {
            List<SelectItemBean> empresaBean = this.enriquecimientoService.findSelects();
            if (empresaBean == null) {
                return Response.status(Status.NO_CONTENT).entity(null).build();
            }
            return Response.status(Status.OK).entity(empresaBean).build();
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }

    @POST
    @Path("/delete")
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response delete(@QueryParam("id") Long id) {
        DatabaseResponse dr = new DatabaseResponse();
        log.info("delete: Peticion recibida");
        dr = enriquecimientoService.delete(id);
        return Response.status(Status.OK).entity(dr).build();
    }

    @POST
    @Path("/search")
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response search(EnriquecimientoBusqueda busqueda) {
        List<ServicioEnriquecimientoBean> enriquecimientos = null;
        try {
            log.info("search: Peticion recibida" + busqueda);
            enriquecimientos = enriquecimientoService.search(busqueda);
            if (enriquecimientos == null) {
                return Response.status(Status.NO_CONTENT).entity(null).build();
            } else {
                return Response.status(Status.OK).entity(enriquecimientos).build();
            }
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }

    @POST
    @Path("/delete-many")
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response deleteMany(Long... ids) {
        List<DatabaseResponse> responses = enriquecimientoService.deleteMany(ids);
        DatabaseResponse dr = new DatabaseResponse();

        String errorMsg = "El enriquecimiento %id no fue eliminado: %msg \b";
        StringBuilder errorMsgs = new StringBuilder();
        boolean error = false;

        for (DatabaseResponse drAux : responses) {
            if (drAux.getSqlCode().longValue() != 0L) {
                error = true;
                errorMsgs.append(errorMsg.replace("%id", drAux.getSequence().toString()).replace("%msg", drAux.getMessage()));
            }
        }
        dr.setSqlCode(!error ? new BigDecimal(0) : new BigDecimal(100));
        dr.setMessage(!error ? "Transacción Exitosa" : errorMsgs.toString());

        return Response.status(Status.OK).entity(dr).build();
    }


}
