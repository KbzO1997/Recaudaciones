
package com.bolivariano.mensajesframework;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.bolivariano.mensajebolivariano.MensajeSalida;


/**
 * <p>Java class for MensajeSalidaObtenerLlaveEspecifica complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MensajeSalidaObtenerLlaveEspecifica">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.bolivariano.com/MensajeBolivariano}MensajeSalida">
 *       &lt;sequence>
 *         &lt;element name="llave" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="passphrase" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MensajeSalidaObtenerLlaveEspecifica", propOrder = {
    "llave",
    "passphrase"
})
public class MensajeSalidaObtenerLlaveEspecifica
    extends MensajeSalida
{

    protected String llave;
    protected String passphrase;

    /**
     * Gets the value of the llave property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLlave() {
        return llave;
    }

    /**
     * Sets the value of the llave property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLlave(String value) {
        this.llave = value;
    }

    /**
     * Gets the value of the passphrase property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPassphrase() {
        return passphrase;
    }

    /**
     * Sets the value of the passphrase property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPassphrase(String value) {
        this.passphrase = value;
    }

}
