package com.bolivariano.otc.bean;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * The persistent class for the OTC_M_IDENTIFICADOR database table.
 *
 */
@JsonInclude(Include.NON_NULL)
public class TipoIdentificadorBean implements Serializable {
    private static final long serialVersionUID = 1L;

    private Long id;
    
    private Long convenioId;

    private String codigo;

    private String etiquetaCodigo;

    private String concatenadorRegionalArea;

    private List<DatoAdicionalBean> datoAdicionales;

    private List<FormaPagoBean> formaPagos;

    private String flujoAyuda;

    private String mascara;

    private Byte matriculable;

    private Byte programable;

    private String regexp;

    private List<RegionalAreaBean> regionalAreas;
    
    private List<String> regionalAreasCodes;

    private String textoAyuda;
    
    private String estado;



    public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public List<String> getRegionalAreasCodes() {
		return regionalAreasCodes;
	}

	public void setRegionalAreasCodes(List<String> regionalAreasCodes) {
		this.regionalAreasCodes = regionalAreasCodes;
	}

	public Long getConvenioId() {
		return convenioId;
	}

	public void setConvenioId(Long convenioId) {
		this.convenioId = convenioId;
	}

	

	public TipoIdentificadorBean() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getEtiquetaCodigo() {
        return etiquetaCodigo;
    }

    public void setEtiquetaCodigo(String etiquetaCodigo) {
        this.etiquetaCodigo = etiquetaCodigo;
    }

    public String getConcatenadorRegionalArea() {
        return concatenadorRegionalArea;
    }

    public void setConcatenadorRegionalArea(String concatenadorRegionalArea) {
        this.concatenadorRegionalArea = concatenadorRegionalArea;
    }

    public List<DatoAdicionalBean> getDatoAdicionales() {
        return datoAdicionales;
    }

    public void setDatoAdicionales(List<DatoAdicionalBean> datoAdicionales) {
        this.datoAdicionales = datoAdicionales;
    }

    public String getFlujoAyuda() {
        return flujoAyuda;
    }

    public void setFlujoAyuda(String flujoAyuda) {
        this.flujoAyuda = flujoAyuda;
    }

    public String getMascara() {
        return mascara;
    }

    public void setMascara(String mascara) {
        this.mascara = mascara;
    }

    public Byte getMatriculable() {
        return matriculable;
    }

    public void setMatriculable(Byte matriculable) {
        this.matriculable = matriculable;
    }

    public Byte getProgramable() {
        return programable;
    }

    public void setProgramable(Byte programable) {
        this.programable = programable;
    }

    public String getRegexp() {
        return regexp;
    }

    public void setRegexp(String regexp) {
        this.regexp = regexp;
    }

    public List<RegionalAreaBean> getRegionalAreas() {
        return regionalAreas;
    }

    public void setRegionalAreas(List<RegionalAreaBean> regionalAreas) {
        this.regionalAreas = regionalAreas;
    }

    public String getTextoAyuda() {
        return textoAyuda;
    }

    public void setTextoAyuda(String textoAyuda) {
        this.textoAyuda = textoAyuda;
    }

    public List<FormaPagoBean> getFormaPagos() {
        return formaPagos;
    }

    public void setFormaPagos(List<FormaPagoBean> formaPagos) {
        this.formaPagos = formaPagos;
    }

    @Override
    public String toString() {
        return "TipoIdentificadorBean{" +
                "id=" + id +
                ", convenioId=" + convenioId +
                ", codigo='" + codigo + '\'' +
                ", etiquetaCodigo='" + etiquetaCodigo + '\'' +
                ", concatenadorRegionalArea='" + concatenadorRegionalArea + '\'' +
                ", datoAdicionales=" + datoAdicionales +
                ", formaPagos=" + formaPagos +
                ", flujoAyuda='" + flujoAyuda + '\'' +
                ", mascara='" + mascara + '\'' +
                ", matriculable=" + matriculable +
                ", programable=" + programable +
                ", regexp='" + regexp + '\'' +
                ", regionalAreas=" + regionalAreas +
                ", regionalAreasCodes=" + regionalAreasCodes +
                ", textoAyuda='" + textoAyuda + '\'' +
                ", estado='" + estado + '\'' +
                '}';
    }
}