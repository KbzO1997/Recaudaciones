package com.bolivariano.otc.service;

import com.bolivariano.otc.bean.*;
import com.bolivariano.otc.dao.CanalesServicioDAO;
import com.bolivariano.otc.dao.GrupoServicioDAO;
import com.bolivariano.otc.dao.ServicioDAO;
import com.bolivariano.otc.enumerators.RegisterStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class GrupoServicioService {

    private static final Logger log = LoggerFactory.getLogger(GrupoServicioService.class);

    @Autowired
    GrupoServicioDAO grupoServicioDAO;

    @Autowired
    ServicioDAO servicioDAO;

    @Autowired
    CanalesServicioDAO canalServicioDAO;

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Transactional(propagation = Propagation.REQUIRED)
    public DatabaseResponse insert(GrupoServicioBean grupoServicio) throws Exception {
        DatabaseResponse dr = null;
        DatabaseResponse drService = null;
        DatabaseResponse drServiceChannel = null;

        try {
            dr = grupoServicioDAO.insert(jdbcTemplate, grupoServicio);
            if (dr.getAffectedRows().intValue() == 0 || dr.getSequence().intValue() == 0
                    || dr.getSqlCode().intValue() != 0) {
                throw new RuntimeException("Error al insertar servicio: " + dr.getMessage());
            }
            for (ServicioBean servicio : grupoServicio.getServicios()) {
                servicio.setGrupoServicioId(dr.getSequence().longValue());
                drService = servicioDAO.insert(jdbcTemplate, servicio);
                if (!(drService.getAffectedRows().intValue() > 0 && drService.getSequence().intValue() > 0
                        && drService.getSqlCode().intValue() == 0)) {
                    throw new RuntimeException("Error al insertar servicio: " + drService.getMessage());
                }
                if (servicio.getCanalesId() != null && !servicio.getCanalesId().isEmpty()
                        && servicio.getCanalesId().size() > 0) {
                    log.info(servicio.getCanalesId().toString());
                    for (Long canal : servicio.getCanalesId()) {
                        drServiceChannel = canalServicioDAO.insert(jdbcTemplate,
                                new ServicioCanalBean(drService.getSequence().longValue(), canal));
                        if (!(drServiceChannel.getAffectedRows().intValue() > 0
                                && drServiceChannel.getSequence().intValue() > 0
                                && drServiceChannel.getSqlCode().intValue() == 0)) {
                            throw new RuntimeException("Error al insertar servicio: " + drServiceChannel.getMessage());
                        }
                    }
                }
            }
            return dr;
        } catch (Exception ex) {
            throw new RuntimeException(ex.getMessage(), ex);
        }
    }

    @Transactional(propagation = Propagation.REQUIRED)
    public DatabaseResponse update(GrupoServicioBean grupoServicio) throws Exception {
        DatabaseResponse dr = null;
        DatabaseResponse drService = null;
        DatabaseResponse drServiceChannel = null;
        Long canalId = null;

        try {
            /* actualizar cabecera */
            dr = grupoServicioDAO.update(jdbcTemplate, grupoServicio);
            if (dr.getAffectedRows().intValue() == 0 || dr.getSqlCode().intValue() != 0) {
                throw new RuntimeException("Error al actualizar grupo-servicio: " + dr.getMessage());
            }

            for (ServicioBean servicio : grupoServicio.getServicios()) {
                if (servicio.getId() == null) {
                    servicio.setGrupoServicioId(grupoServicio.getId());
                    drService = servicioDAO.insert(jdbcTemplate, servicio);
                    if (!(drService.getAffectedRows().intValue() > 0 && drService.getSqlCode().intValue() == 0)) {
                        throw new RuntimeException("Error al actualizar servicio: " + drService.getMessage());
                    }
                    if (servicio.getCanalesId() != null && !servicio.getCanalesId().isEmpty()
                            && servicio.getCanalesId().size() > 0) {
                        log.info(servicio.getCanalesId().toString());
                        for (Long canal : servicio.getCanalesId()) {
                            drServiceChannel = canalServicioDAO.insert(jdbcTemplate,
                                    new ServicioCanalBean(drService.getSequence().longValue(), canal));
                            if (!(drServiceChannel.getAffectedRows().intValue() > 0
                                    && drServiceChannel.getSequence().intValue() > 0
                                    && drServiceChannel.getSqlCode().intValue() == 0)) {
                                throw new RuntimeException(
                                        "Error al insertar servicio: " + drServiceChannel.getMessage());
                            }
                        }
                    }
                } else {
                    if (servicio.getEstado() != null
                            && servicio.getEstado().equals(RegisterStatus.Inactivo.getValue())) {
                        drService = servicioDAO.delete(jdbcTemplate, servicio.getId());
                        // delete
                        if (!(drService.getAffectedRows().intValue() > 0 && drService.getSqlCode().intValue() == 0)) {
                            throw new RuntimeException(
                                    "Error al actualizar servicioEnriquecimiento: " + drService.getMessage());
                        }
                    } else {
                        drService = servicioDAO.update(jdbcTemplate, servicio);
                        if (!(drService.getAffectedRows().intValue() > 0 && drService.getSqlCode().intValue() == 0)) {
                            throw new RuntimeException("Error al actualizar servicio: " + drService.getMessage());
                        }
                        if (servicio.getCanalesId() != null && !servicio.getCanalesId().isEmpty()
                                && servicio.getCanalesId().size() > 0 && servicio.getServicioCanales() != null
                                && !servicio.getServicioCanales().isEmpty()
                                && servicio.getServicioCanales().size() > 0) {
                            // log.info(servicio.getCanalesId().toString());
                            for (ServicioCanalBean canal : servicio.getServicioCanales()) {
                                canalId = servicio.getCanalesId().stream().filter(x -> x.equals(canal.getCanalId()))
                                        .findFirst().orElse(null);
                                if (canalId == null) {
                                    drServiceChannel = canalServicioDAO.delete(jdbcTemplate, canal);
                                    if (!(drServiceChannel.getAffectedRows().intValue() > 0
                                            && drServiceChannel.getSqlCode().intValue() == 0)) {
                                        throw new RuntimeException(
                                                "Error al actualizar servicio: " + drServiceChannel.getMessage());
                                    }

                                } else {
                                    servicio.setCanalesId(servicio.getCanalesId().stream()
                                            .filter(x -> !x.equals(canal.getCanalId())).collect(Collectors.toList()));
                                }

                            }
                            if (servicio.getCanalesId() != null && !servicio.getCanalesId().isEmpty()
                                    && servicio.getCanalesId().size() > 0) {
                                for (Long newCanal : servicio.getCanalesId()) {
                                    drServiceChannel = canalServicioDAO.insert(jdbcTemplate,
                                            new ServicioCanalBean(servicio.getId(), newCanal));
                                    if (!(drServiceChannel.getAffectedRows().intValue() > 0
                                            && drServiceChannel.getSequence().intValue() > 0
                                            && drServiceChannel.getSqlCode().intValue() == 0)) {
                                        throw new RuntimeException(
                                                "Error al actualizar servicio: " + drServiceChannel.getMessage());
                                    }
                                }
                            }

                        }
                    }

                }
            }
            return dr;
        } catch (Exception ex) {
            throw new RuntimeException(ex.getMessage(), ex);
        }
    }

    public PaginatedListGrupoServicio findAll(PaginationRequest pr) throws Exception {

        PaginatedListGrupoServicio pagedGrupos = null;
        if (pr.getSortBy() == null || pr.getSortBy().isEmpty())
            pr.setSortBy("id");
        try {
            pagedGrupos = grupoServicioDAO.findAll(pr, jdbcTemplate.getDataSource().getConnection());
            return pagedGrupos;

        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new RuntimeException(ex.getMessage());
        }
    }

    public GrupoServicioBean findById(Long id) throws Exception {
        GrupoServicioBean grupo = null;
        List<Long> canalesId = null;
        List<ServicioBean> servicios = null;
        try {
            grupo = grupoServicioDAO.findById(jdbcTemplate.getDataSource().getConnection(), id);
            servicios = servicioDAO.findByGroup(jdbcTemplate.getDataSource().getConnection(), id);
            if (servicios == null) {
                return null;
            }
            for (ServicioBean srv : servicios) {
                srv.setServicioCanales(
                        canalServicioDAO.findByServicio(jdbcTemplate.getDataSource().getConnection(), srv.getId()));
                if (srv.getServicioCanales() != null && !srv.getServicioCanales().isEmpty()
                        && srv.getServicioCanales().size() > 0) {
                    canalesId = new ArrayList<Long>();
                    for (ServicioCanalBean scb : srv.getServicioCanales()) {
                        canalesId.add(scb.getCanalId());
                    }
                    srv.setCanalesId(canalesId);
                    canalesId = null;
                }
            }
            grupo.setServicios(servicios);
            return grupo;

        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new Exception(ex.getMessage());
        }
    }


    @Transactional(propagation = Propagation.REQUIRED)
    public DatabaseResponse delete(Long endpointId) {
        DatabaseResponse dr = grupoServicioDAO.delete(jdbcTemplate, endpointId);
        if (dr.getSqlCode().longValue() == 0L) {
            log.info(dr.getMessage());

        } else {
            log.error("Error en la transacción: " + dr.getMessage());
        }
        return dr;

    }

    public List<GrupoServicioBean> search(GrupoServicioBusqueda busqueda) throws Exception {
        List<GrupoServicioBean> gruposervicios = null;
        try {
            gruposervicios = grupoServicioDAO.search(jdbcTemplate.getDataSource().getConnection(), busqueda);
            return gruposervicios;

        } catch (Exception ex) {

            log.error(ex.getMessage(), ex);
            throw new Exception(ex.getMessage());
        }
    }


    @Transactional(propagation = Propagation.REQUIRED)
    public List<DatabaseResponse> deleteMany(Long... ids) {

        List<DatabaseResponse> responses = new ArrayList<DatabaseResponse>();
        DatabaseResponse dr = null;
        for (Long id : ids) {
            dr = grupoServicioDAO.delete(jdbcTemplate, id);
            dr.setSequence(new BigDecimal(id));
            responses.add(dr);

            if (dr.getSqlCode().longValue() == 0L) {
                log.info(dr.getMessage());

            } else {
                log.error("Error en la transacción: " + dr.getMessage());
            }
        }
        return responses;
    }
}
