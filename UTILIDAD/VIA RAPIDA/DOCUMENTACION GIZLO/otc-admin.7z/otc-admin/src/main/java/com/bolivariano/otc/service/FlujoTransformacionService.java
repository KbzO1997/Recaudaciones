package com.bolivariano.otc.service;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.bolivariano.otc.bean.FlujoTransformacionBean;
import com.bolivariano.otc.bean.DatoAtxBean;
import com.bolivariano.otc.dao.FlujoTransformacionDAO;
import com.bolivariano.otc.exception.OTCAdminException;

@Service
public class FlujoTransformacionService {

	private static final Logger log = LoggerFactory.getLogger(FlujoTransformacionService.class);

    @Autowired
    FlujoTransformacionDAO consultaFlujoDAO;
    
    @Autowired
    JdbcTemplate jdbcTemplate;

    
    public FlujoTransformacionBean consultarFlujoPorTransaccion(Long transaccion) throws SQLException, NoSuchMethodException {
    	FlujoTransformacionBean consultaFlujo = null;
        try {
            consultaFlujo = consultaFlujoDAO.consultarFlujoPorTransaccion(jdbcTemplate.getDataSource().getConnection(), transaccion);
            return consultaFlujo;
            
        } catch (SQLException ex) {
            log.error("Error al consultar flujo por transaccion: " + ex.getMessage(), ex);
            throw new SQLException ("Error al consultar flujo por transaccion: " +  ex.getMessage());
            
        } catch (NoSuchMethodException ex) {
            log.error("Error, no se encuentra metodo consultarFlujoPorTransaccion: " + ex.getMessage(), ex);
            throw new NoSuchMethodException ("Error, no se encuentra metodo consultarFlujoPorTransaccion: " +  ex.getMessage());
        }
        
    }
    
    
    public DatoAtxBean consultarDatosFlujo(Long idflujo,String banca) throws OTCAdminException, SQLException, NoSuchMethodException {
    	
    	DatoAtxBean datosAtx = null;
        try {
            datosAtx = consultaFlujoDAO.consultarDatosFlujo(jdbcTemplate.getDataSource().getConnection(), idflujo, banca);
            return datosAtx;
            
        }  catch (SQLException ex) {
            log.error("Error al consultar datos del flujo: " + ex.getMessage(), ex);
            throw new SQLException ("Error al consultar datos del flujo: " +  ex.getMessage());
            
        } catch (NoSuchMethodException ex) {
            log.error("Error, no se encuentra metodo consultarDatosFlujo: " + ex.getMessage(), ex);
            throw new NoSuchMethodException ("Error, no se encuentra metodo consultarDatosFlujo: " +  ex.getMessage());
        }
        
    }

}
