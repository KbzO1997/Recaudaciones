package com.bolivariano.otc.bean;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class FlujoTransformacionBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int flujoId;
	
	private String peticion;
	
	private String respuesta;

	public int getFlujoId() {
		return flujoId;
	}

	public void setFlujoId(int flujoId) {
		this.flujoId = flujoId;
	}

	public String getPeticion() {
		return peticion;
	}

	public void setPeticion(String peticion) {
		this.peticion = peticion;
	}

	public String getRespuesta() {
		return respuesta;
	}

	public void setRespuesta(String respuesta) {
		this.respuesta = respuesta;
	}

	@Override
	public String toString() {
		return "ConsultaFlujoBean [flujoId=" + flujoId + ", peticion=" + peticion + ", respuesta=" + respuesta + "]";
	}


	
}
