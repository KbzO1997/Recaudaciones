package com.bolivariano.otc.dao;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.bolivariano.otc.MapperUtil;
import com.bolivariano.otc.bean.DatabaseResponse;
import com.bolivariano.otc.bean.ParametrosFlujoBean;
import com.bolivariano.otc.exception.OTCAdminException;

import oracle.jdbc.OracleTypes;

@Repository
public class ParametrosFlujoDAO {

	private static final Logger log = LoggerFactory.getLogger(ParametrosFlujoDAO.class);
    private static final String E_PAR_CODIGO = "e_PAR_CODIGO";
    private static final String E_PAR_VALOR = "e_PAR_VALOR";
	private static final String E_FLU_ID = "e_FLU_ID";
	private static final String S_SECUENCIA = "s_secuencia";
	private static final String S_AFECTADOS = "s_afectados";
	private static final String S_CODIGO_ERROR = "s_codigo_error";
	private static final String S_MENSAJE = "s_mensaje";
    
    @Autowired
    MapperUtil<ParametrosFlujoBean> parametrosMapper;

	public DatabaseResponse insert(JdbcTemplate jdbcTemplate, ParametrosFlujoBean parametros) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_IPARAMETROFLUJO")
					.declareParameters(new SqlParameter(E_PAR_CODIGO, Types.VARCHAR),
							new SqlParameter(E_PAR_VALOR, Types.VARCHAR), 
							new SqlParameter(E_FLU_ID, Types.NUMERIC),
							new SqlOutParameter(S_SECUENCIA, Types.NUMERIC),
							new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
							new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
							new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue(E_PAR_CODIGO, parametros.getCodigo());
			source.addValue(E_PAR_VALOR, parametros.getValor());
			source.addValue(E_FLU_ID, parametros.getIdFlujo());
			Map<String, Object> out = simpleJdbcCall.execute(source);
			
			dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
			dr.setMessage((String) out.get(S_MENSAJE));
			dr.setSequence((BigDecimal) out.get(S_SECUENCIA));
			dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}
	

	public DatabaseResponse update(JdbcTemplate jdbcTemplate, ParametrosFlujoBean parametros) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_APARAMETROFLUJO")
					.declareParameters(new SqlParameter("e_PAR_ID", Types.NUMERIC),
							new SqlParameter(E_PAR_CODIGO, Types.VARCHAR), 
							new SqlParameter(E_PAR_VALOR, Types.VARCHAR), 
							new SqlParameter(E_FLU_ID, Types.NUMERIC),
							new SqlParameter("e_PAR_ESTADO", Types.VARCHAR),
							new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
							new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
							new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_PAR_ID", parametros.getId());
			source.addValue(E_PAR_CODIGO, parametros.getCodigo());
			source.addValue(E_PAR_VALOR, parametros.getValor());
			source.addValue(E_FLU_ID, parametros.getIdFlujo());
			source.addValue("e_PAR_ESTADO", parametros.getEstado());
			Map<String, Object> out = simpleJdbcCall.execute(source);
			
			dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
			dr.setMessage((String) out.get(S_MENSAJE));
			dr.setSequence((BigDecimal) out.get(S_SECUENCIA));
			dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}

	public List<ParametrosFlujoBean> findByFlujo(Connection connection, Long flujoId) throws OTCAdminException, SQLException {

        List<ParametrosFlujoBean> parametros = null;
        StringBuilder sql = new StringBuilder();
        ResultSet rset = null;
        sql.append(" { call PA_OTC_CPARAMETROFLUJO_FLUJO(?,?) }");
        try (CallableStatement procStmt = connection.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)){

            
            
            procStmt.setLong("E_FLUJO_ID", flujoId);
            procStmt.registerOutParameter("S_RESPUESTA", OracleTypes.CURSOR);
            procStmt.executeUpdate();
            rset = (ResultSet) procStmt.getObject("S_RESPUESTA");

            if (rset!= null && rset.isBeforeFirst()) {
            	parametros = parametrosMapper.mapResultSetToObject(rset, ParametrosFlujoBean.class);
            }

        } catch (Exception e) {
            log.error("Error al consultar parametros flujo: " + e.getMessage(),e);
        } finally {
            if (rset != null) {
                rset.close();
            }
        }
        return parametros;
    }
	
}
