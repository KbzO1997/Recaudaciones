package com.bolivariano.otc.dao;

import com.bolivariano.otc.MapperUtil;
import com.bolivariano.otc.bean.DatabaseResponse;
import com.bolivariano.otc.bean.FormaPagoBean;
import com.bolivariano.otc.dto.FormaPago;
import com.bolivariano.otc.exception.OTCAdminException;

import oracle.jdbc.OracleTypes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

@Repository
public class FormaPagoDAO {

	private static final Logger log = LoggerFactory.getLogger(FormaPagoDAO.class);
	private static final String E_TID_ID = "e_TID_ID";
	private static final String E_CNV_ID = "e_CNV_ID";
	
	@Autowired
	MapperUtil<FormaPago> selectMapper;

	@Autowired
	MapperUtil<FormaPagoBean> formaPagoMapper;

	public List<FormaPago> traerFormaPago(Connection conn, Long idTIP, Long idCNV) throws Exception {
		List<FormaPago> dats = null;
		StringBuilder sql = new StringBuilder();
		ResultSet rset = null;
		sql.append(" { call PKG_OTC_FORMA_PAGO.PA_OTC_CFORMAPAGO_TIPCNV(?,?,?) }");
		try (CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY,
				ResultSet.CONCUR_READ_ONLY)) {
			procStmt.setLong(1, idTIP);
			procStmt.setLong(2, idCNV);
			procStmt.registerOutParameter(3, OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject(3);
			if (rset.isBeforeFirst()) {
				dats = selectMapper.mapResultSetToObject(rset, FormaPago.class);
			}
		} catch (Exception e) {
			log.error("Error en el proceso" + e.getMessage(), e);
		} finally {
			if (rset != null) {
				rset.close();
			}
		}
		return dats;
	}

	public List<FormaPago> obtenerFormaPago(Connection conn, Long idTipoIdentificador)
			throws OTCAdminException, SQLException {

		List<FormaPago> dats = null;

		StringBuilder sql = new StringBuilder();
		ResultSet rset = null;
		sql.append(" { call PKG_OTC_FORMA_PAGO.PA_OTC_CFORMAPAGO_TIPO_ID(?,?) }");
		try (CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY,
				ResultSet.CONCUR_READ_ONLY)) {
			procStmt.setLong(1, idTipoIdentificador);
			procStmt.registerOutParameter(2, OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject(2);

			if (rset.isBeforeFirst()) {
				dats = selectMapper.mapResultSetToObject(rset, FormaPago.class);

			}

		} catch (Exception e) {
			log.error("Error en el proceso" + e.getMessage(), e);
		} finally {
			if (rset != null) {
				rset.close();
			}
		}

		return dats;
	}

	public DatabaseResponse insert(JdbcTemplate jdbcTemplate, FormaPagoBean formaPago) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_IFORMAPAGO")
					.declareParameters(new SqlParameter("e_FPA_VALOR", Types.VARCHAR),
							new SqlParameter("e_FPA_CUOTAS", Types.NUMERIC),
							new SqlParameter("e_FPA_ETIQUETA", Types.VARCHAR),
							new SqlParameter("e_FPA_INTERES", Types.DECIMAL),
							new SqlParameter("e_FPA_MEDIO", Types.VARCHAR),
							new SqlParameter("e_FPA_NOMBRE", Types.VARCHAR),
							new SqlParameter(E_CNV_ID, Types.NUMERIC), new SqlParameter(E_TID_ID, Types.NUMERIC),
							new SqlOutParameter("s_secuencia", Types.NUMERIC),
							new SqlOutParameter("s_afectados", Types.INTEGER),
							new SqlOutParameter("s_codigo_error", Types.NUMERIC),
							new SqlOutParameter("s_mensaje", Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_FPA_CUOTAS", formaPago.getCuotas());
			source.addValue("e_FPA_ETIQUETA", formaPago.getEtiqueta());
			source.addValue("e_FPA_INTERES", formaPago.getInteres());
			source.addValue("e_FPA_MEDIO", formaPago.getMedio());
			source.addValue("e_FPA_NOMBRE", formaPago.getNombre());
			source.addValue(E_CNV_ID, formaPago.getConvenioId());
			source.addValue(E_TID_ID, formaPago.getTipoId());
			Map<String, Object> out = simpleJdbcCall.execute(source);

			dr.setAffectedRows((Integer) out.get("s_afectados"));
			dr.setMessage((String) out.get("s_mensaje"));
			dr.setSequence((BigDecimal) out.get("s_secuencia"));
			dr.setSqlCode((BigDecimal) out.get("s_codigo_error"));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}

	public DatabaseResponse update(JdbcTemplate jdbcTemplate, FormaPagoBean formaPago) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_AFORMAPAGO")
					.declareParameters(new SqlParameter("e_FPA_VALOR", Types.VARCHAR),
							new SqlParameter("e_FPA_CUOTAS", Types.NUMERIC),
							new SqlParameter("e_FPA_ETIQUETA", Types.VARCHAR),
							new SqlParameter("e_FPA_INTERES", Types.DECIMAL),
							new SqlParameter("e_FPA_MEDIO", Types.VARCHAR),
							new SqlParameter("e_FPA_NOMBRE", Types.VARCHAR),
							new SqlParameter(E_CNV_ID, Types.NUMERIC), new SqlParameter(E_TID_ID, Types.NUMERIC),
							new SqlParameter("e_FPA_ID", Types.NUMERIC),
							new SqlOutParameter("s_afectados", Types.INTEGER),
							new SqlOutParameter("s_codigo_error", Types.NUMERIC),
							new SqlOutParameter("s_mensaje", Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_FPA_ID", formaPago.getId());
			source.addValue("e_FPA_CUOTAS", formaPago.getCuotas());
			source.addValue("e_FPA_ETIQUETA", formaPago.getEtiqueta());
			source.addValue("e_FPA_INTERES", formaPago.getInteres());
			source.addValue("e_FPA_MEDIO", formaPago.getMedio());
			source.addValue("e_FPA_NOMBRE", formaPago.getNombre());
			source.addValue(E_CNV_ID, formaPago.getConvenioId());
			source.addValue(E_TID_ID, formaPago.getTipoId());
			Map<String, Object> out = simpleJdbcCall.execute(source);

			dr.setAffectedRows((Integer) out.get("s_afectados"));
			dr.setMessage((String) out.get("s_mensaje"));
			dr.setSqlCode((BigDecimal) out.get("s_codigo_error"));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}

	public List<FormaPagoBean> findByTipoId(Connection conn, Long tipoId) throws OTCAdminException, SQLException {

		List<FormaPagoBean> formasPago = null;
		
		StringBuilder sql = new StringBuilder();
		ResultSet rset = null;
		sql.append(" { call PKG_OTC_FORMA_PAGO.PA_OTC_CFORMAPAGO_TIPOID(?,?) }");
		try (CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)){			
			procStmt.setLong("e_tipoId", tipoId);
			procStmt.registerOutParameter("S_RESPUESTA", OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject("S_RESPUESTA");

			if (rset != null && rset.isBeforeFirst()) {
				formasPago = formaPagoMapper.mapResultSetToObject(rset, FormaPagoBean.class);
			}

		} catch (Exception e) {
			log.error("Error al consultar identificadores: " + e.getMessage(), e);
		} finally {
			if (rset != null) {
				rset.close();
			}
		}
		return formasPago;
	}

	public DatabaseResponse delete(JdbcTemplate jdbcTemplate, Long formaPagoId) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_EFORMAPAGO")
					.declareParameters(new SqlParameter("e_FPA_id", Types.NUMERIC),
							new SqlOutParameter("s_afectados", Types.INTEGER),
							new SqlOutParameter("s_codigo_error", Types.NUMERIC),
							new SqlOutParameter("s_mensaje", Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_FPA_id", formaPagoId);
			Map<String, Object> out = simpleJdbcCall.execute(source);
			dr.setAffectedRows((Integer) out.get("s_afectados"));
			dr.setMessage((String) out.get("s_mensaje"));
			dr.setSqlCode((BigDecimal) out.get("s_codigo_error"));
		} catch (Exception ex) {
			throw new RuntimeException(ex.getMessage(), ex);
		}
		return dr;
	}
}
