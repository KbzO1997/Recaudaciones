package com.bolivariano.otc.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the OTC_M_GRUPO_SERVICIO database table.
 */

public class GrupoServicio implements Serializable {
    private static final long serialVersionUID = 1L;


    private Long id;

    private List<Servicio> servicios;

    private Catalogo tipoBanca;

    private Catalogo tipoServicio;

    private Empresa empresa;

    private Boolean convenioVisible;

    private Boolean matriculable;

    private Boolean matriculacionMultiple;

    private Boolean validable;

    @JsonIgnore
    private Long idEmpresa;

    @JsonIgnore
    private Integer convenioVisibleInt;

    @JsonIgnore
    private Integer matriculableInt;

    @JsonIgnore
    private Integer matriculacionMultipleInt;

    @JsonIgnore
    private Integer validableInt;


    public GrupoServicio() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List<Servicio> getServicios() {
        return servicios;
    }

    public void setServicios(List<Servicio> servicios) {
        this.servicios = servicios;
    }

    public Catalogo getTipoBanca() {
        return tipoBanca;
    }

    public void setTipoBanca(Catalogo tipoBanca) {
        this.tipoBanca = tipoBanca;
    }

    public Catalogo getTipoServicio() {
        return tipoServicio;
    }

    public void setTipoServicio(Catalogo tipoServicio) {
        this.tipoServicio = tipoServicio;
    }

    public Empresa getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }

    public Boolean getConvenioVisible() {
        return convenioVisible;
    }

    public void setConvenioVisible(Boolean convenioVisible) {
        this.convenioVisible = convenioVisible;
    }

    public Boolean getMatriculable() {
        return matriculable;
    }

    public void setMatriculable(Boolean matriculable) {
        this.matriculable = matriculable;
    }

    public Boolean getMatriculacionMultiple() {
        return matriculacionMultiple;
    }

    public void setMatriculacionMultiple(Boolean matriculacionMultiple) {
        this.matriculacionMultiple = matriculacionMultiple;
    }

    public Boolean getValidable() {
        return validable;
    }

    public void setValidable(Boolean validable) {
        this.validable = validable;
    }

    public Long getIdEmpresa() {
        return idEmpresa;
    }

    public void setIdEmpresa(Long idEmpresa) {
        this.idEmpresa = idEmpresa;
    }

    public Integer getConvenioVisibleInt() {
        return convenioVisibleInt;
    }

    public void setConvenioVisibleInt(Integer convenioVisibleInt) {
        this.convenioVisibleInt = convenioVisibleInt;
    }

    public Integer getMatriculableInt() {
        return matriculableInt;
    }

    public void setMatriculableInt(Integer matriculableInt) {
        this.matriculableInt = matriculableInt;
    }

    public Integer getMatriculacionMultipleInt() {
        return matriculacionMultipleInt;
    }

    public void setMatriculacionMultipleInt(Integer matriculacionMultipleInt) {
        this.matriculacionMultipleInt = matriculacionMultipleInt;
    }

    public Integer getValidableInt() {
        return validableInt;
    }

    public void setValidableInt(Integer validableInt) {
        this.validableInt = validableInt;
    }

    @Override
    public String toString() {
        return "GrupoServicio{" +
                "id=" + id +
                ", servicios=" + servicios +
                ", tipoBanca=" + tipoBanca +
                ", tipoServicio=" + tipoServicio +
                ", empresa=" + empresa +
                ", convenioVisible=" + convenioVisible +
                ", matriculable=" + matriculable +
                ", matriculacionMultiple=" + matriculacionMultiple +
                ", validable=" + validable +
                '}';
    }
}