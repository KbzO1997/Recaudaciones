package com.bolivariano.otc.dao;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.bolivariano.otc.MapperUtil;
import com.bolivariano.otc.bean.CanalBean;
import com.bolivariano.otc.bean.CanalBusqueda;
import com.bolivariano.otc.bean.DatabaseResponse;
import com.bolivariano.otc.bean.PaginatedListCanal;
import com.bolivariano.otc.bean.PaginationRequest;
import com.bolivariano.otc.bean.SelectItemBean;
import com.bolivariano.otc.exception.OTCAdminException;

import oracle.jdbc.OracleTypes;

@Repository
public class CanalDAO {

	@Autowired
	MapperUtil<CanalBean> canalBeanMapper;

	@Autowired
	MapperUtil<SelectItemBean> selectMapper;
	private static final Logger log = LoggerFactory.getLogger(CanalDAO.class);
	private static final String E_CAN_NOMBRE = "e_CAN_NOMBRE";
	private static final String E_CAN_DESCRIPCION = "e_CAN_DESCRIPCION";
	private static final String E_CAN_CODIGO = "e_CAN_CODIGO";
	private static final String E_CTD_ID_MEDIO_ACC = "e_CTD_ID_MEDIO_ACC";
	private static final String S_AFECTADOS = "s_afectados";
	private static final String S_CODIGO_ERROR = "s_codigo_error";
	private static final String S_MENSAJE = "s_mensaje";
	private static final String E_CAN_ID = "e_CAN_ID";
	private static final String E_CODIGO = "e_codigo";
	private static final String S_RESULT = "s_result";
	private static final String ERROR_CANALES = "Error al consultar canales: ";
	private static final String S_RESPUESTA = "S_RESPUESTA";

	public DatabaseResponse insert(JdbcTemplate jdbcTemplate, CanalBean canal) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_ICANAL")
					.declareParameters(new SqlParameter(E_CAN_NOMBRE, Types.VARCHAR),
							new SqlParameter(E_CAN_DESCRIPCION, Types.VARCHAR),
							new SqlParameter(E_CAN_CODIGO, Types.VARCHAR),
							new SqlParameter(E_CTD_ID_MEDIO_ACC, Types.NUMERIC),
							new SqlOutParameter("s_secuencia", Types.NUMERIC),
							new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
							new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
							new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue(E_CAN_NOMBRE, canal.getNombre());
			source.addValue(E_CAN_DESCRIPCION, canal.getDescripcion());
			source.addValue(E_CAN_CODIGO, canal.getCodigo());
			source.addValue(E_CTD_ID_MEDIO_ACC, canal.getMedioAccesoId());
			Map<String, Object> out = simpleJdbcCall.execute(source);
			dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
			dr.setMessage((String) out.get(S_MENSAJE));
			dr.setSequence((BigDecimal) out.get("s_secuencia"));
			dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}

	public DatabaseResponse update(JdbcTemplate jdbcTemplate, CanalBean canal) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_ACANAL")
					.declareParameters(new SqlParameter(E_CAN_ID, Types.NUMERIC),
							new SqlParameter(E_CAN_NOMBRE, Types.VARCHAR),
							new SqlParameter(E_CAN_DESCRIPCION, Types.VARCHAR),
							new SqlParameter(E_CAN_CODIGO, Types.VARCHAR),
							new SqlParameter(E_CTD_ID_MEDIO_ACC, Types.NUMERIC),
							new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
							new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
							new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue(E_CAN_ID, canal.getId());
			source.addValue(E_CAN_NOMBRE, canal.getNombre());
			source.addValue(E_CAN_DESCRIPCION, canal.getDescripcion());
			source.addValue(E_CAN_CODIGO, canal.getCodigo());
			source.addValue(E_CTD_ID_MEDIO_ACC, canal.getMedioAccesoId());
			Map<String, Object> out = simpleJdbcCall.execute(source);
			dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
			dr.setMessage((String) out.get(S_MENSAJE));
			dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}

	public Integer countCode(JdbcTemplate jdbcTemplate, String code) {
		Integer count = null;
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
					.withProcedureName("PA_OTC_PCONTAR_CODCANAL")
					.declareParameters(new SqlParameter(E_CODIGO, Types.VARCHAR),
							new SqlOutParameter("s_cantidad", Types.INTEGER));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue(E_CODIGO, code);
			Map<String, Object> out = simpleJdbcCall.execute(source);
			count = (Integer) out.get("s_cantidad");
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return count;
	}

	public PaginatedListCanal findAll(PaginationRequest pr, Connection conn)
			throws SQLException, NoSuchMethodException {

		CallableStatement procStmt = null;
		StringBuilder sql = new StringBuilder();
		ResultSet rs;
		List<CanalBean> empresas = null;
		PaginatedListCanal pagedEmpresas;

		try {
			sql.append(" { call pa_otc_gcanal(?,?,?,?,?) }");
			procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
			procStmt.setInt("e_size", pr.getSize());
			procStmt.setInt("e_page", pr.getPage());
			procStmt.setString("e_sort", pr.getSortBy());
			procStmt.registerOutParameter("s_totalRecord", Types.NUMERIC);
			procStmt.registerOutParameter(S_RESULT, OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rs = (ResultSet) procStmt.getObject(S_RESULT);
			if (rs != null && rs.isBeforeFirst()) {
				empresas = canalBeanMapper.mapResultSetToObject(rs, CanalBean.class);
				pagedEmpresas = new PaginatedListCanal();
				pagedEmpresas.setRecordsFiltered(pr.getSize());
				pagedEmpresas.setRecordsTotal(procStmt.getBigDecimal("s_totalRecord").longValue());
				pagedEmpresas.setData(empresas);
				rs.close();
				procStmt.close();
				return pagedEmpresas;
			} else {
				return null;
			}

		} catch (SQLException e) {
			log.error(ERROR_CANALES + e.getMessage(), e);
			throw new SQLException(ERROR_CANALES + e.getMessage(), e);
		} finally {
			if (procStmt != null)
				procStmt.close();
			if (conn != null)
				conn.close();
		}
	}

	public CanalBean findById(Connection conn, Long id) throws OTCAdminException, SQLException {

		List<CanalBean> canales = null;	
		CanalBean canalBean = null;
		StringBuilder sql  = new StringBuilder();
		ResultSet rset = null;
		sql.append(" { call PA_OTC_CCANAL_ID(?,?) }");
		try (CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)){
			procStmt.setLong("e_id ", id);
			procStmt.registerOutParameter(S_RESPUESTA, OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject(S_RESPUESTA);
			if (rset.isBeforeFirst()) {
				canales = canalBeanMapper.mapResultSetToObject(rset, CanalBean.class);
				return canales.get(0);
			}

		} catch (Exception e) {
			log.error("Error en el proceso" + e.getMessage(), e);

		} finally {
			if (rset != null) {
				rset.close();
			}
		}
		return canalBean;
	}

	public List<SelectItemBean> findSelectCanales(Connection conn) throws OTCAdminException, SQLException {

		List<SelectItemBean> canales = null;	
		StringBuilder sql = new StringBuilder();
		ResultSet rset = null;
		sql.append(" { call PA_OTC_CCANAL_SELECT(?) }");
		try (CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)){				
			procStmt.registerOutParameter(S_RESPUESTA, OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject(S_RESPUESTA);
			if (rset.isBeforeFirst()) {
				canales = selectMapper.mapResultSetToObject(rset, SelectItemBean.class);
			}
			return canales;
		} catch (Exception e) {
			log.error("Error en el proceso" + e.getMessage(), e);

		} finally {
			if (rset != null) {
				rset.close();
			}
		}
		return canales;
	}

	public DatabaseResponse delete(JdbcTemplate jdbcTemplate, Long canalId) throws OTCAdminException {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_ECANAL")
					.declareParameters(new SqlParameter(E_CAN_ID, Types.NUMERIC),
							new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
							new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
							new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue(E_CAN_ID, canalId);
			Map<String, Object> out = simpleJdbcCall.execute(source);
			dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
			dr.setMessage((String) out.get(S_MENSAJE));
			dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
		} catch (Exception ex) {
			throw new OTCAdminException(ex.getMessage(), ex);
		}
		return dr;
	}

	public List<CanalBean> search(Connection conn, CanalBusqueda busqueda) throws OTCAdminException, SQLException, NoSuchMethodException {
		CallableStatement procStmt = null;
		StringBuilder sql = new StringBuilder();
		ResultSet rset = null ;
		List<CanalBean> canales  = null;
		try {
			sql.append(" { call pa_otc_ccanal(?,?,?,?) }");
			log.info(busqueda.toString());
			procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
			procStmt.setString(E_CODIGO, busqueda.getCodigo());
			procStmt.setString("e_nombre", busqueda.getNombre());
			procStmt.setLong("e_medioAcceso", busqueda.getMedioAcceso() != null? busqueda.getMedioAcceso(): 0);
			procStmt.registerOutParameter(S_RESULT, OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject(S_RESULT);
			if (rset.isBeforeFirst()) {
				canales = canalBeanMapper.mapResultSetToObject(rset, CanalBean.class);	
				rset.close();
				procStmt.close();
				return canales;
			} else {
				return canales;
			}

		} catch (SQLException e) {
			log.error(ERROR_CANALES + e.getMessage(), e);
			throw new SQLException(ERROR_CANALES + e.getMessage(), e);
		} finally {
			if (procStmt != null)
				procStmt.close();
			if (conn != null)
				conn.close();
		}
	}
}
