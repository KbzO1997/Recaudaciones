package com.bolivariano.otc.service;

import com.bolivariano.otc.bean.*;
import com.bolivariano.otc.dao.CanalDAO;
import com.bolivariano.otc.dao.CanalesServicioDAO;
import com.bolivariano.otc.exception.OTCAdminException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Service
public class CanalService {

    private static final Logger log = LoggerFactory.getLogger(CanalService.class);

    @Autowired
    CanalDAO canalDAO;

    @Autowired
    CanalesServicioDAO scDAO;

    @Autowired
    JdbcTemplate jdbcTemplate;


    @Transactional(propagation = Propagation.REQUIRED)
    public DatabaseResponse insert(CanalBean canal) throws Exception {
        DatabaseResponse dr = null;
        try {
            dr = canalDAO.insert(jdbcTemplate, canal);
            if (dr.getAffectedRows().intValue() == 0 || dr.getSequence().intValue() == 0 || dr.getSqlCode().intValue() != 0) {
                throw new RuntimeException("Error al insertar canal: " + dr.getMessage());
            }
            return dr;
        } catch (Exception ex) {
            throw new RuntimeException(ex.getMessage(), ex);
        }
    }

    @Transactional(propagation = Propagation.REQUIRED)
    public DatabaseResponse update(CanalBean grupoServicio) throws Exception {
        DatabaseResponse dr = null;
        try {
            dr = canalDAO.update(jdbcTemplate, grupoServicio);
            if (dr.getAffectedRows().intValue() == 0 || dr.getSqlCode().intValue() != 0) {
                throw new RuntimeException("Error al actualizar canal: " + dr.getMessage());
            }
            return dr;
        } catch (Exception ex) {
            throw new RuntimeException(ex.getMessage(), ex);
        }
    }


    @Transactional(propagation = Propagation.REQUIRED)
    public DatabaseResponse delete(Long endpointId) throws OTCAdminException {
        DatabaseResponse dr = canalDAO.delete(jdbcTemplate, endpointId);
        if (dr.getSqlCode().longValue() == 0L) {
            log.info(dr.getMessage());

        } else {
            log.error("Error en la transacción: " + dr.getMessage());
        }
        return dr;

    }

    public PaginatedListCanal findAll(PaginationRequest pr) throws Exception {

        PaginatedListCanal pagedCanales = null;
        if (pr.getSortBy() == null || pr.getSortBy().isEmpty())
            pr.setSortBy("id");
        try {
            pagedCanales = canalDAO.findAll(pr, jdbcTemplate.getDataSource().getConnection());
            return pagedCanales;

        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new RuntimeException(ex.getMessage());
        }
    }

    public CanalBean findById(Long id) throws Exception {
        CanalBean canal = null;
        //List<ServicioCanalBean> servicioCanales = null;
        try {
            canal = canalDAO.findById(jdbcTemplate.getDataSource().getConnection(), id);
            //servicioCanales = scDAO.findByCanal(jdbcTemplate.getDataSource().getConnection(), id);
            //canal.setServicioCanales(servicioCanales);
            return canal;

        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new Exception(ex.getMessage());
        }
    }

    public List<CanalBean> search(CanalBusqueda busqueda) throws Exception {
        List<CanalBean> canales = null;
        try {
            canales = canalDAO.search(jdbcTemplate.getDataSource().getConnection(), busqueda);
            return canales;

        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new Exception(ex.getMessage());
        }
    }

    public Integer countCode(String code) throws Exception {
        Integer count = null;
        //List<ServicioCanalBean> servicioCanales = null;
        try {
            count = canalDAO.countCode(jdbcTemplate, code);
            return count;

        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new Exception(ex.getMessage());
        }
    }

    public List<SelectItemBean> findSelects() throws Exception {
        List<SelectItemBean> canales = null;
        try {
            canales = canalDAO.findSelectCanales(jdbcTemplate.getDataSource().getConnection());
            return canales;
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new Exception(ex.getMessage());
        }
    }


    @Transactional(propagation = Propagation.REQUIRED)
    public List<DatabaseResponse> deleteMany(Long... ids) throws OTCAdminException {

        List<DatabaseResponse> responses = new ArrayList<DatabaseResponse>();
        DatabaseResponse dr = null;
        for (Long id : ids) {
            dr = canalDAO.delete(jdbcTemplate, id);
            dr.setSequence(new BigDecimal(id));
            responses.add(dr);

            if (dr.getSqlCode().longValue() == 0L) {
                log.info(dr.getMessage());

            } else {
                log.error("Error en la transacción: " + dr.getMessage());
            }
        }
        return responses;
    }

}
