/**
 * 
 */
package com.bolivariano.otc.bean;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * The persistent class for the OTC_P_PARAMETROS_FLUJO database table.
 */
@JsonInclude(Include.NON_NULL)
public class ParametrosFlujoBean implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long id;
	private String codigo;
	private String valor;
	private Long idFlujo;
	private String estado;

	public ParametrosFlujoBean() {

	}

	public ParametrosFlujoBean(Long id, String codigo, String valor, Long idFlujo, String estado) {
		super();
		this.id = id;
		this.codigo = codigo;
		this.valor = valor;
		this.idFlujo = idFlujo;
		this.estado = estado;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	public Long getIdFlujo() {
		return idFlujo;
	}

	public void setIdFlujo(Long idFlujo) {
		this.idFlujo = idFlujo;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public ParametrosFlujoBean(long longValue, ParametrosFlujoBean parametroFlujo) {
		
	}
	
	@Override
	public String toString() {
		return "ParametrosFlujoBean [" + "id=" + id + ", codigo=" + codigo + ", valor=" + valor + ", idFlujo=" + idFlujo
				+ ", estado=" + estado + "]";
	}

}
