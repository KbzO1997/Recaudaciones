package com.bolivariano.otc.service;

import com.bolivariano.otc.bean.*;
import com.bolivariano.otc.dao.EnriquecimientoDAO;
import com.bolivariano.otc.dao.EnriquecimientoParamDAO;
import com.bolivariano.otc.enumerators.RegisterStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Service
public class EnriquecimientoService {

    @Autowired
    EnriquecimientoParamDAO parametroDAO;

    @Autowired
    EnriquecimientoDAO enriquecimientoDAO;

    @Autowired
    JdbcTemplate jdbcTemplate;

    private static final Logger log = LoggerFactory.getLogger(EnriquecimientoService.class);

    @Transactional(propagation = Propagation.REQUIRED)
    public DatabaseResponse insert(ServicioEnriquecimientoBean servicioEnriquecimiento) throws Exception {
        DatabaseResponse dr = null;
        DatabaseResponse drService = null;
        try {
            dr = enriquecimientoDAO.insert(jdbcTemplate, servicioEnriquecimiento);
            if (dr.getAffectedRows().intValue() == 0 || dr.getSequence().intValue() == 0 || dr.getSqlCode().intValue() != 0) {
                throw new RuntimeException("Error al insertar servicio enriquecimiento: " + dr.getMessage());
            }
            for (ServicioEnriquecimientoParamBean detalle : servicioEnriquecimiento.getParametros()) {
                detalle.setEnriquecimientoId(dr.getSequence().longValue());
                drService = parametroDAO.insert(jdbcTemplate, detalle);
                if (!(drService.getAffectedRows().intValue() > 0 && drService.getSequence().intValue() > 0 && drService.getSqlCode().intValue() == 0)) {
                    throw new RuntimeException("Error al insertar servicio enriquecimiento: " + drService.getMessage());
                }
            }
            return dr;
        } catch (Exception ex) {
            throw new RuntimeException(ex.getMessage(), ex);
        }
    }


    @Transactional(propagation = Propagation.REQUIRED)
    public DatabaseResponse delete(Long endpointId) {
        DatabaseResponse dr = enriquecimientoDAO.delete(jdbcTemplate, endpointId);
        if (dr.getSqlCode().longValue() == 0L) {
            log.info(dr.getMessage());

        } else {
            log.error("Error en la transacción: " + dr.getMessage());
        }
        return dr;

    }

    @Transactional(propagation = Propagation.REQUIRED)
    public DatabaseResponse update(ServicioEnriquecimientoBean servicioEnriquecimiento) throws Exception {
        DatabaseResponse dr = null;
        DatabaseResponse drDetail = null;
        try {
            dr = enriquecimientoDAO.update(jdbcTemplate, servicioEnriquecimiento);
            if (dr.getAffectedRows().intValue() == 0 || dr.getSqlCode().intValue() != 0) {
                throw new RuntimeException("Error al actualizar servicioEnriquecimiento: " + dr.getMessage());
            }
            for (ServicioEnriquecimientoParamBean detalle : servicioEnriquecimiento.getParametros()) {
                if (detalle.getId() == null) {
                    detalle.setEnriquecimientoId((servicioEnriquecimiento.getId()));
                    drDetail = parametroDAO.insert(jdbcTemplate, detalle);
                    if (!(drDetail.getAffectedRows().intValue() > 0 && drDetail.getSqlCode().intValue() == 0)) {
                        throw new RuntimeException("Error al actualizar servicioEnriquecimiento: " + drDetail.getMessage());
                    }
                } else {
                    if (detalle.getEstado() != null && detalle.getEstado().equals(RegisterStatus.Inactivo.getValue())) {
                        drDetail = parametroDAO.delete(jdbcTemplate, detalle.getId());
                        //delete
                        if (!(drDetail.getAffectedRows().intValue() > 0 && drDetail.getSqlCode().intValue() == 0)) {
                            throw new RuntimeException("Error al actualizar servicioEnriquecimiento: " + drDetail.getMessage());
                        }
                    } else {
                        drDetail = parametroDAO.update(jdbcTemplate, detalle);
                        if (!(drDetail.getAffectedRows().intValue() > 0 && drDetail.getSqlCode().intValue() == 0)) {
                            throw new RuntimeException("Error al actualizar servicioEnriquecimiento: " + drDetail.getMessage());
                        }
                    }

                }
            }
            return dr;
        } catch (Exception ex) {
            throw new RuntimeException(ex.getMessage(), ex);
        }
    }

    public PaginatedListServicioEnriquecimiento findAll(PaginationRequest pr) throws Exception {

        PaginatedListServicioEnriquecimiento pagedServicios = null;
        if (pr.getSortBy() == null || pr.getSortBy().isEmpty())
            pr.setSortBy("id");
        try {
            pagedServicios = enriquecimientoDAO.findAll(pr, jdbcTemplate.getDataSource().getConnection());
            return pagedServicios;

        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new RuntimeException(ex.getMessage());
        }
    }

    public ServicioEnriquecimientoBean findById(Long id) throws Exception {
        ServicioEnriquecimientoBean servicioEnriquecimiento = null;
        List<ServicioEnriquecimientoParamBean> parametros = null;
        try {
            servicioEnriquecimiento = enriquecimientoDAO.findById(jdbcTemplate.getDataSource().getConnection(), id);
            if (servicioEnriquecimiento == null) {
                return null;
            }
            parametros = parametroDAO.findByEnrichmentService(jdbcTemplate.getDataSource().getConnection(), id);
            servicioEnriquecimiento.setParametros(parametros);
            return servicioEnriquecimiento;

        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new Exception(ex.getMessage());
        }
    }

    public List<SelectItemBean> findSelects() throws Exception {
        List<SelectItemBean> empresas = null;
        try {
            empresas = enriquecimientoDAO.findSelectEnriquecimientos(jdbcTemplate.getDataSource().getConnection());
            return empresas;
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new Exception(ex.getMessage());
        }
    }


    public List<ServicioEnriquecimientoBean> search(EnriquecimientoBusqueda busqueda) throws Exception {
        List<ServicioEnriquecimientoBean> enriquecimientos = null;
        try {
            enriquecimientos = enriquecimientoDAO.search(jdbcTemplate.getDataSource().getConnection(), busqueda);
            return enriquecimientos;

        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new Exception(ex.getMessage());
        }
    }


    @Transactional(propagation = Propagation.REQUIRED)
    public List<DatabaseResponse> deleteMany(Long... ids) {

        List<DatabaseResponse> responses = new ArrayList<DatabaseResponse>();
        DatabaseResponse dr = null;
        for (Long id : ids) {
            dr = enriquecimientoDAO.delete(jdbcTemplate, id);
            dr.setSequence(new BigDecimal(id));
            responses.add(dr);

            if (dr.getSqlCode().longValue() == 0L) {
                log.info(dr.getMessage());

            } else {
                log.error("Error en la transacción: " + dr.getMessage());
            }
        }
        return responses;
    }
}
