package com.bolivariano.otc.bean;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * The persistent class for the OTC_D_DATOS_ADICIONALES database table.
 *
 */

@JsonInclude(Include.NON_NULL)
public class DatoAdicionalBean implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long id;

	private String codigo;

	private String etiqueta;

	private Byte editable;

	private String formato;

	private List<SeleccionBean> listasSeleccion;

	private String longitud;

	private String mascara;

	private String regexp;

	private String tipo;

	private String valor;

	private Byte visible;

	private Long tipoIdentificadorId;

	private Long convenioId;
	
	private String estado;
	
	

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public Long getConvenioId() {
		return convenioId;
	}

	public void setConvenioId(Long convenioId) {
		this.convenioId = convenioId;
	}

	public DatoAdicionalBean() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getEtiqueta() {
		return etiqueta;
	}

	public void setEtiqueta(String etiqueta) {
		this.etiqueta = etiqueta;
	}

	public Byte getEditable() {
		return editable;
	}

	public void setEditable(Byte editable) {
		this.editable = editable;
	}

	public String getFormato() {
		return formato;
	}

	public void setFormato(String formato) {
		this.formato = formato;
	}

	public List<SeleccionBean> getListasSeleccion() {
		return listasSeleccion;
	}

	public void setListasSeleccion(List<SeleccionBean> listasSeleccion) {
		this.listasSeleccion = listasSeleccion;
	}

	public String getLongitud() {
		return longitud;
	}

	public void setLongitud(String longitud) {
		this.longitud = longitud;
	}

	public String getMascara() {
		return mascara;
	}

	public void setMascara(String mascara) {
		this.mascara = mascara;
	}

	public String getRegexp() {
		return regexp;
	}

	public void setRegexp(String regexp) {
		this.regexp = regexp;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	public Byte getVisible() {
		return visible;
	}

	public void setVisible(Byte visible) {
		this.visible = visible;
	}

	public Long getTipoIdentificadorId() {
		return tipoIdentificadorId;
	}

	public void setTipoIdentificadorId(Long tipoIdentificadorId) {
		this.tipoIdentificadorId = tipoIdentificadorId;
	}

	@Override
	public String toString() {
		return "DatoAdicionalBean [id=" + id + ", codigo=" + codigo + ", etiqueta=" + etiqueta + ", editable="
				+ editable + ", formato=" + formato + ", listasSeleccion=" + listasSeleccion + ", Longitud=" + longitud
				+ ", mascara=" + mascara + ", regexp=" + regexp + ", tipo=" + tipo + ", valor=" + valor + ", visible="
				+ visible + "]";
	}
}