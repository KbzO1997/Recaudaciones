package com.bolivariano.otc.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the OTC_M_FLUJO database table.
 */

public class Flujo implements Serializable {
    private static final long serialVersionUID = 1L;


    private Long id;

    private Catalogo operacion;

    private List<ServicioEnriquecimiento> servicioEnriquecimiento;

    private PuntoFinal puntoFinal;

    private Convenio convenio;

    @JsonIgnore
    private Long idPuntoFinal;

    @JsonIgnore
    private String nombrePuntoFinal;

    @JsonIgnore
    private String operacionPuntoFinal;

    @JsonIgnore
    private String transformacionPeticion;

    @JsonIgnore
    private String puntoFinalURL;

    @JsonIgnore
    private String repositorioPeticion;

    @JsonIgnore
    private String repositorioRespuesta;

    @JsonIgnore
    private String transformacionRespuesta;

    @JsonIgnore
    private String ambiente;

    @JsonIgnore
    private String codigoOperacion;

    public Flujo() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Catalogo getOperacion() {
        return operacion;
    }

    public void setOperacion(Catalogo operacion) {
        this.operacion = operacion;
    }

    public List<ServicioEnriquecimiento> getServicioEnriquecimiento() {
        return servicioEnriquecimiento;
    }

    public void setServicioEnriquecimiento(List<ServicioEnriquecimiento> servicioEnriquecimiento) {
        this.servicioEnriquecimiento = servicioEnriquecimiento;
    }

    public PuntoFinal getPuntoFinal() {
        return puntoFinal;
    }

    public void setPuntoFinal(PuntoFinal puntoFinal) {
        this.puntoFinal = puntoFinal;
    }

    public Convenio getConvenio() {
        return convenio;
    }

    public void setConvenio(Convenio convenio) {
        this.convenio = convenio;
    }

    public Long getIdPuntoFinal() {
        return idPuntoFinal;
    }

    public void setIdPuntoFinal(Long idPuntoFinal) {
        this.idPuntoFinal = idPuntoFinal;
    }

    public String getNombrePuntoFinal() {
        return nombrePuntoFinal;
    }

    public void setNombrePuntoFinal(String nombrePuntoFinal) {
        this.nombrePuntoFinal = nombrePuntoFinal;
    }

    public String getOperacionPuntoFinal() {
        return operacionPuntoFinal;
    }

    public void setOperacionPuntoFinal(String operacionPuntoFinal) {
        this.operacionPuntoFinal = operacionPuntoFinal;
    }

    public String getTransformacionPeticion() {
        return transformacionPeticion;
    }

    public void setTransformacionPeticion(String transformacionPeticion) {
        this.transformacionPeticion = transformacionPeticion;
    }

    public String getPuntoFinalURL() {
        return puntoFinalURL;
    }

    public void setPuntoFinalURL(String puntoFinalURL) {
        this.puntoFinalURL = puntoFinalURL;
    }

    public String getRepositorioPeticion() {
        return repositorioPeticion;
    }

    public void setRepositorioPeticion(String repositorioPeticion) {
        this.repositorioPeticion = repositorioPeticion;
    }

    public String getRepositorioRespuesta() {
        return repositorioRespuesta;
    }

    public void setRepositorioRespuesta(String repositorioRespuesta) {
        this.repositorioRespuesta = repositorioRespuesta;
    }

    public String getTransformacionRespuesta() {
        return transformacionRespuesta;
    }

    public void setTransformacionRespuesta(String transformacionRespuesta) {
        this.transformacionRespuesta = transformacionRespuesta;
    }

    public String getCodigoOperacion() {
        return codigoOperacion;
    }

    public void setCodigoOperacion(String codigoOperacion) {
        this.codigoOperacion = codigoOperacion;
    }

    public String getAmbiente() {
        return ambiente;
    }

    public void setAmbiente(String ambiente) {
        this.ambiente = ambiente;
    }

    @Override
    public String toString() {
        return "Flujo{" +
                "id=" + id +
                ", operacion=" + operacion +
                ", servicioEnriquecimiento=" + servicioEnriquecimiento +
                ", puntoFinal=" + puntoFinal +
                ", convenio=" + convenio +
                ", idPuntoFinal=" + idPuntoFinal +
                ", nombrePuntoFinal='" + nombrePuntoFinal + '\'' +
                ", operacionPuntoFinal='" + operacionPuntoFinal + '\'' +
                ", transformacionPeticion='" + transformacionPeticion + '\'' +
                ", puntoFinalURL='" + puntoFinalURL + '\'' +
                ", repositorioPeticion='" + repositorioPeticion + '\'' +
                ", repositorioRespuesta='" + repositorioRespuesta + '\'' +
                ", transformacionRespuesta='" + transformacionRespuesta + '\'' +
                ", ambiente='" + ambiente + '\'' +
                ", codigoOperacion='" + codigoOperacion + '\'' +
                '}';
    }
}