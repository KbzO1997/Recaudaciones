package com.bolivariano.otc.web.rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.bolivariano.otc.bean.ConsultaFlujoBean;
import com.bolivariano.otc.bean.DatoAtxBean;
import com.bolivariano.otc.service.ConsultaFlujoService;

@Component
@Repository
@Path("/admin/v1/consultaflujo")
public class ConsultaFlujoRest {
	
	@Autowired
	ConsultaFlujoService consultaFLujoService;
	
    private static final Logger log = LoggerFactory.getLogger(ConsultaFlujoRest.class);

    @GET
    @Path("/{transaccion}")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response consultaFlujoPorTransaccion(@PathParam("transaccion") Long transaccion) {
        log.info("consultaFlujoPorTransaccion: Petición Recibida");
        try {
        	ConsultaFlujoBean consultaFlujoBean = this.consultaFLujoService.consultaFlujoPorTransaccion(transaccion);
            if (consultaFlujoBean == null) {
                return Response.status(Status.NO_CONTENT).entity(null).build();
            }
            return Response.status(Status.OK).entity(consultaFlujoBean).build();
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }
    
    
    @GET
    @Path("/obtenerDatos/{id}/{banca}")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response consultarDatosFlujo(@PathParam("id") Long id,@PathParam("banca") String banca ) {
        log.info("obtenerDatos-Flujo: Petición Recibida");
        try {
        	DatoAtxBean datosAtx = this.consultaFLujoService.consultarDatosFlujo(id,banca);
            if (datosAtx == null) {
                return Response.status(Status.NO_CONTENT).entity(null).build();
            }
            return Response.status(Status.OK).entity(datosAtx).build();
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }

}
