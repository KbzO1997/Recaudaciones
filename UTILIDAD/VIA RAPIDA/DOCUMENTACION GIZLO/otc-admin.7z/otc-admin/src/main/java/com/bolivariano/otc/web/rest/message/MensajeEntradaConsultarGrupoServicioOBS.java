package com.bolivariano.otc.web.rest.message;

//import com.fasterxml.jackson.annotation.JsonIgnore;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import java.io.Serializable;

@JsonInclude(Include.NON_NULL)
public class MensajeEntradaConsultarGrupoServicioOBS implements Serializable {


    /**
     *
     */
    private static final long serialVersionUID = 5065686930287078082L;
    private String tipoBanca;
    private String tipoServicio;
    private Boolean matriculable;
    //@JsonIgnore
    //private String cacheId;

    public MensajeEntradaConsultarGrupoServicioOBS() {

    }

    public String getTipoBanca() {
        return tipoBanca;
    }

    public void setTipoBanca(String tipoBanca) {
        this.tipoBanca = tipoBanca;
    }

    public String getTipoServicio() {
        return tipoServicio;
    }

    public void setTipoServicio(String tipoServicio) {
        this.tipoServicio = tipoServicio;
    }


    public Boolean getMatriculable() {
        return matriculable;
    }

    public void setMatriculable(Boolean matriculable) {
        this.matriculable = matriculable;
    }

    @Override
    public String toString() {
        return "MensajeEntradaConsultarGrupoServicioOBS{" +
                "tipoBanca='" + tipoBanca + '\'' +
                ", tipoServicio='" + tipoServicio + '\'' +
                ", matriculable=" + matriculable +
                '}';
    }
}