package com.bolivariano.otc.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bolivariano.otc.MapperUtil;
import com.bolivariano.otc.bean.FlujoTransformacionBean;
import com.bolivariano.otc.bean.DatoAtxBean;

import oracle.jdbc.OracleTypes;

@Repository
public class FlujoTransformacionDAO {

	@Autowired
	MapperUtil<FlujoTransformacionBean> consultaFlujoMapper;
	
	@Autowired
	MapperUtil<DatoAtxBean> consultaDatosFlujoMapper;

	private static final Logger log = LoggerFactory.getLogger(FlujoTransformacionBean.class);
	private static final String S_RESULT = "s_result";
	
	public FlujoTransformacionBean consultarFlujoPorTransaccion( Connection conn, Long transaccion) 
			throws SQLException, NoSuchMethodException {

		CallableStatement procStmt = null;
		StringBuilder sql = new StringBuilder();
		ResultSet rs = null;
		List<FlujoTransformacionBean> consultaFlujo = null;
		try {
			sql.append(" { call PA_OTC_COBTIENE_IDFLUJO(?,?) }");
			procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
			procStmt.setLong("e_transaccion ", transaccion);
			procStmt.registerOutParameter(S_RESULT, OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rs = (ResultSet) procStmt.getObject(S_RESULT);

			if (rs != null && rs.isBeforeFirst()) {
				consultaFlujo = consultaFlujoMapper.mapResultSetToObject(rs, FlujoTransformacionBean.class);
				rs.close();
				procStmt.close();
				return consultaFlujo.get(0);
			} else {
				return null;
			}

		} catch (SQLException e) {
			log.error("Error al consultar flujo por transaccion: " + e.getMessage(), e);
			throw new SQLException("Error al consultar flujo por transaccion: " + e.getMessage(), e);
		} finally {
			if (procStmt != null)
				procStmt.close();
			if (conn != null)
				conn.close();
		}
	}

	public DatoAtxBean consultarDatosFlujo( Connection conn, Long idflujo, String banca) 
			throws SQLException, NoSuchMethodException {

		CallableStatement procStmt = null;
		StringBuilder sql = new StringBuilder();
		ResultSet rs;
		List<DatoAtxBean> datosAtx = null;
		try {
			sql.append(" { call PA_OTC_COBTIENE_DATOSFLUJO(?,?,?) }");
			procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
			procStmt.setLong("e_flujo", idflujo);
			procStmt.setString("e_banca", banca);
			procStmt.registerOutParameter(S_RESULT, OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rs = (ResultSet) procStmt.getObject(S_RESULT);
			if (rs != null && rs.isBeforeFirst()) {
				datosAtx = consultaDatosFlujoMapper.mapResultSetToObject(rs, DatoAtxBean.class);
				rs.close();
				procStmt.close();
				return datosAtx.get(0);
			} else {
				return null;
			}

		} catch (SQLException e) {
			log.error("Error al consultar datos de flujo: " + e.getMessage(), e);
			throw new SQLException("Error al consultar datos de flujo: " + e.getMessage(), e);
		} finally {
			if (procStmt != null)
				procStmt.close();
			if (conn != null)
				conn.close();
		}
	}
	
}
