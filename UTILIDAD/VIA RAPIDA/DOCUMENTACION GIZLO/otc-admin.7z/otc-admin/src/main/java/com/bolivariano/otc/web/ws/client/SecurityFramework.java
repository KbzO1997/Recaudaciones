package com.bolivariano.otc.web.ws.client;

import java.io.Serializable;

/**
 * The type Security framework.
 */
public class SecurityFramework implements Serializable {
    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private String user;
    private String password;
    private String server;
    private String port;
    private String databasename;

	/**
	 * Gets user.
	 *
	 * @return the user
	 */
	public String getUser() {
        return user;
    }

	/**
	 * Sets user.
	 *
	 * @param user the user
	 */
	public void setUser(String user) {
        this.user = user;
    }

	/**
	 * Gets password.
	 *
	 * @return the password
	 */
	public String getPassword() {
        return password;
    }

	/**
	 * Sets password.
	 *
	 * @param password the password
	 */
	public void setPassword(String password) {
        this.password = password;
    }

	/**
	 * Gets server.
	 *
	 * @return the server
	 */
	public String getServer() {
        return server;
    }

	/**
	 * Sets server.
	 *
	 * @param server the server
	 */
	public void setServer(String server) {
        this.server = server;
    }

	/**
	 * Gets port.
	 *
	 * @return the port
	 */
	public String getPort() {
        return port;
    }

	/**
	 * Sets port.
	 *
	 * @param port the port
	 */
	public void setPort(String port) {
        this.port = port;
    }

	/**
	 * Gets databasename.
	 *
	 * @return the databasename
	 */
	public String getDatabasename() {
        return databasename;
    }

	/**
	 * Sets databasename.
	 *
	 * @param databasename the databasename
	 */
	public void setDatabasename(String databasename) {
        this.databasename = databasename;
    }

    @Override
    public String toString() {
        return "SecurityFramework {"
                + "user='" + user + '\''
                + ", password='" + password + '\''
                + ", server='" + server + '\''
                + ", port='" + port + '\''
                + ", databasename='" + databasename + '\''
                + "}";
    }

}
