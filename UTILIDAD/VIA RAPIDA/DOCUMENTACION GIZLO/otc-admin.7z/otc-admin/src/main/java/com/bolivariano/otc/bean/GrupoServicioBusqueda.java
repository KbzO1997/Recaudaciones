package com.bolivariano.otc.bean;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class GrupoServicioBusqueda implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long empresa;
	private Long tipoBanca;
	private Long tipoServicio;

	public Long getEmpresa() {
		return empresa;
	}

	public void setEmpresa(Long empresa) {
		this.empresa = empresa;
	}

	public Long getTipoBanca() {
		return tipoBanca;
	}

	public void setTipoBanca(Long tipoBanca) {
		this.tipoBanca = tipoBanca;
	}

	public Long getTipoServicio() {
		return tipoServicio;
	}

	public void setTipoServicio(Long tipoServicio) {
		this.tipoServicio = tipoServicio;
	}

	@Override
	public String toString() {
		return "GrupoServicioBusqueda [empresa=" + empresa + ", tipoBanca=" + tipoBanca + ", tipoServicio="
				+ tipoServicio + "]";
	}
}
