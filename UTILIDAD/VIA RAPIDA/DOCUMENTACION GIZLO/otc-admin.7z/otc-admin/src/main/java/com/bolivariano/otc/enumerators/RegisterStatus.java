package com.bolivariano.otc.enumerators;

public enum RegisterStatus {
	
	Activo("A"), /**
     * Online load type.
     */
    Inactivo("I");

    private String value;

    private RegisterStatus(final String value) {
        this.value = value;
    }

	public String getValue() {
		return value;
	}
    
    

}
