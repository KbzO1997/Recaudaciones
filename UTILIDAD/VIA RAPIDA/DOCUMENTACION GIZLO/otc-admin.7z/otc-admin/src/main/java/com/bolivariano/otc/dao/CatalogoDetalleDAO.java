package com.bolivariano.otc.dao;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.bolivariano.otc.MapperUtil;
import com.bolivariano.otc.bean.DatabaseResponse;
import com.bolivariano.otc.bean.DetalleCatalogoBean;
import com.bolivariano.otc.enumerators.RegisterStatus;

import oracle.jdbc.OracleTypes;

@Repository
public class CatalogoDetalleDAO {
	
	@Autowired
	MapperUtil<DetalleCatalogoBean> detalleMapper;
	

	private static final Logger log = LoggerFactory.getLogger(CatalogoDetalleDAO.class);
	
	
	 public List<DetalleCatalogoBean> findByCode(Connection conn, String code) throws Exception {

	        List<DetalleCatalogoBean> servicios = null;
	        StringBuilder SQL = new StringBuilder();
	        ResultSet rset = null;
	        SQL.append(" { call PA_OTC_CDCAT_CAT(?,?) }");
	        try (CallableStatement procStmt = conn.prepareCall(SQL.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)){
	            
	            
	            procStmt.setString("e_catalogoCodigo", code);
	            procStmt.registerOutParameter("S_RESPUESTA", OracleTypes.CURSOR);
	            procStmt.executeUpdate();
	            rset = (ResultSet) procStmt.getObject("S_RESPUESTA");

	            if (rset!= null && rset.isBeforeFirst()) {
	                servicios = detalleMapper.mapResultSetToObject(rset, DetalleCatalogoBean.class);
	            }

	        } catch (Exception e) {
	            log.error("Error al consultar detalles: " + e.getMessage(),e);
	        } finally {
	            if (rset != null) {
	                rset.close();
	            }
	        }
	        return servicios;
	    }
	 
	 public List<DetalleCatalogoBean> findByCatalogueId(Connection conn, Long catalogueId) throws Exception {

	        List<DetalleCatalogoBean> servicios = null;
	        StringBuilder SQL = new StringBuilder();
	        ResultSet rset = null;
	        SQL.append(" { call PA_OTC_CDCAT_CATID(?,?) }");
	        try (CallableStatement procStmt = conn.prepareCall(SQL.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)){
	            
	            
	            procStmt.setLong("e_catalogoId", catalogueId);
	            procStmt.registerOutParameter("S_RESPUESTA", OracleTypes.CURSOR);
	            procStmt.executeUpdate();
	            rset = (ResultSet) procStmt.getObject("S_RESPUESTA");

	            if (rset!= null && rset.isBeforeFirst()) {
	                servicios = detalleMapper.mapResultSetToObject(rset, DetalleCatalogoBean.class);
	            }

	        } catch (Exception e) {
	            log.error("Error al consultar detalles: " + e.getMessage(),e);
	        } finally {
	            if (rset != null) {
	                rset.close();
	            }
	        }
	        return servicios;
	    }
	 
	 public DatabaseResponse insert(JdbcTemplate jdbcTemplate, DetalleCatalogoBean detalle) {
			DatabaseResponse dr = new DatabaseResponse();
			try {
				SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_IDCATALOGO")
						.declareParameters(new SqlParameter("e_CTD_NOMBRE", Types.VARCHAR),
								new SqlParameter("e_CTD_ESTADO", Types.VARCHAR), 
								new SqlParameter("e_CTD_FECHA_REGISTRO", Types.DATE),
								new SqlParameter("e_CT_ID", Types.NUMERIC),
								new SqlParameter("e_CTD_CODIGO", Types.VARCHAR),
								new SqlParameter("e_CTD_DESCRIPCION", Types.VARCHAR),
								new SqlOutParameter("s_secuencia", Types.NUMERIC),
								new SqlOutParameter("s_afectados", Types.INTEGER),
								new SqlOutParameter("s_codigo_error", Types.NUMERIC),
								new SqlOutParameter("s_mensaje", Types.VARCHAR));
				MapSqlParameterSource source = new MapSqlParameterSource();
				source.addValue("e_CTD_NOMBRE", detalle.getNombre());
				source.addValue("e_CTD_ESTADO", RegisterStatus.Activo.getValue());
				source.addValue("e_CTD_FECHA_REGISTRO", Date.valueOf(LocalDate.now()));
				source.addValue("e_CT_ID", detalle.getCatalogoId());		
				source.addValue("e_CTD_CODIGO", detalle.getCodigo());	
				source.addValue("e_CTD_DESCRIPCION", detalle.getDescripcion());	
				Map<String, Object> out = simpleJdbcCall.execute(source);			
				dr.setAffectedRows((Integer) out.get("s_afectados"));
				dr.setMessage((String) out.get("s_mensaje"));
				dr.setSequence((BigDecimal) out.get("s_secuencia"));
				dr.setSqlCode((BigDecimal) out.get("s_codigo_error"));
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			return dr;
		}
		
	 
	 public DatabaseResponse update(JdbcTemplate jdbcTemplate, DetalleCatalogoBean detalle) {
			DatabaseResponse dr = new DatabaseResponse();
			try {
				SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_ADCATALOGO")
						.declareParameters(new SqlParameter("e_CTD_ID", Types.NUMERIC),
								new SqlParameter("e_CTD_NOMBRE", Types.VARCHAR),
								new SqlParameter("e_CTD_ESTADO", Types.VARCHAR), 
								new SqlParameter("e_CTD_FECHA_REGISTRO", Types.DATE),
								new SqlParameter("e_CT_ID", Types.NUMERIC),
								new SqlParameter("e_CTD_CODIGO", Types.VARCHAR),
								new SqlParameter("e_CTD_DESCRIPCION", Types.VARCHAR),
								new SqlOutParameter("s_afectados", Types.INTEGER),
								new SqlOutParameter("s_codigo_error", Types.NUMERIC),
								new SqlOutParameter("s_mensaje", Types.VARCHAR));
				MapSqlParameterSource source = new MapSqlParameterSource();
				source.addValue("e_CTD_ID", detalle.getId());
				source.addValue("e_CTD_NOMBRE", detalle.getNombre());
				source.addValue("e_CTD_ESTADO", detalle.getEstado());
				source.addValue("e_CTD_FECHA_REGISTRO", detalle.getFechaRegistro());
				source.addValue("e_CT_ID", detalle.getCatalogoId());		
				source.addValue("e_CTD_CODIGO", detalle.getCodigo());	
				source.addValue("e_CTD_DESCRIPCION", detalle.getDescripcion());	
				Map<String, Object> out = simpleJdbcCall.execute(source);			
				dr.setAffectedRows((Integer) out.get("s_afectados"));
				dr.setMessage((String) out.get("s_mensaje"));
				dr.setSqlCode((BigDecimal) out.get("s_codigo_error"));
			} catch (Exception ex) {
				log.error(ex.getMessage(), ex);
			}
			return dr;
		}
	 
	 public DatabaseResponse delete(JdbcTemplate jdbcTemplate, Long detalleId) {
			DatabaseResponse dr = new DatabaseResponse();
			try {
				SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_EDCATALOGO")
						.declareParameters(new SqlParameter("e_cd_id", Types.NUMERIC),
								new SqlOutParameter("s_afectados", Types.INTEGER),
								new SqlOutParameter("s_codigo_error", Types.NUMERIC),
								new SqlOutParameter("s_mensaje", Types.VARCHAR));
				MapSqlParameterSource source = new MapSqlParameterSource();
				source.addValue("e_cd_id", detalleId);
				Map<String, Object> out = simpleJdbcCall.execute(source);
				dr.setAffectedRows((Integer) out.get("s_afectados"));
				dr.setMessage((String) out.get("s_mensaje"));
				dr.setSqlCode((BigDecimal) out.get("s_codigo_error"));
			} catch (Exception ex) {
				throw new RuntimeException(ex.getMessage(), ex);
			}
			return dr;
		}

}
