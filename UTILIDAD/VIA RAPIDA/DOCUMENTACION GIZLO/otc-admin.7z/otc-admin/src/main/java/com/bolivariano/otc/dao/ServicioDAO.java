package com.bolivariano.otc.dao;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.bolivariano.otc.MapperUtil;
import com.bolivariano.otc.bean.DatabaseResponse;
import com.bolivariano.otc.bean.SelectItemBean;
import com.bolivariano.otc.bean.ServicioBean;
import com.bolivariano.otc.dto.Servicio;
import com.bolivariano.otc.exception.OTCAdminException;

import oracle.jdbc.OracleTypes;

@Repository
public class ServicioDAO {

    private static final Logger log = LoggerFactory.getLogger(ServicioDAO.class);
    private static final String S_CODIGO_ERROR = "s_codigo_error";
    private static final String S_AFECTADOS = "s_afectados";
    private static final String E_GRUPO_SERVICIO = "e_grupoServicioId";
    private static final String S_MENSAJE = "s_mensaje";
    private static final String S_RESPUESTA = "S_RESPUESTA";
    
    @Autowired
    MapperUtil<Servicio> servicioMapper;
    
    @Autowired
    MapperUtil<ServicioBean> servicioBeanMapper;
    
    @Autowired
    MapperUtil<SelectItemBean> selectMapper;

	public List<Servicio> obtenerServicios(Connection conn, Long idGrupoServicio)
			throws OTCAdminException, SQLException {

        List<Servicio> servicios = null;
        StringBuilder sql = new StringBuilder();
        ResultSet rset = null;
        sql.append(" { call PA_OTC_CSERVICIO_GRUP_SERV(?,?) }");
        try (CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)){
            
            
            procStmt.setLong(1, idGrupoServicio);
            procStmt.registerOutParameter(2, OracleTypes.CURSOR);
            procStmt.executeUpdate();
            rset = (ResultSet) procStmt.getObject(2);

            if (rset.isBeforeFirst()) {
                servicios = servicioMapper.mapResultSetToObject(rset, Servicio.class);

            }

        } catch (Exception e) {
            log.error("Error en el proceso" + e.getMessage(),e);
        } finally {
            if (rset != null) {
                rset.close();
            }
        }

        return servicios;
    }
    
    public DatabaseResponse insert(JdbcTemplate jdbcTemplate, ServicioBean servicio) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("pa_otc_iservicio")
					.declareParameters(new SqlParameter("e_nombre", Types.VARCHAR),
							new SqlParameter(E_GRUPO_SERVICIO, Types.NUMERIC), 
							new SqlParameter("e_convenioId", Types.NUMERIC),
							new SqlOutParameter("s_secuencia", Types.NUMERIC),
							new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
							new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
							new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_nombre", servicio.getNombre());
			source.addValue(E_GRUPO_SERVICIO, servicio.getGrupoServicioId());
			source.addValue("e_convenioId", servicio.getConvenioId());			
			Map<String, Object> out = simpleJdbcCall.execute(source);			
			dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
			dr.setMessage((String) out.get(S_MENSAJE));
			dr.setSequence((BigDecimal) out.get("s_secuencia"));
			dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}
	
    public DatabaseResponse update(JdbcTemplate jdbcTemplate, ServicioBean servicio) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("pa_otc_aservicio")
					.declareParameters(new SqlParameter("e_GRP_ID", Types.NUMERIC),
							new SqlParameter("e_SRV_NOMBRE", Types.VARCHAR),
							new SqlParameter("e_CNV_ID", Types.NUMERIC), 
							new SqlParameter("e_SRV_ID", Types.NUMERIC),
							new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
							new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
							new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_GRP_ID", servicio.getGrupoServicioId());
			source.addValue("e_SRV_NOMBRE", servicio.getNombre());
			source.addValue("e_CNV_ID", servicio.getConvenioId());		
			source.addValue("e_SRV_ID", servicio.getId());		
			Map<String, Object> out = simpleJdbcCall.execute(source);			
			dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
			dr.setMessage((String) out.get(S_MENSAJE));
			dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}
    
    public List<ServicioBean> findByGroup(Connection conn, Long idGrupoServicio) throws OTCAdminException, SQLException {

        List<ServicioBean> servicios = null;
        StringBuilder sql = new StringBuilder();
        ResultSet rset = null;
        sql.append(" { call PA_OTC_CSERVICIO_GRUPSERV(?,?) }");
        try (CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)){
            
            
            procStmt.setLong(E_GRUPO_SERVICIO, idGrupoServicio);
            procStmt.registerOutParameter(S_RESPUESTA, OracleTypes.CURSOR);
            procStmt.executeUpdate();
            rset = (ResultSet) procStmt.getObject(S_RESPUESTA);

            if (rset!= null && rset.isBeforeFirst()) {
                servicios = servicioBeanMapper.mapResultSetToObject(rset, ServicioBean.class);
            }

        } catch (Exception e) {
            log.error("Error al consultar servicios: " + e.getMessage(),e);
        } finally {
            if (rset != null) {
                rset.close();
            }
        }
        return servicios;
    }
    
    public List<SelectItemBean> findSelects(Connection conn) throws OTCAdminException, SQLException {

        List<SelectItemBean> servicios = null;
        StringBuilder sql = new StringBuilder();
        ResultSet rset = null;
        sql.append(" { call PA_OTC_CSERVICIO_SELECT(?) }");
        try (CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)){
            
            
            procStmt.registerOutParameter(S_RESPUESTA, OracleTypes.CURSOR);
            procStmt.executeUpdate();
            rset = (ResultSet) procStmt.getObject(S_RESPUESTA);

            if (rset!= null && rset.isBeforeFirst()) {
                servicios = selectMapper.mapResultSetToObject(rset, SelectItemBean.class);
            }

        } catch (Exception e) {
            log.error("Error al consultar servicios: " + e.getMessage(),e);
        } finally {
            if (rset != null) {
                rset.close();
            }
        }
        return servicios;
    }
    
    public DatabaseResponse delete(JdbcTemplate jdbcTemplate, Long servicioId) throws OTCAdminException {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_ESERVICIO")
					.declareParameters(new SqlParameter("e_srv_id", Types.NUMERIC),
							new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
							new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
							new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_srv_id", servicioId);
			Map<String, Object> out = simpleJdbcCall.execute(source);
			dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
			dr.setMessage((String) out.get(S_MENSAJE));
			dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
		} catch (Exception ex) {
			throw new OTCAdminException(ex.getMessage(), ex);
		}
		return dr;
	}
}
