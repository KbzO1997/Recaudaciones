package com.bolivariano.otc.bean;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * The persistent class for the OTC_M_FLUJO database table.
 */
@JsonInclude(Include.NON_NULL)
public class FlujoBean implements Serializable {
    private static final long serialVersionUID = 1L;


    private Long id;

    private Long convenioId;
    private Long operacionId;
    private Long endpointId;
    private List<FlujoEnriquecimientoBean> flujosEnriquecimiento;
    private List<ParametrosFlujoBean> parametrosFlujo;
    private List<Long> enriquecimientoId;
   	public List<Long> getEnriquecimientoId() {
   		return enriquecimientoId;
   	}
   	public void setEnriquecimientoId(List<Long> enriquecimientoId) {
   		this.enriquecimientoId = enriquecimientoId;
   	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getConvenioId() {
		return convenioId;
	}
	public void setConvenioId(Long convenioId) {
		this.convenioId = convenioId;
	}
	public Long getOperacionId() {
		return operacionId;
	}
	public void setOperacionId(Long operacionId) {
		this.operacionId = operacionId;
	}
	public Long getEndpointId() {
		return endpointId;
	}
	public void setEndpointId(Long endpointId) {
		this.endpointId = endpointId;
	}
	
	public List<FlujoEnriquecimientoBean> getFlujosEnriquecimiento() {
		return flujosEnriquecimiento;
	}
	public void setFlujosEnriquecimiento(List<FlujoEnriquecimientoBean> flujosEnriquecimiento) {
		this.flujosEnriquecimiento = flujosEnriquecimiento;
	}	
	public List<ParametrosFlujoBean> getParametrosFlujo() {
		return parametrosFlujo;
	}
	public void setParametrosFlujo(List<ParametrosFlujoBean> parametrosFlujo) {
		this.parametrosFlujo = parametrosFlujo;
	}
	@Override
	public String toString() {
		return "FlujoBean [id=" + id + ", convenioId=" + convenioId + ", operacionId=" + operacionId + ", endpointId="
				+ endpointId + ", flujosEnriquecimiento=" + flujosEnriquecimiento + ", parametrosFlujo="
				+ parametrosFlujo + ", enriquecimientoId=" + enriquecimientoId + "]";
	}
	
}