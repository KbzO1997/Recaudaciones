package com.bolivariano.otc.dao;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.bolivariano.otc.MapperUtil;
import com.bolivariano.otc.bean.DatabaseResponse;
import com.bolivariano.otc.bean.DatoAdicionalBean;
import com.bolivariano.otc.dto.DatoAdicional;

import oracle.jdbc.OracleTypes;

@Repository
public class DatosAdicionalesDAO {

	private static final Logger log = LoggerFactory.getLogger(DatosAdicionalesDAO.class);
	// @Autowired
	// JdbcTemplate jdbcTemplate;

	@Autowired
	MapperUtil<DatoAdicional> selectMapper;

	@Autowired
	MapperUtil<DatoAdicionalBean> datoAdicionalMapper;

	public List<DatoAdicional> obtenerAdicionalesTiposIdentificador(Connection conn, Long idTipoIdentificador)
			throws Exception {

		List<DatoAdicional> dats = null;

		StringBuilder SQL = new StringBuilder();
		ResultSet rset = null;
		SQL.append(" { call PA_OTC_CDATOS_AD_TIPO_ID(?,?) }");
		try (CallableStatement procStmt = conn.prepareCall(SQL.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)){
			
			
			procStmt.setLong(1, idTipoIdentificador);
			procStmt.registerOutParameter(2, OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject(2);

			if (rset.isBeforeFirst()) {
				dats = selectMapper.mapResultSetToObject(rset, DatoAdicional.class);

			}

	
		} catch (Exception e) {
			log.error("Error en el proceso" + e.getMessage(), e);
		} finally {
			if (rset != null) {
				rset.close();
			}
		}

		return dats;
	}

	public DatabaseResponse insert(JdbcTemplate jdbcTemplate, DatoAdicionalBean convenio) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_IDATOADICIONAL")
					.declareParameters(new SqlParameter("e_DAT_VALOR", Types.VARCHAR),
							new SqlParameter("e_DAT_MASCARA", Types.VARCHAR),
							new SqlParameter("e_DAT_TIPO", Types.VARCHAR),
							new SqlParameter("e_DAT_CODIGO", Types.VARCHAR),
							new SqlParameter("e_DAT_FORMATO", Types.VARCHAR),
							new SqlParameter("e_DAT_EDITABLE", Types.NUMERIC),
							new SqlParameter("e_CNV_ID", Types.NUMERIC),
							new SqlParameter("e_DAT_VISIBLE", Types.NUMERIC),
							new SqlParameter("e_DAT_LONGITUD", Types.VARCHAR),
							new SqlParameter("e_TID_ID", Types.NUMERIC),
							new SqlParameter("e_DAT_ETIQUETA", Types.VARCHAR),
							new SqlParameter("e_DAT_REGEXP", Types.VARCHAR),
							new SqlOutParameter("s_secuencia", Types.NUMERIC),
							new SqlOutParameter("s_afectados", Types.INTEGER),
							new SqlOutParameter("s_codigo_error", Types.NUMERIC),
							new SqlOutParameter("s_mensaje", Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_DAT_VALOR", convenio.getValor());
			source.addValue("e_DAT_MASCARA", convenio.getMascara());
			source.addValue("e_DAT_TIPO", convenio.getTipo());
			source.addValue("e_DAT_CODIGO", convenio.getCodigo());
			source.addValue("e_DAT_FORMATO", convenio.getFormato());
			source.addValue("e_DAT_EDITABLE", convenio.getEditable());
			source.addValue("e_CNV_ID", convenio.getConvenioId());
			source.addValue("e_DAT_VISIBLE", convenio.getVisible());
			source.addValue("e_DAT_LONGITUD", convenio.getLongitud());
			source.addValue("e_TID_ID", convenio.getTipoIdentificadorId());
			source.addValue("e_DAT_ETIQUETA", convenio.getEtiqueta());
			source.addValue("e_DAT_REGEXP", convenio.getRegexp());
			Map<String, Object> out = simpleJdbcCall.execute(source);

			dr.setAffectedRows((Integer) out.get("s_afectados"));
			dr.setMessage((String) out.get("s_mensaje"));
			dr.setSequence((BigDecimal) out.get("s_secuencia"));
			dr.setSqlCode((BigDecimal) out.get("s_codigo_error"));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}

	public DatabaseResponse update(JdbcTemplate jdbcTemplate, DatoAdicionalBean convenio) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_ADATOADICIONAL")
					.declareParameters(new SqlParameter("e_DAT_VALOR", Types.VARCHAR),
							new SqlParameter("e_DAT_MASCARA", Types.VARCHAR),
							new SqlParameter("e_DAT_TIPO", Types.VARCHAR),
							new SqlParameter("e_DAT_CODIGO", Types.VARCHAR),
							new SqlParameter("e_DAT_FORMATO", Types.VARCHAR),
							new SqlParameter("e_DAT_EDITABLE", Types.NUMERIC),
							new SqlParameter("e_CNV_ID", Types.NUMERIC),
							new SqlParameter("e_DAT_VISIBLE", Types.NUMERIC),
							new SqlParameter("e_DAT_LONGITUD", Types.VARCHAR),
							new SqlParameter("e_TID_ID", Types.NUMERIC),
							new SqlParameter("e_DAT_ETIQUETA", Types.VARCHAR),
							new SqlParameter("e_DAT_REGEXP", Types.VARCHAR),
							new SqlParameter("e_DAT_ID", Types.NUMERIC),
							new SqlOutParameter("s_afectados", Types.INTEGER),
							new SqlOutParameter("s_codigo_error", Types.NUMERIC),
							new SqlOutParameter("s_mensaje", Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_DAT_ID", convenio.getId());
			source.addValue("e_DAT_VALOR", convenio.getValor());
			source.addValue("e_DAT_MASCARA", convenio.getMascara());
			source.addValue("e_DAT_TIPO", convenio.getTipo());
			source.addValue("e_DAT_CODIGO", convenio.getCodigo());
			source.addValue("e_DAT_FORMATO", convenio.getFormato());
			source.addValue("e_DAT_EDITABLE", convenio.getEditable());
			source.addValue("e_CNV_ID", convenio.getConvenioId());
			source.addValue("e_DAT_VISIBLE", convenio.getVisible());
			source.addValue("e_DAT_LONGITUD", convenio.getLongitud());
			source.addValue("e_TID_ID", convenio.getTipoIdentificadorId());
			source.addValue("e_DAT_ETIQUETA", convenio.getEtiqueta());
			source.addValue("e_DAT_REGEXP", convenio.getRegexp());
			Map<String, Object> out = simpleJdbcCall.execute(source);

			dr.setAffectedRows((Integer) out.get("s_afectados"));
			dr.setMessage((String) out.get("s_mensaje"));
			dr.setSqlCode((BigDecimal) out.get("s_codigo_error"));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}

	public List<DatoAdicionalBean> findByTipoId(Connection conn, Long tipoId) throws Exception {

		List<DatoAdicionalBean> datosAdicionales = null;
		StringBuilder SQL = new StringBuilder();
		ResultSet rset = null;
		SQL.append(" { call PA_OTC_CDATOADIC_TIPOID(?,?) }");
		try (CallableStatement procStmt = conn.prepareCall(SQL.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)){
			
			
			procStmt.setLong("e_tipoId", tipoId);
			procStmt.registerOutParameter("S_RESPUESTA", OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject("S_RESPUESTA");

			if (rset != null && rset.isBeforeFirst()) {
				datosAdicionales = datoAdicionalMapper.mapResultSetToObject(rset, DatoAdicionalBean.class);
			}

		} catch (Exception e) {
			log.error("Error al consultar identificadores: " + e.getMessage(), e);
		} finally {
			if (rset != null) {
				rset.close();
			}
		}
		return datosAdicionales;
	}

	public DatabaseResponse delete(JdbcTemplate jdbcTemplate, Long canalId) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_EDATOADIC")
					.declareParameters(new SqlParameter("e_dat_id", Types.NUMERIC),
							new SqlOutParameter("s_afectados", Types.INTEGER),
							new SqlOutParameter("s_codigo_error", Types.NUMERIC),
							new SqlOutParameter("s_mensaje", Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_dat_id", canalId);
			Map<String, Object> out = simpleJdbcCall.execute(source);
			dr.setAffectedRows((Integer) out.get("s_afectados"));
			dr.setMessage((String) out.get("s_mensaje"));
			dr.setSqlCode((BigDecimal) out.get("s_codigo_error"));
		} catch (Exception ex) {
			throw new RuntimeException(ex.getMessage(), ex);
		}
		return dr;
	}
}
