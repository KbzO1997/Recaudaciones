package com.bolivariano.otc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.annotation.PostConstruct;
import java.util.TimeZone;
//import org.springframework.cache.annotation.EnableCaching;

//@EnableCaching
@SpringBootApplication
public class OTCAdminApplication {
    public static void main(String[] args) {
        SpringApplication.run(OTCAdminApplication.class, args);
    }

    /**
     * This method triggers initialization of the Jedis Pool. Only one Pool will be available
     * in the life of the running application.
     * Running this as @PostConstruct ensures that all the static variables
     * needed to initialize the pool are available.
     * Triggering the initialization from "main" method will result in Null Pointr
     * as the static variables would not have been initialized.
     */
    @PostConstruct
    private void initializeJedisPool() {
        TimeZone.setDefault(TimeZone.getTimeZone("America/Guayaquil"));
    }
}
