package com.bolivariano.otc.dao;

import com.bolivariano.otc.MapperUtil;
import com.bolivariano.otc.bean.*;
import com.bolivariano.otc.dto.Convenio;
import oracle.jdbc.OracleTypes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.*;
import java.util.List;
import java.util.Map;

@Repository
public class ConvenioDAO {

    private static final Logger log = LoggerFactory.getLogger(ConvenioDAO.class);

    @Autowired
    MapperUtil<Convenio> convenioMapper;

    @Autowired
    MapperUtil<ConvenioBean> convenioBeanMapper;

    @Autowired
    MapperUtil<SelectItemBean> selectMapper;

    public Convenio obtenerConvenio(Connection conn, Long idConvenio) throws Exception {

        List<Convenio> convenios = null;
        StringBuilder SQL = new StringBuilder();
        ResultSet rset = null;
        SQL.append(" { call PA_OTC_CCONVENIO(?,?) }");
        try (CallableStatement procStmt = conn.prepareCall(SQL.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)){
            
            
            procStmt.setLong(1, idConvenio);
            procStmt.registerOutParameter(2, OracleTypes.CURSOR);
            procStmt.executeUpdate();
            rset = (ResultSet) procStmt.getObject(2);

            if (rset.isBeforeFirst()) {
                convenios = convenioMapper.mapResultSetToObject(rset, Convenio.class);

            }

        } catch (Exception e) {
            log.error("Error en el proceso" + e.getMessage(), e);
        } finally {
            if (rset != null) {
                rset.close();
            }
        }


        return convenios != null ? convenios.get(0) : null;
    }

    public List<SelectItemBean> findSelectConvenios(Connection conn) throws Exception {

        List<SelectItemBean> convenios = null;
        StringBuilder SQL = new StringBuilder();
        ResultSet rset = null;
        SQL.append(" { call PA_OTC_CCONVENIO_SELECT(?) }");
        try (CallableStatement procStmt = conn.prepareCall(SQL.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)){
            
            
            procStmt.registerOutParameter("S_RESPUESTA", OracleTypes.CURSOR);
            procStmt.executeUpdate();
            rset = (ResultSet) procStmt.getObject("S_RESPUESTA");
            if (rset.isBeforeFirst()) {
                convenios = selectMapper.mapResultSetToObject(rset, SelectItemBean.class);
            }
            return convenios;
        } catch (Exception e) {
            log.error("Error en el proceso" + e.getMessage(), e);

        } finally {
            if (rset != null) {
                rset.close();
            }
        }
        return null;
    }

    public PaginatedListConvenio findAll(PaginationRequest pr, Connection conn) throws SQLException, NoSuchMethodException {

        StringBuilder SQL = new StringBuilder();
        ResultSet rs;
        List<ConvenioBean> convenios = null;
        PaginatedListConvenio pagedConvenios;
        SQL.append(" { call pa_otc_gconvenio(?,?,?,?,?) }");
        try (CallableStatement procStmt = conn.prepareCall(SQL.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)){
            
            
            procStmt.setInt("e_size", pr.getSize());
            procStmt.setInt("e_page", pr.getPage());
            procStmt.setString("e_sort", pr.getSortBy());
            procStmt.registerOutParameter("s_totalRecord", Types.NUMERIC);
            procStmt.registerOutParameter("s_result", OracleTypes.CURSOR);
            procStmt.executeUpdate();
            rs = (ResultSet) procStmt.getObject("s_result");
            if (rs != null && rs.isBeforeFirst()) {
                convenios = convenioBeanMapper.mapResultSetToObject(rs, ConvenioBean.class);
                pagedConvenios = new PaginatedListConvenio();
                pagedConvenios.setRecordsFiltered(pr.getSize());
                pagedConvenios.setRecordsTotal(procStmt.getBigDecimal("s_totalRecord").longValue());
                pagedConvenios.setData(convenios);
                rs.close();
                return pagedConvenios;
            } else {
                return null;
            }

        } catch (SQLException e) {
            log.error("Error al consultar convenios: " + e.getMessage(), e);
            throw new SQLException("Error al consultar convenios: " + e.getMessage(), e);
        } finally {
            if (conn != null)
                conn.close();
        }
    }

    public DatabaseResponse insert(JdbcTemplate jdbcTemplate, ConvenioBean convenio) {
        DatabaseResponse dr = new DatabaseResponse();
        try {
            SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("pa_otc_iconvenio")
                    .declareParameters(new SqlParameter("e_CNV_ETIQUETA_CODIGO", Types.VARCHAR),
                            new SqlParameter("e_CNV_CODIGO", Types.VARCHAR),
                            new SqlParameter("e_CNV_VISIBLE", Types.NUMERIC),
                            new SqlOutParameter("s_secuencia", Types.NUMERIC),
                            new SqlOutParameter("s_afectados", Types.INTEGER),
                            new SqlOutParameter("s_codigo_error", Types.NUMERIC),
                            new SqlOutParameter("s_mensaje", Types.VARCHAR));
            MapSqlParameterSource source = new MapSqlParameterSource();
            source.addValue("e_CNV_ETIQUETA_CODIGO", convenio.getEtiquetaCodigo());
            source.addValue("e_CNV_CODIGO", convenio.getCodigo());
            source.addValue("e_CNV_VISIBLE", convenio.getVisible());
            Map<String, Object> out = simpleJdbcCall.execute(source);

            dr.setAffectedRows((Integer) out.get("s_afectados"));
            dr.setMessage((String) out.get("s_mensaje"));
            dr.setSequence((BigDecimal) out.get("s_secuencia"));
            dr.setSqlCode((BigDecimal) out.get("s_codigo_error"));
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
        }
        return dr;
    }

    public DatabaseResponse update(JdbcTemplate jdbcTemplate, ConvenioBean convenio) {
        DatabaseResponse dr = new DatabaseResponse();
        try {
            SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("pa_otc_aconvenio")
                    .declareParameters(new SqlParameter("e_CNV_ETIQUETA_CODIGO", Types.VARCHAR),
                            new SqlParameter("e_CNV_CODIGO", Types.VARCHAR),
                            new SqlParameter("e_CNV_VISIBLE", Types.NUMERIC),
                            new SqlParameter("e_CNV_ID", Types.NUMERIC),
                            new SqlOutParameter("s_afectados", Types.INTEGER),
                            new SqlOutParameter("s_codigo_error", Types.NUMERIC),
                            new SqlOutParameter("s_mensaje", Types.VARCHAR));
            MapSqlParameterSource source = new MapSqlParameterSource();
            source.addValue("e_CNV_ETIQUETA_CODIGO", convenio.getEtiquetaCodigo());
            source.addValue("e_CNV_CODIGO", convenio.getCodigo());
            source.addValue("e_CNV_VISIBLE", convenio.getVisible());
            source.addValue("e_CNV_ID", convenio.getId());
            Map<String, Object> out = simpleJdbcCall.execute(source);
            dr.setAffectedRows((Integer) out.get("s_afectados"));
            dr.setMessage((String) out.get("s_mensaje"));
            dr.setSqlCode((BigDecimal) out.get("s_codigo_error"));
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
        }
        return dr;
    }


    public ConvenioBean findById(Connection conn, Long id) throws Exception {

        List<ConvenioBean> convenios = null;
        StringBuilder SQL = new StringBuilder();
        ResultSet rset = null;
        SQL.append(" { call PA_OTC_CCONVENIO_ID(?,?) }");
        try (CallableStatement procStmt = conn.prepareCall(SQL.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)){
            
            
            procStmt.setLong("e_id ", id);
            procStmt.registerOutParameter("S_RESPUESTA", OracleTypes.CURSOR);
            procStmt.executeUpdate();
            rset = (ResultSet) procStmt.getObject("S_RESPUESTA");
            if (rset != null && rset.isBeforeFirst()) {
                convenios = convenioBeanMapper.mapResultSetToObject(rset, ConvenioBean.class);
                return convenios.get(0);
            }

        } catch (Exception e) {
            log.error("Error en el proceso" + e.getMessage(), e);

        } finally {
            if (rset != null) {
                rset.close();
            }
        }
        return null;
    }

    public Integer countCode(JdbcTemplate jdbcTemplate, String code) {
        Integer count = null;
        try {
            SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_PCONTAR_CODCONV")
                    .declareParameters(new SqlParameter("e_codigo", Types.VARCHAR),
                            new SqlOutParameter("s_cantidad", Types.INTEGER));
            MapSqlParameterSource source = new MapSqlParameterSource();
            source.addValue("e_codigo", code);
            Map<String, Object> out = simpleJdbcCall.execute(source);
            count = (Integer) out.get("s_cantidad");
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
        }
        return count;
    }

    public DatabaseResponse delete(JdbcTemplate jdbcTemplate, Long convenioId) {
        DatabaseResponse dr = new DatabaseResponse();
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_ECONVENIO")
                .declareParameters(new SqlParameter("e_cnv_id", Types.NUMERIC),
                        new SqlOutParameter("s_afectados", Types.INTEGER),
                        new SqlOutParameter("s_codigo_error", Types.NUMERIC),
                        new SqlOutParameter("s_mensaje", Types.VARCHAR));
        MapSqlParameterSource source = new MapSqlParameterSource();
        source.addValue("e_cnv_id", convenioId);
        Map<String, Object> out = simpleJdbcCall.execute(source);
        dr.setAffectedRows((Integer) out.get("s_afectados"));
        dr.setMessage((String) out.get("s_mensaje"));
        dr.setSqlCode((BigDecimal) out.get("s_codigo_error"));

        return dr;
    }

    public List<ConvenioBean> search(Connection conn, ConvenioBusqueda busqueda) throws Exception {
        
        StringBuilder SQL = new StringBuilder();
        ResultSet rset = null;
        List<ConvenioBean> catalogos = null;
        SQL.append(" { call PA_OTC_CCONVENIO_SEARCH(?,?,?) }");
        try (CallableStatement procStmt = conn.prepareCall(SQL.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)){                    
            
            procStmt.setString("e_codigo", busqueda.getCodigo());
            procStmt.setString("e_etiqueta", busqueda.getEtiquetaCodigo());
            procStmt.registerOutParameter("s_result", OracleTypes.CURSOR);
            procStmt.executeUpdate();
            rset = (ResultSet) procStmt.getObject("s_result");
            //log.info(rset.toString());
            if (rset.isBeforeFirst()) {
                catalogos = convenioBeanMapper.mapResultSetToObject(rset, ConvenioBean.class);
                rset.close();
                return catalogos;
            } else {
                return null;
            }

        } catch (SQLException e) {
            log.error("Error al consultar convenios: " + e.getMessage(), e);
            throw new SQLException("Error al consultar convenios: " + e.getMessage(), e);
        } finally {
            if (conn != null)
                conn.close();
        }
    }

}
