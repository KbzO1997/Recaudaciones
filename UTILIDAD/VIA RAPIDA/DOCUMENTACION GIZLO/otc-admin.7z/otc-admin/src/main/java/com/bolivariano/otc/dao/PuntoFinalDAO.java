package com.bolivariano.otc.dao;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.bolivariano.otc.MapperUtil;
import com.bolivariano.otc.bean.DatabaseResponse;
import com.bolivariano.otc.bean.EnriquecimientoBusqueda;
import com.bolivariano.otc.bean.PaginatedListPuntoFinal;
import com.bolivariano.otc.bean.PaginationRequest;
import com.bolivariano.otc.bean.PuntoFinalBean;
import com.bolivariano.otc.bean.SelectItemBean;

import oracle.jdbc.OracleTypes;

@Repository
public class PuntoFinalDAO {
	
	private static final Logger log = LoggerFactory.getLogger(PuntoFinalDAO.class);
	
	@Autowired
	MapperUtil<PuntoFinalBean> puntoFinalMapper;
	
	@Autowired
	MapperUtil<SelectItemBean> selectMapper;
	
	
	public DatabaseResponse insert(JdbcTemplate jdbcTemplate, PuntoFinalBean endpoint) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_IENDPA_OTC_GENDPOINTPOINT")
					.declareParameters(new SqlParameter("e_END_NOMBRE", Types.VARCHAR),
							new SqlParameter("e_END_REPOSITORIO_PETICION", Types.VARCHAR), 
							new SqlParameter("e_END_OPERACION", Types.VARCHAR),
							new SqlParameter("e_END_RESPUESTA", Types.VARCHAR),
							new SqlParameter("e_END_PUNTO_FINAL", Types.VARCHAR),
							new SqlParameter("e_END_REPOSITORIO_RESPUESTA", Types.VARCHAR),
							new SqlParameter("e_END_PETICION", Types.VARCHAR),
							new SqlParameter("e_END_AMBIENTE", Types.VARCHAR),
							new SqlOutParameter("s_secuencia", Types.NUMERIC),
							new SqlOutParameter("s_afectados", Types.INTEGER),
							new SqlOutParameter("s_codigo_error", Types.NUMERIC),
							new SqlOutParameter("s_mensaje", Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_END_NOMBRE", endpoint.getNombre());
			source.addValue("e_END_REPOSITORIO_PETICION", endpoint.getRepositorioPeticion());
			source.addValue("e_END_OPERACION", endpoint.getOperacion());
			source.addValue("e_END_RESPUESTA", endpoint.getRespuesta());		
			source.addValue("e_END_PUNTO_FINAL", endpoint.getPuntoFinal());	
			source.addValue("e_END_REPOSITORIO_RESPUESTA", endpoint.getRepositorioRespuesta());	
			source.addValue("e_END_PETICION", endpoint.getPeticion());
			source.addValue("e_END_AMBIENTE", endpoint.getAmbiente());
			Map<String, Object> out = simpleJdbcCall.execute(source);			
			dr.setAffectedRows((Integer) out.get("s_afectados"));
			dr.setMessage((String) out.get("s_mensaje"));
			dr.setSequence((BigDecimal) out.get("s_secuencia"));
			dr.setSqlCode((BigDecimal) out.get("s_codigo_error"));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}
	
	public DatabaseResponse update(JdbcTemplate jdbcTemplate, PuntoFinalBean endpoint) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_AENDPOINT")
					.declareParameters(new SqlParameter("e_END_ID", Types.NUMERIC),
							new SqlParameter("e_END_NOMBRE", Types.VARCHAR),
							new SqlParameter("e_END_REPOSITORIO_PETICION", Types.VARCHAR), 
							new SqlParameter("e_END_OPERACION", Types.VARCHAR),
							new SqlParameter("e_END_RESPUESTA", Types.VARCHAR),
							new SqlParameter("e_END_PUNTO_FINAL", Types.VARCHAR),
							new SqlParameter("e_END_REPOSITORIO_RESPUESTA", Types.VARCHAR),
							new SqlParameter("e_END_PETICION", Types.VARCHAR),
                            new SqlParameter("e_END_AMBIENTE", Types.VARCHAR),
							new SqlOutParameter("s_afectados", Types.INTEGER),
							new SqlOutParameter("s_codigo_error", Types.NUMERIC),
							new SqlOutParameter("s_mensaje", Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_END_ID", endpoint.getId());
			source.addValue("e_END_NOMBRE", endpoint.getNombre());
			source.addValue("e_END_REPOSITORIO_PETICION", endpoint.getRepositorioPeticion());
			source.addValue("e_END_OPERACION", endpoint.getOperacion());
			source.addValue("e_END_RESPUESTA", endpoint.getRespuesta());		
			source.addValue("e_END_PUNTO_FINAL", endpoint.getPuntoFinal());	
			source.addValue("e_END_REPOSITORIO_RESPUESTA", endpoint.getRepositorioRespuesta());	
			source.addValue("e_END_PETICION", endpoint.getPeticion());
            source.addValue("e_END_AMBIENTE", endpoint.getAmbiente());
			Map<String, Object> out = simpleJdbcCall.execute(source);			
			dr.setAffectedRows((Integer) out.get("s_afectados"));
			dr.setMessage((String) out.get("s_mensaje"));
			dr.setSqlCode((BigDecimal) out.get("s_codigo_error"));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}
	
	public PaginatedListPuntoFinal findAll(PaginationRequest pr,  Connection conn) throws SQLException, NoSuchMethodException {
     
        StringBuilder sql = new StringBuilder();
        ResultSet rs;
        List<PuntoFinalBean> endpoints = null;
        PaginatedListPuntoFinal pagedEndpoints;
        sql.append(" { call pa_otc_gendpoint(?,?,?,?,?) }");
        try (CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)){
            
            
            procStmt.setInt("e_size", pr.getSize());
            procStmt.setInt("e_page", pr.getPage());
            procStmt.setString("e_sort", pr.getSortBy());
            procStmt.registerOutParameter("s_totalRecord", Types.NUMERIC);
            procStmt.registerOutParameter("s_result", OracleTypes.CURSOR);
            procStmt.executeUpdate();
            rs = (ResultSet) procStmt.getObject("s_result");
            if (rs!= null && rs.isBeforeFirst()) {
                endpoints = puntoFinalMapper.mapResultSetToObject(rs, PuntoFinalBean.class);
                pagedEndpoints = new PaginatedListPuntoFinal();
                pagedEndpoints.setRecordsFiltered(pr.getSize());
                pagedEndpoints.setRecordsTotal(procStmt.getBigDecimal("s_totalRecord").longValue());
                pagedEndpoints.setData(endpoints);
                rs.close();
                return pagedEndpoints;
            } else {
                return null;
            }

        } catch (SQLException e) {
            log.error("Error al consultar endpoints: " + e.getMessage(), e);
            throw new SQLException("Error al consultar endpoints: " + e.getMessage(), e);
        } finally {
            if (conn != null)
                conn.close();
        }
    }
	
	public PuntoFinalBean findById(Connection conn, Long id) throws Exception {

		List<PuntoFinalBean> endpoints = null;
		StringBuilder sql = new StringBuilder();
		ResultSet rset = null;
		sql.append(" { call PA_OTC_CENDPOINT_ID(?,?) }");
		try (CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)){
			
			
			procStmt.setLong("e_id ", id);
			procStmt.registerOutParameter("S_RESPUESTA", OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject("S_RESPUESTA");
			if (rset!= null && rset.isBeforeFirst()) {
				endpoints = puntoFinalMapper.mapResultSetToObject(rset, PuntoFinalBean.class);
				return endpoints.get(0);
			}
			
		} catch (Exception e) {
			log.error("Error en el proceso" + e.getMessage(), e);
			
		} finally {
			if (rset != null) {
				rset.close();
			}
		}
		return null;
	}
	
	public List<SelectItemBean> findSelectEndpoints(Connection conn) throws Exception {

		List<SelectItemBean> endpoints = null;
		StringBuilder sql = new StringBuilder();
		ResultSet rset = null;
		sql.append(" { call PA_OTC_CENDPOINT_SELECT(?) }");
		try (CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)){
			
			
			procStmt.registerOutParameter("S_RESPUESTA", OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject("S_RESPUESTA");
			if (rset.isBeforeFirst()) {
				endpoints = selectMapper.mapResultSetToObject(rset, SelectItemBean.class);
			}
			return endpoints;
		} catch (Exception e) {
			log.error("Error en el proceso" + e.getMessage(), e);
			
		} finally {
			if (rset != null) {
				rset.close();
			}
		}
		return null;
	}
	
	 public DatabaseResponse delete(JdbcTemplate jdbcTemplate, Long endpointId) {
			DatabaseResponse dr = new DatabaseResponse();
			try {
				SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_EENDPOINT")
						.declareParameters(new SqlParameter("e_end_id", Types.NUMERIC),
								new SqlOutParameter("s_afectados", Types.INTEGER),
								new SqlOutParameter("s_codigo_error", Types.NUMERIC),
								new SqlOutParameter("s_mensaje", Types.VARCHAR));
				MapSqlParameterSource source = new MapSqlParameterSource();
				source.addValue("e_end_id", endpointId);
				Map<String, Object> out = simpleJdbcCall.execute(source);
				dr.setAffectedRows((Integer) out.get("s_afectados"));
				dr.setMessage((String) out.get("s_mensaje"));
				dr.setSqlCode((BigDecimal) out.get("s_codigo_error"));
			} catch (Exception ex) {
				throw new RuntimeException(ex.getMessage(), ex);
			}
			return dr;
		}
	 
	 public List<PuntoFinalBean> search(Connection conn, EnriquecimientoBusqueda busqueda) throws Exception {
			StringBuilder sql = new StringBuilder();
			ResultSet rset = null;
			List<PuntoFinalBean> canales = null;
			sql.append(" { call pa_otc_cendpoint(?,?,?) }");
			try (CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)){
				
				procStmt.setString("e_operacion", busqueda.getOperacion());
				procStmt.setString("e_nombre", busqueda.getNombre());
				procStmt.registerOutParameter("s_result", OracleTypes.CURSOR);
				procStmt.executeUpdate();
				rset = (ResultSet) procStmt.getObject("s_result");
				if (rset.isBeforeFirst()) {
					canales = puntoFinalMapper.mapResultSetToObject(rset, PuntoFinalBean.class);
					rset.close();
					return canales;
				} else {
					return null;
				}

			} catch (SQLException e) {
				log.error("Error al consultar endpoint: " + e.getMessage(), e);
				throw new SQLException("Error al consultar endpoint: " + e.getMessage(), e);
			} finally {
				if (conn != null)
					conn.close();
			}
		}
}
