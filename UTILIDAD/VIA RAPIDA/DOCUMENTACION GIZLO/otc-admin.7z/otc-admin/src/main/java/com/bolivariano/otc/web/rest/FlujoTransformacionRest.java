package com.bolivariano.otc.web.rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.bolivariano.otc.bean.FlujoTransformacionBean;
import com.bolivariano.otc.bean.DatoAtxBean;
import com.bolivariano.otc.service.FlujoTransformacionService;

@Component
@Repository
@Path("/admin/v1/flujoTransformacion")
public class FlujoTransformacionRest {
	
	@Autowired
	FlujoTransformacionService flujoTransformacionService;
	
    private static final Logger log = LoggerFactory.getLogger(FlujoTransformacionRest.class);

    @GET
    @Path("/{transaccion}")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response consultarFlujoPorTransaccion(@PathParam("transaccion") Long transaccion) {
        log.info("consultaFlujoPorTransaccion: Petición Recibida");
        try {
        	FlujoTransformacionBean flujoTransformacionBean = this.flujoTransformacionService.consultarFlujoPorTransaccion(transaccion);
            if (flujoTransformacionBean == null) {
                return Response.status(Status.NOT_FOUND).entity(null).build();
            }
            return Response.status(Status.OK).entity(flujoTransformacionBean).build();
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }
    
    
    @GET
    @Path("/obtenerDatos/{id}/{banca}")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response consultarDatosFlujo(@PathParam("id") Long id,@PathParam("banca") String banca ) {
        log.info("obtenerDatos-Flujo: Petición Recibida");
        try {
        	DatoAtxBean datosAtx = this.flujoTransformacionService.consultarDatosFlujo(id,banca);
            if (datosAtx == null) {
                return Response.status(Status.NOT_FOUND).entity(null).build();
            }
            return Response.status(Status.OK).entity(datosAtx).build();
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }

}
