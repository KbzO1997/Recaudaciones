package com.bolivariano.otc.dao;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.bolivariano.otc.MapperUtil;
import com.bolivariano.otc.bean.CatalogoBean;
import com.bolivariano.otc.bean.CatalogoBusqueda;
import com.bolivariano.otc.bean.DatabaseResponse;
import com.bolivariano.otc.bean.PaginatedListCatalogo;
import com.bolivariano.otc.bean.PaginationRequest;
import com.bolivariano.otc.enumerators.RegisterStatus;

import oracle.jdbc.OracleTypes;

@Repository
public class CatalogoDAO {

	@Autowired
	MapperUtil<CatalogoBean> catalogoBeanMapper;
	private static final Logger log = LoggerFactory.getLogger(CatalogoDAO.class);

	public DatabaseResponse insert(JdbcTemplate jdbcTemplate, CatalogoBean catalogo) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_ICATALOGO")
					.declareParameters(new SqlParameter("e_CT_FECHA_REGISTRO", Types.DATE),
							new SqlParameter("e_CT_NOMBRE", Types.VARCHAR), new SqlParameter("e_CT_ESTADO", Types.CHAR),
							new SqlParameter("e_CT_DESCRIPCION", Types.VARCHAR),
							new SqlParameter("e_CT_CODIGO", Types.VARCHAR),
							new SqlOutParameter("s_secuencia", Types.NUMERIC),
							new SqlOutParameter("s_afectados", Types.INTEGER),
							new SqlOutParameter("s_codigo_error", Types.NUMERIC),
							new SqlOutParameter("s_mensaje", Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_CT_FECHA_REGISTRO", Date.valueOf(LocalDate.now()));
			source.addValue("e_CT_NOMBRE", catalogo.getNombre());
			source.addValue("e_CT_ESTADO", RegisterStatus.Activo.getValue());
			source.addValue("e_CT_DESCRIPCION", catalogo.getDescripcion());
			source.addValue("e_CT_CODIGO", catalogo.getCodigo());
			Map<String, Object> out = simpleJdbcCall.execute(source);
			dr.setAffectedRows((Integer) out.get("s_afectados"));
			dr.setMessage((String) out.get("s_mensaje"));
			dr.setSequence((BigDecimal) out.get("s_secuencia"));
			dr.setSqlCode((BigDecimal) out.get("s_codigo_error"));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}

	public DatabaseResponse update(JdbcTemplate jdbcTemplate, CatalogoBean catalogo) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_ACATALOGO")
					.declareParameters(new SqlParameter("e_CT_ID", Types.NUMERIC),
							new SqlParameter("e_CT_FECHA_REGISTRO", Types.DATE),
							new SqlParameter("e_CT_NOMBRE", Types.VARCHAR), new SqlParameter("e_CT_ESTADO", Types.CHAR),
							new SqlParameter("e_CT_DESCRIPCION", Types.VARCHAR),
							new SqlParameter("e_CT_CODIGO", Types.VARCHAR),
							new SqlOutParameter("s_afectados", Types.INTEGER),
							new SqlOutParameter("s_codigo_error", Types.NUMERIC),
							new SqlOutParameter("s_mensaje", Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_CT_ID", catalogo.getId());
			source.addValue("e_CT_FECHA_REGISTRO", catalogo.getFechaRegistro());
			source.addValue("e_CT_NOMBRE", catalogo.getNombre());
			source.addValue("e_CT_ESTADO", catalogo.getEstado());
			source.addValue("e_CT_DESCRIPCION", catalogo.getDescripcion());
			source.addValue("e_CT_CODIGO", catalogo.getCodigo());
			Map<String, Object> out = simpleJdbcCall.execute(source);
			dr.setAffectedRows((Integer) out.get("s_afectados"));
			dr.setMessage((String) out.get("s_mensaje"));
			dr.setSqlCode((BigDecimal) out.get("s_codigo_error"));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}

	public PaginatedListCatalogo findAll(PaginationRequest pr, Connection conn)
			throws SQLException, NoSuchMethodException {

		StringBuilder SQL = new StringBuilder();
		ResultSet rs;
		List<CatalogoBean> catalogos = null;
		PaginatedListCatalogo pagedCatalogos;
		SQL.append(" { call pa_otc_gcatalogo(?,?,?,?,?) }");
		try (CallableStatement procStmt = conn.prepareCall(SQL.toString(), ResultSet.TYPE_FORWARD_ONLY,
				ResultSet.CONCUR_READ_ONLY)) {

			procStmt.setInt("e_size", pr.getSize());
			procStmt.setInt("e_page", pr.getPage());
			procStmt.setString("e_sort", pr.getSortBy());
			procStmt.registerOutParameter("s_totalRecord", Types.NUMERIC);
			procStmt.registerOutParameter("s_result", OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rs = (ResultSet) procStmt.getObject("s_result");
			if (rs != null && rs.isBeforeFirst()) {
				catalogos = catalogoBeanMapper.mapResultSetToObject(rs, CatalogoBean.class);
				pagedCatalogos = new PaginatedListCatalogo();
				pagedCatalogos.setRecordsFiltered(pr.getSize());
				pagedCatalogos.setRecordsTotal(procStmt.getBigDecimal("s_totalRecord").longValue());
				pagedCatalogos.setData(catalogos);
				rs.close();
				return pagedCatalogos;
			} else {
				return null;
			}

		} catch (SQLException e) {
			log.error("Error al consultar catálogos: " + e.getMessage(), e);
			throw new SQLException("Error al consultar catálogos: " + e.getMessage(), e);
		} finally {
			if (conn != null)
				conn.close();
		}
	}

	public CatalogoBean findById(Connection conn, Long id) throws Exception {

		List<CatalogoBean> catalogos = null;

		StringBuilder SQL = new StringBuilder();
		ResultSet rset = null;
		SQL.append(" { call PA_OTC_CCATALOGO_ID(?,?) }");
		try (CallableStatement procStmt = conn.prepareCall(SQL.toString(), ResultSet.TYPE_FORWARD_ONLY,
				ResultSet.CONCUR_READ_ONLY)) {

			procStmt.setLong("e_id ", id);
			procStmt.registerOutParameter("S_RESPUESTA", OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject("S_RESPUESTA");
			if (rset != null && rset.isBeforeFirst()) {
				catalogos = catalogoBeanMapper.mapResultSetToObject(rset, CatalogoBean.class);
				return catalogos.get(0);
			}

		} catch (Exception e) {
			log.error("Error en el proceso" + e.getMessage(), e);

		} finally {
			if (rset != null) {
				rset.close();
			}
		}
		return null;
	}

	public Integer countCode(JdbcTemplate jdbcTemplate, String code) {
		Integer count = null;
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_PCONTAR_CODCAT")
					.declareParameters(new SqlParameter("e_codigo", Types.VARCHAR),
							new SqlOutParameter("s_cantidad", Types.INTEGER));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_codigo", code);
			Map<String, Object> out = simpleJdbcCall.execute(source);
			count = (Integer) out.get("s_cantidad");
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return count;
	}

	public DatabaseResponse delete(JdbcTemplate jdbcTemplate, Long catalogoId) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_ECATALOGO")
					.declareParameters(new SqlParameter("e_ct_id", Types.NUMERIC),
							new SqlOutParameter("s_afectados", Types.INTEGER),
							new SqlOutParameter("s_codigo_error", Types.NUMERIC),
							new SqlOutParameter("s_mensaje", Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_ct_id", catalogoId);
			Map<String, Object> out = simpleJdbcCall.execute(source);
			dr.setAffectedRows((Integer) out.get("s_afectados"));
			dr.setMessage((String) out.get("s_mensaje"));
			dr.setSqlCode((BigDecimal) out.get("s_codigo_error"));
		} catch (Exception ex) {
			throw new RuntimeException(ex.getMessage(), ex);
		}
		return dr;
	}

	public List<CatalogoBean> search(Connection conn, CatalogoBusqueda busqueda) throws Exception {
		StringBuilder SQL = new StringBuilder();
		ResultSet rset = null;
		List<CatalogoBean> catalogos = null;
		SQL.append(" { call pa_otc_ccatalogo(?,?,?) }");
		try (CallableStatement procStmt = conn.prepareCall(SQL.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)){			
			procStmt.setString("e_codigo", busqueda.getCodigo());
			procStmt.setString("e_nombre", busqueda.getNombre());
			procStmt.registerOutParameter("s_result", OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject("s_result");
			// log.info(rset.toString());
			if (rset.isBeforeFirst()) {
				catalogos = catalogoBeanMapper.mapResultSetToObject(rset, CatalogoBean.class);
				rset.close();
				return catalogos;
			} else {
				return null;
			}

		} catch (SQLException e) {
			log.error("Error al consultar catalogos: " + e.getMessage(), e);
			throw new SQLException("Error al consultar catalogos: " + e.getMessage(), e);
		} finally {
			if (conn != null)
				conn.close();
		}
	}
}
