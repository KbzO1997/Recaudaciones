
package com.bolivariano.frameworkseguridadtypes;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="LoginAplicacion_out" type="{http://www.bolivariano.com/FrameworkSeguridadTypes}LoginAplicacionType_out2"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "loginAplicacionOut"
})
@XmlRootElement(name = "LoginAplicacion_out")
public class LoginAplicacionOut {

    @XmlElement(name = "LoginAplicacion_out", required = true)
    protected LoginAplicacionTypeOut2 loginAplicacionOut;

    /**
     * Gets the value of the loginAplicacionOut property.
     * 
     * @return
     *     possible object is
     *     {@link LoginAplicacionTypeOut2 }
     *     
     */
    public LoginAplicacionTypeOut2 getLoginAplicacionOut() {
        return loginAplicacionOut;
    }

    /**
     * Sets the value of the loginAplicacionOut property.
     * 
     * @param value
     *     allowed object is
     *     {@link LoginAplicacionTypeOut2 }
     *     
     */
    public void setLoginAplicacionOut(LoginAplicacionTypeOut2 value) {
        this.loginAplicacionOut = value;
    }

}
