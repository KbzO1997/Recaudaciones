package com.bolivariano.otc.web.rest;

import com.bolivariano.otc.bean.DatabaseResponse;
import com.bolivariano.otc.bean.GrupoServicioBean;
import com.bolivariano.otc.bean.GrupoServicioBusqueda;
import com.bolivariano.otc.bean.PaginationRequest;
import com.bolivariano.otc.dao.*;
import com.bolivariano.otc.dto.*;
import com.bolivariano.otc.service.GrupoServicioService;
import com.bolivariano.otc.web.rest.message.MensajeEntradaConsultarGrupoServicio;
import com.bolivariano.otc.web.rest.message.MensajeEntradaConsultarGrupoServicioOBS;
import com.bolivariano.otc.web.rest.message.MensajeSalidaConsultarGrupoServicio;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

@Component
@Repository
@Path("/admin/v1/gruposervicio")
public class GrupoServicioRest {

    private static final Logger log = LoggerFactory.getLogger(GrupoServicioRest.class);

    @Autowired
    GrupoServicioEmpresaDAO grupoServicioEmpresaDAO;

    @Autowired
    ServicioDAO servicioDAO;

    @Autowired
    ConvenioDAO convenioDAO;

    @Autowired
    CanalesServicioDAO canalesServicioDAO;

    @Autowired
    TipoIdentificadorDAO obtenerTipoIdentificadorDAO;

    @Autowired
    TipoIdentificadorDAO tipoIdentificadorDAO;

    @Autowired
    RegionalTipoIdentificadorDAO regionalTipoIdentificadorDAO;

    @Autowired
    ListaSeleccionDAO listaSeleccionDAO;

    @Autowired
    FlujosConvenioDAO flujosConvenioDAO;

    @Autowired
    EnriquecimientoFlujoDAO enriquecimientoFlujoDAO;

    @Autowired
    EnriquecimientoParamDAO enriquecimientoParamDAO;

    @Autowired
    DatosAdicionalesDAO datosAdicionalesDAO;

    @Autowired
    FormaPagoDAO formaPagoDAO;


    @Autowired
    EmpresaDAO empresaDAO;

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Autowired
    GrupoServicioService grpService;

    private static final String ESTADO_ERROR = "ERROR";

    /***
     * Expone un servicio rest a través del método POST para obtener los catálogos almacenados
     * utilizando paginación
     * @param pr Contiene el tamaño, número de página y los criterios de ordenamiento .
     * @return El servicio responde con el estado HTTP 200 y el objeto cátalogo enviado.
     * Si ocurre un error inesperado el servicio responde con el estado HTTP 500
     *
     */
    //@Cacheable(value = "gr-top", key = "#pr.cacheId")
    @POST
    @Path("/obtenerGrupoServicioOBS")
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response obtenerGrupoServicioOBS(MensajeEntradaConsultarGrupoServicioOBS pr) {

            MensajeSalidaConsultarGrupoServicio br = new MensajeSalidaConsultarGrupoServicio();
            Connection conn = null;
            Response respuesta = null;

            try {
                conn = jdbcTemplate.getDataSource().getConnection();
                br.setCodigo("0");

                List<GrupoServicio> grps = null;
                List<Servicio> servicios;
                Empresa empresa;
                Convenio conv;
                List<Flujo> flujos;
                Catalogo operacion;
                PuntoFinal endpoint;
                List<ServicioEnriquecimiento> serviciosEnr;
                List<ServicioEnriquecimientoParam> params;
                List<TipoIdentificador> tipos;
                List<DatoAdicional> datos;
                List<FormaPago> formaPagos;
                List<ListaSeleccion> seleccion;
                List<RegionalArea> regs ;

                Empresa banco = empresaDAO.obtenerBanco(conn);

                if (banco == null) {
                    br.setCodigo("OTC_ADM04");
                    br.setMensaje(null);
                    br.setMensajeUsuario("Error al consultar Banco ");
                    br.setEstado(ESTADO_ERROR);
                    respuesta = Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(br).build();
                }else{
                    grps = grupoServicioEmpresaDAO.obtenerGrupoServicioEmpresaCodigo(conn, pr.getTipoBanca(), pr.getTipoServicio(), banco.getCodigo());
                }

                if (grps != null && !grps.isEmpty()) {
                    for (GrupoServicio grp : grps) {
                        servicios = servicioDAO.obtenerServicios(conn, grp.getId());
                        empresa = empresaDAO.obtenerEmpresa(conn, grp.getIdEmpresa());
                        grp.setEmpresa(empresa);

                        grp.setConvenioVisible((grp.getConvenioVisibleInt() != null && grp.getConvenioVisibleInt().intValue() == 1) ?
                                Boolean.TRUE : Boolean.FALSE);
                        grp.setMatriculable((grp.getMatriculableInt() != null && grp.getMatriculableInt().intValue() == 1) ?
                                Boolean.TRUE : Boolean.FALSE);
                        grp.setMatriculacionMultiple((grp.getMatriculacionMultipleInt() != null && grp.getMatriculacionMultipleInt().intValue() == 1) ?
                                Boolean.TRUE : Boolean.FALSE);
                        grp.setValidable((grp.getValidableInt() != null && grp.getValidableInt().intValue() == 1) ?
                                Boolean.TRUE : Boolean.FALSE);

                        if (servicios != null && !servicios.isEmpty()) {
                            for (Servicio servicio : servicios) {
                                conv = convenioDAO.obtenerConvenio(conn, servicio.getConvenioId());
                                servicio.setServiciosCanales(canalesServicioDAO.obtenerCanalesServicios(conn, servicio.getId()));

                                if (conv != null) {
                                    conv.setVisible((conv.getVisibleInt() != null && conv.getVisibleInt().intValue() == 1) ?
                                            Boolean.TRUE : Boolean.FALSE);

                                    if (banco.getCodigo()!= null && !banco.getCodigo().isEmpty()) {
                                        flujos = flujosConvenioDAO.obtenerFlujosConvenio(conn, conv.getId());

                                        if (flujos != null && !flujos.isEmpty()) {
                                            for (Flujo flujo : flujos) {
                                                operacion = new Catalogo();
                                                operacion.setCodigo(flujo.getCodigoOperacion());

                                                endpoint = new PuntoFinal();
                                                endpoint.setOperacion(flujo.getOperacionPuntoFinal());
                                                endpoint.setPuntoFinal(flujo.getPuntoFinalURL());
                                                endpoint.setId(flujo.getIdPuntoFinal());
                                                endpoint.setNombre(flujo.getNombrePuntoFinal());
                                                endpoint.setRepositorioPeticion(flujo.getRepositorioPeticion());
                                                endpoint.setRepositorioRespuesta(flujo.getRepositorioRespuesta());
                                                endpoint.setTransformacionPeticion(flujo.getTransformacionPeticion());
                                                endpoint.setTransformacionRespuesta(flujo.getTransformacionRespuesta());
                                                endpoint.setAmbiente(flujo.getAmbiente());

                                                flujo.setPuntoFinal(endpoint);
                                                flujo.setOperacion(operacion);

                                                serviciosEnr = enriquecimientoFlujoDAO.obtenerEnriquecimientoConvenio(conn, flujo.getId());
                                                if (serviciosEnr != null && !serviciosEnr.isEmpty()) {
                                                    for (ServicioEnriquecimiento srv : serviciosEnr) {
                                                        params = enriquecimientoParamDAO.obtenerEnriquecimientoParams(conn, srv.getId());
                                                        srv.setParametros(params);

                                                    }
                                                    flujo.setServicioEnriquecimiento(serviciosEnr);
                                                }

                                            }
                                        }

                                        conv.setFlujos(flujos);
                                    }

                                    tipos = obtenerTipoIdentificadorDAO.obtenerTiposIdentificadorConvenio(conn, conv.getId());
                                    if (tipos != null && !tipos.isEmpty()) {
                                        for (TipoIdentificador tipoIdentificador : tipos) {

                                            datos = datosAdicionalesDAO.obtenerAdicionalesTiposIdentificador(conn, tipoIdentificador.getId());
                                            if (datos != null && !datos.isEmpty()) {

                                                for (DatoAdicional datoAdicional : datos) {
                                                    datoAdicional.setEditable((datoAdicional.getEditableInt() != null && datoAdicional.getEditableInt().intValue() == 1) ?
                                                            Boolean.TRUE : Boolean.FALSE);
                                                    datoAdicional.setVisible((datoAdicional.getVisibleInt() != null && datoAdicional.getVisibleInt().intValue() == 1) ?
                                                            Boolean.TRUE : Boolean.FALSE);

                                                    seleccion = listaSeleccionDAO.obtenerSeleccionDatosAds(conn, datoAdicional.getId());
                                                    datoAdicional.setListasSeleccion(seleccion);
                                                }
                                            }
                                            regs = regionalTipoIdentificadorDAO.obtenerRegionalTiposIdentificador(conn, tipoIdentificador.getId());
                                            formaPagos = formaPagoDAO.obtenerFormaPago(conn, tipoIdentificador.getId());

                                            if (formaPagos != null && !formaPagos.isEmpty()) {
                                                Convenio cnvObj = new Convenio();
                                                cnvObj.setId(conv.getId());
                                                cnvObj.setCodigo(conv.getCodigo());
                                                for (FormaPago formaPago : formaPagos) {
                                                    formaPago.setConvenio(cnvObj);
                                                }
                                            }

                                            tipoIdentificador.setDatoAdicionales(datos);
                                            tipoIdentificador.setRegionalAreas(regs);
                                            tipoIdentificador.setFormaPagos(formaPagos);

                                            tipoIdentificador.setMatriculable((tipoIdentificador.getMatriculableInt() != null && tipoIdentificador.getMatriculableInt().intValue() == 1) ?
                                                    Boolean.TRUE : Boolean.FALSE);
                                            tipoIdentificador.setProgramable((tipoIdentificador.getProgramableInt() != null && tipoIdentificador.getProgramableInt().intValue() == 1) ?
                                                    Boolean.TRUE : Boolean.FALSE);

                                        }

                                    }

                                    conv.setTipoIdentificadores(tipos);
                                    servicio.setConvenio(conv);
                                }

                            }
                        }
                        grp.setServicios(servicios);
                    }

                    br.setMensaje(grps);
                    br.setMensajeUsuario("Transaccion Exitosa");
                } else {
                    br.setMensajeUsuario("No hay datos que presentar");
                }

                br.setEstado("OK");
                respuesta = Response.status(Response.Status.OK).entity(br).build();

            } catch (Exception ex) {
                br.setCodigo("OTC_ADM01");
                br.setMensaje(null);
                br.setMensajeUsuario("Error al consultar los catálogos " + ex.getMessage());
                br.setEstado(ESTADO_ERROR);
                respuesta = Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(br).build();

                log.error("Error en el proceso" + ex.getMessage(), ex);

            } finally {
                if (conn != null) {
                    try {
                        conn.close();
                    } catch (SQLException e) {
                        log.error("Error en el proceso" + e.getMessage(), e);
                    }
                }
            }

            return respuesta;

    }
    
    /***
     * Expone un servicio rest a través del método POST para obtener los catálogos almacenados
     * utilizando paginación
     * @param pr Contiene el tamaño, número de página y los criterios de ordenamiento .
     * @return El servicio responde con el estado HTTP 200 y el objeto cátalogo enviado.
     * Si ocurre un error inesperado el servicio responde con el estado HTTP 500
     *
     */
    //@Cacheable(value = "gr-top", key = "#pr.cacheId")
    @POST
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response obtenerGrupoServicio(MensajeEntradaConsultarGrupoServicio pr) {
        MensajeSalidaConsultarGrupoServicio br = new MensajeSalidaConsultarGrupoServicio();
        Connection conn = null;
        Response respuesta = null;

        try {
            conn = jdbcTemplate.getDataSource().getConnection();
            br.setCodigo("0");

            List<GrupoServicio> grps = null;
            List<Servicio> servicios = null;
            Empresa empresa = null;
            Convenio conv = null;
            List<Flujo> flujos = null;
            Catalogo operacion = null;
            PuntoFinal endpoint = null;
            List<ServicioEnriquecimiento> serviciosEnr = null;
            List<ServicioEnriquecimientoParam> params = null;
            List<TipoIdentificador> tipos = null;
            List<DatoAdicional> datos = null;
            List<FormaPago> formaPagos = null;
            List<ListaSeleccion> seleccion = null;
            List<RegionalArea> regs = null;

            if (pr.getCodigoEmpresa() != null && !pr.getCodigoEmpresa().isEmpty()) {
                grps = grupoServicioEmpresaDAO.obtenerGrupoServicioEmpresaCodigo(conn, pr.getTipoBanca(), pr.getTipoServicio(), pr.getCodigoEmpresa());
            } else if (pr.getNombreEmpresa() != null && !pr.getNombreEmpresa().isEmpty()) {
                grps = grupoServicioEmpresaDAO.obtenerGruposServicio(conn, pr.getTipoBanca(), pr.getTipoServicio(), pr.getNombreEmpresa() + "%");
            } else {
                grps = grupoServicioEmpresaDAO.obtenerGruposServicio(conn, pr.getTipoBanca(), pr.getTipoServicio());
            }

            if (grps != null && !grps.isEmpty()) {
                for (GrupoServicio grp : grps) {
                    servicios = servicioDAO.obtenerServicios(conn, grp.getId());
                    empresa = empresaDAO.obtenerEmpresa(conn, grp.getIdEmpresa());
                    grp.setEmpresa(empresa);

                    grp.setConvenioVisible((grp.getConvenioVisibleInt() != null && grp.getConvenioVisibleInt().intValue() == 1) ?
                            Boolean.TRUE : Boolean.FALSE);
                    grp.setMatriculable((grp.getMatriculableInt() != null && grp.getMatriculableInt().intValue() == 1) ?
                            Boolean.TRUE : Boolean.FALSE);
                    grp.setMatriculacionMultiple((grp.getMatriculacionMultipleInt() != null && grp.getMatriculacionMultipleInt().intValue() == 1) ?
                            Boolean.TRUE : Boolean.FALSE);
                    grp.setValidable((grp.getValidableInt() != null && grp.getValidableInt().intValue() == 1) ?
                            Boolean.TRUE : Boolean.FALSE);

                    if (servicios != null && !servicios.isEmpty()) {
                        for (Servicio servicio : servicios) {
                            conv = convenioDAO.obtenerConvenio(conn, servicio.getConvenioId());
                            servicio.setServiciosCanales(canalesServicioDAO.obtenerCanalesServicios(conn, servicio.getId()));

                            if (conv != null) {
                                conv.setVisible((conv.getVisibleInt() != null && conv.getVisibleInt().intValue() == 1) ?
                                        Boolean.TRUE : Boolean.FALSE);

                                if (pr.getCodigoEmpresa() != null && !pr.getCodigoEmpresa().isEmpty()) {
                                    flujos = flujosConvenioDAO.obtenerFlujosConvenio(conn, conv.getId());

                                    if (flujos != null && !flujos.isEmpty()) {
                                        for (Flujo flujo : flujos) {
                                            operacion = new Catalogo();
                                            operacion.setCodigo(flujo.getCodigoOperacion());

                                            endpoint = new PuntoFinal();
                                            endpoint.setOperacion(flujo.getOperacionPuntoFinal());
                                            endpoint.setPuntoFinal(flujo.getPuntoFinalURL());
                                            endpoint.setId(flujo.getIdPuntoFinal());
                                            endpoint.setNombre(flujo.getNombrePuntoFinal());
                                            endpoint.setRepositorioPeticion(flujo.getRepositorioPeticion());
                                            endpoint.setRepositorioRespuesta(flujo.getRepositorioRespuesta());
                                            endpoint.setTransformacionPeticion(flujo.getTransformacionPeticion());
                                            endpoint.setTransformacionRespuesta(flujo.getTransformacionRespuesta());
                                            endpoint.setAmbiente(flujo.getAmbiente());

                                            flujo.setPuntoFinal(endpoint);
                                            flujo.setOperacion(operacion);

                                            serviciosEnr = enriquecimientoFlujoDAO.obtenerEnriquecimientoConvenio(conn, flujo.getId());
                                            if (serviciosEnr != null && !serviciosEnr.isEmpty()) {
                                                for (ServicioEnriquecimiento srv : serviciosEnr) {
                                                    params = enriquecimientoParamDAO.obtenerEnriquecimientoParams(conn, srv.getId());
                                                    srv.setParametros(params);

                                                }
                                                flujo.setServicioEnriquecimiento(serviciosEnr);
                                            }

                                        }
                                    }

                                    conv.setFlujos(flujos);
                                }

                                tipos = obtenerTipoIdentificadorDAO.obtenerTiposIdentificadorConvenio(conn, conv.getId());
                                if (tipos != null && !tipos.isEmpty()) {
                                    for (TipoIdentificador tipoIdentificador : tipos) {

                                        datos = datosAdicionalesDAO.obtenerAdicionalesTiposIdentificador(conn, tipoIdentificador.getId());
                                        if (datos != null && !datos.isEmpty()) {

                                            for (DatoAdicional datoAdicional : datos) {
                                                datoAdicional.setEditable((datoAdicional.getEditableInt() != null && datoAdicional.getEditableInt().intValue() == 1) ?
                                                        Boolean.TRUE : Boolean.FALSE);
                                                datoAdicional.setVisible((datoAdicional.getVisibleInt() != null && datoAdicional.getVisibleInt().intValue() == 1) ?
                                                        Boolean.TRUE : Boolean.FALSE);

                                                seleccion = listaSeleccionDAO.obtenerSeleccionDatosAds(conn, datoAdicional.getId());
                                                datoAdicional.setListasSeleccion(seleccion);
                                            }
                                        }
                                        regs = regionalTipoIdentificadorDAO.obtenerRegionalTiposIdentificador(conn, tipoIdentificador.getId());
                                        formaPagos = formaPagoDAO.obtenerFormaPago(conn, tipoIdentificador.getId());

                                        if (formaPagos != null && !formaPagos.isEmpty()) {
                                            Convenio cnvObj = new Convenio();
                                            cnvObj.setId(conv.getId());
                                            cnvObj.setCodigo(conv.getCodigo());
                                            for (FormaPago formaPago : formaPagos) {
                                                formaPago.setConvenio(cnvObj);
                                            }
                                        }

                                        tipoIdentificador.setDatoAdicionales(datos);
                                        tipoIdentificador.setRegionalAreas(regs);
                                        tipoIdentificador.setFormaPagos(formaPagos);

                                        tipoIdentificador.setMatriculable((tipoIdentificador.getMatriculableInt() != null && tipoIdentificador.getMatriculableInt().intValue() == 1) ?
                                                Boolean.TRUE : Boolean.FALSE);
                                        tipoIdentificador.setProgramable((tipoIdentificador.getProgramableInt() != null && tipoIdentificador.getProgramableInt().intValue() == 1) ?
                                                Boolean.TRUE : Boolean.FALSE);

                                    }

                                }

                                conv.setTipoIdentificadores(tipos);
                                servicio.setConvenio(conv);
                            }

                        }
                    }
                    grp.setServicios(servicios);
                }

                br.setMensaje(grps);
                br.setMensajeUsuario("Transaccion Exitosa");
            } else {
                br.setMensajeUsuario("No hay datos que presentar");
            }

            br.setEstado("OK");
            respuesta = Response.status(Response.Status.OK).entity(br).build();

        } catch (Exception ex) {
            br.setCodigo("OTC_ADM01");
            br.setMensaje(null);
            br.setMensajeUsuario("Error al consultar los catálogos " + ex.getMessage());
            br.setEstado(ESTADO_ERROR);
            respuesta = Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(br).build();

            log.error("Error en el proceso funcional" + ex.getMessage(), ex);

        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    log.error("Error en el proceso tecnico (cierre de conexion)" + e.getMessage(), e);
                }
            }
        }

        return respuesta;
    }

    @POST
    @Path("/save")
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response insert(GrupoServicioBean grupoServicio) {
        DatabaseResponse dr = new DatabaseResponse();
        try {
            log.info("insertarGrupoServicio: Peticion recibida");
            dr = grpService.insert(grupoServicio);
            if (dr.getSqlCode().intValue() == 0 && dr.getAffectedRows().intValue() > 0 && dr.getSequence().intValue() > 0) {
                return Response.status(Status.OK).entity(dr).build();
            } else {
                return Response.status(Status.ACCEPTED).entity(dr).build();
            }
        } catch (Exception ex) {
            dr.setMessage(ex.getMessage());
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(dr).build();
        }

    }

    @POST
    @Path("/update")
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response update(GrupoServicioBean grupoServicio) {
        DatabaseResponse dr = new DatabaseResponse();
        try {
            log.info("actualizarGrupoServicio: Peticion recibida");
            dr = grpService.update(grupoServicio);
            log.info(dr.toString());
            if (dr.getSqlCode().intValue() == 0 && dr.getAffectedRows().intValue() > 0) {
                return Response.status(Status.OK).entity(dr).build();
            } else {
                return Response.status(Status.ACCEPTED).entity(dr).build();
            }
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            dr.setMessage(ex.getMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(dr).build();
        }
    }


    @POST
    @Path("/all")
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response findAll(PaginationRequest pr) {
        log.info("getGrupoServicio: Petición Recibida");
        try {
            return Response.status(Status.OK).entity(this.grpService.findAll(pr)).build();
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response findById(@PathParam("id") Long id) {
        log.info("findById: Petición Recibida");
        try {
            GrupoServicioBean grupoServicioBean = this.grpService.findById(id);
            if (grupoServicioBean == null) {
                return Response.status(Status.NO_CONTENT).entity(null).build();
            }
            return Response.status(Status.OK).entity(grupoServicioBean).build();
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }

    @POST
    @Path("/delete")
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response delete(@QueryParam("id") Long id) {
        log.info("delete: Peticion recibida");
        DatabaseResponse dr = grpService.delete(id);
        return Response.status(Status.OK).entity(dr).build();
    }

    @POST
    @Path("/search")
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response search(GrupoServicioBusqueda busqueda) {
        List<GrupoServicioBean> grupoServicios = null;
        try {
            log.info("search: Peticion recibida" + busqueda);
            grupoServicios = grpService.search(busqueda);
            if (grupoServicios == null) {
                return Response.status(Status.NO_CONTENT).entity(null).build();
            } else {
                return Response.status(Status.OK).entity(grupoServicios).build();
            }
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }

    @POST
    @Path("/delete-many")
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response deleteMany(Long... ids) {
        List<DatabaseResponse> responses = grpService.deleteMany(ids);
        DatabaseResponse dr = new DatabaseResponse();

        String errorMsg = "El grupo de servicio %id no fue eliminado: %msg \b";
        StringBuilder errorMsgs = new StringBuilder();
        boolean error = false;

        for (DatabaseResponse drAux : responses) {
            if (drAux.getSqlCode().longValue() != 0L) {
                error = true;
                errorMsgs.append(errorMsg.replace("%id", drAux.getSequence().toString()).replace("%msg", drAux.getMessage()));
            }
        }
        dr.setSqlCode(!error ? new BigDecimal(0) : new BigDecimal(100));
        dr.setMessage(!error ? "Transacción Exitosa" : errorMsgs.toString());

        return Response.status(Status.OK).entity(dr).build();
    }

}
