package com.bolivariano.otc.dto;

import java.io.Serializable;


public class ServicioCanal implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long id;

	private Servicio servicio;

	private Canal canal;

	public ServicioCanal(Servicio servicio, Canal canal) {
		super();
		this.servicio = servicio;
		this.canal = canal;
	}

	

	public ServicioCanal() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Servicio getServicio() {
		return servicio;
	}

	public void setServicio(Servicio servicio) {
		this.servicio = servicio;
	}

	public Canal getCanal() {
		return canal;
	}

	public void setCanal(Canal canal) {
		this.canal = canal;
	}



	@Override
	public String toString() {
		return "ServicioCanal{" +
				"id=" + id +
				", servicio=" + servicio +
				", canal=" + canal +
				'}';
	}
}