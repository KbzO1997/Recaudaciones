
package com.bolivariano.mensajesframework;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.bolivariano.mensajebolivariano.MensajeEntrada;


/**
 * <p>Java class for MensajeEntradaObtenerLlaveEspecifica complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MensajeEntradaObtenerLlaveEspecifica">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.bolivariano.com/MensajeBolivariano}MensajeEntrada">
 *       &lt;sequence>
 *         &lt;element name="servicio" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="codigoLlave" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="tipo">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="PUBLICA"/>
 *               &lt;enumeration value="PRIVADA"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MensajeEntradaObtenerLlaveEspecifica", propOrder = {
    "servicio",
    "codigoLlave",
    "tipo"
})
public class MensajeEntradaObtenerLlaveEspecifica
    extends MensajeEntrada
{

    @XmlElement(required = true)
    protected String servicio;
    @XmlElement(required = true)
    protected String codigoLlave;
    @XmlElement(required = true)
    protected String tipo;

    /**
     * Gets the value of the servicio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServicio() {
        return servicio;
    }

    /**
     * Sets the value of the servicio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServicio(String value) {
        this.servicio = value;
    }

    /**
     * Gets the value of the codigoLlave property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigoLlave() {
        return codigoLlave;
    }

    /**
     * Sets the value of the codigoLlave property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigoLlave(String value) {
        this.codigoLlave = value;
    }

    /**
     * Gets the value of the tipo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipo() {
        return tipo;
    }

    /**
     * Sets the value of the tipo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipo(String value) {
        this.tipo = value;
    }

}
