package com.bolivariano.otc.dao;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.bolivariano.otc.MapperUtil;
import com.bolivariano.otc.bean.DatabaseResponse;
import com.bolivariano.otc.bean.EmpresaBean;
import com.bolivariano.otc.bean.EmpresaBusqueda;
import com.bolivariano.otc.bean.PaginatedListEmpresa;
import com.bolivariano.otc.bean.PaginationRequest;
import com.bolivariano.otc.bean.SelectItemBean;
import com.bolivariano.otc.dto.Empresa;

import oracle.jdbc.OracleTypes;

@Repository
public class EmpresaDAO {

	private static final Logger log = LoggerFactory.getLogger(EmpresaDAO.class);

	@Autowired
	MapperUtil<Empresa> empresaMapper;

	@Autowired
	MapperUtil<EmpresaBean> empresaBeanMapper;

	@Autowired
	MapperUtil<SelectItemBean> selectMapper;

	private static final  String S_RESPUESTA = "S_RESPUESTA";

	public Empresa obtenerBanco(Connection conn) throws SQLException {
		List<Empresa> empresas = null;
		StringBuilder proceduteStr = new StringBuilder();
		ResultSet rset = null;
		proceduteStr.append(" { call PQ_OTC_EMPRESA.PA_OTC_CEMPRESABANCO(?) }");
		try (CallableStatement procStmt = conn.prepareCall(proceduteStr.toString(), ResultSet.TYPE_FORWARD_ONLY,
				ResultSet.CONCUR_READ_ONLY);){
			
			
			procStmt.registerOutParameter(S_RESPUESTA, OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject(S_RESPUESTA);

			if (rset.isBeforeFirst()) {
				empresas = empresaMapper.mapResultSetToObject(rset, Empresa.class);

			}
		} catch (Exception e) {
			log.error("Error en el proceso" + e.getMessage(), e);
		} finally {
			if (rset != null) {
				rset.close();
			}
		}

		return (empresas != null && !empresas.isEmpty()) ? empresas.get(0) : null;
	}

	public Empresa obtenerEmpresa(Connection conn, Long idEmpresa) throws Exception {
		List<Empresa> empresas = null;
		StringBuilder SQL = new StringBuilder();
		ResultSet rset = null;
		SQL.append(" { call PA_OTC_CEMPRESA(?,?) }");
		try (CallableStatement procStmt = conn.prepareCall(SQL.toString(), ResultSet.TYPE_FORWARD_ONLY,
				ResultSet.CONCUR_READ_ONLY)) {

			procStmt.setLong(1, idEmpresa);
			procStmt.registerOutParameter(2, OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject(2);

			if (rset.isBeforeFirst()) {
				empresas = empresaMapper.mapResultSetToObject(rset, Empresa.class);

			}

		} catch (Exception e) {
			log.error("Error en el proceso" + e.getMessage(), e);
		} finally {
			if (rset != null) {
				rset.close();
			}
		}

		return (empresas != null && !empresas.isEmpty()) ? empresas.get(0) : null;
	}

	public Integer countCode(JdbcTemplate jdbcTemplate, String code) {
		Integer count = null;
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_PCONTAR_CODEMP")
					.declareParameters(new SqlParameter("e_codigo", Types.VARCHAR),
							new SqlOutParameter("s_cantidad", Types.INTEGER));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_codigo", code);
			Map<String, Object> out = simpleJdbcCall.execute(source);
			count = (Integer) out.get("s_cantidad");
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return count;
	}

	public DatabaseResponse insert(JdbcTemplate jdbcTemplate, EmpresaBean empresa) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("pa_otc_iempresa")
					.declareParameters(new SqlParameter("e_identificacion", Types.VARCHAR),
							new SqlParameter("e_nombre", Types.VARCHAR), new SqlParameter("e_codigo", Types.VARCHAR),
							new SqlParameter("e_descripcion", Types.VARCHAR),
							new SqlOutParameter("s_secuencia", Types.NUMERIC),
							new SqlOutParameter("s_afectados", Types.INTEGER),
							new SqlOutParameter("s_codigo_error", Types.NUMERIC),
							new SqlOutParameter("s_mensaje", Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_identificacion", empresa.getIdentificacion());
			source.addValue("e_nombre", empresa.getNombre());
			source.addValue("e_codigo", empresa.getCodigo());
			source.addValue("e_descripcion", empresa.getDescripcion());
			Map<String, Object> out = simpleJdbcCall.execute(source);

			dr.setAffectedRows((Integer) out.get("s_afectados"));
			dr.setMessage((String) out.get("s_mensaje"));
			dr.setSequence((BigDecimal) out.get("s_secuencia"));
			dr.setSqlCode((BigDecimal) out.get("s_codigo_error"));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}

	public DatabaseResponse update(JdbcTemplate jdbcTemplate, EmpresaBean empresa) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("pa_otc_aempresa")
					.declareParameters(new SqlParameter("e_emp_id", Types.NUMERIC),
							new SqlParameter("e_emp_identificacion", Types.VARCHAR),
							new SqlParameter("e_emp_nombre", Types.VARCHAR),
							new SqlParameter("e_EMP_CODIGO", Types.VARCHAR),
							new SqlParameter("e_EMP_DESCRIPCION", Types.VARCHAR),
							new SqlOutParameter("s_afectados", Types.INTEGER),
							new SqlOutParameter("s_codigo_error", Types.NUMERIC),
							new SqlOutParameter("s_mensaje", Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_EMP_ID", empresa.getId());
			source.addValue("e_EMP_IDENTIFICACION", empresa.getIdentificacion());
			source.addValue("e_EMP_NOMBRE", empresa.getNombre());
			source.addValue("e_EMP_CODIGO", empresa.getCodigo());
			source.addValue("e_EMP_DESCRIPCION", empresa.getDescripcion());
			Map<String, Object> out = simpleJdbcCall.execute(source);
			dr.setAffectedRows((Integer) out.get("s_afectados"));
			dr.setMessage((String) out.get("s_mensaje"));
			dr.setSqlCode((BigDecimal) out.get("s_codigo_error"));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}

	public PaginatedListEmpresa findAll(PaginationRequest pr, Connection conn)
			throws SQLException, NoSuchMethodException {

		StringBuilder SQL = new StringBuilder();
		ResultSet rs;
		List<EmpresaBean> empresas = null;
		PaginatedListEmpresa pagedEmpresas;
		SQL.append(" { call PA_OTC_GEMPRESA(?,?,?,?,?) }");
		try (CallableStatement procStmt = conn.prepareCall(SQL.toString(), ResultSet.TYPE_FORWARD_ONLY,
				ResultSet.CONCUR_READ_ONLY)) {

			procStmt.setInt("e_size", pr.getSize());
			procStmt.setInt("e_page", pr.getPage());
			procStmt.setString("e_sort", pr.getSortBy());
			procStmt.registerOutParameter("s_totalRecord", Types.NUMERIC);
			procStmt.registerOutParameter("s_result", OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rs = (ResultSet) procStmt.getObject("s_result");
			if (rs != null && rs.isBeforeFirst()) {
				empresas = empresaBeanMapper.mapResultSetToObject(rs, EmpresaBean.class);
				pagedEmpresas = new PaginatedListEmpresa();
				pagedEmpresas.setRecordsFiltered(pr.getSize());
				pagedEmpresas.setRecordsTotal(procStmt.getBigDecimal("s_totalRecord").longValue());
				pagedEmpresas.setData(empresas);
				rs.close();
				return pagedEmpresas;
			} else {
				return null;
			}

		} catch (SQLException e) {
			log.error("Error al consultar empresas: " + e.getMessage(), e);
			throw new SQLException("Error al consultar empresas: " + e.getMessage(), e);
		} finally {
			if (conn != null)
				conn.close();
		}
	}

	public EmpresaBean findById(Connection conn, Long id) throws Exception {

		List<EmpresaBean> empresas = null;
		StringBuilder SQL = new StringBuilder();
		ResultSet rset = null;
		SQL.append(" { call PA_OTC_CEMPRESA_ID(?,?) }");
		try (CallableStatement procStmt = conn.prepareCall(SQL.toString(), ResultSet.TYPE_FORWARD_ONLY,
				ResultSet.CONCUR_READ_ONLY)) {
			procStmt.setLong("e_id ", id);
			procStmt.registerOutParameter(S_RESPUESTA, OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject(S_RESPUESTA);
			if (rset.isBeforeFirst()) {
				empresas = empresaBeanMapper.mapResultSetToObject(rset, EmpresaBean.class);
				return empresas.get(0);
			}

		} catch (Exception e) {
			log.error("Error en el proceso" + e.getMessage(), e);

		} finally {
			if (rset != null) {
				rset.close();
			}
		}
		return null;
	}

	public List<SelectItemBean> findSelectEmpresas(Connection conn) throws Exception {

		List<SelectItemBean> empresas = null;
		StringBuilder SQL = new StringBuilder();
		ResultSet rset = null;
		SQL.append(" { call PA_OTC_CEMPRESA_SELECT(?) }");
		try (CallableStatement procStmt = conn.prepareCall(SQL.toString(), ResultSet.TYPE_FORWARD_ONLY,
				ResultSet.CONCUR_READ_ONLY)) {

			procStmt.registerOutParameter(S_RESPUESTA, OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject(S_RESPUESTA);
			if (rset.isBeforeFirst()) {
				empresas = selectMapper.mapResultSetToObject(rset, SelectItemBean.class);
			}
			return empresas;
		} catch (Exception e) {
			log.error("Error en el proceso" + e.getMessage(), e);

		} finally {
			if (rset != null) {
				rset.close();
			}
		}
		return null;
	}

	public DatabaseResponse delete(JdbcTemplate jdbcTemplate, Long empresaId) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_EEMPRESA")
					.declareParameters(new SqlParameter("e_emp_id", Types.NUMERIC),
							new SqlOutParameter("s_afectados", Types.INTEGER),
							new SqlOutParameter("s_codigo_error", Types.NUMERIC),
							new SqlOutParameter("s_mensaje", Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_emp_id", empresaId);
			Map<String, Object> out = simpleJdbcCall.execute(source);
			dr.setAffectedRows((Integer) out.get("s_afectados"));
			dr.setMessage((String) out.get("s_mensaje"));
			dr.setSqlCode((BigDecimal) out.get("s_codigo_error"));
		} catch (Exception ex) {
			throw new RuntimeException(ex.getMessage(), ex);
		}
		return dr;
	}

	public List<EmpresaBean> search(Connection conn, EmpresaBusqueda busqueda) throws Exception {

		StringBuilder SQL = new StringBuilder();
		ResultSet rset = null;
		List<EmpresaBean> canales = null;
		SQL.append(" { call pa_otc_cempresa_search(?,?,?,?) }");
		try (CallableStatement procStmt = conn.prepareCall(SQL.toString(), ResultSet.TYPE_FORWARD_ONLY,
				ResultSet.CONCUR_READ_ONLY)) {

			procStmt.setString("e_codigo", busqueda.getCodigo());
			procStmt.setString("e_nombre", busqueda.getNombre());
			procStmt.setString("e_identificacion", busqueda.getIdentificacion());
			procStmt.registerOutParameter("s_result", OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject("s_result");
			if (rset.isBeforeFirst()) {
				canales = empresaBeanMapper.mapResultSetToObject(rset, EmpresaBean.class);
				rset.close();
				return canales;
			} else {
				return null;
			}

		} catch (SQLException e) {
			log.error("Error al consultar empresas: " + e.getMessage(), e);
			throw new SQLException("Error al consultar empresas: " + e.getMessage(), e);
		} finally {
			if (conn != null)
				conn.close();
		}
	}
}
