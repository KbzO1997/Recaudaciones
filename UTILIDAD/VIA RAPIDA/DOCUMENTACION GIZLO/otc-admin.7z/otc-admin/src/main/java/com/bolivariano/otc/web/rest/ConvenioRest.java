package com.bolivariano.otc.web.rest;

import com.bolivariano.otc.bean.*;
import com.bolivariano.otc.service.ConvenioService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import java.math.BigDecimal;
import java.util.List;

@Component
@Path("/admin/v1/convenio")
public class ConvenioRest {

    private static final Logger log = LoggerFactory.getLogger(ConvenioRest.class);
    private static final String ENTITY_NAME = "convenio";

    @Autowired
    ConvenioService convenioService;

    @GET
    @Path("/select-convenios")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response findSelects() {
        log.info("getEmpresas: Petición Recibida");
        try {
            List<SelectItemBean> convenios = this.convenioService.findSelects();
            if (convenios == null) {
                return Response.status(Status.NO_CONTENT).entity(null).build();
            }
            return Response.status(Status.OK).entity(convenios).build();
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response getConvenios(PaginationRequest pr) {
        log.info("getConvenios: Petición Recibida");
        try {
            return Response.status(Status.OK).entity(this.convenioService.findAll(pr)).build();
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }

    @POST
    @Path("/save")
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response insert(ConvenioBean convenio) {
        DatabaseResponse dr = new DatabaseResponse();
        try {
            log.info("insert: Peticion recibida");
            dr = convenioService.insert(convenio);
            if (dr.getSqlCode().intValue() == 0 && dr.getAffectedRows().intValue() > 0
                    && dr.getSequence().intValue() > 0) {
                return Response.status(Status.OK).entity(dr).build();
            } else {
                return Response.status(Status.ACCEPTED).entity(dr).build();
            }
        } catch (Exception ex) {
            dr.setMessage(ex.getMessage());

            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(dr).build();
        }

    }

    @POST
    @Path("/update")
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response update(ConvenioBean canal) {
        DatabaseResponse dr = new DatabaseResponse();
        try {
            log.info("update: Peticion recibida");
            dr = convenioService.update(canal);
            // log.info(dr.toString());
            if (dr.getSqlCode().intValue() == 0 && dr.getAffectedRows().intValue() > 0) {
                return Response.status(Status.OK).entity(dr).build();
            } else {
                return Response.status(Status.ACCEPTED).entity(dr).build();
            }
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            dr.setMessage(ex.getMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(dr).build();
        }
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response findById(@PathParam("id") Long id) {
        log.info("findById: Petición Recibida");
        try {
            ConvenioBean canal = this.convenioService.findById(id);
            if (canal == null) {
                return Response.status(Status.NO_CONTENT).entity(null).build();
            }

            return Response.status(Status.OK).entity(canal).build();
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }

    @GET
    @Path("/count-code")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response countCode(@QueryParam("code") String code) {
        log.info("countCode: Petición Recibida");
        try {
            Integer count = this.convenioService.countCode(code);
            if (count == null) {
                return Response.status(Status.NO_CONTENT).entity(null).build();
            }
            return Response.status(Status.OK).entity(count).build();
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }

    @POST
    @Path("/delete")
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response delete(@QueryParam("id") Long id) {
        DatabaseResponse dr = new DatabaseResponse();
        log.info("delete: Peticion recibida");
        dr = convenioService.delete(id);
        return Response.status(Status.OK).entity(dr).build();

    }

    @POST
    @Path("/search")
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response search(ConvenioBusqueda busqueda) {
        List<ConvenioBean> convenios = null;
        try {
            log.info("search: Peticion recibida" + busqueda);
            convenios = convenioService.search(busqueda);
            if (convenios == null) {
                return Response.status(Status.NO_CONTENT).entity(null).build();
            } else {
                return Response.status(Status.OK).entity(convenios).build();
            }
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }

    @POST
    @Path("/delete-many")
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response deleteMany(Long... ids) {
        List<DatabaseResponse> responses = convenioService.deleteMany(ids);
        DatabaseResponse dr = new DatabaseResponse();

        String errorMsg = "El convenio %id no fue eliminado: %msg \b";
        StringBuilder errorMsgs = new StringBuilder();
        boolean error = false;

        for (DatabaseResponse drAux : responses) {
            if (drAux.getSqlCode().longValue() != 0L) {
                error = true;
                errorMsgs.append(errorMsg.replace("%id", drAux.getSequence().toString()).replace("%msg", drAux.getMessage()));
            }
        }
        dr.setSqlCode(!error ? new BigDecimal(0) : new BigDecimal(100));
        dr.setMessage(!error ? "Transacción Exitosa" : errorMsgs.toString());

        return Response.status(Status.OK).entity(dr).build();

    }


}
