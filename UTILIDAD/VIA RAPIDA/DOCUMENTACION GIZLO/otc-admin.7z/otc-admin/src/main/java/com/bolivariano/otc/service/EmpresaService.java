package com.bolivariano.otc.service;

import com.bolivariano.otc.bean.*;
import com.bolivariano.otc.dao.EmpresaDAO;
import com.bolivariano.otc.dto.Empresa;
import com.bolivariano.otc.exception.OTCAdminException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Service
public class EmpresaService {

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	EmpresaDAO empresaDAO;

	private static final Logger log = LoggerFactory.getLogger(EmpresaService.class);

	@Transactional(propagation = Propagation.REQUIRED)
	public Empresa obtenerBanco() throws OTCAdminException {

		Empresa empresa = null;
		try {
			empresa = empresaDAO.obtenerBanco(jdbcTemplate.getDataSource().getConnection());
			return empresa;

		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
			throw new OTCAdminException(ex.getMessage());
		}
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public DatabaseResponse insert(EmpresaBean empresa) throws OTCAdminException {
		DatabaseResponse dr = null;
		try {
			dr = empresaDAO.insert(jdbcTemplate, empresa);
			return dr;
		} catch (Exception ex) {
			throw new OTCAdminException(ex.getMessage());
		}
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public DatabaseResponse update(EmpresaBean empresa) throws OTCAdminException {
		DatabaseResponse dr = null;
		try {
			dr = empresaDAO.update(jdbcTemplate, empresa);
			return dr;
		} catch (Exception ex) {
			throw new OTCAdminException(ex.getMessage());
		}
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public DatabaseResponse delete(Long endpointId) {
		DatabaseResponse dr = empresaDAO.delete(jdbcTemplate, endpointId);
		if (dr.getSqlCode().longValue() == 0L) {
			log.info(dr.getMessage());

		} else {
			log.error("Error en la transacción: " + dr.getMessage());
		}
		return dr;

	}

	@Transactional(propagation = Propagation.REQUIRED)
	public List<DatabaseResponse> deleteMany(Long... ids) {

		List<DatabaseResponse> responses = new ArrayList<DatabaseResponse>();
		DatabaseResponse dr = null;
		for (Long id : ids) {
			dr = empresaDAO.delete(jdbcTemplate, id);
			dr.setSequence(new BigDecimal(id));
			responses.add(dr);

			if (dr.getSqlCode().longValue() == 0L) {
				log.info(dr.getMessage());

			} else {
				log.error("Error en la transacción: " + dr.getMessage());
			}
		}
		return responses;
	}

	public PaginatedListEmpresa findAll(PaginationRequest pr) throws OTCAdminException {

		PaginatedListEmpresa pagedEmpresas = null;
		if (pr.getSortBy() == null || pr.getSortBy().isEmpty())
			pr.setSortBy("id");
		try {
			pagedEmpresas = empresaDAO.findAll(pr, jdbcTemplate.getDataSource().getConnection());
			return pagedEmpresas;

		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
			throw new OTCAdminException(ex.getMessage());
		}
	}

	public EmpresaBean findById(Long id) throws OTCAdminException {
		EmpresaBean empresa = null;
		try {
			empresa = empresaDAO.findById(jdbcTemplate.getDataSource().getConnection(), id);
			return empresa;

		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
			throw new OTCAdminException(ex.getMessage());
		}
	}

	public List<SelectItemBean> findSelects() throws OTCAdminException {
		List<SelectItemBean> empresas = null;
		try {
			empresas = empresaDAO.findSelectEmpresas(jdbcTemplate.getDataSource().getConnection());
			return empresas;
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
			throw new OTCAdminException(ex.getMessage());
		}
	}

	public List<SelectItemBean> findSelects(String esBanco) throws OTCAdminException {
		List<SelectItemBean> empresas = null;
		try {
			empresas = empresaDAO.findSelectEmpresas(jdbcTemplate.getDataSource().getConnection(), esBanco);
			return empresas;
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
			throw new OTCAdminException(ex.getMessage());
		}
	}

	public Integer countCode(String code) throws OTCAdminException {
		Integer count = null;
		// List<ServicioCanalBean> servicioCanales = null;
		try {
			count = empresaDAO.countCode(jdbcTemplate, code);
			return count;

		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
			throw new OTCAdminException(ex.getMessage());
		}
	}

	public List<EmpresaBean> search(EmpresaBusqueda busqueda) throws OTCAdminException {
		List<EmpresaBean> empresas = null;
		try {
			empresas = empresaDAO.search(jdbcTemplate.getDataSource().getConnection(), busqueda);
			return empresas;

		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
			throw new OTCAdminException(ex.getMessage());
		}
	}

}
