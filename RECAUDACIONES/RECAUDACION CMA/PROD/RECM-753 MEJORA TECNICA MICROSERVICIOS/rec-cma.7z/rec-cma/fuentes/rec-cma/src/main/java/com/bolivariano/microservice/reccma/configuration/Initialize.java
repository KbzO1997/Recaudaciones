package com.bolivariano.microservice.reccma.configuration;

import com.bolivariano.microservice.reccma.service.ProcessorService;
import io.quarkus.runtime.ShutdownEvent;

import javax.enterprise.event.Observes;
import javax.inject.Inject;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class Initialize implements Runnable{

    @Inject
    ProcessorService processorService;

    private ExecutorService scheduler;

    void onStart() {
        scheduler = Executors.newFixedThreadPool(1);
        scheduler.submit(this);
    }

    void onStop(@Observes ShutdownEvent event) {
        scheduler.shutdown();
    }

    @Override
    public void run() {
        try {
            String messageMQ = "{\"tipoFlujo\":\"CONSULTA\",\"mensajeEntradaConsultarDeuda\":{\"canal\":\"VEN\",\"depuracion\":\"\",\"fecha\":\"2023-01-12T15:34:52\",\"oficina\":\"0\",\"secuencial\":\"132993498\",\"servicio\":{\"codTipoServicio\":\"PAGO_ADUANA\",\"codigoConvenio\":\"1929\",\"codigoEmpresa\":\"20717\",\"codigoTipoBanca\":\"BP\",\"codigoTipoIdentificador\":\"1\",\"datosAdicionales\":{\"datoAdicional\":[{\"codigo\":\"e_srv\",\"etiqueta\":null,\"editable\":null,\"formato\":null,\"listasSeleccion\":null,\"longitud\":null,\"mascara\":null,\"regexp\":null,\"tipo\":null,\"valor\":\"SRVDESA2\",\"visible\":null},{\"codigo\":\"e_term\",\"etiqueta\":null,\"editable\":null,\"formato\":null,\"listasSeleccion\":null,\"longitud\":null,\"mascara\":null,\"regexp\":null,\"tipo\":null,\"valor\":\"VIRTUAL_BB\",\"visible\":null},{\"codigo\":\"e_rol\",\"etiqueta\":null,\"editable\":null,\"formato\":null,\"listasSeleccion\":null,\"longitud\":null,\"mascara\":null,\"regexp\":null,\"tipo\":null,\"valor\":\"252\",\"visible\":null},{\"codigo\":\"e_corr\",\"etiqueta\":null,\"editable\":null,\"formato\":null,\"listasSeleccion\":null,\"longitud\":null,\"mascara\":null,\"regexp\":null,\"tipo\":null,\"valor\":\"N\",\"visible\":null},{\"codigo\":\"e_ssn_corr\",\"etiqueta\":null,\"editable\":null,\"formato\":null,\"listasSeleccion\":null,\"longitud\":null,\"mascara\":null,\"regexp\":null,\"tipo\":null,\"valor\":\"0\",\"visible\":null},{\"codigo\":\"e_mon\",\"etiqueta\":null,\"editable\":null,\"formato\":null,\"listasSeleccion\":null,\"longitud\":null,\"mascara\":null,\"regexp\":null,\"tipo\":null,\"valor\":\"1\",\"visible\":null},{\"codigo\":\"e_servicio\",\"etiqueta\":null,\"editable\":null,\"formato\":null,\"listasSeleccion\":null,\"longitud\":null,\"mascara\":null,\"regexp\":null,\"tipo\":null,\"valor\":\"1929\",\"visible\":null},{\"codigo\":\"e_identificacion\",\"etiqueta\":null,\"editable\":null,\"formato\":null,\"listasSeleccion\":null,\"longitud\":null,\"mascara\":null,\"regexp\":null,\"tipo\":null,\"valor\":\"1\",\"visible\":null},{\"codigo\":\"e_autoriza\",\"etiqueta\":null,\"editable\":null,\"formato\":null,\"listasSeleccion\":null,\"longitud\":null,\"mascara\":null,\"regexp\":null,\"tipo\":null,\"valor\":\"N\",\"visible\":null},{\"codigo\":\"e_ubi\",\"etiqueta\":null,\"editable\":null,\"formato\":null,\"listasSeleccion\":null,\"longitud\":null,\"mascara\":null,\"regexp\":null,\"tipo\":null,\"valor\":\"\",\"visible\":null},{\"codigo\":\"e_opcion\",\"etiqueta\":null,\"editable\":null,\"formato\":null,\"listasSeleccion\":null,\"longitud\":null,\"mascara\":null,\"regexp\":null,\"tipo\":null,\"valor\":\"C\",\"visible\":null},{\"codigo\":\"e_prov_req\",\"etiqueta\":null,\"editable\":null,\"formato\":null,\"listasSeleccion\":null,\"longitud\":null,\"mascara\":null,\"regexp\":null,\"tipo\":null,\"valor\":\"MS_REC_CMA_REQ\",\"visible\":null},{\"codigo\":\"e_prov_resp\",\"etiqueta\":null,\"editable\":null,\"formato\":null,\"listasSeleccion\":null,\"longitud\":null,\"mascara\":null,\"regexp\":null,\"tipo\":null,\"valor\":\"MS_REC_CMA_RESP\",\"visible\":null},{\"codigo\":\"vp_s_fecha_contable\",\"etiqueta\":null,\"editable\":null,\"formato\":null,\"listasSeleccion\":null,\"longitud\":null,\"mascara\":null,\"regexp\":null,\"tipo\":null,\"valor\":null,\"visible\":null},{\"codigo\":\"vp_s_ssn\",\"etiqueta\":null,\"editable\":null,\"formato\":null,\"listasSeleccion\":null,\"longitud\":null,\"mascara\":null,\"regexp\":null,\"tipo\":null,\"valor\":\"132993498\",\"visible\":null},{\"codigo\":\"vp_s_comision\",\"etiqueta\":null,\"editable\":null,\"formato\":null,\"listasSeleccion\":null,\"longitud\":null,\"mascara\":null,\"regexp\":null,\"tipo\":null,\"valor\":\"0\",\"visible\":null},{\"codigo\":\"vp_s_tasa\",\"etiqueta\":null,\"editable\":null,\"formato\":null,\"listasSeleccion\":null,\"longitud\":null,\"mascara\":null,\"regexp\":null,\"tipo\":null,\"valor\":null,\"visible\":null},{\"codigo\":\"vp_s_base_imp\",\"etiqueta\":null,\"editable\":null,\"formato\":null,\"listasSeleccion\":null,\"longitud\":null,\"mascara\":null,\"regexp\":null,\"tipo\":null,\"valor\":null,\"visible\":null},{\"codigo\":\"vp_s_impuesto\",\"etiqueta\":null,\"editable\":null,\"formato\":null,\"listasSeleccion\":null,\"longitud\":null,\"mascara\":null,\"regexp\":null,\"tipo\":null,\"valor\":null,\"visible\":null},{\"codigo\":\"vp_s_empresa\",\"etiqueta\":null,\"editable\":null,\"formato\":null,\"listasSeleccion\":null,\"longitud\":null,\"mascara\":null,\"regexp\":null,\"tipo\":null,\"valor\":\"CMA-CGM ECUADOR S.A.\",\"visible\":null},{\"codigo\":\"vp_s_recaudacion\",\"etiqueta\":null,\"editable\":null,\"formato\":null,\"listasSeleccion\":null,\"longitud\":null,\"mascara\":null,\"regexp\":null,\"tipo\":null,\"valor\":\"LINEA   \",\"visible\":null},{\"codigo\":\"vp_s_referencia1\",\"etiqueta\":null,\"editable\":null,\"formato\":null,\"listasSeleccion\":null,\"longitud\":null,\"mascara\":null,\"regexp\":null,\"tipo\":null,\"valor\":null,\"visible\":null},{\"codigo\":\"vp_s_referencia2\",\"etiqueta\":null,\"editable\":null,\"formato\":null,\"listasSeleccion\":null,\"longitud\":null,\"mascara\":null,\"regexp\":null,\"tipo\":null,\"valor\":null,\"visible\":null},{\"codigo\":\"vp_s_referencia3\",\"etiqueta\":null,\"editable\":null,\"formato\":null,\"listasSeleccion\":null,\"longitud\":null,\"mascara\":null,\"regexp\":null,\"tipo\":null,\"valor\":null,\"visible\":null},{\"codigo\":\"e_prov_req\",\"etiqueta\":null,\"editable\":null,\"formato\":null,\"listasSeleccion\":null,\"longitud\":null,\"mascara\":null,\"regexp\":null,\"tipo\":null,\"valor\":\"MS_REC_CMA_REQ\",\"visible\":null},{\"codigo\":\"e_prov_resp\",\"etiqueta\":null,\"editable\":null,\"formato\":null,\"listasSeleccion\":null,\"longitud\":null,\"mascara\":null,\"regexp\":null,\"tipo\":null,\"valor\":\"MS_REC_CMA_RESP\",\"visible\":null}]},\"identificador\":\"0993241539001\"},\"transaccion\":\"43569\",\"usuario\":\"msilvag\"}}";
            String userId = UUID.randomUUID().toString().replace("-", "").substring(0, 12);
            processorService.processMessage(messageMQ, userId);
        } catch (Exception ignored) {
        }finally {
            scheduler.shutdown();
        }
    }

}
