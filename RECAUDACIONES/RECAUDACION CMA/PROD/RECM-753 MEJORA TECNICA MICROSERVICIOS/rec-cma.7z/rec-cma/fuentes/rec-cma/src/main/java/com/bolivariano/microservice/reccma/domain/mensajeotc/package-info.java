@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.bolivariano.com/mensaje/MensajeOTC", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.bolivariano.microservice.reccma.domain.mensajeotc;
