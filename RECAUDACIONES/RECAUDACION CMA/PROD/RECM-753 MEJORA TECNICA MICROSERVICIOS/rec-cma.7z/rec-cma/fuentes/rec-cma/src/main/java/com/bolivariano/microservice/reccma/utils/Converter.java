/*
 * Converter.java
 * 
 * Copyright (c) 2012 FARCOMED.
 * Todos los derechos reservados.
 */
package com.bolivariano.microservice.reccma.utils;

import com.bolivariano.microservice.reccma.exception.ConverterException;

import java.io.InputStream;

/**
 * Clase
 * 
 * @author
 * @revision $Revision: 1.1 $
 */
public interface Converter {

	<T> T convertirAObjeto(InputStream valor, Class<T> clase)
			throws ConverterException;

	<T> T convertirAObjeto(String valor, Class<T> clase)
			throws ConverterException;

	String convertirDeObjeto(Object o) throws ConverterException;

	String convertirDeObjeto2(Object o, String xmlRootElement) throws ConverterException;
}
