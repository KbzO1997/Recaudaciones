package com.bolivariano.microservice.reccma.domain;

public enum TipoFlujo {
    PAGO,
    CONSULTA,
    REVERSO;
}
