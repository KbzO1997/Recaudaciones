package com.bolivariano.microservice.reccma.configuration;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.event.Observes;
import javax.inject.Inject;

import org.apache.cxf.Bus;
import org.apache.cxf.BusFactory;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transport.http.HTTPConduitConfigurer;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;

import io.quarkus.runtime.StartupEvent;
import org.jboss.logging.Logger;

@ApplicationScoped
public class AppLifecycleBean {

	@Inject
	ApplicationProperties applicationProperties;

	void onStart(@Observes StartupEvent ev) {

		HTTPConduitConfigurer httpConduitConfigurer = (String name, String address, HTTPConduit c) -> {
				HTTPConduit httpConduit =  c;
				HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
				httpClientPolicy.setConnectionRequestTimeout(applicationProperties.provider().connRequestTimeout());
				httpClientPolicy.setConnectionTimeout(applicationProperties.provider().connTimeout());
				httpClientPolicy.setReceiveTimeout(applicationProperties.provider().readTimeout());
				httpClientPolicy.setAllowChunking(false);
				httpConduit.setClient(httpClientPolicy);
		};

		final Bus bus = BusFactory.getThreadDefaultBus();
		bus.setExtension(httpConduitConfigurer, HTTPConduitConfigurer.class);
	}
}
