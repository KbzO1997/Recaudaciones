@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.bolivariano.com/dominio/ListaSeleccion")
package com.bolivariano.microservice.reccma.domain.listaseleccion;
