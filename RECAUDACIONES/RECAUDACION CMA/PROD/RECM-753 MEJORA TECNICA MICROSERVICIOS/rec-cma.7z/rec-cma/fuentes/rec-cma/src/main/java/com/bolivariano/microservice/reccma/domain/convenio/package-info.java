@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.bolivariano.com/dominio/Convenio")
package com.bolivariano.microservice.reccma.domain.convenio;
