package com.bolivariano.microservice.reccma.service;

import com.bolivariano.microservice.reccma.domain.mensajeotc.*;
import com.bolivariano.microservice.reccma.mq.MessageProducer;
import com.bolivariano.microservice.reccma.utils.ContentTypeEnum;
import com.bolivariano.microservice.reccma.utils.Converter;
import com.bolivariano.microservice.reccma.utils.ConverterFactory;
import org.jboss.logging.Logger;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.nio.charset.StandardCharsets;

@ApplicationScoped
public class ProcessorService {
	private static final String COD_OK = "00000";

	@Inject
	CMAService cmaService;

	@Inject
	Logger log;

	@Inject
    MessageProducer mqProducer;

	public void processMessage(String mensaje, String idCorrelacion) {
		MensajeEntradaProcesar mensajeEntradaProcesar;
		MensajeSalidaProcesar mensajeSalidaProcesar;
		Converter converter = ConverterFactory.getConverter(ContentTypeEnum.JSON);

		try {
			mensajeEntradaProcesar = converter.convertirAObjeto(mensaje, MensajeEntradaProcesar.class);
			if (mensajeEntradaProcesar == null) {
				throw new IllegalArgumentException("Mensaje de entrada vacio");
			}

			switch(mensajeEntradaProcesar.getTipoFlujo()){
				case CONSULTA:
					mensajeSalidaProcesar = consulta(mensajeEntradaProcesar);
					if ((mensajeSalidaProcesar != null && mensajeSalidaProcesar.getMensajeSalidaConsultarDeuda() != null)&&
							(COD_OK.equals(mensajeSalidaProcesar.getMensajeSalidaConsultarDeuda().getCodigoError()))){
							log.info("CODIGO DE RESPUESTA OK");
							mensajeSalidaProcesar.getMensajeSalidaConsultarDeuda().setCodigoError("0");
					}
					break;
				case PAGO:
					mensajeSalidaProcesar = ejecutarPago(mensajeEntradaProcesar);
					break;
				case REVERSO:
					mensajeSalidaProcesar = reverso(mensajeEntradaProcesar);
					break;
				default:
					log.error( "Flujo no implementado");
					throw new IllegalArgumentException("Flujo no implementado");

			}
			if ((mensajeSalidaProcesar != null && mensajeSalidaProcesar.getMensajeSalidaEjecutarPago() != null) &&
					(COD_OK.equals(mensajeSalidaProcesar.getMensajeSalidaEjecutarPago().getCodigoError()))){
					log.info("CODIGO DE RESPUESTA OK");
					mensajeSalidaProcesar.getMensajeSalidaEjecutarPago().setCodigoError("0");
			}
		} catch (Exception e) {
			log.error("Error procesar mensaje: " + e.getMessage(),e);
			mensajeSalidaProcesar = new MensajeSalidaProcesar();
			mensajeSalidaProcesar.setMensajeUsuario("Excepcion no controlada: " + e.getMessage());
			mensajeSalidaProcesar.setCodigo("300");
			mensajeSalidaProcesar.setEstado("ERROR");
		}
		sendMensageSalidaProcesar(converter, mensajeSalidaProcesar, idCorrelacion);
	}

	private void sendMensageSalidaProcesar(Converter converter, MensajeSalidaProcesar mensajeSalidaProcesar, String idCorrelacion){
		try {

			String mensajeJmsResponseUTF8 = converter.convertirDeObjeto(mensajeSalidaProcesar);
			byte[] ptext = mensajeJmsResponseUTF8.getBytes(StandardCharsets.UTF_8);
			mensajeJmsResponseUTF8 = new String(ptext, StandardCharsets.UTF_8);
			mqProducer.sendMessage(mensajeJmsResponseUTF8, idCorrelacion, false);
		} catch (Exception e) {
			log.error("Error enviar mensaje: " + e.getMessage(), e);

		}
	}
	
	public MensajeSalidaProcesar consulta(MensajeEntradaProcesar datoEntrada){
		MensajeSalidaProcesar mensajeSalidaConsulta = new MensajeSalidaProcesar();
		MensajeEntradaConsultarDeuda mecd = datoEntrada.getMensajeEntradaConsultarDeuda();
		MensajeSalidaConsultarDeuda mscd = this.cmaService.consultarDeuda(mecd);
		mensajeSalidaConsulta.setMensajeSalidaConsultarDeuda(mscd);
		mensajeSalidaConsulta.setCodigo("0");
		mensajeSalidaConsulta.setEstado("OK");
		mensajeSalidaConsulta.setMensajeUsuario("Consulta ejecutada");

		return mensajeSalidaConsulta;
	}
	
	public MensajeSalidaProcesar ejecutarPago (MensajeEntradaProcesar datoEntradaPago) {
		MensajeSalidaProcesar mensajeSalidaPago = new MensajeSalidaProcesar();
		MensajeEntradaEjecutarPago meep = datoEntradaPago.getMensajeEntradaEjecutarPago();
		MensajeSalidaEjecutarPago msep = this.cmaService.ejecutarPago(meep);
		mensajeSalidaPago.setMensajeSalidaEjecutarPago(msep);

		mensajeSalidaPago.setCodigo("0");
		mensajeSalidaPago.setEstado("OK");
		mensajeSalidaPago.setMensajeUsuario("PAGO EJECUTADO");

		return mensajeSalidaPago;
	}
	
	public MensajeSalidaProcesar reverso(MensajeEntradaProcesar datoReverso) {
		MensajeSalidaProcesar mensajeSalidaPago = new MensajeSalidaProcesar();
		MensajeEntradaEjecutarReverso meer = datoReverso.getMensajeEntradaEjecutarReverso();

		MensajeSalidaEjecutarPago mser = this.cmaService.ejecutarReverso(meer);
		mensajeSalidaPago.setMensajeSalidaEjecutarPago(mser);
		mensajeSalidaPago.setCodigo("0");
		mensajeSalidaPago.setEstado("OK");
		mensajeSalidaPago.setMensajeUsuario("Reverso ejecutado");
			
		return mensajeSalidaPago;
	}
}



