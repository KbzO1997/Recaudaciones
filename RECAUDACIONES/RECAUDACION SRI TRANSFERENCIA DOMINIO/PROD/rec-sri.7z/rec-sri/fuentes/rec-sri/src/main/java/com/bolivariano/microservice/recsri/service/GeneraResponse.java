package com.bolivariano.microservice.recsri.service;
import com.bolivariano.microservice.recsri.domain.datoadicional.DatoAdicional;
import com.bolivariano.microservice.recsri.domain.sri.parameterBlock;
import com.bolivariano.microservice.recsri.utils.GeneralUtils;

import javax.enterprise.context.ApplicationScoped;
import java.util.ArrayList;
import java.util.List;


@ApplicationScoped
public class GeneraResponse {
    List<parameterBlock> list;
    List<DatoAdicional> listDataAditional = new ArrayList<>();

    public void responseGenerico(String codigo, String valor) {
        DatoAdicional datoAdicional = new DatoAdicional();
        datoAdicional.setCodigo(codigo);
        datoAdicional.setValor(GeneralUtils.obtenerValorParameterBlock(valor, list));
        listDataAditional.add(datoAdicional);
    }

    public List<parameterBlock> obtenerResponseProveedor(List<parameterBlock> datosParameterBlocks){
    	list = datosParameterBlocks;
    	return list; 
    }

    public List<DatoAdicional> resultData(){
        return listDataAditional;
    }
}
