@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.bolivariano.com/dominio/Servicio")
package com.bolivariano.microservice.recsri.domain.servicio;
