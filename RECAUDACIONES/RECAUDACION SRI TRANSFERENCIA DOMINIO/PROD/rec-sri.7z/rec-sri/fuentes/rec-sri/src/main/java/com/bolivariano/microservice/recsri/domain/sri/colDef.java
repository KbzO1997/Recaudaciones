package com.bolivariano.microservice.recsri.domain.sri;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@Data
@AllArgsConstructor
@NoArgsConstructor
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class colDef {
    @XmlAttribute
    public String name;
    @XmlAttribute
    public String dataType;
    @XmlAttribute
    public String maxLen;
    @XmlAttribute
    public String scale;
    @XmlAttribute
    public String precision;
}