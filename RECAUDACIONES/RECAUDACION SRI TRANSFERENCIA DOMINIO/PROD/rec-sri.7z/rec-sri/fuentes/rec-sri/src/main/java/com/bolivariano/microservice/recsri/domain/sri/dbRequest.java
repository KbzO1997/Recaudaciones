package com.bolivariano.microservice.recsri.domain.sri;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class dbRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	public List<spParameter> spParameter;
	@XmlAttribute
	public String user;
	@XmlAttribute
	public String base;
	@XmlAttribute
	public String pkg;
	@XmlAttribute
	public String name;
	@XmlAttribute
	public String MCN;
	@XmlAttribute
	public String destino;
	@XmlAttribute
	public String TR;
	@XmlAttribute
	public String ORG;
	@XmlAttribute
	public String TO;
	@XmlAttribute
	public String chanel;
	@XmlAttribute
	public String id;
}
