package com.bolivariano.microservice.recsri.configuration;

import javax.inject.Named;

import io.quarkus.runtime.annotations.StaticInitSafe;
import io.smallrye.config.ConfigMapping;
import io.smallrye.config.ConfigMapping.NamingStrategy;

import java.util.List;

/**
 * 
 * @author Gizlo-Fernando Andrade
 *         <p>
 *         Interface para mapear los properties con el prefijo mi-claro-app-api
 *
 */
@StaticInitSafe
@ConfigMapping(prefix = "sri", namingStrategy = NamingStrategy.VERBATIM)
@Named("applicationConfig")
public interface ApplicationProperties {

	Provider provider();

	MQ mq();

	Truststore truststore();

	TCP tcp();

	List<ParametrosEmpresa> parametrosEmpresa();

	interface Provider {
		Integer connTimeout();

		Integer connRequestTimeout();

		Integer readTimeout();

		String formatoTiempo();

		String formatoFecha();
		
		String formatoFecha2();

		String codigoDatoAdicionalFechaContable();

		String channelVENT();

		String channelBVIR();

	}

	interface MQ {
		String host();

		Integer port();

		String channel();

		String queueManager();

		String requestQueue();

		String responseQueue();

		Integer poolJms();

		Integer delayReconnect();
		
		Long timeToLive();

		Integer characterSet();

	}

	interface Truststore {

		String path();

		String password();

		String type();

	}

	interface TCP{
		String host();

		int port();

		int timeout();
	}

	interface ParametrosEmpresa {
		String empresa();
	}


}
