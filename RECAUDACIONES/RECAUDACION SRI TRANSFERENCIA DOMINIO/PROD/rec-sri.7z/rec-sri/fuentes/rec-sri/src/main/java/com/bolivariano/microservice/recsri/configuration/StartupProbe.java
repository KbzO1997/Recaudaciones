package com.bolivariano.microservice.recsri.configuration;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

import org.eclipse.microprofile.health.HealthCheck;
import org.eclipse.microprofile.health.HealthCheckResponse;
import org.eclipse.microprofile.health.Startup;

import com.bolivariano.microservice.recsri.service.ProcessorService;
import org.jboss.logging.Logger;


@Startup
@ApplicationScoped

public class StartupProbe implements HealthCheck {

	@Inject
	ProcessorService processorService;

	@Inject
	Logger log;

	@Inject
	Initialize initialize;

	@Override
    public HealthCheckResponse call() {
		try{
			initialize.onStart();
			log.info("StartupProbe OK");
			return HealthCheckResponse.up("Ok StartupProbe");

		} catch (Exception ex) {
			return HealthCheckResponse.down(ex.getMessage());
		}

    }



}