package com.bolivariano.microservice.recsri.domain.sri;

import java.io.Serializable;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@Data
@AllArgsConstructor
@NoArgsConstructor
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class dbResponse implements Serializable {
    private static final long serialVersionUID = 1L;

    public List<parameterBlock> parameterBlock;

    @XmlAttribute
    public String MCN;
    @XmlAttribute
    public String id;
    @XmlAttribute
    public String destino;
    @XmlAttribute
    public String ruta;
    @XmlAttribute
    public String recibo;
    @XmlAttribute
    public String result;
    @XmlAttribute
    public String ssn;
    @XmlAttribute
    public String user;
    @XmlAttribute
    public String base;
    @XmlAttribute
    public String pkg;
    @XmlAttribute
    public String name;
}
