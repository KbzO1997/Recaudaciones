/*
 * Converter.java
 * 
 * Copyright (c) 2012 FARCOMED.
 * Todos los derechos reservados.
 */
package com.bolivariano.microservice.recsri.utils;
import java.io.InputStream;
import com.bolivariano.microservice.recsri.exception.ConverterException;

/**
 * Clase
 * 
 * @author
 * @revision $Revision: 1.1 $
 */
public interface Converter {

	<T> T convertirAObjeto(InputStream valor, Class<T> clase) throws ConverterException;

	<T> T convertirAObjeto(String valor, Class<T> clase) throws ConverterException;

	String convertirDeObjeto(Object o) throws ConverterException;

}
