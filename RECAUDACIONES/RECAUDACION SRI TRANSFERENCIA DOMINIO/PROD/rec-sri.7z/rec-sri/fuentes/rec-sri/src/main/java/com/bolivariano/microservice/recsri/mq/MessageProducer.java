package com.bolivariano.microservice.recsri.mq;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSContext;
import javax.jms.JMSProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.jboss.logging.Logger;

import com.bolivariano.microservice.recsri.configuration.ApplicationProperties;
import com.bolivariano.microservice.recsri.configuration.MQConnectionFactoryData;
@ApplicationScoped
public class MessageProducer {
	
	@Inject
	Logger log;
	
	@MQConnectionFactoryData
	ConnectionFactory mqConnectionFactory;

	@Inject
	ApplicationProperties applicationProperties;

	public void sendMessage(String mensajeStr, final String correlationId , boolean testMQ){
		try (final JMSContext context = mqConnectionFactory.createContext(Session.AUTO_ACKNOWLEDGE)) {
			final JMSProducer producer = context.createProducer();
			final Destination destination ;
			if (testMQ)	destination= context.createQueue(applicationProperties.mq().requestQueue());
			else destination= context.createQueue(applicationProperties.mq().responseQueue());
			TextMessage messageJMS = context.createTextMessage();
			messageJMS.setJMSCorrelationID(correlationId);
			messageJMS.setJMSTimestamp(System.nanoTime());			messageJMS.setText(mensajeStr);
			if (!testMQ) log.infof("Rsp: " + mensajeStr);
			producer.send(destination, messageJMS);
		} catch (Exception e) {
			log.error("Error en producir de servicio JMS", e);
			throw new IllegalArgumentException("Error al consultar deuda SRI: " + e.getMessage());
		}
	}
		

}
