package com.bolivariano.microservice.recsri.domain;

public enum TipoFlujo {
    PAGO,
    CONSULTA,
    REVERSO;
}
