package com.bolivariano.microservice.recsri.service;

import com.bolivariano.microservice.recsri.configuration.ApplicationProperties;
import com.bolivariano.microservice.recsri.domain.datoadicional.DatoAdicional;
import com.bolivariano.microservice.recsri.domain.mensajeotc.*;
import com.bolivariano.microservice.recsri.domain.recibo.Recibo;
import com.bolivariano.microservice.recsri.domain.sri.DatosGenericos;
import com.bolivariano.microservice.recsri.domain.sri.dbResponse;
import com.bolivariano.microservice.recsri.domain.sri.parameterBlock;
import com.bolivariano.microservice.recsri.utils.ContentTypeEnum;
import com.bolivariano.microservice.recsri.utils.Converter;
import com.bolivariano.microservice.recsri.utils.ConverterFactory;
import com.bolivariano.microservice.recsri.utils.GeneralUtils;

import io.netty.channel.ConnectTimeoutException;
import io.netty.handler.timeout.ReadTimeoutException;
import io.netty.handler.timeout.TimeoutException;
import org.jboss.logging.Logger;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import java.math.BigDecimal;


@ApplicationScoped
public class SRIService {

	private static final String CONSULTA = "CONSULTA";
	private static final String PAGO = "PAGO";
	private static final String REVERSO = "REVERSO";
	private static final String COD_MSJ = "PNO_COD_OPERATIVO_COD_MSJ";
	private static final String PSO_CHASIS_VEHICULO = "PSO_CHASIS_VEHICULO";
	private static final String E_SSN_CORR = "e_ssn_corr";
	private static final String E_PROVINCIA ="e_provincia";
	private static final String E_TERM = "e_term";
	
    @Inject
    ApplicationProperties applicationProperties;

    @Inject
    Logger log;

    @Inject
    GeneraRequest invokeReq;

    @Inject
    GeneraResponse invDataResp;


    public MensajeSalidaConsultarDeuda consultarDeuda(MensajeEntradaConsultarDeuda mensajeEntradaConsultarDeuda) {
        MensajeSalidaConsultarDeuda mensajeSalidaConsultarDeuda = new MensajeSalidaConsultarDeuda();
        Converter converter = ConverterFactory.getConverter(ContentTypeEnum.XML);
        Date fechaTrx = new Date();
        try {
            List<DatoAdicional> datosAdicionales = mensajeEntradaConsultarDeuda.getServicio().getDatosAdicionales().getDatoAdicional();
            DatosGenericos datosGenericos = new DatosGenericos();
            datosGenericos.setCanal(mensajeEntradaConsultarDeuda.getCanal());
            datosGenericos.setSecuencial(mensajeEntradaConsultarDeuda.getSecuencial());
            datosGenericos.setOficina(mensajeEntradaConsultarDeuda.getOficina());
            datosGenericos.setUsuario(mensajeEntradaConsultarDeuda.getUsuario());
            datosGenericos.setIdentificador(mensajeEntradaConsultarDeuda.getServicio().getIdentificador());
            datosGenericos.setTipoDeuda(mensajeEntradaConsultarDeuda.getServicio().getCodigoTipoIdentificador());
            datosGenericos.setFechaContable(GeneralUtils.formatearFechaTiempo(fechaTrx, applicationProperties.provider().formatoFecha2()));
            datosGenericos.setTerminal(GeneralUtils.obtenerDatoAdicional(E_TERM, datosAdicionales));
            datosGenericos.setProvincia(GeneralUtils.obtenerDatoAdicional(E_PROVINCIA, datosAdicionales));
            datosGenericos.setSecuencialCorreccion(GeneralUtils.obtenerDatoAdicional(E_SSN_CORR, datosAdicionales));
            
            String response =  invokeReq.requestGenerico(datosGenericos, CONSULTA);           
            
            if(response != null){
                convertirDeObjetoByConsultaRs(converter, response);
            }
            mensajeSalidaConsultarDeuda = salidaConsulta(response);

        } catch (Exception e) {
            log.error("ERROR EN CONSULTA" + e.getMessage(), e);
            mensajeSalidaConsultarDeuda.setMensajeUsuario("ERROR AL EJECUTAR CONSULTA: " + e.getMessage());
            mensajeSalidaConsultarDeuda.setCodigoError("300");
        }
        return mensajeSalidaConsultarDeuda;
    }

    private MensajeSalidaConsultarDeuda salidaConsulta(String response) {
        MensajeSalidaConsultarDeuda mensajeSalida = new MensajeSalidaConsultarDeuda();
        Converter converter = ConverterFactory.getConverter(ContentTypeEnum.XML);
        dbResponse responseProveedor;
        MensajeSalidaConsultarDeuda.Recibos recibos = new MensajeSalidaConsultarDeuda.Recibos();
        Recibo recibo = new Recibo();
        try {
            if (response != null) {
                responseProveedor = converter.convertirAObjeto(response, dbResponse.class);
                List<parameterBlock> datosParameterBlocks = responseProveedor.getParameterBlock();
                invDataResp.obtenerResponseProveedor(datosParameterBlocks);

                String codigoRespuesta = GeneralUtils.obtenerValorParameterBlock(COD_MSJ, datosParameterBlocks);
                if (codigoRespuesta.equals("15")) { //CODIGO_EXITO
                    mensajeSalida.setCodigoError("0");
                    mensajeSalida.setMensajeUsuario(GeneralUtils.obtenerValorParameterBlock(COD_MSJ, datosParameterBlocks));
                    mensajeSalida.setMensajeSistema(GeneralUtils.obtenerValorParameterBlock(COD_MSJ, datosParameterBlocks));
                    mensajeSalida.setNombreCliente(GeneralUtils.obtenerValorParameterBlock("PSO_NOMBRE_PROPIETARIO", datosParameterBlocks));                    
                    
                    double valorTotal = stringToDouble(GeneralUtils.obtenerValorParameterBlock("PNIO_VALOR_TOTAL_PAGO", datosParameterBlocks));
                    valorTotal = valorTotal / 100;
                    mensajeSalida.setMontoTotal(valorTotal);
                                        
                    recibo.setComprobante(GeneralUtils.obtenerValorParameterBlock("PSO_NOMBRE_PROPIETARIO", datosParameterBlocks));
                    recibo.setConcepto(GeneralUtils.obtenerValorParameterBlock("PSO_NUM_IDEN_PROPIETARIO", datosParameterBlocks));
                    recibo.setCuota(GeneralUtils.obtenerValorParameterBlock("PSO_ANIO_VEHICULO", datosParameterBlocks));
                    recibo.setDato1(GeneralUtils.obtenerValorParameterBlock(PSO_CHASIS_VEHICULO, datosParameterBlocks));
                    recibo.setDato2(GeneralUtils.obtenerValorParameterBlock("PNIO_CODIGO_VEHICULO", datosParameterBlocks));
                    recibo.setPago(stringToDouble(GeneralUtils.obtenerValorParameterBlock("PNO_VALOR_AVALUO_VEHICULO", datosParameterBlocks)));
                    recibo.setValor(stringToDouble(GeneralUtils.obtenerValorParameterBlock("PNO_VALOR_CONTRATOS", datosParameterBlocks)));
                    recibo.setTotalAPagar(valorTotal);                    
                    recibos.getRecibo().add(recibo);
                    
                    mensajeSalida.setRecibos(recibos);
                    if (mensajeSalida.getDatosAdicionales() == null) {
                        mensajeSalida.setDatosAdicionales(new MensajeSalidaConsultarDeuda.DatosAdicionales());
                    }
                    mensajeSalida.getDatosAdicionales().getDatoAdicional().addAll(invDataResp.resultData());

                } else {
                    mensajeSalida.setCodigoError(codigoRespuesta);
                    mensajeSalida.setMensajeUsuario(GeneralUtils.obtenerValorParameterBlock(COD_MSJ, datosParameterBlocks));
                    mensajeSalida.setMensajeSistema(GeneralUtils.obtenerValorParameterBlock(COD_MSJ, datosParameterBlocks));
                }

            } else {
                mensajeSalida.setCodigoError("99");
                mensajeSalida.setMensajeUsuario("ERROR EN LA CONSULTA SRI");
            }

            return mensajeSalida;

        } catch (Exception ex1) {
            throw new IllegalArgumentException("Error al ejecutar salida Consulta deuda SRI: " + ex1.getMessage());
        }
    }

    private void convertirDeObjetoByConsultaRs(Converter converter, String result) {
        try {
            log.info("RESPONSE CONSULTA SRI: " + converter.convertirAObjeto(result, dbResponse.class));
        } catch (Exception ex1) {
            log.error("ERROR AL CONVERTIR RESPONSE:   " + ex1.getMessage(), ex1);
        }
    }



    public MensajeSalidaEjecutarPago ejecutarPago(MensajeEntradaEjecutarPago mensajeEntradaEjecutarPago) {
        MensajeSalidaEjecutarPago mensajeSalidaEjecutarPago = new MensajeSalidaEjecutarPago();
        Converter converter = ConverterFactory.getConverter(ContentTypeEnum.XML);
        mensajeSalidaEjecutarPago.setCodigoError("0");
        mensajeSalidaEjecutarPago.setMensajeUsuario("PAGO EXISTOSO");
        Date fechaTrx = new Date();
        List<DatoAdicional> datosAdicionales = mensajeEntradaEjecutarPago.getServicio().getDatosAdicionales().getDatoAdicional();
        DatosGenericos datosGenericos = new DatosGenericos();
        try {
            
            if(mensajeEntradaEjecutarPago.getServicio().getCodigoConvenio().equals("SRI-TRNF-DOM")){
                datosGenericos.setTipoDeuda("TRANSF_DOM");
            }           
                       
            BigDecimal valorPago = BigDecimal.valueOf(mensajeEntradaEjecutarPago.getValorPago());
            BigDecimal totalPagoDecimal = valorPago.multiply(BigDecimal.valueOf(100));
            int totalPagoConvert = totalPagoDecimal.intValue();
            
            datosGenericos.setCanal(mensajeEntradaEjecutarPago.getCanal());
            datosGenericos.setSecuencial(mensajeEntradaEjecutarPago.getSecuencial());
            datosGenericos.setOficina(mensajeEntradaEjecutarPago.getOficina());
            datosGenericos.setUsuario(mensajeEntradaEjecutarPago.getUsuario());
            datosGenericos.setIdentificador(mensajeEntradaEjecutarPago.getServicio().getIdentificador());
            datosGenericos.setPagoTotal(String.valueOf(totalPagoConvert));   
            
            datosGenericos.setFechaContable(GeneralUtils.formatearFechaTiempo(fechaTrx, applicationProperties.provider().formatoFecha2()));
            datosGenericos.setTerminal(GeneralUtils.obtenerDatoAdicional(E_TERM, datosAdicionales));
            datosGenericos.setProvincia(GeneralUtils.obtenerDatoAdicional(E_PROVINCIA, datosAdicionales));
            datosGenericos.setSecuencialCorreccion(GeneralUtils.obtenerDatoAdicional(E_SSN_CORR, datosAdicionales));
            datosGenericos.setCodVehiculo(GeneralUtils.obtenerDatoAdicional("e_codigo_vehiculo", datosAdicionales));

            String response =  invokeReq.requestGenerico(datosGenericos, PAGO);            

            if(response != null){
                convertirDeObjetoByPagoRs(converter, response);
            }
            mensajeSalidaEjecutarPago = salidaPago(response, "P");

        } catch (Exception e) {
            log.error("ERROR AL EJECUTAR PAGO SRI: " + e.getMessage(), e);
            log.info("TIPO EXCEPCION: " + e.getClass());
            return validateException(e);
        }
        return mensajeSalidaEjecutarPago;
    }

     private MensajeSalidaEjecutarPago salidaPago(String response, String tipo) {
        MensajeSalidaEjecutarPago mensajeSalida = new MensajeSalidaEjecutarPago();
        Converter converter = ConverterFactory.getConverter(ContentTypeEnum.XML);
        dbResponse responseProveedor;
        try {
        	
            if (response != null) {
            	
                responseProveedor = converter.convertirAObjeto(response, dbResponse.class);
                List<parameterBlock> datosParameterBlocks = responseProveedor.getParameterBlock();
                invDataResp.obtenerResponseProveedor(datosParameterBlocks);
                String codigoRespuesta = GeneralUtils.obtenerValorParameterBlock(COD_MSJ, datosParameterBlocks);
                
                if (codigoRespuesta.equals("15")) { //CODIGO_EXITO
                    mensajeSalida.setCodigoError("0");
                    mensajeSalida.setMensajeUsuario(GeneralUtils.obtenerValorParameterBlock(COD_MSJ, datosParameterBlocks));
                    mensajeSalida.setMensajeSistema(GeneralUtils.obtenerValorParameterBlock(COD_MSJ, datosParameterBlocks));
                    mensajeSalida.setReferencia(GeneralUtils.obtenerValorParameterBlock("PNIO_CODIGO_VEHICULO", datosParameterBlocks));
                                        
                    if (mensajeSalida.getDatosAdicionales() == null) {
                    	mensajeSalida.setDatosAdicionales(new MensajeSalidaEjecutarPago.DatosAdicionales());
                    }
                    List<DatoAdicional> datoAdicional = new ArrayList<>();

                    DatoAdicional codigoPago= new DatoAdicional();
                    codigoPago.setCodigo(PSO_CHASIS_VEHICULO);
                    codigoPago.setValor((tipo.equals("R")) ? "" : GeneralUtils.obtenerValorParameterBlock(PSO_CHASIS_VEHICULO, datosParameterBlocks));
                    datoAdicional.add(codigoPago);

                    codigoPago= new DatoAdicional();
                    codigoPago.setCodigo("PDO_FECHA_CAD_MATRICULA");
                    codigoPago.setValor((tipo.equals("R")) ? "" : GeneralUtils.obtenerValorParameterBlock("PDO_FECHA_CAD_MATRICULA", datosParameterBlocks));
                    datoAdicional.add(codigoPago);
                    
                    codigoPago= new DatoAdicional();
                    codigoPago.setCodigo("PNO_LOG_SRI");
                    codigoPago.setValor(GeneralUtils.obtenerValorParameterBlock("PNO_LOG_SRI", datosParameterBlocks));
                    datoAdicional.add(codigoPago);
                    mensajeSalida.getDatosAdicionales().getDatoAdicional().addAll(datoAdicional);
                    
                } else {
                	
                    mensajeSalida.setCodigoError(codigoRespuesta);
                    mensajeSalida.setMensajeUsuario(GeneralUtils.obtenerValorParameterBlock(COD_MSJ, datosParameterBlocks));
                    mensajeSalida.setMensajeSistema(GeneralUtils.obtenerValorParameterBlock(COD_MSJ, datosParameterBlocks));
                }

            } else {
                mensajeSalida.setCodigoError("99");
                mensajeSalida.setMensajeUsuario("ERROR EN LA CONSULTA SRI");
            }

        } catch (Exception e) {
            log.error("Error al salida pago SRI: " + e.getMessage(), e);
            throw new IllegalArgumentException(e);

        }
        return mensajeSalida;
    }


    private void convertirDeObjetoByPagoRs(Converter converter, String result) {
        try {
            log.info("RESPONSE PAGO SRI: " + converter.convertirAObjeto(result, dbResponse.class));
        } catch (Exception ex1) {
            log.error("ERROR AL CONVERTIR RESPONSE: " + ex1.getMessage(), ex1);
        }
    }


    public MensajeSalidaEjecutarPago ejecutarReverso(MensajeEntradaEjecutarReverso mensajeEntradaEjecutarReverso) {
        MensajeSalidaEjecutarPago mensajeSalidaEjecutarPago;
        Converter converter = ConverterFactory.getConverter(ContentTypeEnum.XML);
        Date fechaTrx = new Date();
        try {
            List<DatoAdicional> datosAdicionales = mensajeEntradaEjecutarReverso.getServicio().getDatosAdicionales().getDatoAdicional();

            if (mensajeEntradaEjecutarReverso.getDatosAdicionales() != null && mensajeEntradaEjecutarReverso.getDatosAdicionales().getDatoAdicional() != null
                    && !mensajeEntradaEjecutarReverso.getDatosAdicionales().getDatoAdicional().isEmpty()) {
                datosAdicionales.addAll(mensajeEntradaEjecutarReverso.getDatosAdicionales().getDatoAdicional());
            }

            String secuencial = GeneralUtils.obtenerDatoAdicional(E_SSN_CORR, datosAdicionales);
            DatosGenericos datosGenericos = new DatosGenericos();
            if(mensajeEntradaEjecutarReverso.getServicio().getCodigoConvenio().equals("SRI-TRNF-DOM")){
                datosGenericos.setTipoDeuda("TRANSF_DOM");
            }

            BigDecimal valorPago = BigDecimal.valueOf(mensajeEntradaEjecutarReverso.getValorPago());
            BigDecimal totalPagoDecimal = valorPago.multiply(BigDecimal.valueOf(100));
            int totalPagoConvert = totalPagoDecimal.intValue();

            datosGenericos.setCanal(mensajeEntradaEjecutarReverso.getCanal());
            datosGenericos.setSecuencial(mensajeEntradaEjecutarReverso.getSecuencial());
            datosGenericos.setOficina(mensajeEntradaEjecutarReverso.getOficina());
            datosGenericos.setUsuario(mensajeEntradaEjecutarReverso.getUsuario());
            datosGenericos.setIdentificador(mensajeEntradaEjecutarReverso.getServicio().getIdentificador());

            datosGenericos.setPagoTotal(String.valueOf(totalPagoConvert));
            datosGenericos.setFechaContable(GeneralUtils.formatearFechaTiempo(fechaTrx, applicationProperties.provider().formatoFecha2()));
            datosGenericos.setTerminal(GeneralUtils.obtenerDatoAdicional(E_TERM, datosAdicionales));
            datosGenericos.setProvincia(GeneralUtils.obtenerDatoAdicional(E_PROVINCIA, datosAdicionales));
            datosGenericos.setCodVehiculo(GeneralUtils.obtenerDatoAdicional("e_codigo_vehiculo", datosAdicionales));
            datosGenericos.setSecuencialCorreccion(secuencial);
            
            String response =  invokeReq.requestGenerico(datosGenericos, REVERSO);
            
            if(response != null){
                convertirDeObjetoByReversoRs(converter, response);
            }
            mensajeSalidaEjecutarPago = salidaPago(response, "R");

        } catch (Exception e) {
            log.error("ERROR AL EJECUTAR REVERSO SRI: " + e.getMessage(), e);
            log.info("TIPO EXCEPCION: " + e.getClass());
            return validateException(e);
        }
        return mensajeSalidaEjecutarPago;
    }

    private void convertirDeObjetoByReversoRs(Converter converter, String result) {
        try {
            log.info("RESPONSE REVERSO SRI: " + converter.convertirAObjeto(result, dbResponse.class));
        } catch (Exception ex1) {
            log.error("ERROR AL CONVERTIR RESPONSE: " + ex1.getMessage(), ex1);
        }
    }

    private Double stringToDouble(String value){
        return (value != null && !value.isEmpty()) ? Double.valueOf(value) : 0d;
    }

    private MensajeSalidaEjecutarPago validateException(Exception e) {
        if (e instanceof SocketTimeoutException || e instanceof ReadTimeoutException || e instanceof TimeoutException || e instanceof ConnectTimeoutException) {
            return this.buildErrorMessage("EMPRESA_DESTINO_NO_DISPONIBLE", e.getMessage(), "REV_001");
        } else if (e instanceof ConnectException) {
            return this.buildErrorMessage("ERROR DE CONEXION", e.getMessage(), "SRI_001");
        }
        return this.buildErrorMessage("ERROR_CONSUMIR_PROVEEDOR", e.getMessage(), "SRI_003");

    }

    private MensajeSalidaEjecutarPago buildErrorMessage(String message, String techMessage, String code) {
        MensajeSalidaEjecutarPago msep = new MensajeSalidaEjecutarPago();
        msep.setCodigoError(code);
        msep.setMensajeUsuario(message);
        msep.setMensajeSistema(techMessage);
        return msep;
    }
}
