package com.bolivariano.microservice.recsri.service;
import com.bolivariano.microservice.recsri.configuration.ApplicationProperties;
import com.bolivariano.microservice.recsri.domain.sri.DatosGenericos;
import com.bolivariano.microservice.recsri.domain.sri.dbRequest;
import com.bolivariano.microservice.recsri.domain.sri.spParameter;
import com.bolivariano.microservice.recsri.utils.ContentTypeEnum;
import com.bolivariano.microservice.recsri.utils.Converter;
import com.bolivariano.microservice.recsri.utils.ConverterFactory;
import org.jboss.logging.Logger;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

@ApplicationScoped
public class GeneraRequest {
    private static final String TRA_CON = "TRA_CON";
    private static final String TRA_AFE = "TRA_AFE";
    private static final String TRA_REV = "TRA_REV";
    private static final String PAGO = "PAGO";
    private static final String CONSULTA = "CONSULTA";
    private static final String REVERSO = "REVERSO";

    @Inject
    Logger log;

    @Inject
    ApplicationProperties applicationProperties;

    public String requestGenerico(DatosGenericos datosGenericos, String tipoTrx){

        Converter converter = ConverterFactory.getConverter(ContentTypeEnum.XML);
        dbRequest request;
        spParameter spParameter;
        String result = null;
        List<spParameter> list = new ArrayList<>();

        String canal        = (datosGenericos.getCanal().equals("VEN")) ? "VENTANILLA" : "WEB";
        String typeAction = "";
        switch(tipoTrx) 
        {
          case PAGO:
        	  typeAction = TRA_AFE;
            break;
          case CONSULTA:
        	  typeAction = TRA_CON;
            break;
          case REVERSO:
        	  typeAction = TRA_REV;
            break;
          default:
            break;
        }
        try {
            request = new dbRequest();
            //Ref. Genera Header
            request = configHeader(datosGenericos.getUsuario(), datosGenericos.getSecuencial(), request);
            
            //Ref. Add Lista de Parametros
            spParameter = configValue("PNI_CODIGO_ENTIDAD_IFI", "7", 'S', "I");
            list.add(spParameter);
            spParameter = configValue("PSI_CODIGO_PROVE_SWITCH_IFI", "07", 'S', "I");
            list.add(spParameter);
            spParameter = configValue("PNI_CODIGO_TRANSACC_PROVEEDOR", datosGenericos.getSecuencial(), 'S', "I");
            list.add(spParameter);
            spParameter = configValue("PSI_CODIGO_AGENCIA_IFI", datosGenericos.getOficina(), 'S', "I");
            list.add(spParameter);
            spParameter = configValue("PSI_CODIGO_CANAL_PAGO_IFI", canal, 'S', "I");
            list.add(spParameter);
            spParameter = configValue("PSIO_CODIGO_TERMINAL_IFI", datosGenericos.getTerminal(), 'S', "I");
            list.add(spParameter);
            spParameter = configValue("PSI_CODIGO_OPERADOR_IFI", datosGenericos.getUsuario(), 'S', "I");
            list.add(spParameter);
            spParameter = configValue("PSI_NOMBRE_OPERADOR_IFI", datosGenericos.getUsuario(), 'S', "I");
            list.add(spParameter);
            spParameter = configValue("PSIO_FECHA_CONTABLE_IFI", datosGenericos.getFechaContable(), 'S', "I");
            list.add(spParameter);
            spParameter = configValue("PSI_PLACA_CAMV_CPN", datosGenericos.getIdentificador(), 'S', "I");
            list.add(spParameter);
            spParameter = configValue("PSI_PROVINCIA_IFI", datosGenericos.getProvincia(), 'S', "I");
            list.add(spParameter);
            spParameter = configValue("PSI_TIPO_DEUDA", datosGenericos.getTipoDeuda(), 'S', "I");
            list.add(spParameter);
            spParameter = configValue("PSI_TIPO_TRANSACCION", typeAction, 'S', "I");
            list.add(spParameter);
            spParameter = configValue("PNI_ID_TRAN_REVERSO_IFI", datosGenericos.getSecuencialCorreccion(), 'F', "I");
            list.add(spParameter);
            spParameter = configValue("PNI_ID_TRAN_REVERSO_SRI", "", 'F', "I");
            list.add(spParameter);
            spParameter = configValue("PNI_LOG_REVERSO_SRI", "", 'F', "I");
            list.add(spParameter);
            spParameter = configValue("PNIO_CODIGO_VEHICULO", datosGenericos.getCodVehiculo(), 'F', "IO");
            list.add(spParameter);
            spParameter = configValue("PNIO_VALOR_TOTAL_PAGO", datosGenericos.getPagoTotal(), 'F', "IO");
            list.add(spParameter);
            spParameter = configValue("PCO_VALORES_PAGO", "", 'C', "IO");
            list.add(spParameter);
            spParameter = configValue("PDO_FECHA_CAD_MATRICULA", "", 'D', "IO");
            list.add(spParameter);
            spParameter = configValue("PNO_CODIGO_CANTON_VEHICULO", "", 'F', "IO");
            list.add(spParameter);
            spParameter = configValue("PNO_COD_OPERATIVO_COD_MSJ", "", 'F', "IO");
            list.add(spParameter);
            spParameter = configValue("PNO_LOG_SRI", "", 'F', "IO");
            list.add(spParameter);
            spParameter = configValue("PNO_VALOR_AVALUO_VEHICULO", "", 'S', "IO");
            list.add(spParameter);
            spParameter = configValue("PNO_VALOR_CONTRATOS", "", 'S', "IO");
            list.add(spParameter);
            spParameter = configValue("PSO_ANIO_VEHICULO", "", 'S', "IO");
            list.add(spParameter);
            spParameter = configValue("PSO_CAMV_CPN_VEHICULO", "", 'S', "IO");
            list.add(spParameter);
            spParameter = configValue("PSO_CHASIS_VEHICULO", "", 'S', "IO");
            list.add(spParameter);
            spParameter = configValue("PSO_CLASE_VEHICULO", "", 'S', "IO");
            list.add(spParameter);
            spParameter = configValue("PSO_COD_ENT_POL_VEHICULO", "", 'S', "IO");
            list.add(spParameter);
            spParameter = configValue("PSO_EST_MATRICULA_VEHICULO", "", 'S', "IO");
            list.add(spParameter);
            spParameter = configValue("PSO_MARCA_VEHICULO", "", 'S', "IO");
            list.add(spParameter);
            spParameter = configValue("PSO_MODELO_VEHICULO", "", 'S', "IO");
            list.add(spParameter);
            spParameter = configValue("PSO_MOTOR_VEHICULO", "", 'S', "IO");
            list.add(spParameter);
            spParameter = configValue("PSO_NOMBRE_PROPIETARIO", "", 'S', "IO");
            list.add(spParameter);
            spParameter = configValue("PSO_NUM_IDEN_PROPIETARIO", "", 'S', "IO");
            list.add(spParameter);
            spParameter = configValue("PSO_PAIS_VEHICULO", "", 'S', "IO");
            list.add(spParameter);
            spParameter = configValue("PSO_PLACA_VEHICULO", "", 'S', "IO");
            list.add(spParameter);
            spParameter = configValue("PSO_SERVICIO_VEHICULO", "", 'S', "IO");
            list.add(spParameter);            
            request.setSpParameter(list);

            //Ref. Convertir valores header
            String xmlString  = "<?xml version='1.0'?>" + convertirDeObjetoByRq(converter, request);
            String replaceMCN = xmlString.replace("mcn=", "MCN=");
            String replaceTR  = replaceMCN.replace("tr=", "TR=");
            String replaceORG = replaceTR.replace("org=", "ORG=");
            String replaceTO = replaceORG.replace("to=", "TO=");
        	String resultProveedor = enviarTrama(replaceTO);
            result = resultProveedor.substring(21);
                                       
        } catch (Exception ex)
        {
            log.error("ERROR AL CONSUMIR PROVEEDOR:  " + ex.getMessage(), ex);
        }
        return result;
    }

    public spParameter configValue(String name, String value, char typeData, String io) {
    	value = (value == null) ? "0" : value;
        String dataType = (typeData == 'S') ? "string" : "float";
        dataType = (typeData == 'C') ? "cursor" : dataType;
        dataType = (typeData == 'D') ? "date" : dataType;
        spParameter spParameter = new spParameter();
        spParameter.setName(name);
        spParameter.setDataType(dataType);
        spParameter.setIo(io);
        spParameter.setMaxlen("0");
        spParameter.setValue(value);
        return spParameter;
    }

    public dbRequest configHeader(String user, String secuencial, dbRequest request) {
        request.setUser(user);        
        request.setMCN(secuencial);
        request.setPkg("TSW_PCK_SISTEMA_MAT_VEHICULAR");
        request.setName("TSW_PRO_PAGO_IFI");
        request.setDestino("LINKSRV");
        request.setTR("Q");
        request.setORG("C");
        request.setTO("N");
        request.setId("1");
        request.setBase("");
        return request;
    }

    private String convertirDeObjetoByRq(Converter converter, dbRequest request) {
        String resultConvert = null;
        try {
            resultConvert = converter.convertirDeObjeto(request);
            log.info("REQUEST SRI: " + resultConvert);
        } catch (Exception ex1) {
            log.error("ERROR AL CONVERTIR REQUEST:  " + ex1.getMessage(), ex1);
        }
        return resultConvert;
    }
    
    public static byte[] numeroEnBytes (long numero) {
		byte bytes[] = new byte[2];
		bytes[0] = (byte)(numero / 256); // considerar que es una división entera
		bytes[1] = (byte)(numero % 256);
		return bytes;
	}

	public static long bytesEnNumero (byte[]bytes) {
        int byte1 = bytes[1];
        //los byte en java tienen signo por lo que el siguiente codigo transforma a entero positivo
        byte1=byte1<0?byte1+256:byte1; 
		return ((long)bytes[0]*256 + (long)byte1);
	}	
	
    public String enviarTrama(String mensaje) throws IOException{
    	String ip = applicationProperties.tcp().host();
    	int puerto = applicationProperties.tcp().port(); 
    	// CODIGO PARA ESCRIBIR UN MENSAJE
        log.debug(mensaje);

    	String respuesta="";
        try (Socket sc = new Socket(ip,puerto);){
		
		OutputStream os =sc.getOutputStream();
		byte mensajeBytes[] =mensaje.getBytes();

		log.debug("Se va a enviar el mensaje");
		os.write(numeroEnBytes(mensajeBytes.length +2L));
		os.write(mensajeBytes);
		os.flush();

		// CODIGO PARA LEER LA RESPUESTA
		InputStream is = sc.getInputStream();
		log.debug("Se inicia la lectura");
	    byte longRespEnBytes[]= new byte[2];
		
	    int count = 0;
		while (count = is.read(longRespEnBytes) > 0) {}		
	    long longRespuesta = bytesEnNumero(longRespEnBytes)-2;
		log.debug("Longitud Recibida: " + longRespuesta);
	    for (int i=0; i<longRespuesta; i++) {
	    	int byteLeido=is.read();
	    	if (byteLeido!= 0) {
	    	   respuesta+=(char)byteLeido;
	    	}
	    }
        log.info("Mensaje Recibido: " + respuesta.replaceAll("(\n)",""));


        } catch (Exception e) {
            log.error("ERROR EN ENVIAR TRAMA" + e.getMessage(), e);
        }
		return respuesta;
	}
}
