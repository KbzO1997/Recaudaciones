@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.bolivariano.com/dominio/DatoAdicional")
package com.bolivariano.microservice.recsri.domain.datoadicional;
