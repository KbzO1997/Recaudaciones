package com.bolivariano.microservice.recsri.domain.sri;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.xml.bind.annotation.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class spParameter {
    @XmlAttribute
    public String name;
    @XmlAttribute
    public String dataType;
    @XmlAttribute
    public String io;
    @XmlAttribute
    public String maxlen;
    @XmlAttribute
    public String value;
}
