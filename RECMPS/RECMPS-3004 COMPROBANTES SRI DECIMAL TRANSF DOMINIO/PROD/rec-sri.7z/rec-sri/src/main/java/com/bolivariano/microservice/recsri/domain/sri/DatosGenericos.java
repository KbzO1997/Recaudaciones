package com.bolivariano.microservice.recsri.domain.sri;

import lombok.Data;

@Data
public class DatosGenericos {
    String canal;
    String secuencial;
    String fechaContable;
    String  oficina;
    String terminal;
    String usuario;
    String identificador;
    String provincia;
    String tipoDeuda;
    String secuencialCorreccion;
    String pagoTotal;
    String codReverso;
    String codVehiculo;
}
