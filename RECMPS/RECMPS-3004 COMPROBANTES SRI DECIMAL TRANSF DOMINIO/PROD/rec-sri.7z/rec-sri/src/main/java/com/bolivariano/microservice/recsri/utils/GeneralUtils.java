package com.bolivariano.microservice.recsri.utils;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import com.bolivariano.microservice.recsri.domain.datoadicional.DatoAdicional;
import com.bolivariano.microservice.recsri.domain.sri.parameterBlock;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

public class GeneralUtils {

	private GeneralUtils() {
	}

	public static String formatearFechaTiempo(Date fecha, String formato) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(formato);
		return simpleDateFormat.format(fecha);
	}

	public static XMLGregorianCalendar formatearFechaGregorian(String fecha) throws DatatypeConfigurationException {
		return DatatypeFactory.newInstance().newXMLGregorianCalendar(fecha);
	}

	public static XMLGregorianCalendar formatearFechaGregorian2(Date fecha) throws DatatypeConfigurationException {

		GregorianCalendar gc = new GregorianCalendar();
		gc.setTime(fecha);

		return DatatypeFactory.newInstance().newXMLGregorianCalendar(gc);
	}

	public static String obtenerValorParameterBlock(String clave, List<parameterBlock> parameterBlocks) {
		parameterBlock resultParameterBlock = parameterBlocks.parallelStream().filter(x -> x.getName().equals(clave) && x.getParameterValue().getScalarParameter().getValue() != null && !x.getParameterValue().getScalarParameter().getValue().isEmpty() && !"0".equals(x.getParameterValue().getScalarParameter().getValue())).findFirst().orElse(null);
		//SI EXISTE ALGUNO BUSCA EL ULTIMO
		if (resultParameterBlock != null){
			int lastIndex = parameterBlocks.parallelStream().filter(x -> x.getName().equals(clave) && x.getParameterValue().getScalarParameter().getValue() != null && !x.getParameterValue().getScalarParameter().getValue().isEmpty() && !"0".equals(x.getParameterValue().getScalarParameter().getValue()))
			.mapToInt(parameterBlocks::indexOf).max().getAsInt();
					

			resultParameterBlock = parameterBlocks.get(lastIndex);

		}
		return resultParameterBlock != null?resultParameterBlock.getParameterValue().getScalarParameter().getValue():"";
	}

	public static String obtenerDatoAdicional(String clave, List<DatoAdicional> datosAdicionales) {
		DatoAdicional resultDatoAdicional = datosAdicionales.parallelStream().filter(x -> x.getCodigo().equals(clave)
				&& x.getValor() != null && !x.getValor().isEmpty() && !"0".equals(x.getValor())).findFirst()
				.orElse(null);
		// SI EXISTE ALGUNO BUSCA EL ULTIMO
		if (resultDatoAdicional != null) {
			int lastIndex = datosAdicionales
					.parallelStream().filter(x -> x.getCodigo().equals(clave) && x.getValor() != null
							&& !x.getValor().isEmpty() && !"0".equals(x.getValor()))
					.mapToInt(datosAdicionales::indexOf).max()
					.getAsInt();
			resultDatoAdicional = datosAdicionales.get(lastIndex);

		}
		return resultDatoAdicional != null ? resultDatoAdicional.getValor() : "";
	}

	/**
	 * 
	 * @param commission
	 * @param amount
	 * @return
	 */
	public static Double obtenerMontoTotal(String commission, String amount) {
		return Double.valueOf(commission) + Double.valueOf(amount);
	}

	/**
	 * 
	 * @param standIN
	 * @return
	 */
	public static Boolean obtieneBooleano(String standIN) {
		Boolean result = false;
		if ("Online".equals(standIN)) {
			result = true;
		}
		return result;
	}

}
