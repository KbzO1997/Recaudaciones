package com.bolivariano.microservice.recbroadnet.domain;

public enum TipoFlujo {
    PAGO,
    CONSULTA,
    REVERSO;
}
