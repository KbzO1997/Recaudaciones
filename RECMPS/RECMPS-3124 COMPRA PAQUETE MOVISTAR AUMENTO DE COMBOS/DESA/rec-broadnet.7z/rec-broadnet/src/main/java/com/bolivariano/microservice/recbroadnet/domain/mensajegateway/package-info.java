@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.bolivariano.com/mensaje/MensajeOSB",
                                     elementFormDefault =
                                     javax.xml
                                                        .bind
                                                        .annotation
                                                        .XmlNsForm
                                                        .QUALIFIED)
package com.bolivariano.microservice.recbroadnet.domain.mensajegateway;

