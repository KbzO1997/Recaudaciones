@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.bolivariano.com/dominio/Empresa")
package com.bolivariano.dominio.empresa;
