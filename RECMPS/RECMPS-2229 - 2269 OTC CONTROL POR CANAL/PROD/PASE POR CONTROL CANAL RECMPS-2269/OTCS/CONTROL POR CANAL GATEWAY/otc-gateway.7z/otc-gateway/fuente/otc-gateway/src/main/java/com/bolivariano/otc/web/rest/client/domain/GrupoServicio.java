package com.bolivariano.otc.web.rest.client.domain;

import java.io.Serializable;
import java.util.List;


/**
 * The persistent class for the OTC_M_GRUPO_SERVICIO database table.
 */

public class GrupoServicio implements Serializable {
    private static final long serialVersionUID = 1L;


    private Long id;

    private List<Servicio> servicios;

    private Catalogo tipoBanca;

    private Catalogo tipoServicio;

    private Empresa empresa;

    private Boolean convenioVisible;

    private Boolean matriculable;

    private Boolean matriculacionMultiple;

    private Boolean validable;

    public GrupoServicio() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List<Servicio> getServicios() {
        return servicios;
    }

    public void setServicios(List<Servicio> servicios) {
        this.servicios = servicios;
    }

    public Catalogo getTipoBanca() {
        return tipoBanca;
    }

    public void setTipoBanca(Catalogo tipoBanca) {
        this.tipoBanca = tipoBanca;
    }

    public Catalogo getTipoServicio() {
        return tipoServicio;
    }

    public void setTipoServicio(Catalogo tipoServicio) {
        this.tipoServicio = tipoServicio;
    }

    public Empresa getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }

    public Boolean getConvenioVisible() {
        return convenioVisible;
    }

    public void setConvenioVisible(Boolean convenioVisible) {
        this.convenioVisible = convenioVisible;
    }

    public Boolean getMatriculable() {
        return matriculable;
    }

    public void setMatriculable(Boolean matriculable) {
        this.matriculable = matriculable;
    }

    public Boolean getMatriculacionMultiple() {
        return matriculacionMultiple;
    }

    public void setMatriculacionMultiple(Boolean matriculacionMultiple) {
        this.matriculacionMultiple = matriculacionMultiple;
    }

    public Boolean getValidable() {
        return validable;
    }

    public void setValidable(Boolean validable) {
        this.validable = validable;
    }

    @Override
    public String toString() {
        return "GrupoServicio{" +
                "id=" + id +
                ", servicios=" + servicios +
                ", tipoBanca=" + tipoBanca +
                ", tipoServicio=" + tipoServicio +
                ", empresa=" + empresa +
                ", convenioVisible=" + convenioVisible +
                ", matriculable=" + matriculable +
                ", matriculacionMultiple=" + matriculacionMultiple +
                ", validable=" + validable +
                '}';
    }
}