package com.bolivariano.otc.web.rest.client.domain;

import java.io.Serializable;
import java.util.Date;


/**
 * The persistent class for the OTC_M_CATALOGO database table.
 * 
 */

public class Catalogo implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long id;
	
	private String descripcion;

	private String estado;
	
	private Date fechaRegistro;

	private String nombre;

	private String codigo;

	private TipoCatalogo tipoCatalogo;

	public Catalogo() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public Date getFechaRegistro() {
		return fechaRegistro;
	}

	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public TipoCatalogo getTipoCatalogo() {
		return tipoCatalogo;
	}

	public void setTipoCatalogo(TipoCatalogo tipoCatalogo) {
		this.tipoCatalogo = tipoCatalogo;
	}

	@Override
	public String toString() {
		return "Catalogo{" +
				"id=" + id +
				", descripcion='" + descripcion + '\'' +
				", estado='" + estado + '\'' +
				", fechaRegistro=" + fechaRegistro +
				", nombre='" + nombre + '\'' +
				", codigo='" + codigo + '\'' +
				", tipoCatalogo=" + tipoCatalogo +
				'}';
	}
}