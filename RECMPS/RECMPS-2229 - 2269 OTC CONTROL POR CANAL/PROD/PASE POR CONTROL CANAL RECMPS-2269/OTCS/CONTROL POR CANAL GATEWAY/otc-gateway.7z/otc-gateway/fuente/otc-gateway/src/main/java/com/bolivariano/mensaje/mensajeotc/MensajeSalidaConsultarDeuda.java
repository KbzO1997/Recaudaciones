
package com.bolivariano.mensaje.mensajeotc;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.bolivariano.dominio.datoadicional.DatoAdicional;
import com.bolivariano.dominio.recibo.Recibo;


/**
 * <p>Clase Java para mensajeSalidaConsultarDeuda complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="mensajeSalidaConsultarDeuda">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codigoError" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="datosAdicionales" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="datoAdicional" type="{http://www.bolivariano.com/dominio/DatoAdicional}datoAdicional" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="fechaVencimiento" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="formaPago" type="{http://www.bolivariano.com/dominio/FormaPago}formaPago" minOccurs="0"/>
 *         &lt;element name="formaPagoRecibos" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="identificadorDeuda" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="limiteMontoMaximo" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="limiteMontoMinimo" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="mensajeUsuario" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="montoMinimo" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="montoTotal" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="nombreCliente" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="recibos" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="recibo" type="{http://www.bolivariano.com/dominio/Recibo}recibo" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="textoAyuda" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "mensajeSalidaConsultarDeuda", propOrder = {
    "codigoError",
    "datosAdicionales",
    "fechaVencimiento",
    "formaPago",
    "formaPagoRecibos",
    "identificadorDeuda",
    "limiteMontoMaximo",
    "limiteMontoMinimo",
    "mensajeUsuario",
    "montoMinimo",
    "montoTotal",
    "nombreCliente",
    "recibos",
    "textoAyuda"
})
public class MensajeSalidaConsultarDeuda {

    protected String codigoError;
    protected MensajeSalidaConsultarDeuda.DatosAdicionales datosAdicionales;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar fechaVencimiento;
    protected String formaPago;
    protected String formaPagoRecibos;
    protected String identificadorDeuda;
    protected Double limiteMontoMaximo;
    protected Double limiteMontoMinimo;
    protected String mensajeUsuario;
    protected Double montoMinimo;
    protected Double montoTotal;
    protected String nombreCliente;
    protected MensajeSalidaConsultarDeuda.Recibos recibos;
    protected String textoAyuda;

    /**
     * Obtiene el valor de la propiedad codigoError.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigoError() {
        return codigoError;
    }

    /**
     * Define el valor de la propiedad codigoError.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigoError(String value) {
        this.codigoError = value;
    }

    /**
     * Obtiene el valor de la propiedad datosAdicionales.
     * 
     * @return
     *     possible object is
     *     {@link MensajeSalidaConsultarDeuda.DatosAdicionales }
     *     
     */
    public MensajeSalidaConsultarDeuda.DatosAdicionales getDatosAdicionales() {
        return datosAdicionales;
    }

    /**
     * Define el valor de la propiedad datosAdicionales.
     * 
     * @param value
     *     allowed object is
     *     {@link MensajeSalidaConsultarDeuda.DatosAdicionales }
     *     
     */
    public void setDatosAdicionales(MensajeSalidaConsultarDeuda.DatosAdicionales value) {
        this.datosAdicionales = value;
    }

    /**
     * Obtiene el valor de la propiedad fechaVencimiento.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getFechaVencimiento() {
        return fechaVencimiento;
    }

    /**
     * Define el valor de la propiedad fechaVencimiento.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFechaVencimiento(XMLGregorianCalendar value) {
        this.fechaVencimiento = value;
    }

    /**
     * Obtiene el valor de la propiedad formaPago.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormaPago() {
        return formaPago;
    }

    /**
     * Define el valor de la propiedad formaPago.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormaPago(String value) {
        this.formaPago = value;
    }

    /**
     * Obtiene el valor de la propiedad formaPagoRecibos.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormaPagoRecibos() {
        return formaPagoRecibos;
    }

    /**
     * Define el valor de la propiedad formaPagoRecibos.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormaPagoRecibos(String value) {
        this.formaPagoRecibos = value;
    }

    /**
     * Obtiene el valor de la propiedad identificadorDeuda.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentificadorDeuda() {
        return identificadorDeuda;
    }

    /**
     * Define el valor de la propiedad identificadorDeuda.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentificadorDeuda(String value) {
        this.identificadorDeuda = value;
    }

    /**
     * Obtiene el valor de la propiedad limiteMontoMaximo.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getLimiteMontoMaximo() {
        return limiteMontoMaximo;
    }

    /**
     * Define el valor de la propiedad limiteMontoMaximo.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setLimiteMontoMaximo(Double value) {
        this.limiteMontoMaximo = value;
    }

    /**
     * Obtiene el valor de la propiedad limiteMontoMinimo.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getLimiteMontoMinimo() {
        return limiteMontoMinimo;
    }

    /**
     * Define el valor de la propiedad limiteMontoMinimo.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setLimiteMontoMinimo(Double value) {
        this.limiteMontoMinimo = value;
    }

    /**
     * Obtiene el valor de la propiedad mensajeUsuario.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMensajeUsuario() {
        return mensajeUsuario;
    }

    /**
     * Define el valor de la propiedad mensajeUsuario.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMensajeUsuario(String value) {
        this.mensajeUsuario = value;
    }

    /**
     * Obtiene el valor de la propiedad montoMinimo.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getMontoMinimo() {
        return montoMinimo;
    }

    /**
     * Define el valor de la propiedad montoMinimo.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setMontoMinimo(Double value) {
        this.montoMinimo = value;
    }

    /**
     * Obtiene el valor de la propiedad montoTotal.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getMontoTotal() {
        return montoTotal;
    }

    /**
     * Define el valor de la propiedad montoTotal.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setMontoTotal(Double value) {
        this.montoTotal = value;
    }

    /**
     * Obtiene el valor de la propiedad nombreCliente.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNombreCliente() {
        return nombreCliente;
    }

    /**
     * Define el valor de la propiedad nombreCliente.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNombreCliente(String value) {
        this.nombreCliente = value;
    }

    /**
     * Obtiene el valor de la propiedad recibos.
     * 
     * @return
     *     possible object is
     *     {@link MensajeSalidaConsultarDeuda.Recibos }
     *     
     */
    public MensajeSalidaConsultarDeuda.Recibos getRecibos() {
        return recibos;
    }

    /**
     * Define el valor de la propiedad recibos.
     * 
     * @param value
     *     allowed object is
     *     {@link MensajeSalidaConsultarDeuda.Recibos }
     *     
     */
    public void setRecibos(MensajeSalidaConsultarDeuda.Recibos value) {
        this.recibos = value;
    }

    /**
     * Obtiene el valor de la propiedad textoAyuda.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTextoAyuda() {
        return textoAyuda;
    }

    /**
     * Define el valor de la propiedad textoAyuda.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTextoAyuda(String value) {
        this.textoAyuda = value;
    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="datoAdicional" type="{http://www.bolivariano.com/dominio/DatoAdicional}datoAdicional" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "datoAdicional"
    })
    public static class DatosAdicionales {

        @XmlElement(nillable = true)
        protected List<DatoAdicional> datoAdicional;

        /**
         * Gets the value of the datoAdicional property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the datoAdicional property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDatoAdicional().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link DatoAdicional }
         * 
         * 
         */
        public List<DatoAdicional> getDatoAdicional() {
            if (datoAdicional == null) {
                datoAdicional = new ArrayList<>();
            }
            return this.datoAdicional;
        }

    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="recibo" type="{http://www.bolivariano.com/dominio/Recibo}recibo" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "recibo"
    })
    public static class Recibos {

        @XmlElement(nillable = true)
        protected List<Recibo> recibo;

        /**
         * Gets the value of the recibo property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the recibo property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getRecibo().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link Recibo }
         * 
         * 
         */
        public List<Recibo> getRecibo() {
            if (recibo == null) {
                recibo = new ArrayList<>();
            }
            return this.recibo;
        }

    }

}
