package com.bolivariano.otc.web.rest.client.domain;

import java.io.Serializable;
import java.util.Date;


/**
 * The persistent class for the OTC_P_SERV_ENRIQ_PARAM database table.
 * 
 */
public class ServicioEnriquecimientoParam implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long id;

	private ServicioEnriquecimiento servicioEnriquecimiento;

	private String alias;

	private String estado;

	private Date fechaRegistro;

	private String tipo;

	public ServicioEnriquecimientoParam() {
	}

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ServicioEnriquecimiento getServicioEnriquecimiento() {
		return servicioEnriquecimiento;
	}

	public void setServicioEnriquecimiento(ServicioEnriquecimiento servicioEnriquecimiento) {
		this.servicioEnriquecimiento = servicioEnriquecimiento;
	}

	public String getAlias() {
		return this.alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public String getEstado() {
		return this.estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public Date getFechaRegistro() {
		return this.fechaRegistro;
	}

	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

	public String getTipo() {
		return this.tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	@Override
	public String toString() {
		return "ServicioEnriquecimientoParam{" +
				"id=" + id +
				", servicioEnriquecimiento=" + servicioEnriquecimiento +
				", alias='" + alias + '\'' +
				", estado='" + estado + '\'' +
				", fechaRegistro=" + fechaRegistro +
				", tipo='" + tipo + '\'' +
				'}';
	}
}