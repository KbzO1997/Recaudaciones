package com.bolivariano.otc.processor;

import com.bolivariano.mensaje.mensajeotc.*;
import com.bolivariano.ws.otcservice.OTCEndpoint;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.springframework.beans.factory.annotation.Autowired;

public class OTCEndpointProcessor implements Processor {

    @Autowired
    OTCEndpoint otcEndpoint;

    public void process(Exchange exchange) throws Exception {
        
        exchange.getProperty(Exchange.CHARSET_NAME, "UTF-8");
        Message inMessage = exchange.getIn();

        String operationName = inMessage.getHeader(CxfConstants.OPERATION_NAME, String.class);

        if ("ejecutarPago".equals(operationName)) {
            MensajeEntradaEjecutarPago mensaje = inMessage.getBody(MensajeEntradaEjecutarPago.class);
            MensajeSalidaEjecutarPago respuesta = otcEndpoint.ejecutarPago(mensaje);
            exchange.getOut().setBody(respuesta);

        }
        if ("consultarEmpresa".equals(operationName)) {
            MensajeEntradaConsultarEmpresa mensaje = inMessage.getBody(MensajeEntradaConsultarEmpresa.class);
            MensajeSalidaConsultarEmpresa respuesta = otcEndpoint.consultarEmpresa(mensaje);
            exchange.getOut().setBody(respuesta);

        }
        if ("ejecutarReverso".equals(operationName)) {
            MensajeEntradaEjecutarReverso mensaje = inMessage.getBody(MensajeEntradaEjecutarReverso.class);
            otcEndpoint.ejecutarReverso(mensaje);

        }
        if ("consultarDeuda".equals(operationName)) {
            MensajeEntradaConsultarDeuda mensaje = inMessage.getBody(MensajeEntradaConsultarDeuda.class);
            MensajeSalidaConsultarDeuda respuesta = otcEndpoint.consultarDeuda(mensaje);
            exchange.getOut().setBody(respuesta);

        }

    }

    public void setOTCEndpoint(OTCEndpoint otcEndpoint) {
        this.otcEndpoint = otcEndpoint;
    }
}