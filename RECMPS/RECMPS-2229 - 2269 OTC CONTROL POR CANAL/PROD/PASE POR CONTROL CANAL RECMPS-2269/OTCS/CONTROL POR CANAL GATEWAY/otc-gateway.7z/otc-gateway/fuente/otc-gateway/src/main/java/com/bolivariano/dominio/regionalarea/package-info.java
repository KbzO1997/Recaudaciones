@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.bolivariano.com/dominio/RegionalArea")
package com.bolivariano.dominio.regionalarea;
