package com.bolivariano.otc.config;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.UnsupportedCallbackException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;


/**
 * Callback handler to handle passwords
 */
public class UTPasswordCallback implements CallbackHandler {

    private Map<String, String> passwords = new HashMap<String, String>();
    private byte[] secret;

    public UTPasswordCallback() {
        passwords.put("osbbolivariano", "welcome1");
        passwords.put("esbsswsd1", "server");
        passwords.put("symm", "server");
        passwords.put("usrcyberbank", "P@ssw0rd");
        String tmp="\"HKXEWHYxCJ9wE5nd0IDRaXzxlLY=\"";
        secret= tmp.getBytes();

    }

    /**
     * Here, we attempt to get the password from the private alias/passwords map.
     */
    public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException {

        String user = "";

        for (Callback callback : callbacks) {
            String pass = passwords.get(getIdentifier(callback));
            if (pass != null) {
                setPassword(callback, pass);
                return;
            }

        }

        // Password not found
        throw new IOException("Password does not exist for the user : " + user);
    }

    private void setPassword(Callback callback, String pass) {
        try {
            callback.getClass().getMethod("setPassword", String.class).invoke(callback, pass);
            callback.getClass().getMethod("setKey", byte[].class).invoke(callback, secret);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private String getPassword(Callback callback) {
        try {
            return (String)callback.getClass().getMethod("getPassword").invoke(callback);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private String getIdentifier(Callback cb) {
        try {
            return (String)cb.getClass().getMethod("getIdentifier").invoke(cb);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Add an alias/password pair to the callback mechanism.
     */
    public void setAliasPassword(String alias, String password) {
        passwords.put(alias, password);
    }

    private String getPasswordType(Callback pc) {
        try {
            Method getType = null;
            try {
                getType = pc.getClass().getMethod("getPasswordType");
            } catch (NoSuchMethodException ex) {
                // keep looking
            } catch (SecurityException ex) {
                // keep looking
            }
            if (getType == null) {
                getType = pc.getClass().getMethod("getType");
            }
            String result = (String)getType.invoke(pc);
            return result;

        } catch (Exception ex) {
            return null;
        }
    }

    /**
     * Set the Key.
     * <p/>
     *
     * @param secret
     */
    public void setKey(byte[] secret) {
        this.secret = secret;
    }
    public byte[] getKey() {


        return this.secret;
    }
}