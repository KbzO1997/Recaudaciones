package com.bolivariano.otc.web.rest.client.message;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import java.io.Serializable;

@JsonInclude(Include.NON_NULL)
public class MensajeEntradaConsultarGrupoServicio implements Serializable {

	private static final long serialVersionUID = 5065686930287078082L;
	private String tipoBanca;
	private String tipoServicio;
	private String nombreEmpresa;
	private String codigoEmpresa;
	private Boolean matriculable;
	private String canal;

	public MensajeEntradaConsultarGrupoServicio() {

	}

	public String getTipoBanca() {
		return tipoBanca;
	}

	public void setTipoBanca(String tipoBanca) {
		this.tipoBanca = tipoBanca;
	}

	public String getTipoServicio() {
		return tipoServicio;
	}

	public void setTipoServicio(String tipoServicio) {
		this.tipoServicio = tipoServicio;
	}


	public Boolean getMatriculable() {
		return matriculable;
	}

	public void setMatriculable(Boolean matriculable) {
		this.matriculable = matriculable;
	}

	public String getCodigoEmpresa() {
		return codigoEmpresa;
	}

	public void setCodigoEmpresa(String codigoEmpresa) {
		this.codigoEmpresa = codigoEmpresa;
	}

	public String getNombreEmpresa() {
		return nombreEmpresa;
	}

	public void setNombreEmpresa(String nombreEmpresa) {
		this.nombreEmpresa = nombreEmpresa;
	}

	public String getCanal() {
		return canal;
	}

	public void setCanal(String canal) {
		this.canal = canal;
	}

	@Override
	public String toString() {
		return "MensajeEntradaConsultarGrupoServicio{" +
				"tipoBanca='" + tipoBanca + '\'' +
				", tipoServicio='" + tipoServicio + '\'' +
				", nombreEmpresa='" + nombreEmpresa + '\'' +
				", codigoEmpresa='" + codigoEmpresa + '\'' +
				", canal='" + canal + '\'' +
				", matriculable=" + matriculable +
				'}';
	}
}