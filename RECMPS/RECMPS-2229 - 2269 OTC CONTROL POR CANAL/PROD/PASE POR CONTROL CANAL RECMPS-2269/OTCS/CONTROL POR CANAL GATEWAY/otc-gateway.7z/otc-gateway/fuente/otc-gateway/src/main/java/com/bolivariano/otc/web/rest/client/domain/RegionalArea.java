package com.bolivariano.otc.web.rest.client.domain;

import java.io.Serializable;


/**
 * The persistent class for the OTC_M_FLUJO database table.
 * 
 */

public class RegionalArea implements Serializable {
	private static final long serialVersionUID = 1L;


	private Long id;

	private String codigo;

	public RegionalArea() {
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public Long getId() {
		return id;
	}

	public String getCodigo() {
		return codigo;
	}

	@Override
	public String toString() {
		return "RegionalArea{" +
				"id=" + id +
				", codigo='" + codigo + '\'' +
				'}';
	}
}