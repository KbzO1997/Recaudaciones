package com.bolivariano.otc.web.rest.client;

import com.bolivariano.otc.web.rest.client.message.MensajeEntradaProcesar;
import com.bolivariano.otc.web.rest.client.message.MensajeSalidaProcesar;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.Charset;

@Service
public class CoreServicioProxy {
    
    private static final Logger log = LoggerFactory.getLogger(CoreServicioProxy.class);

    @Value("${otc.endpoint.core}")
    private String endpoint;

    public CoreServicioProxy() {
    	//CoreServicioProxy
    }

    private ClientHttpRequestFactory getClientHttpRequestFactory() {
        int timeout = 5000;
        HttpComponentsClientHttpRequestFactory clientHttpRequestFactory
                = new HttpComponentsClientHttpRequestFactory();
        clientHttpRequestFactory.setConnectTimeout(timeout);
        return clientHttpRequestFactory;
    }

    public MensajeSalidaProcesar procesar(MensajeEntradaProcesar peticionObj)
            throws JsonProcessingException {

        RestTemplate restTemplate = new RestTemplate(getClientHttpRequestFactory());
        restTemplate.getMessageConverters()
                .add(0, new StringHttpMessageConverter(Charset.forName("UTF-8")));
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

        ObjectMapper mapper = new ObjectMapper();

        String messageJSONString = mapper.writeValueAsString(peticionObj);
        log.info("MESSAJE_JSON: " + messageJSONString);

        HttpEntity<String> peticion = new HttpEntity<>(messageJSONString, headers);

        return restTemplate.postForObject(endpoint, peticion, MensajeSalidaProcesar.class);
    }

}
