package com.bolivariano.otc.config;

import com.bolivariano.otc.processor.OTCEndpointProcessor;
import com.bolivariano.otc.web.ws.OTCEndpointImpl;
import com.bolivariano.ws.otcservice.OTCEndpoint;
import org.apache.camel.component.cxf.CxfEndpoint;
import org.apache.cxf.Bus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

@Configuration
public class WebServiceConfig {

    @Autowired
    private Bus bus;


    //NOTE THE VALUE OF cxf.path in application.properties this leads to
    //the URL of the soap service being of the form /service/CustomerServicePort

    @Bean(name = "OTCEndpointProcessor")
    public OTCEndpointProcessor getProcessor() {
        return new OTCEndpointProcessor();
    }

    @Bean(name = "OTCEndpoint")
    public CxfEndpoint customerServiceEndpoint() {

        CxfEndpoint cxfEndpoint = new CxfEndpoint();
        cxfEndpoint.setAddress("/OTCEndpoint");
        cxfEndpoint.setServiceClass(OTCEndpoint.class);
        cxfEndpoint.setBus(bus);
        cxfEndpoint.setWsdlURL("wsdl/otc-nopolicy.wsdl");

        return cxfEndpoint;
    }

    @Bean(name = "OTCEndpointSecurity")
    public CxfEndpoint customerServiceEndpointSecurity() {

        CxfEndpoint cxfEndpoint = new CxfEndpoint();
        cxfEndpoint.setAddress("/OTCEndpointSecurity");
        cxfEndpoint.setServiceClass(OTCEndpoint.class);
        cxfEndpoint.setBus(bus);
        cxfEndpoint.setWsdlURL("wsdl/otc.wsdl");

        Map<String, Object> inProps = new HashMap<String, Object>();
        inProps.put("security.callback-handler", UTPasswordCallback.class.getName());
        inProps.put("security.signature.propertie", "crypto.properties");
        inProps.put("security.encryption.properties", "crypto.properties");
        inProps.put("security.encryption.username", "localosb");
        inProps.put("ws-security.is-bsp-compliant", "false");

        cxfEndpoint.setProperties(inProps);
        return cxfEndpoint;
    }

    @Bean
    public OTCEndpoint otcEndpoint() {
        return new OTCEndpointImpl();
    }
}
