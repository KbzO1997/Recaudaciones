@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.bolivariano.com/dominio/Recibo")
package com.bolivariano.dominio.recibo;
