package com.bolivariano.otc.dao;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.bolivariano.otc.MapperUtil;
import com.bolivariano.otc.bean.CatalogoBean;
import com.bolivariano.otc.bean.CatalogoBusqueda;
import com.bolivariano.otc.bean.DatabaseResponse;
import com.bolivariano.otc.bean.PaginatedListCatalogo;
import com.bolivariano.otc.bean.PaginationRequest;
import com.bolivariano.otc.enumerators.RegisterStatus;
import com.bolivariano.otc.exception.OTCAdminException;

import oracle.jdbc.OracleTypes;

@Repository
public class CatalogoDAO {

	private static final String E_CONSULTA = "Error al consultar catalogos: ";
	private static final String E_CT_FECHA_REGISTRO = "e_CT_FECHA_REGISTRO";
	private static final String E_CT_NOMBRE = "e_CT_NOMBRE";
	private static final String E_CT_ESTADO = "e_CT_ESTADO";
	private static final String E_CT_DESCRIPCION = "e_CT_DESCRIPCION";
	private static final String E_CT_CODIGO = "e_CT_CODIGO";
	private static final String S_AFECTADOS = "s_afectados";
	private static final String S_CODIGO_ERROR = "s_codigo_error";
	private static final String S_MENSAJE = "s_mensaje";
	private static final String E_CODIGO = "e_codigo";
	private static final String S_RESULT = "s_result";
	
	@Autowired
	MapperUtil<CatalogoBean> catalogoBeanMapper;
	private static final Logger log = LoggerFactory.getLogger(CatalogoDAO.class);

	public DatabaseResponse insert(JdbcTemplate jdbcTemplate, CatalogoBean catalogo) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_ICATALOGO")
					.declareParameters(new SqlParameter(E_CT_FECHA_REGISTRO, Types.DATE),
							new SqlParameter(E_CT_NOMBRE, Types.VARCHAR), new SqlParameter(E_CT_ESTADO, Types.CHAR),
							new SqlParameter(E_CT_DESCRIPCION, Types.VARCHAR),
							new SqlParameter(E_CT_CODIGO, Types.VARCHAR),
							new SqlOutParameter("s_secuencia", Types.NUMERIC),
							new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
							new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
							new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue(E_CT_FECHA_REGISTRO, Date.valueOf(LocalDate.now()));
			source.addValue(E_CT_NOMBRE, catalogo.getNombre());
			source.addValue(E_CT_ESTADO, RegisterStatus.Activo.getValue());
			source.addValue(E_CT_DESCRIPCION, catalogo.getDescripcion());
			source.addValue(E_CT_CODIGO, catalogo.getCodigo());
			Map<String, Object> out = simpleJdbcCall.execute(source);
			dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
			dr.setMessage((String) out.get(S_MENSAJE));
			dr.setSequence((BigDecimal) out.get("s_secuencia"));
			dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}

	public DatabaseResponse update(JdbcTemplate jdbcTemplate, CatalogoBean catalogo) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_ACATALOGO")
					.declareParameters(new SqlParameter("e_CT_ID", Types.NUMERIC),
							new SqlParameter(E_CT_FECHA_REGISTRO, Types.DATE),
							new SqlParameter(E_CT_NOMBRE, Types.VARCHAR), new SqlParameter(E_CT_ESTADO, Types.CHAR),
							new SqlParameter(E_CT_DESCRIPCION, Types.VARCHAR),
							new SqlParameter(E_CT_CODIGO, Types.VARCHAR),
							new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
							new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
							new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_CT_ID", catalogo.getId());
			source.addValue(E_CT_FECHA_REGISTRO, catalogo.getFechaRegistro());
			source.addValue(E_CT_NOMBRE, catalogo.getNombre());
			source.addValue(E_CT_ESTADO, catalogo.getEstado());
			source.addValue(E_CT_DESCRIPCION, catalogo.getDescripcion());
			source.addValue(E_CT_CODIGO, catalogo.getCodigo());
			Map<String, Object> out = simpleJdbcCall.execute(source);
			dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
			dr.setMessage((String) out.get(S_MENSAJE));
			dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}

	public PaginatedListCatalogo findAll(PaginationRequest pr, Connection conn)
			throws SQLException, NoSuchMethodException {

		StringBuilder sql = new StringBuilder();
		ResultSet rs;
		List<CatalogoBean> catalogos = null;
		PaginatedListCatalogo pagedCatalogos;
		sql.append(" { call pa_otc_gcatalogo(?,?,?,?,?) }");
		try(CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);){
			procStmt.setInt("e_size", pr.getSize());
			procStmt.setInt("e_page", pr.getPage());
			procStmt.setString("e_sort", pr.getSortBy());
			procStmt.registerOutParameter("s_totalRecord", Types.NUMERIC);
			procStmt.registerOutParameter(S_RESULT, OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rs = (ResultSet) procStmt.getObject(S_RESULT);
			if (rs != null && rs.isBeforeFirst()) {
				catalogos = catalogoBeanMapper.mapResultSetToObject(rs, CatalogoBean.class);
				pagedCatalogos = new PaginatedListCatalogo();
				pagedCatalogos.setRecordsFiltered(pr.getSize());
				pagedCatalogos.setRecordsTotal(procStmt.getBigDecimal("s_totalRecord").longValue());
				pagedCatalogos.setData(catalogos);
				rs.close();
				
				return pagedCatalogos;
			} else {
				return null;
			}

		} catch (SQLException e) {
			log.error(E_CONSULTA + e.getMessage(), e);
			throw new SQLException(E_CONSULTA + e.getMessage(), e);
		}
	}

	public CatalogoBean findById(Connection conn, Long id) throws OTCAdminException {
		List<CatalogoBean> catalogos = null;
		StringBuilder sql = new StringBuilder();
		ResultSet rset = null;
		sql.append(" { call PA_OTC_CCATALOGO_ID(?,?) }");
		try(CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);){
			procStmt.setLong("e_id ", id);
			procStmt.registerOutParameter("S_RESPUESTA", OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject("S_RESPUESTA");
			if (rset != null && rset.isBeforeFirst()) {
				catalogos = catalogoBeanMapper.mapResultSetToObject(rset, CatalogoBean.class);
				return catalogos.get(0);
			}

		} catch (Exception e) {
			log.error("Error en el proceso" + e.getMessage(), e);

		}
		return null;
	}

	public Integer countCode(JdbcTemplate jdbcTemplate, String code) {
		Integer count = null;
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_PCONTAR_CODCAT")
					.declareParameters(new SqlParameter(E_CODIGO, Types.VARCHAR),
							new SqlOutParameter("s_cantidad", Types.INTEGER));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue(E_CODIGO, code);
			Map<String, Object> out = simpleJdbcCall.execute(source);
			count = (Integer) out.get("s_cantidad");
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return count;
	}

	public DatabaseResponse delete(JdbcTemplate jdbcTemplate, Long catalogoId) throws OTCAdminException {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_ECATALOGO")
					.declareParameters(new SqlParameter("e_ct_id", Types.NUMERIC),
							new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
							new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
							new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_ct_id", catalogoId);
			Map<String, Object> out = simpleJdbcCall.execute(source);
			dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
			dr.setMessage((String) out.get(S_MENSAJE));
			dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
		} catch (Exception ex) {
			throw new RuntimeException(ex.getMessage(), ex);
		}
		return dr;
	}
	
	public List<CatalogoBean> search(Connection conn, CatalogoBusqueda busqueda) throws OTCAdminException, NoSuchMethodException {
		StringBuilder sql = new StringBuilder();
		ResultSet rset = null ;
		List<CatalogoBean> catalogos  = null;
		sql.append(" { call pa_otc_ccatalogo(?,?,?) }");
		try(CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);){
			log.info(busqueda.toString());
			procStmt.setString(E_CODIGO, busqueda.getCodigo());
			procStmt.setString("e_nombre", busqueda.getNombre());
			procStmt.registerOutParameter(S_RESULT, OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject(S_RESULT);
			if (rset.isBeforeFirst()) {
				catalogos = catalogoBeanMapper.mapResultSetToObject(rset, CatalogoBean.class);
				rset.close();
				
				return catalogos;
			} else {
				return  Collections.emptyList();
			}

		} catch (SQLException e) {
			log.error(E_CONSULTA + e.getMessage(), e);
			throw new OTCAdminException(E_CONSULTA + e.getMessage(), e);
		}
	}
}
