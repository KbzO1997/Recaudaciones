package com.bolivariano.otc.bean;

import java.io.Serializable;
import java.sql.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * The persistent class for the OTC_M_SERV_ENRIQUECIMIENTO database table.
 * 
 */
@JsonInclude(Include.NON_NULL)
public class ServicioEnriquecimientoBean implements Serializable {
	private static final long serialVersionUID = 1L;

	
	private Long id;

	private String descripcion;

	private String endpoint;

	private String estado;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/Guayaquil")
    private Date fechaRegistro;

	private String nombre;

	private String operacion;

	private List<ServicioEnriquecimientoParamBean> parametros;

	private String peticion;

	public ServicioEnriquecimientoBean() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getEndpoint() {
		return endpoint;
	}

	public void setEndpoint(String endpoint) {
		this.endpoint = endpoint;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public Date getFechaRegistro() {
		return fechaRegistro;
	}

	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getOperacion() {
		return operacion;
	}

	public void setOperacion(String operacion) {
		this.operacion = operacion;
	}

	public List<ServicioEnriquecimientoParamBean> getParametros() {
		return parametros;
	}

	public void setParametros(List<ServicioEnriquecimientoParamBean> parametros) {
		this.parametros = parametros;
	}

	public String getPeticion() {
		return peticion;
	}

	public void setPeticion(String peticion) {
		this.peticion = peticion;
	}

	@Override
	public String toString() {
		return "ServicioEnriquecimiento [id=" + id + ", descripcion=" + descripcion + ", endpoint=" + endpoint
				+ ", estado=" + estado + ", fechaRegistro=" + fechaRegistro + ", nombre=" + nombre + ", operacion="
				+ operacion + ", parametros=" + parametros + ", peticion=" + peticion + "]";
	}
}