package com.bolivariano.otc.dao;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.bolivariano.otc.MapperUtil;
import com.bolivariano.otc.bean.DatabaseResponse;
import com.bolivariano.otc.bean.ServicioCanalBean;
import com.bolivariano.otc.dto.Canal;
import com.bolivariano.otc.dto.Catalogo;
import com.bolivariano.otc.dto.Servicio;
import com.bolivariano.otc.dto.ServicioCanal;
import com.bolivariano.otc.exception.OTCAdminException;

import oracle.jdbc.OracleTypes;

@Repository
public class CanalesServicioDAO {

    private static final Logger log = LoggerFactory.getLogger(CanalesServicioDAO.class);
    private static final String MSG = "Error en el proceso: ";
    private static final String S_RESPUESTA = "S_RESPUESTA";
    private static final String E_CAN_ID = "e_CAN_ID";
    private static final String S_AFECTADOS = "s_afectados";
    private static final String S_CODIGO_ERROR = "s_codigo_error";
	private static final String S_MENSAJE = "s_mensaje";
	private static final String E_SRV_ID = "e_SRV_ID";
    
    @Autowired
    MapperUtil<Canal> selectMapper;
    
    @Autowired
    MapperUtil<ServicioCanalBean> scMapper;

    public List<ServicioCanal> obtenerCanalesServicios(Connection conn, Long idServicio) throws OTCAdminException, SQLException {

        List<ServicioCanal> sc = new ArrayList<>();
        List<Canal> canales = null;

        StringBuilder sql = new StringBuilder();
        ResultSet rset = null;
        sql.append(" { call PA_OTC_CCANALES_SERVICIO(?,?) }");
        try(CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);){
            procStmt.setLong(1, idServicio);
            procStmt.registerOutParameter(2, OracleTypes.CURSOR);
            procStmt.executeUpdate();
            rset = (ResultSet) procStmt.getObject(2);

            if (rset.isBeforeFirst()) {
                canales = selectMapper.mapResultSetToObject(rset, Canal.class);
            }

            if (canales != null && !canales.isEmpty()) {
                for (Canal canal : canales) {
                    Catalogo medio = new Catalogo();
                    medio.setCodigo(canal.getCtd_codigo());
                    canal.setMedioAcceso(medio);
                    sc.add(new ServicioCanal(new Servicio(), canal));
                }
            }

		} catch (Exception e) {
			log.error(MSG + e.getMessage(), e);
		} finally {
			if (rset != null) {
				rset.close();
			}
		}

		return sc;
	}

	public List<ServicioCanalBean> findByCanal(Connection conn, Long canalId) throws OTCAdminException, SQLException {

		List<ServicioCanalBean> canales = null;
		StringBuilder sql = new StringBuilder();
		ResultSet rset = null;
		sql.append(" { call PA_OTC_CSERVCANAL_CANAL(?,?) }");
		try(CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);){
			procStmt.setLong("e_canalId ", canalId);
			procStmt.registerOutParameter(S_RESPUESTA, OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject(S_RESPUESTA);
			if (rset.isBeforeFirst()) {
				canales = scMapper.mapResultSetToObject(rset, ServicioCanalBean.class);
				return canales;
			}
		} catch (Exception e) {
			log.error(MSG + e.getMessage(), e);

		} finally {
			if (rset != null) {
				rset.close();
			}
		}
		return Collections.emptyList();
	}
    
    public List<ServicioCanalBean> findByServicio(Connection conn, Long servicioId) throws OTCAdminException, SQLException {

		List<ServicioCanalBean> canales = null;
		StringBuilder sql = new StringBuilder();
		ResultSet rset = null;
		sql.append(" { call PA_OTC_CSERVCANAL_SERV(?,?) }");
		try(CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);){
			procStmt.setLong("e_servicioId ", servicioId);
			procStmt.registerOutParameter(S_RESPUESTA, OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject(S_RESPUESTA);
			if (rset.isBeforeFirst()) {
				canales = scMapper.mapResultSetToObject(rset, ServicioCanalBean.class);
				return canales;
			}		
		} catch (Exception e) {
			log.error(MSG + e.getMessage(), e);

		}finally {
			if (rset != null) {
				rset.close();
			}
		}
		return Collections.emptyList();
	}
    
    public DatabaseResponse insert(JdbcTemplate jdbcTemplate, ServicioCanalBean canal) {
  		DatabaseResponse dr = new DatabaseResponse();
  		try {
  			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_ISRVCANAL")
  					.declareParameters(new SqlParameter(E_CAN_ID, Types.VARCHAR),
  							new SqlParameter(E_SRV_ID, Types.VARCHAR), 
  							new SqlOutParameter("s_secuencia", Types.NUMERIC),
  							new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
  							new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
  							new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
  			MapSqlParameterSource source = new MapSqlParameterSource();
  			source.addValue(E_CAN_ID, canal.getCanalId());
  			source.addValue(E_SRV_ID, canal.getServicioId());	
  			Map<String, Object> out = simpleJdbcCall.execute(source);			
  			dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
  			dr.setMessage((String) out.get(S_MENSAJE));
  			dr.setSequence((BigDecimal) out.get("s_secuencia"));
  			dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
  		} catch (Exception ex) {
  			log.error(ex.getMessage(), ex);
  		}
  		return dr;
  	}
    
    public DatabaseResponse delete(JdbcTemplate jdbcTemplate, ServicioCanalBean canal) {
  		DatabaseResponse dr = new DatabaseResponse();
  		try {
  			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_ESRVCANAL")
  					.declareParameters(new SqlParameter(E_CAN_ID, Types.VARCHAR),
  							new SqlParameter(E_SRV_ID, Types.VARCHAR), 
  							new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
  							new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
  							new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
  			MapSqlParameterSource source = new MapSqlParameterSource();
  			source.addValue(E_CAN_ID, canal.getCanalId());
  			source.addValue(E_SRV_ID, canal.getServicioId());	
  			Map<String, Object> out = simpleJdbcCall.execute(source);			
  			dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
  			dr.setMessage((String) out.get(S_MENSAJE));
  			dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
  		} catch (Exception ex) {
  			log.error(ex.getMessage(), ex);
  		}
  		return dr;
  	}

}
