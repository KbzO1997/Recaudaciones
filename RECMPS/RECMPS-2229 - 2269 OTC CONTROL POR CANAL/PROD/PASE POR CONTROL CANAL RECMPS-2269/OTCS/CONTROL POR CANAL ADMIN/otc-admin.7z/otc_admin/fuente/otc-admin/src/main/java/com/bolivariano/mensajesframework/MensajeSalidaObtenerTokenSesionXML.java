
package com.bolivariano.mensajesframework;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.bolivariano.mensajebolivariano.MensajeSalida;


/**
 * <p>Java class for MensajeSalidaObtenerTokenSesionXML complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MensajeSalidaObtenerTokenSesionXML">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.bolivariano.com/MensajeBolivariano}MensajeSalida">
 *       &lt;sequence>
 *         &lt;element name="token" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="semilla" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="longitudToken" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MensajeSalidaObtenerTokenSesionXML", propOrder = {
    "token",
    "semilla",
    "longitudToken"
})
public class MensajeSalidaObtenerTokenSesionXML
    extends MensajeSalida
{

    protected String token;
    protected String semilla;
    protected Integer longitudToken;

    /**
     * Gets the value of the token property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getToken() {
        return token;
    }

    /**
     * Sets the value of the token property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setToken(String value) {
        this.token = value;
    }

    /**
     * Gets the value of the semilla property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSemilla() {
        return semilla;
    }

    /**
     * Sets the value of the semilla property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSemilla(String value) {
        this.semilla = value;
    }

    /**
     * Gets the value of the longitudToken property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getLongitudToken() {
        return longitudToken;
    }

    /**
     * Sets the value of the longitudToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setLongitudToken(Integer value) {
        this.longitudToken = value;
    }

}
