package com.bolivariano.otc.dao;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.bolivariano.otc.MapperUtil;
import com.bolivariano.otc.bean.DatabaseResponse;
import com.bolivariano.otc.bean.ServicioEnriquecimientoParamBean;
import com.bolivariano.otc.dto.ServicioEnriquecimientoParam;
import com.bolivariano.otc.enumerators.RegisterStatus;
import com.bolivariano.otc.exception.OTCAdminException;

import oracle.jdbc.OracleTypes;

@Repository
public class EnriquecimientoParamDAO {

	private static final Logger log = LoggerFactory.getLogger(EnriquecimientoParamDAO.class);
	
	private static final String E_ESP_ESTADO = "e_ESP_ESTADO";
	private static final String E_ESP_FECHA_REGISTRO = "e_ESP_FECHA_REGISTRO";
	private static final String E_ESP_ALIAS = "e_ESP_ALIAS";	
	private static final String E_ES_ID = "e_ES_ID";
	private static final String S_SECUENCIA = "s_secuencia";
	private static final String S_AFECTADOS = "s_afectados";	
	private static final String S_CODIGO_ERROR = "s_codigo_error";
	private static final String S_MENSAJE = "s_mensaje";
	private static final String E_ESP_TIPO = "e_ESP_TIPO";
	
	private static final String MSG = "Error en el proceso: ";

	@Autowired
	MapperUtil<ServicioEnriquecimientoParam> selectMapper;

	@Autowired
	MapperUtil<ServicioEnriquecimientoParamBean> parametroMapper;

	public List<ServicioEnriquecimientoParam> obtenerEnriquecimientoParams(Connection conn, Long idEnriquecimiento)
			throws OTCAdminException, SQLException {

		List<ServicioEnriquecimientoParam> enriqParams = null;
		StringBuilder sql = new StringBuilder();
		ResultSet rset = null;
		sql.append(" { call PA_OTC_CENRIQ_PARAM(?,?) }");
			try(CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);){
			procStmt.setLong(1, idEnriquecimiento);
			procStmt.registerOutParameter(2, OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject(2);

			if (rset.isBeforeFirst()) {
				enriqParams = selectMapper.mapResultSetToObject(rset, ServicioEnriquecimientoParam.class);
			}

		} catch (Exception e) {
			log.error("Error en el proceso" + e.getMessage(), e);
		}finally {
			if (rset != null) {
				rset.close();
			}
		}

		return enriqParams;
	}

	public DatabaseResponse insert(JdbcTemplate jdbcTemplate, ServicioEnriquecimientoParamBean parametro) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_ISRVENRPARAM")
					.declareParameters(new SqlParameter(E_ESP_ESTADO, Types.VARCHAR),
							new SqlParameter(E_ESP_FECHA_REGISTRO, Types.DATE),
							new SqlParameter(E_ESP_ALIAS, Types.VARCHAR), new SqlParameter(E_ESP_TIPO, Types.CHAR),
							new SqlParameter(E_ES_ID, Types.NUMERIC),
							new SqlOutParameter(S_SECUENCIA, Types.NUMERIC),
							new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
							new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
							new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue(E_ESP_ESTADO, RegisterStatus.Activo.getValue());
			source.addValue(E_ESP_FECHA_REGISTRO, Date.valueOf(LocalDate.now()));
			source.addValue(E_ESP_ALIAS, parametro.getAlias());
			source.addValue(E_ESP_TIPO, parametro.getTipo());
			source.addValue(E_ES_ID, parametro.getEnriquecimientoId());
			Map<String, Object> out = simpleJdbcCall.execute(source);
			dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
			dr.setMessage((String) out.get(S_MENSAJE));
			dr.setSequence((BigDecimal) out.get(S_SECUENCIA));
			dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}

	public DatabaseResponse update(JdbcTemplate jdbcTemplate, ServicioEnriquecimientoParamBean parametro) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_ASRVENRPARAM")
					.declareParameters(new SqlParameter(E_ESP_ESTADO, Types.VARCHAR),
							new SqlParameter(E_ESP_FECHA_REGISTRO, Types.DATE),
							new SqlParameter(E_ESP_ALIAS, Types.VARCHAR), new SqlParameter(E_ESP_TIPO, Types.CHAR),
							new SqlParameter(E_ES_ID, Types.NUMERIC), new SqlParameter("e_ESP_ID", Types.NUMERIC),
							new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
							new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
							new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue(E_ESP_ESTADO, parametro.getEstado());
			source.addValue(E_ESP_FECHA_REGISTRO, parametro.getFechaRegistro());
			source.addValue(E_ESP_ALIAS, parametro.getAlias());
			source.addValue(E_ESP_TIPO, parametro.getTipo());
			source.addValue(E_ES_ID, parametro.getEnriquecimientoId());
			source.addValue("e_ESP_ID", parametro.getId());
			Map<String, Object> out = simpleJdbcCall.execute(source);
			dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
			dr.setMessage((String) out.get(S_MENSAJE));
			dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}

	public List<ServicioEnriquecimientoParamBean> findByEnrichmentService(Connection conn, Long enriquecimientoId)
			throws OTCAdminException, SQLException {

		List<ServicioEnriquecimientoParamBean> params = null;
		StringBuilder sql = new StringBuilder();
		ResultSet rset = null;
		sql.append(" { call PA_OTC_CSRVENRPARAM_SRVENR(?,?) }");
		try(CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);){
			procStmt.setLong("e_enriquecimientoId ", enriquecimientoId);
			procStmt.registerOutParameter("S_RESPUESTA", OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject("S_RESPUESTA");
			if (rset != null && rset.isBeforeFirst()) {
				params = parametroMapper.mapResultSetToObject(rset, ServicioEnriquecimientoParamBean.class);
				return params;
			}

		} catch (Exception e) {
			log.error(MSG + e.getMessage(), e);

		} finally {
			if (rset != null) {
				rset.close();
			}
		}
		return params;
	}
	
	 public DatabaseResponse delete(JdbcTemplate jdbcTemplate, Long parametroId) throws OTCAdminException {
			DatabaseResponse dr = new DatabaseResponse();
			try {
				SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_ESRVENRPARAM")
						.declareParameters(new SqlParameter("e_esp_id", Types.NUMERIC),
								new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
								new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
								new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
				MapSqlParameterSource source = new MapSqlParameterSource();
				source.addValue("e_esp_id", parametroId);
				Map<String, Object> out = simpleJdbcCall.execute(source);
				dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
				dr.setMessage((String) out.get(S_MENSAJE));
				dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
			} catch (Exception ex) {
				throw new OTCAdminException(ex.getMessage(), ex);
			}
			return dr;
		}
}
