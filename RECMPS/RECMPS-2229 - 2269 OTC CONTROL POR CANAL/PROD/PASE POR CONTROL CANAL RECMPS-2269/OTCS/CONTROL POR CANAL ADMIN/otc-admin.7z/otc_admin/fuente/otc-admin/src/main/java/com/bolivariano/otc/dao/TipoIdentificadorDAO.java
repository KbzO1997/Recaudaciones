package com.bolivariano.otc.dao;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.bolivariano.otc.MapperUtil;
import com.bolivariano.otc.bean.DatabaseResponse;
import com.bolivariano.otc.bean.TipoIdentificadorBean;
import com.bolivariano.otc.dto.TipoIdentificador;
import com.bolivariano.otc.exception.OTCAdminException;

import oracle.jdbc.OracleTypes;

@Repository
public class TipoIdentificadorDAO {

    private static final Logger log = LoggerFactory.getLogger(TipoIdentificadorDAO.class);
    private static final String E_TID_MATRICULABLE = "e_TID_MATRICULABLE";
    private static final String E_TID_TEXTO_AYUDA = "e_TID_TEXTO_AYUDA";
    private static final String E_TID_PROGRAMABLE = "e_TID_PROGRAMABLE";
    private static final String E_TID_CODIGO = "e_TID_CODIGO";
    private static final String E_TID_ETIQUETA_CODIGO = "e_TID_ETIQUETA_CODIGO";
    private static final String E_CNV_ID = "e_CNV_ID";
    private static final String E_TID_MASCARA = "e_TID_MASCARA";
    private static final String E_TID_FLUJO_AYUDA = "e_TID_FLUJO_AYUDA";
    private static final String E_TID_CONCAT_REGIONAL_AREA = "e_TID_CONCAT_REGIONAL_AREA";
    private static final String E_TID_REGEXP = "e_TID_REGEXP";    
	private static final String S_AFECTADOS = "s_afectados";
	private static final String S_CODIGO_ERROR = "s_codigo_error";
	private static final String S_MENSAJE = "s_mensaje";

    @Autowired
    MapperUtil<TipoIdentificador> selectMapper;
    
    @Autowired
    MapperUtil<TipoIdentificadorBean> identificadorMapper;


    public List<TipoIdentificador> obtenerTiposIdentificadorConvenio(Connection conn, Long idConvenio) throws OTCAdminException, SQLException {

        List<TipoIdentificador> tipos = null;
        StringBuilder sql = new StringBuilder();
        ResultSet rset = null;
        sql.append(" { call PA_OTC_CTIPOIND_CONV(?,?) }");
        try(CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);){
            procStmt.setLong(1, idConvenio);
            procStmt.registerOutParameter(2, OracleTypes.CURSOR);
            procStmt.executeUpdate();
            rset = (ResultSet) procStmt.getObject(2);

            if (rset.isBeforeFirst()) {
                tipos = selectMapper.mapResultSetToObject(rset, TipoIdentificador.class);
            }

        } catch (Exception e) {
            log.error("Error en el proceso" + e.getMessage(), e);
        } finally {
            if (rset != null) {
                rset.close();
            }
        }
        
        return tipos;
    }
    
    public DatabaseResponse insert(JdbcTemplate jdbcTemplate, TipoIdentificadorBean convenio) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_ITIPOIDE")
					.declareParameters(new SqlParameter(E_TID_MATRICULABLE, Types.NUMERIC),
							new SqlParameter(E_TID_TEXTO_AYUDA, Types.VARCHAR), 
							new SqlParameter(E_TID_PROGRAMABLE, Types.NUMERIC),
							new SqlParameter(E_TID_CODIGO, Types.VARCHAR),
							new SqlParameter(E_TID_ETIQUETA_CODIGO, Types.VARCHAR),
							new SqlParameter(E_CNV_ID, Types.NUMERIC),
							new SqlParameter(E_TID_MASCARA, Types.VARCHAR),							
							new SqlParameter(E_TID_FLUJO_AYUDA, Types.VARCHAR),
							new SqlParameter(E_TID_CONCAT_REGIONAL_AREA, Types.VARCHAR),
							new SqlParameter(E_TID_REGEXP, Types.VARCHAR),
							new SqlOutParameter("s_secuencia", Types.NUMERIC),
							new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
							new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
							new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue(E_TID_MATRICULABLE, convenio.getMatriculable());
			source.addValue(E_TID_TEXTO_AYUDA, convenio.getTextoAyuda());
			source.addValue(E_TID_PROGRAMABLE, convenio.getProgramable());
			source.addValue(E_TID_ETIQUETA_CODIGO, convenio.getEtiquetaCodigo());
			source.addValue(E_TID_CODIGO, convenio.getCodigo());
			source.addValue(E_CNV_ID, convenio.getConvenioId());
			source.addValue(E_TID_MASCARA, convenio.getMascara());
			source.addValue(E_TID_FLUJO_AYUDA, convenio.getFlujoAyuda());
			source.addValue(E_TID_CONCAT_REGIONAL_AREA, convenio.getConcatenadorRegionalArea());
			source.addValue(E_TID_REGEXP, convenio.getRegexp());
			Map<String, Object> out = simpleJdbcCall.execute(source);
			
			dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
			dr.setMessage((String) out.get(S_MENSAJE));
			dr.setSequence((BigDecimal) out.get("s_secuencia"));
			dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}
    
    public DatabaseResponse update(JdbcTemplate jdbcTemplate, TipoIdentificadorBean convenio) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_ATIPOIDE")
					.declareParameters(new SqlParameter(E_TID_MATRICULABLE, Types.NUMERIC),
							new SqlParameter(E_TID_TEXTO_AYUDA, Types.VARCHAR), 
							new SqlParameter(E_TID_PROGRAMABLE, Types.NUMERIC),
							new SqlParameter(E_TID_CODIGO, Types.VARCHAR),
							new SqlParameter(E_TID_ETIQUETA_CODIGO, Types.VARCHAR),
							new SqlParameter(E_CNV_ID, Types.NUMERIC),
							new SqlParameter(E_TID_MASCARA, Types.VARCHAR),							
							new SqlParameter(E_TID_FLUJO_AYUDA, Types.VARCHAR),
							new SqlParameter(E_TID_CONCAT_REGIONAL_AREA, Types.VARCHAR),
							new SqlParameter(E_TID_REGEXP, Types.VARCHAR),
							new SqlParameter("e_TID_ID", Types.NUMERIC),
							new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
							new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
							new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue(E_TID_MATRICULABLE, convenio.getMatriculable());
			source.addValue(E_TID_TEXTO_AYUDA, convenio.getTextoAyuda());
			source.addValue(E_TID_PROGRAMABLE, convenio.getProgramable());
			source.addValue(E_TID_ETIQUETA_CODIGO, convenio.getEtiquetaCodigo());
			source.addValue(E_TID_CODIGO, convenio.getCodigo());
			source.addValue(E_CNV_ID, convenio.getConvenioId());
			source.addValue(E_TID_MASCARA, convenio.getMascara());
			source.addValue(E_TID_FLUJO_AYUDA, convenio.getFlujoAyuda());
			source.addValue(E_TID_CONCAT_REGIONAL_AREA, convenio.getConcatenadorRegionalArea());
			source.addValue(E_TID_REGEXP, convenio.getRegexp());
			source.addValue("e_TID_ID", convenio.getId());
			Map<String, Object> out = simpleJdbcCall.execute(source);
			
			dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
			dr.setMessage((String) out.get(S_MENSAJE));
			dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}
    
    public List<TipoIdentificadorBean> findByConvenioId(Connection conn, Long convenioId) throws OTCAdminException, SQLException {

        List<TipoIdentificadorBean> identificadores = null;
        StringBuilder sql = new StringBuilder();
        ResultSet rset = null;
        sql.append(" { call PA_OTC_CTIPOIDE_CNV(?,?) }");
        try(CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);){
            procStmt.setLong("e_convenioId", convenioId);
            procStmt.registerOutParameter("S_RESPUESTA", OracleTypes.CURSOR);
            procStmt.executeUpdate();
            rset = (ResultSet) procStmt.getObject("S_RESPUESTA");

            if (rset!= null && rset.isBeforeFirst()) {
                identificadores = identificadorMapper.mapResultSetToObject(rset, TipoIdentificadorBean.class);
            }

        } catch (Exception e) {
            log.error("Error al consultar identificadores: " + e.getMessage(),e);
        } finally {
            if (rset != null) {
                rset.close();
            }
        }
        return identificadores;
    }
    
	public DatabaseResponse delete(JdbcTemplate jdbcTemplate, Long canalId) throws OTCAdminException {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_ETIPOID")
					.declareParameters(new SqlParameter("e_tid_id", Types.NUMERIC),
							new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
							new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
							new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_tid_id", canalId);
			Map<String, Object> out = simpleJdbcCall.execute(source);
			dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
			dr.setMessage((String) out.get(S_MENSAJE));
			dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
		} catch (Exception ex) {
			throw new OTCAdminException(ex.getMessage(), ex);
		}
		return dr;
	}
}
