package com.bolivariano.otc.web.rest;

import com.bolivariano.otc.bean.*;
import com.bolivariano.otc.exception.OTCAdminException;
import com.bolivariano.otc.service.CanalService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import java.math.BigDecimal;
import java.util.List;

@Component
@Path("/admin/v1/canal")
public class CanalRest {

    @Autowired
    CanalService canalService;

    private static final Logger log = LoggerFactory.getLogger(CanalRest.class);


    @POST
    @Path("/save")
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response insert(CanalBean canal) {
        DatabaseResponse dr = new DatabaseResponse();
        try {
            log.info("insert: Peticion recibida");
            dr = canalService.insert(canal);
            if (dr.getSqlCode().intValue() == 0 && dr.getAffectedRows().intValue() > 0 && dr.getSequence().intValue() > 0) {
                return Response.status(Status.OK).entity(dr).build();
            } else {
                return Response.status(Status.ACCEPTED).entity(dr).build();
            }
        } catch (Exception ex) {
            dr.setMessage(ex.getMessage());
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(dr).build();
        }

    }

    @POST
    @Path("/update")
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response update(CanalBean canal) {
        DatabaseResponse dr = new DatabaseResponse();
        try {
            log.info("update: Peticion recibida");
            dr = canalService.update(canal);
            log.info(dr.toString());
            if (dr.getSqlCode().intValue() == 0 && dr.getAffectedRows().intValue() > 0) {
                return Response.status(Status.OK).entity(dr).build();
            } else {
                return Response.status(Status.ACCEPTED).entity(dr).build();
            }
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            dr.setMessage(ex.getMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(dr).build();
        }
    }


    @POST
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response findAll(PaginationRequest pr) {
        log.info("findAll: Petición Recibida");
        try {
            return Response.status(Status.OK).entity(this.canalService.findAll(pr)).build();
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response findById(@PathParam("id") Long id) {
        log.info("findById: Petición Recibida");
        try {
            CanalBean canal = this.canalService.findById(id);
            if (canal == null) {
                return Response.status(Status.NO_CONTENT).entity(null).build();
            }
            return Response.status(Status.OK).entity(canal).build();
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }

    @GET
    @Path("/select-canales")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response findSelects() {
        log.info("findSelects: Petición Recibida");
        try {
            List<SelectItemBean> canales = this.canalService.findSelects();
            if (canales == null) {
                return Response.status(Status.NO_CONTENT).entity(null).build();
            }
            return Response.status(Status.OK).entity(canales).build();
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }

    @POST
    @Path("/delete")
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response delete(@QueryParam("id") Long id) throws OTCAdminException {
        DatabaseResponse dr = new DatabaseResponse();
        log.info("delete: Peticion recibida");
        dr = canalService.delete(id);
        return Response.status(Status.OK).entity(dr).build();
    }

    @POST
    @Path("/search")
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response search(CanalBusqueda busqueda) {
        List<CanalBean> canales = null;
        try {
            log.info("search: Peticion recibida" + busqueda);
            canales = canalService.search(busqueda);
            if (canales == null) {
                return Response.status(Status.NO_CONTENT).entity(null).build();
            } else {
                return Response.status(Status.OK).entity(canales).build();
            }
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }


    @GET
    @Path("/count-code")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response countCode(@QueryParam("code") String code) {
        log.info("countCode: Petición Recibida");
        try {
            Integer count = this.canalService.countCode(code);
            if (count == null) {
                return Response.status(Status.NO_CONTENT).entity(null).build();
            }
            return Response.status(Status.OK).entity(count).build();
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }

    @POST
    @Path("/delete-many")
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response deleteMany(Long... ids) throws OTCAdminException {
        List<DatabaseResponse> responses = canalService.deleteMany(ids);
        DatabaseResponse dr = new DatabaseResponse();

        String errorMsg = "El canal %id no fue eliminado: %msg \b";
        StringBuilder errorMsgs = new StringBuilder();
        boolean error = false;

        for (DatabaseResponse drAux : responses) {
            if (drAux.getSqlCode().longValue() != 0L) {
                error = true;
                errorMsgs.append(errorMsg.replace("%id", drAux.getSequence().toString()).replace("%msg", drAux.getMessage()));
            }
        }
        dr.setSqlCode(!error ? new BigDecimal(0) : new BigDecimal(100));
        dr.setMessage(!error ? "Transacción Exitosa" : errorMsgs.toString());

        return Response.status(Status.OK).entity(dr).build();
    }


}
