package com.bolivariano.otc.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.bolivariano.otc.bean.SelectItemBean;
import com.bolivariano.otc.dao.ServicioDAO;

@Service
public class ServiceService {
	
	
	private static final Logger log = LoggerFactory.getLogger(ServiceService.class);

	
	@Autowired
	ServicioDAO servicioDAO;
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	
	public List<SelectItemBean> findSelects() throws Exception {
		List<SelectItemBean> empresas = null;
		try {
			empresas = servicioDAO.findSelects(jdbcTemplate.getDataSource().getConnection());
			return empresas;
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
			throw new Exception(ex.getMessage());
		}
	}
}
