package com.bolivariano.otc.exception;

public class ConverterRuntimeException extends RuntimeException{
	private static final long serialVersionUID = -7100096136236248627L;

	public ConverterRuntimeException(final String arg0, final Throwable arg1) {
		super(arg0, arg1);
	}

	public ConverterRuntimeException(final String arg0) {
		super(arg0);
	}

	public ConverterRuntimeException(final Throwable arg0) {
		super(arg0);
	}
}
