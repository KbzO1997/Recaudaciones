package com.bolivariano.otc.exception;

public class BusinessException  extends Exception {
    
	private static final long serialVersionUID = 4310021852492720239L;
	public BusinessException(String message){
        super(message);
    }
    public BusinessException(Throwable cause){
        super(cause);
    }
}