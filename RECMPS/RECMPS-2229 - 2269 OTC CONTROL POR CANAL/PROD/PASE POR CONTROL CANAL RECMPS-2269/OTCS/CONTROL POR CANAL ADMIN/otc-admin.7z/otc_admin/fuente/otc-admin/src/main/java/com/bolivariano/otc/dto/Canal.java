package com.bolivariano.otc.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;


public class Canal implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long id;

	private String codigo;

	private String descripcion;

	private Catalogo medioAcceso;

	@JsonIgnore
	private String ctd_codigo;

	public String getCtd_codigo() {
		return ctd_codigo;
	}

	public void setCtd_codigo(String ctd_codigo) {
		this.ctd_codigo = ctd_codigo;
	}

	private String nombre;

	public Canal() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Catalogo getMedioAcceso() {
		return medioAcceso;
	}

	public void setMedioAcceso(Catalogo medioAcceso) {
		this.medioAcceso = medioAcceso;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
}