package com.bolivariano.otc.bean;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.io.Serializable;

/**
 * The persistent class for the OTC_D_FORMA_PAGO database table.
 *
 */

@JsonInclude(Include.NON_NULL)
public class FormaPagoBean implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long id;

	private String nombre;

	private Double interes;

	private Integer cuotas;

	private String medio;

	private String etiqueta;

	private Long convenioId;

	private Long tipoId;
	
	private String estado;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Double getInteres() {
		return interes;
	}

	public void setInteres(Double interes) {
		this.interes = interes;
	}

	public Integer getCuotas() {
		return cuotas;
	}

	public void setCuotas(Integer cuotas) {
		this.cuotas = cuotas;
	}

	public String getMedio() {
		return medio;
	}

	public void setMedio(String medio) {
		this.medio = medio;
	}

	public String getEtiqueta() {
		return etiqueta;
	}

	public void setEtiqueta(String etiqueta) {
		this.etiqueta = etiqueta;
	}

	public Long getConvenioId() {
		return convenioId;
	}

	public void setConvenioId(Long convenioId) {
		this.convenioId = convenioId;
	}
	
	public Long getTipoId() {
		return tipoId;
	}

	public void setTipoId(Long tipoId) {
		this.tipoId = tipoId;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	@Override
	public String toString() {
		return "FormaPagoBean [id=" + id + ", nombre=" + nombre + ", interes=" + interes + ", cuotas=" + cuotas
				+ ", medio=" + medio + ", etiqueta=" + etiqueta + ", convenioId=" + convenioId + ", tipoId=" + tipoId
				+ ", estado=" + estado + "]";
	}

}