@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.bolivariano.com/FrameworkSeguridadTypes", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.bolivariano.frameworkseguridadtypes;
