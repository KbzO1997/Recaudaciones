package com.bolivariano.otc.bean;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;


/**
 * The persistent class for the OTC_M_CATALOGO database table.
 * 
 */

public class DetalleCatalogoBean implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long id;

	private String descripcion;

	private String estado;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/Guayaquil")

    private Date fechaRegistro;

	private String nombre;

	private String codigo;
	
	private Long catalogoId;


	public Long getCatalogoId() {
		return catalogoId;
	}

	public void setCatalogoId(Long catalogoId) {
		this.catalogoId = catalogoId;
	}

	public DetalleCatalogoBean() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public Date getFechaRegistro() {
		return fechaRegistro;
	}

	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	@Override
	public String toString() {
		return "DetalleCatalogoBean [id=" + id + ", descripcion=" + descripcion + ", estado=" + estado
				+ ", fechaRegistro=" + fechaRegistro + ", nombre=" + nombre + ", codigo=" + codigo + ", catalogoId="
				+ catalogoId + "]";
	}
}