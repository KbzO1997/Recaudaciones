
package com.bolivariano.frameworkseguridadtypes;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for LoginAplicacionType_out complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LoginAplicacionType_out">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="CodError" type="{http://www.w3.org/2001/XMLSchema}integer" />
 *       &lt;attribute name="MsgError" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="PS_UsrSitio" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="PS_TokenSitio" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="PS_MaqSitio" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="PS_IdUsuario" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="PS_Token" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="PS_Maquina" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="PS_Parametros" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LoginAplicacionType_out")
public class LoginAplicacionTypeOut {

    @XmlAttribute(name = "CodError")
    protected BigInteger codError;
    @XmlAttribute(name = "MsgError")
    protected String msgError;
    @XmlAttribute(name = "PS_UsrSitio")
    protected String psUsrSitio;
    @XmlAttribute(name = "PS_TokenSitio")
    protected String psTokenSitio;
    @XmlAttribute(name = "PS_MaqSitio")
    protected String psMaqSitio;
    @XmlAttribute(name = "PS_IdUsuario")
    protected String psIdUsuario;
    @XmlAttribute(name = "PS_Token")
    protected String psToken;
    @XmlAttribute(name = "PS_Maquina")
    protected String psMaquina;
    @XmlAttribute(name = "PS_Parametros")
    protected String psParametros;

    /**
     * Gets the value of the codError property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCodError() {
        return codError;
    }

    /**
     * Sets the value of the codError property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCodError(BigInteger value) {
        this.codError = value;
    }

    /**
     * Gets the value of the msgError property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMsgError() {
        return msgError;
    }

    /**
     * Sets the value of the msgError property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMsgError(String value) {
        this.msgError = value;
    }

    /**
     * Gets the value of the psUsrSitio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPSUsrSitio() {
        return psUsrSitio;
    }

    /**
     * Sets the value of the psUsrSitio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPSUsrSitio(String value) {
        this.psUsrSitio = value;
    }

    /**
     * Gets the value of the psTokenSitio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPSTokenSitio() {
        return psTokenSitio;
    }

    /**
     * Sets the value of the psTokenSitio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPSTokenSitio(String value) {
        this.psTokenSitio = value;
    }

    /**
     * Gets the value of the psMaqSitio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPSMaqSitio() {
        return psMaqSitio;
    }

    /**
     * Sets the value of the psMaqSitio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPSMaqSitio(String value) {
        this.psMaqSitio = value;
    }

    /**
     * Gets the value of the psIdUsuario property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPSIdUsuario() {
        return psIdUsuario;
    }

    /**
     * Sets the value of the psIdUsuario property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPSIdUsuario(String value) {
        this.psIdUsuario = value;
    }

    /**
     * Gets the value of the psToken property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPSToken() {
        return psToken;
    }

    /**
     * Sets the value of the psToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPSToken(String value) {
        this.psToken = value;
    }

    /**
     * Gets the value of the psMaquina property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPSMaquina() {
        return psMaquina;
    }

    /**
     * Sets the value of the psMaquina property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPSMaquina(String value) {
        this.psMaquina = value;
    }

    /**
     * Gets the value of the psParametros property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPSParametros() {
        return psParametros;
    }

    /**
     * Sets the value of the psParametros property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPSParametros(String value) {
        this.psParametros = value;
    }

}
