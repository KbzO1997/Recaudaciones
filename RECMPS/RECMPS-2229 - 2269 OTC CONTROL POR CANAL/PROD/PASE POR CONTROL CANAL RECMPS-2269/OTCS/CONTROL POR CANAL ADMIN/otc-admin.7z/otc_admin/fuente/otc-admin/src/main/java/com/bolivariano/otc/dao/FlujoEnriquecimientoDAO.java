package com.bolivariano.otc.dao;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.bolivariano.otc.MapperUtil;
import com.bolivariano.otc.bean.DatabaseResponse;
import com.bolivariano.otc.bean.FlujoEnriquecimientoBean;
import com.bolivariano.otc.exception.OTCAdminException;

import oracle.jdbc.OracleTypes;

@Repository
public class FlujoEnriquecimientoDAO {
	
	private static final Logger log = LoggerFactory.getLogger(FlujoEnriquecimientoDAO.class);
	private static final String E_FLU_ID = "e_FLU_ID";
	private static final String E_ES_ID = "e_ES_ID";
	private static final String S_AFECTADOS = "s_afectados";
	private static final String S_CODIGO_ERROR = "s_codigo_error";
	private static final String S_MENSAJE = "s_mensaje";

    @Autowired
    MapperUtil<FlujoEnriquecimientoBean> flujoMapper;
   
    public DatabaseResponse insert(JdbcTemplate jdbcTemplate, FlujoEnriquecimientoBean flujo) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_IFLUJOSRV")
					.declareParameters(new SqlParameter(E_FLU_ID, Types.NUMERIC),
							new SqlParameter(E_ES_ID, Types.NUMERIC), 
							new SqlOutParameter("s_secuencia", Types.NUMERIC),
							new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
							new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
							new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue(E_FLU_ID, flujo.getFlujoId());
			source.addValue(E_ES_ID, flujo.getEnriquecimientoId());
			Map<String, Object> out = simpleJdbcCall.execute(source);
			
			dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
			dr.setMessage((String) out.get(S_MENSAJE));
			dr.setSequence((BigDecimal) out.get("s_secuencia"));
			dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}
    
    public DatabaseResponse update(JdbcTemplate jdbcTemplate, FlujoEnriquecimientoBean flujo) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_AFLUJOSRV")
					.declareParameters(new SqlParameter(E_FLU_ID, Types.NUMERIC),
							new SqlParameter(E_ES_ID, Types.NUMERIC), 
							new SqlParameter("e_FSE_ID", Types.NUMERIC),
							new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
							new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
							new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue(E_FLU_ID, flujo.getFlujoId());
			source.addValue(E_ES_ID, flujo.getEnriquecimientoId());
			source.addValue("e_FSE_ID", flujo.getId());

			Map<String, Object> out = simpleJdbcCall.execute(source);
			
			dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
			dr.setMessage((String) out.get(S_MENSAJE));
			dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}
		
    public List<FlujoEnriquecimientoBean> findByFlujo(Connection conn, Long flujoId) throws OTCAdminException, SQLException {

        List<FlujoEnriquecimientoBean> flujos = null;
        StringBuilder sql = new StringBuilder();
        ResultSet rset = null;
        sql.append(" { call PA_OTC_CFLUJOSERV_FLU(?,?) }");
        try(CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);){
            procStmt.setLong("e_flujoId", flujoId);
            procStmt.registerOutParameter("S_RESPUESTA", OracleTypes.CURSOR);
            procStmt.executeUpdate();
            rset = (ResultSet) procStmt.getObject("S_RESPUESTA");

            if (rset!= null && rset.isBeforeFirst()) {
                flujos = flujoMapper.mapResultSetToObject(rset, FlujoEnriquecimientoBean.class);
            }

		} catch (Exception e) {
			log.error("Error al consultar identificadores: " + e.getMessage(), e);
		} finally {
			if (rset != null) {
				rset.close();
			}
		}
		return flujos;
	}

	public DatabaseResponse delete(JdbcTemplate jdbcTemplate, Long endpointId) throws OTCAdminException{
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_EFLUJOENR")
					.declareParameters(new SqlParameter("e_fse_id", Types.NUMERIC),
							new SqlOutParameter("s_afectados", Types.INTEGER),
							new SqlOutParameter("s_codigo_error", Types.NUMERIC),
							new SqlOutParameter("s_mensaje", Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_fse_id", endpointId);
			Map<String, Object> out = simpleJdbcCall.execute(source);
			dr.setAffectedRows((Integer) out.get("s_afectados"));
			dr.setMessage((String) out.get("s_mensaje"));
			dr.setSqlCode((BigDecimal) out.get("s_codigo_error"));
		} catch (Exception ex) {
			throw new OTCAdminException(ex.getMessage(), ex);
		}
		return dr;
	}

}
