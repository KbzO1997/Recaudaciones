package com.bolivariano.otc.service;

import com.bolivariano.otc.bean.*;
import com.bolivariano.otc.dao.PuntoFinalDAO;
import com.bolivariano.otc.exception.OTCAdminException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Service
public class PuntoFinalService {

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Autowired
    PuntoFinalDAO puntoFinalDAO;

    private static final Logger log = LoggerFactory.getLogger(PuntoFinalService.class);

    @Transactional(propagation = Propagation.REQUIRED)
    public DatabaseResponse insert(PuntoFinalBean endpoint) throws Exception {
        DatabaseResponse dr = null;
        try {
            dr = puntoFinalDAO.insert(jdbcTemplate, endpoint);
            return dr;
        } catch (Exception ex) {
            throw new Exception(ex.getMessage());
        }
    }

    @Transactional(propagation = Propagation.REQUIRED)
    public DatabaseResponse update(PuntoFinalBean endpoint) throws Exception {
        DatabaseResponse dr = null;
        try {
            dr = puntoFinalDAO.update(jdbcTemplate, endpoint);
            return dr;
        } catch (Exception ex) {
            throw new Exception(ex.getMessage());
        }
    }

    public PaginatedListPuntoFinal findAll(PaginationRequest pr) throws Exception {

        PaginatedListPuntoFinal pagedEndpoints = null;
        if (pr.getSortBy() == null || pr.getSortBy().isEmpty())
            pr.setSortBy("id");
        try {
            pagedEndpoints = puntoFinalDAO.findAll(pr, jdbcTemplate.getDataSource().getConnection());
            return pagedEndpoints;

        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new Exception(ex.getMessage());
        }
    }

    public PuntoFinalBean findById(Long id) throws Exception {
        PuntoFinalBean endpoint = null;
        try {
            endpoint = puntoFinalDAO.findById(jdbcTemplate.getDataSource().getConnection(), id);
            return endpoint;

        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new Exception(ex.getMessage());
        }
    }

    public List<SelectItemBean> findSelects() throws Exception {
        List<SelectItemBean> empresas = null;
        try {
            empresas = puntoFinalDAO.findSelectEndpoints(jdbcTemplate.getDataSource().getConnection());
            return empresas;
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new Exception(ex.getMessage());
        }
    }

    @Transactional(propagation = Propagation.REQUIRED)
    public DatabaseResponse delete(Long endpointId) throws OTCAdminException {
        DatabaseResponse dr = puntoFinalDAO.delete(jdbcTemplate, endpointId);
        if (dr.getSqlCode().longValue() == 0L) {
            log.info(dr.getMessage());

        } else {
            log.error("Error en la transacción: " + dr.getMessage());
        }
        return dr;

    }

    public List<PuntoFinalBean> search(EnriquecimientoBusqueda busqueda) throws Exception {
        List<PuntoFinalBean> endpoints = null;
        try {
            endpoints = puntoFinalDAO.search(jdbcTemplate.getDataSource().getConnection(), busqueda);
            return endpoints;

        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new Exception(ex.getMessage());
        }
    }

    @Transactional(propagation = Propagation.REQUIRED)
    public List<DatabaseResponse> deleteMany(Long... ids) throws OTCAdminException {

        List<DatabaseResponse> responses = new ArrayList<DatabaseResponse>();
        DatabaseResponse dr = null;
        for (Long id : ids) {
            dr = puntoFinalDAO.delete(jdbcTemplate, id);
            dr.setSequence(new BigDecimal(id));
            responses.add(dr);

            if (dr.getSqlCode().longValue() == 0L) {
                log.info(dr.getMessage());

            } else {
                log.error("Error en la transacción: " + dr.getMessage());
            }
        }
        return responses;
    }
}
