
package com.bolivariano.mensajebolivariano;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.bolivariano.mensajebolivariano package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _MensajeEntrada_QNAME = new QName("http://www.bolivariano.com/MensajeBolivariano", "MensajeEntrada");
    private final static QName _MensajeSalida_QNAME = new QName("http://www.bolivariano.com/MensajeBolivariano", "MensajeSalida");
    private final static QName _MensajeFault_QNAME = new QName("http://www.bolivariano.com/MensajeBolivariano", "MensajeFault");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.bolivariano.mensajebolivariano
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link MensajeSalida }
     * 
     */
    public MensajeSalida createMensajeSalida() {
        return new MensajeSalida();
    }

    /**
     * Create an instance of {@link MensajeEntrada }
     * 
     */
    public MensajeEntrada createMensajeEntrada() {
        return new MensajeEntrada();
    }

    /**
     * Create an instance of {@link MensajeFault }
     * 
     */
    public MensajeFault createMensajeFault() {
        return new MensajeFault();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MensajeEntrada }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.bolivariano.com/MensajeBolivariano", name = "MensajeEntrada")
    public JAXBElement<MensajeEntrada> createMensajeEntrada(MensajeEntrada value) {
        return new JAXBElement<MensajeEntrada>(_MensajeEntrada_QNAME, MensajeEntrada.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MensajeSalida }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.bolivariano.com/MensajeBolivariano", name = "MensajeSalida")
    public JAXBElement<MensajeSalida> createMensajeSalida(MensajeSalida value) {
        return new JAXBElement<MensajeSalida>(_MensajeSalida_QNAME, MensajeSalida.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MensajeFault }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.bolivariano.com/MensajeBolivariano", name = "MensajeFault")
    public JAXBElement<MensajeFault> createMensajeFault(MensajeFault value) {
        return new JAXBElement<MensajeFault>(_MensajeFault_QNAME, MensajeFault.class, null, value);
    }

}
