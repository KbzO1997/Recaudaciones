package com.bolivariano.otc.web.rest.errors;

import javax.ws.rs.core.Response;


import org.zalando.problem.AbstractThrowableProblem;
import org.zalando.problem.Status;

public class ConstraintViolationException extends  AbstractThrowableProblem {

    public ConstraintViolationException() {
        super(ErrorConstants.CONSTRAINT_VIOLATION_TYPE, "Constraint Violation", Status.BAD_REQUEST);
    }
}
