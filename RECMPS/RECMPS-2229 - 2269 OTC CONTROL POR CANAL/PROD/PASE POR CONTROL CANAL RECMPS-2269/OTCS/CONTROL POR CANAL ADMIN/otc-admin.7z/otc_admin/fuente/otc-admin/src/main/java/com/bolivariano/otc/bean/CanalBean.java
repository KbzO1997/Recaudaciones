package com.bolivariano.otc.bean;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class CanalBean implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long id;

	private String codigo;

	private String descripcion;

	private Long medioAccesoId;
	
	private String medioAcceso;

	private String nombre;
	
	private List<ServicioCanalBean> servicioCanales;
	
	
	public Long getId() {
		return id;
	}




	public void setId(Long id) {
		this.id = id;
	}




	public String getCodigo() {
		return codigo;
	}




	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}




	public String getDescripcion() {
		return descripcion;
	}




	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}




	public Long getMedioAccesoId() {
		return medioAccesoId;
	}




	public void setMedioAccesoId(Long medioAccesoId) {
		this.medioAccesoId = medioAccesoId;
	}




	public String getMedioAcceso() {
		return medioAcceso;
	}




	public void setMedioAcceso(String medioAcceso) {
		this.medioAcceso = medioAcceso;
	}




	public String getNombre() {
		return nombre;
	}




	public void setNombre(String nombre) {
		this.nombre = nombre;
	}




	public CanalBean() {
	}




	public List<ServicioCanalBean> getServicioCanales() {
		return servicioCanales;
	}




	public void setServicioCanales(List<ServicioCanalBean> servicioCanales) {
		this.servicioCanales = servicioCanales;
	}




	@Override
	public String toString() {
		return "CanalBean [id=" + id + ", codigo=" + codigo + ", descripcion=" + descripcion + ", medioAccesoId="
				+ medioAccesoId + ", medioAcceso=" + medioAcceso + ", nombre=" + nombre + ", servicioCanales="
				+ servicioCanales + "]";
	}

	}