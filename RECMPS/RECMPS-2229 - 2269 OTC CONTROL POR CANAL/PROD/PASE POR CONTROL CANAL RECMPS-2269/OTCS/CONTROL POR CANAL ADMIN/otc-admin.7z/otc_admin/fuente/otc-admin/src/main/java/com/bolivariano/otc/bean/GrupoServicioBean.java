package com.bolivariano.otc.bean;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * The persistent class for the OTC_M_GRUPO_SERVICIO database table.
 */

@JsonInclude(Include.NON_NULL)
public class GrupoServicioBean implements Serializable {
	
    private static final long serialVersionUID = 1L;

    private Long id;

    private List<ServicioBean> servicios;

    private Long tipoBancaId;

    private Long tipoServicioId;
    
    private String tipoBanca;
    
    private String tipoServicio;

    private Long empresaId;

    private Byte convenioVisible;

    private Byte matriculable;

    private Byte matriculacionMultiple;

    private Byte validable;
	private String empresa;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public List<ServicioBean> getServicios() {
		return servicios;
	}

	public void setServicios(List<ServicioBean> servicios) {
		this.servicios = servicios;
	}

	public Long getTipoBancaId() {
		return tipoBancaId;
	}

	public void setTipoBancaId(Long tipoBancaId) {
		this.tipoBancaId = tipoBancaId;
	}

	public Long getTipoServicioId() {
		return tipoServicioId;
	}

	public void setTipoServicioId(Long tipoServicioId) {
		this.tipoServicioId = tipoServicioId;
	}

	public Long getEmpresaId() {
		return empresaId;
	}

	public void setEmpresaId(Long empresaId) {
		this.empresaId = empresaId;
	}

	public Byte getConvenioVisible() {
		return convenioVisible;
	}

	public void setConvenioVisible(Byte convenioVisible) {
		this.convenioVisible = convenioVisible;
	}

	public Byte getMatriculable() {
		return matriculable;
	}

	public void setMatriculable(Byte matriculable) {
		this.matriculable = matriculable;
	}

	public Byte getMatriculacionMultiple() {
		return matriculacionMultiple;
	}

	public void setMatriculacionMultiple(Byte matriculacionMultiple) {
		this.matriculacionMultiple = matriculacionMultiple;
	}

	public Byte getValidable() {
		return validable;
	}

	public void setValidable(Byte validable) {
		this.validable = validable;
	}

	public String getTipoBanca() {
		return tipoBanca;
	}

	public void setTipoBanca(String tipoBanca) {
		this.tipoBanca = tipoBanca;
	}

	public String getTipoServicio() {
		return tipoServicio;
	}

	public void setTipoServicio(String tipoServicio) {
		this.tipoServicio = tipoServicio;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}
}