package com.bolivariano.otc.config;

import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.server.wadl.internal.WadlResource;
import org.springframework.stereotype.Component;

import com.bolivariano.otc.CORSResponseFilter;
import com.bolivariano.otc.web.rest.CanalRest;
import com.bolivariano.otc.web.rest.CatalogoRest;
import com.bolivariano.otc.web.rest.ConvenioRest;
import com.bolivariano.otc.web.rest.EmpresaRest;
import com.bolivariano.otc.web.rest.EnriquecimientoRest;
import com.bolivariano.otc.web.rest.GrupoServicioRest;
import com.bolivariano.otc.web.rest.PuntoFinalRest;
import com.bolivariano.otc.web.rest.ServicioRest;

@Component
public class JerseyConfig extends ResourceConfig {
    public JerseyConfig() {
        registerEndpoints();
    }

    private void registerEndpoints() {
    	register(WadlResource.class);
    	register(CORSResponseFilter.class);
        register(GrupoServicioRest.class);
        register(EmpresaRest.class);
        register(CatalogoRest.class);
        register(ConvenioRest.class);
        register(CanalRest.class);
        register(ServicioRest.class);
        register(PuntoFinalRest.class);
        register(EnriquecimientoRest.class);
    }
}
