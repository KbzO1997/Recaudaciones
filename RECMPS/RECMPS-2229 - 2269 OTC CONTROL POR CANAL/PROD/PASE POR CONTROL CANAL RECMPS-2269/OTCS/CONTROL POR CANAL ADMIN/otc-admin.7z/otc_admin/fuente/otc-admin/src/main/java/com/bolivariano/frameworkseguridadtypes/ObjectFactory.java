
package com.bolivariano.frameworkseguridadtypes;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.bolivariano.frameworkseguridadtypes package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _MensajeEntrada_QNAME = new QName("http://www.bolivariano.com/FrameworkSeguridadTypes", "MensajeEntrada");
    private final static QName _MensajeSalida_QNAME = new QName("http://www.bolivariano.com/FrameworkSeguridadTypes", "MensajeSalida");
    private final static QName _MensajeEntradaDesencriptarAE_QNAME = new QName("http://www.bolivariano.com/FrameworkSeguridadTypes", "MensajeEntradaDesencriptarAE");
    private final static QName _MensajeEntradaNoInput_QNAME = new QName("http://www.bolivariano.com/FrameworkSeguridadTypes", "MensajeEntradaNoInput");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.bolivariano.frameworkseguridadtypes
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link LoginAplicacionTypeOut2 }
     * 
     */
    public LoginAplicacionTypeOut2 createLoginAplicacionTypeOut2() {
        return new LoginAplicacionTypeOut2();
    }

    /**
     * Create an instance of {@link LoginAplicacionOutTemp }
     * 
     */
    public LoginAplicacionOutTemp createLoginAplicacionOutTemp() {
        return new LoginAplicacionOutTemp();
    }

    /**
     * Create an instance of {@link LoginAplicacionTypeOut }
     * 
     */
    public LoginAplicacionTypeOut createLoginAplicacionTypeOut() {
        return new LoginAplicacionTypeOut();
    }

    /**
     * Create an instance of {@link MensajeEntradaNoInput }
     * 
     */
    public MensajeEntradaNoInput createMensajeEntradaNoInput() {
        return new MensajeEntradaNoInput();
    }

    /**
     * Create an instance of {@link LoginAplicacionIn }
     * 
     */
    public LoginAplicacionIn createLoginAplicacionIn() {
        return new LoginAplicacionIn();
    }

    /**
     * Create an instance of {@link LoginAplicacionTypeIn }
     * 
     */
    public LoginAplicacionTypeIn createLoginAplicacionTypeIn() {
        return new LoginAplicacionTypeIn();
    }

    /**
     * Create an instance of {@link MensajeEntradaDesencriptarAE }
     * 
     */
    public MensajeEntradaDesencriptarAE createMensajeEntradaDesencriptarAE() {
        return new MensajeEntradaDesencriptarAE();
    }

    /**
     * Create an instance of {@link MensajeSalida }
     * 
     */
    public MensajeSalida createMensajeSalida() {
        return new MensajeSalida();
    }

    /**
     * Create an instance of {@link MensajeEntrada }
     * 
     */
    public MensajeEntrada createMensajeEntrada() {
        return new MensajeEntrada();
    }

    /**
     * Create an instance of {@link LoginAplicacionOut }
     * 
     */
    public LoginAplicacionOut createLoginAplicacionOut() {
        return new LoginAplicacionOut();
    }

    /**
     * Create an instance of {@link LoginAplicacionTypeOut2 .Campo }
     * 
     */
    public LoginAplicacionTypeOut2 .Campo createLoginAplicacionTypeOut2Campo() {
        return new LoginAplicacionTypeOut2 .Campo();
    }

    /**
     * Create an instance of {@link LoginAplicacionTypeOut2 .Nodo }
     * 
     */
    public LoginAplicacionTypeOut2 .Nodo createLoginAplicacionTypeOut2Nodo() {
        return new LoginAplicacionTypeOut2 .Nodo();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MensajeEntrada }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.bolivariano.com/FrameworkSeguridadTypes", name = "MensajeEntrada")
    public JAXBElement<MensajeEntrada> createMensajeEntrada(MensajeEntrada value) {
        return new JAXBElement<MensajeEntrada>(_MensajeEntrada_QNAME, MensajeEntrada.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MensajeSalida }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.bolivariano.com/FrameworkSeguridadTypes", name = "MensajeSalida")
    public JAXBElement<MensajeSalida> createMensajeSalida(MensajeSalida value) {
        return new JAXBElement<MensajeSalida>(_MensajeSalida_QNAME, MensajeSalida.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MensajeEntradaDesencriptarAE }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.bolivariano.com/FrameworkSeguridadTypes", name = "MensajeEntradaDesencriptarAE")
    public JAXBElement<MensajeEntradaDesencriptarAE> createMensajeEntradaDesencriptarAE(MensajeEntradaDesencriptarAE value) {
        return new JAXBElement<MensajeEntradaDesencriptarAE>(_MensajeEntradaDesencriptarAE_QNAME, MensajeEntradaDesencriptarAE.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MensajeEntradaNoInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.bolivariano.com/FrameworkSeguridadTypes", name = "MensajeEntradaNoInput")
    public JAXBElement<MensajeEntradaNoInput> createMensajeEntradaNoInput(MensajeEntradaNoInput value) {
        return new JAXBElement<MensajeEntradaNoInput>(_MensajeEntradaNoInput_QNAME, MensajeEntradaNoInput.class, null, value);
    }

}
