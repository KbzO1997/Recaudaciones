package com.bolivariano.otc.bean;

import java.io.Serializable;


public class ServicioCanalBean implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long id;

	private Long servicioId;

	private Long canalId;
	

	public ServicioCanalBean() {
	}

	public ServicioCanalBean(Long servicioId, Long canalId) {
		this.servicioId = servicioId;
		this.canalId = canalId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getServicioId() {
		return servicioId;
	}

	public void setServicioId(Long servicioId) {
		this.servicioId = servicioId;
	}

	public Long getCanalId() {
		return canalId;
	}

	public void setCanalId(Long canalId) {
		this.canalId = canalId;
	}

	@Override
	public String toString() {
		return "ServicioCanal [id=" + id + ", servicioId=" + servicioId + ", canalId=" + canalId + "]";
	}
}