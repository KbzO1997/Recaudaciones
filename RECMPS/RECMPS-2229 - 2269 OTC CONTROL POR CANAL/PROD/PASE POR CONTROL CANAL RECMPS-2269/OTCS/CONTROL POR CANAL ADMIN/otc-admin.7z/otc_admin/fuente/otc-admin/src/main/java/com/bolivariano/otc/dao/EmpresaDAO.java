package com.bolivariano.otc.dao;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.bolivariano.otc.MapperUtil;
import com.bolivariano.otc.bean.DatabaseResponse;
import com.bolivariano.otc.bean.EmpresaBean;
import com.bolivariano.otc.bean.EmpresaBusqueda;
import com.bolivariano.otc.bean.PaginatedListEmpresa;
import com.bolivariano.otc.bean.PaginationRequest;
import com.bolivariano.otc.bean.SelectItemBean;
import com.bolivariano.otc.dto.Empresa;

import oracle.jdbc.OracleTypes;
import com.bolivariano.otc.exception.OTCAdminException;

@Repository
public class EmpresaDAO {

	private static final Logger log = LoggerFactory.getLogger(EmpresaDAO.class);
	private static final String ERROR_PROCESO = "Error en el proceso: ";
	private static final String ERROR_CONSULTA = "Error al consultar empresas: ";
	private static final String S_RESPUESTA = "S_RESPUESTA";
	private static final String E_IDENTIFICACION = "e_identificacion";
	private static final String E_NOMBRE = "e_nombre";

	private static final String S_AFECTADOS = "s_afectados";
	private static final String S_CODIGO_ERROR = "s_codigo_error";
	private static final String S_MENSAJE = "s_mensaje";
	private static final String E_EMP_ID = "e_emp_id";
	private static final String S_RESULT = "s_result";
	private static final String E_CODIGO = "e_codigo";
	
	@Autowired
	MapperUtil<Empresa> empresaMapper;

	@Autowired
	MapperUtil<EmpresaBean> empresaBeanMapper;

	@Autowired
	MapperUtil<SelectItemBean> selectMapper;

	public Empresa obtenerBanco(Connection conn) throws SQLException {
		List<Empresa> empresas = null;
		StringBuilder proceduteStr = new StringBuilder();
		ResultSet rset = null;
		proceduteStr.append(" { call PQ_OTC_EMPRESA.PA_OTC_CEMPRESABANCO(?) }");
		try(CallableStatement procStmt = conn.prepareCall(proceduteStr.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);){
			procStmt.registerOutParameter(S_RESPUESTA, OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject(S_RESPUESTA);

			if (rset.isBeforeFirst()) {
				empresas = empresaMapper.mapResultSetToObject(rset, Empresa.class);

			}
		} catch (Exception e) {
			log.error(ERROR_PROCESO + e.getMessage(), e);
		} finally {
			if (rset != null) {
				rset.close();
			}
		}

		return (empresas!= null && !empresas.isEmpty())?empresas.get(0):null;
	}

	public Empresa obtenerEmpresa(Connection conn, Long idEmpresa) throws OTCAdminException, SQLException {
		List<Empresa> empresas = null;
		StringBuilder sql = new StringBuilder();
		ResultSet rset = null;
		sql.append(" { call PA_OTC_CEMPRESA(?,?) }");
		try(CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);){
			procStmt.setLong(1, idEmpresa);
			procStmt.registerOutParameter(2, OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject(2);

			if (rset.isBeforeFirst()) {
				empresas = empresaMapper.mapResultSetToObject(rset, Empresa.class);
			}

			
		} catch (Exception e) {
			log.error(ERROR_PROCESO + e.getMessage(), e);
		} finally {
			if (rset != null) {
				rset.close();
			}
		}

		return (empresas != null && !empresas.isEmpty()) ? empresas.get(0) : null;
	}

	public Integer countCode(JdbcTemplate jdbcTemplate, String code) {
		Integer count = null;
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_PCONTAR_CODEMP")
					.declareParameters(new SqlParameter(E_CODIGO, Types.VARCHAR),
							new SqlOutParameter("s_cantidad", Types.INTEGER));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue(E_CODIGO, code);
			Map<String, Object> out = simpleJdbcCall.execute(source);
			count = (Integer) out.get("s_cantidad");
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return count;
	}

	public DatabaseResponse insert(JdbcTemplate jdbcTemplate, EmpresaBean empresa) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("pa_otc_iempresa")
					.declareParameters(new SqlParameter(E_IDENTIFICACION, Types.VARCHAR),
							new SqlParameter(E_NOMBRE, Types.VARCHAR), new SqlParameter(E_CODIGO, Types.VARCHAR),
							new SqlParameter("e_descripcion", Types.VARCHAR),
							new SqlOutParameter("s_secuencia", Types.NUMERIC),
							new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
							new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
							new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue(E_IDENTIFICACION, empresa.getIdentificacion());
			source.addValue(E_NOMBRE, empresa.getNombre());
			source.addValue(E_CODIGO, empresa.getCodigo());
			source.addValue("e_descripcion", empresa.getDescripcion());
			Map<String, Object> out = simpleJdbcCall.execute(source);

			dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
			dr.setMessage((String) out.get(S_MENSAJE));
			dr.setSequence((BigDecimal) out.get("s_secuencia"));
			dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}

	public DatabaseResponse update(JdbcTemplate jdbcTemplate, EmpresaBean empresa) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("pa_otc_aempresa")
					.declareParameters(new SqlParameter(E_EMP_ID, Types.NUMERIC),
							new SqlParameter("e_emp_identificacion", Types.VARCHAR),
							new SqlParameter("e_emp_nombre", Types.VARCHAR),
							new SqlParameter("e_EMP_CODIGO", Types.VARCHAR),
							new SqlParameter("e_EMP_DESCRIPCION", Types.VARCHAR),
							new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
							new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
							new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_EMP_ID", empresa.getId());
			source.addValue("e_EMP_IDENTIFICACION", empresa.getIdentificacion());
			source.addValue("e_EMP_NOMBRE", empresa.getNombre());
			source.addValue("e_EMP_CODIGO", empresa.getCodigo());
			source.addValue("e_EMP_DESCRIPCION", empresa.getDescripcion());
			Map<String, Object> out = simpleJdbcCall.execute(source);
			dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
			dr.setMessage((String) out.get(S_MENSAJE));
			dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}

	public PaginatedListEmpresa findAll(PaginationRequest pr, Connection conn)
			throws SQLException, NoSuchMethodException {

		CallableStatement procStmt = null;
		StringBuilder sql = new StringBuilder();
		ResultSet rs;
		List<EmpresaBean> empresas = null;
		PaginatedListEmpresa pagedEmpresas;

		try {
			sql.append(" { call PA_OTC_GEMPRESA(?,?,?,?,?) }");
			procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
			procStmt.setInt("e_size", pr.getSize());
			procStmt.setInt("e_page", pr.getPage());
			procStmt.setString("e_sort", pr.getSortBy());
			procStmt.registerOutParameter("s_totalRecord", Types.NUMERIC);
			procStmt.registerOutParameter(S_RESULT, OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rs = (ResultSet) procStmt.getObject(S_RESULT);
			if (rs != null && rs.isBeforeFirst()) {
				empresas = empresaBeanMapper.mapResultSetToObject(rs, EmpresaBean.class);
				pagedEmpresas = new PaginatedListEmpresa();
				pagedEmpresas.setRecordsFiltered(pr.getSize());
				pagedEmpresas.setRecordsTotal(procStmt.getBigDecimal("s_totalRecord").longValue());
				pagedEmpresas.setData(empresas);
				rs.close();
				procStmt.close();
				return pagedEmpresas;
			} else {
				return null;
			}

		} catch (SQLException e) {
			log.error(ERROR_CONSULTA + e.getMessage(), e);
			throw new SQLException(ERROR_CONSULTA + e.getMessage(), e);
		} finally {
			if (procStmt != null)
				procStmt.close();
			if (conn != null)
				conn.close();
		}
	}

	public EmpresaBean findById(Connection conn, Long id) throws OTCAdminException, SQLException {

		List<EmpresaBean> empresas = null;
		StringBuilder sql = new StringBuilder();
		ResultSet rset = null;
		sql.append(" { call PA_OTC_CEMPRESA_ID(?,?) }");
		try(CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);){
			procStmt.setLong("e_id ", id);
			procStmt.registerOutParameter(S_RESPUESTA, OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject(S_RESPUESTA);
			if (rset.isBeforeFirst()) {
				empresas = empresaBeanMapper.mapResultSetToObject(rset, EmpresaBean.class);
				return empresas.get(0);
			}

		} catch (Exception e) {
			log.error(ERROR_PROCESO + e.getMessage(), e);

		} finally {
			if (rset != null) {
				rset.close();
			}
		}
		return null;
	}

	public List<SelectItemBean> findSelectEmpresasUnique(Connection conn) throws OTCAdminException, SQLException {

		List<SelectItemBean> empresas = null;
		StringBuilder sql = new StringBuilder();
		ResultSet rset = null;
		sql.append(" { call PA_OTC_CEMPRESA_SELECT(?) }");
		try (CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY,
				ResultSet.CONCUR_READ_ONLY)) {

			procStmt.registerOutParameter(S_RESPUESTA, OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject(S_RESPUESTA);
			if (rset.isBeforeFirst()) {
				empresas = selectMapper.mapResultSetToObject(rset, SelectItemBean.class);
			}
			return empresas;
		} catch (Exception e) {
			log.error(ERROR_PROCESO + e.getMessage(), e);

		} 
		return empresas;
	}
	
	
	public List<SelectItemBean> findSelectEmpresas(Connection conn, String esBanco) throws OTCAdminException, SQLException {

		List<SelectItemBean> empresas = null;
		StringBuilder sql = new StringBuilder();
		ResultSet rset = null;
		sql.append(" { call PA_OTC_CEMPRESA_SELECT(?,?) }");
		try (CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY,
				ResultSet.CONCUR_READ_ONLY)) {
			procStmt.setInt("paramEmp_Banco", Integer.valueOf(esBanco));
			procStmt.registerOutParameter(S_RESPUESTA, OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject(S_RESPUESTA);
			if (rset.isBeforeFirst()) {
				empresas = selectMapper.mapResultSetToObject(rset, SelectItemBean.class);
			}
			return empresas;
		} catch (Exception e) {
			log.error(ERROR_PROCESO + e.getMessage(), e);

		} 
		return empresas;
	}

	public DatabaseResponse delete(JdbcTemplate jdbcTemplate, Long empresaId) throws OTCAdminException {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_EEMPRESA")
					.declareParameters(new SqlParameter(E_EMP_ID, Types.NUMERIC),
							new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
							new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
							new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue(E_EMP_ID, empresaId);
			Map<String, Object> out = simpleJdbcCall.execute(source);
			dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
			dr.setMessage((String) out.get(S_MENSAJE));
			dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
		} catch (Exception ex) {
			throw new OTCAdminException(ex.getMessage(), ex);
		}
		return dr;
	}

	public List<EmpresaBean> search(Connection conn, EmpresaBusqueda busqueda) throws OTCAdminException, SQLException, NoSuchMethodException {
		CallableStatement procStmt = null;
		StringBuilder sql = new StringBuilder();
		ResultSet rset = null;
		List<EmpresaBean> canales = null;
		try {
			sql.append(" { call pa_otc_cempresa_search(?,?,?,?) }");
			log.info(busqueda.toString());
			procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
			procStmt.setString(E_CODIGO, busqueda.getCodigo());
			procStmt.setString(E_NOMBRE, busqueda.getNombre());
			procStmt.setString(E_IDENTIFICACION, busqueda.getIdentificacion());
			procStmt.registerOutParameter(S_RESULT, OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject(S_RESULT);
			if (rset.isBeforeFirst()) {
				canales = empresaBeanMapper.mapResultSetToObject(rset, EmpresaBean.class);
				rset.close();
				procStmt.close();
				return canales;
			} else {
				return  Collections.emptyList();  
			}

		} catch (SQLException e) {
			log.error(ERROR_CONSULTA+ e.getMessage(), e);
			throw new SQLException(ERROR_CONSULTA + e.getMessage(), e);
		} finally {
			if (procStmt != null)
				procStmt.close();
			if (conn != null)
				conn.close();
		}
	}
}
