package com.bolivariano.otc.web.rest;

import com.bolivariano.otc.bean.*;
import com.bolivariano.otc.dto.Empresa;
import com.bolivariano.otc.exception.OTCAdminException;
import com.bolivariano.otc.service.EmpresaService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import java.math.BigDecimal;
import java.util.List;

@Component
@Path("/admin/v1/empresa")
public class EmpresaRest {

    private static final Logger log = LoggerFactory.getLogger(EmpresaRest.class);
    private static final String C_PETICION = "getEmpresas: Petición Recibida ";
    @Autowired
    EmpresaService empresaService;

	
    @GET
    @Path("/select-banco")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response obtenerBanco() {
        log.info("getBanco: Petición Recibida");
        try {
            Empresa empresaBean = this.empresaService.obtenerBanco();
            if (empresaBean == null) {
                return Response.status(Status.NO_CONTENT).entity(null).build();
            }
            return Response.status(Status.OK).entity(empresaBean).build();
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }


    @POST
    @Path("/save")
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response insert(EmpresaBean empresa) {
        DatabaseResponse dr = new DatabaseResponse();
        try {
            log.info("insertarEmpresa: Peticion recibida");
            dr = empresaService.insert(empresa);
            if (dr.getSqlCode().intValue() == 0 && dr.getAffectedRows().intValue() > 0 && dr.getSequence().intValue() > 0) {
                return Response.status(Status.OK).entity(dr).build();
            } else {
                return Response.status(Status.ACCEPTED).entity(dr).build();
            }
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }

    }

    @POST
    @Path("/update")
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response update(EmpresaBean empresa) {
        DatabaseResponse dr = new DatabaseResponse();
        try {
            log.info("actualizarEmpresa: Peticion recibida");
            dr = empresaService.update(empresa);
            log.info(dr.toString());
            if (dr.getSqlCode().intValue() == 0 && dr.getAffectedRows().intValue() > 0) {
                return Response.status(Status.OK).entity(dr).build();
            } else {
                return Response.status(Status.ACCEPTED).entity(dr).build();
            }
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }


    @POST
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response getEmpresas(PaginationRequest pr) {
        log.info(C_PETICION);
        try {
            return Response.status(Status.OK).entity(this.empresaService.findAll(pr)).build();
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response findById(@PathParam("id") Long id) {
        log.info(C_PETICION);
        try {
            EmpresaBean empresaBean = this.empresaService.findById(id);
            if (empresaBean == null) {
                return Response.status(Status.NO_CONTENT).entity(null).build();
            }
            return Response.status(Status.OK).entity(empresaBean).build();
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }

    @GET
    @Path("/select-empresas")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response findSelects(@QueryParam("esBanco")@DefaultValue("0") String esBanco) {
        log.info(C_PETICION);
        try {

            List<SelectItemBean> empresaBean = this.empresaService.findSelects(esBanco);
            if (empresaBean == null) {
                return Response.status(Status.NO_CONTENT).entity(null).build();
            }
            return Response.status(Status.OK).entity(empresaBean).build();
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }

    @GET
    @Path("/count-code")
    @Produces(MediaType.APPLICATION_JSON)
    public Response countCode(@QueryParam("code") String code) {
        log.info("countCode: Petición Recibida");
        try {
            Integer count = this.empresaService.countCode(code);
            if (count == null) {
                return Response.status(Status.NO_CONTENT).entity(null).build();
            }
            return Response.status(Status.OK).entity(count).build();
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }

    @POST
    @Path("/delete")
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response delete(@QueryParam("id") Long id) throws OTCAdminException {
        DatabaseResponse dr;
        log.info("delete: Peticion recibida");
        dr = empresaService.delete(id);
        return Response.status(Status.OK).entity(dr).build();
    }

    @POST
    @Path("/search")
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response search(EmpresaBusqueda busqueda) {
        List<EmpresaBean> convenios = null;
        try {
            log.info("search: Peticion recibida" + busqueda);
            convenios = empresaService.search(busqueda);
            if (convenios == null) {
                return Response.status(Status.NO_CONTENT).entity(null).build();
            } else {
                return Response.status(Status.OK).entity(convenios).build();
            }
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(null).build();
        }
    }

    @POST
    @Path("/delete-many")
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response deleteMany(Long... ids) throws OTCAdminException {
        List<DatabaseResponse> responses = empresaService.deleteMany(ids);
        DatabaseResponse dr = new DatabaseResponse();

        String errorMsg = "El empresa %id no fue eliminado: %msg \b";
        StringBuilder errorMsgs = new StringBuilder();
        boolean error = false;

        for (DatabaseResponse drAux : responses) {
            if (drAux.getSqlCode().longValue() != 0L) {
                error = true;
                errorMsgs.append(errorMsg.replace("%id", drAux.getSequence().toString()).replace("%msg", drAux.getMessage()));
            }
        }
        dr.setSqlCode(!error ? new BigDecimal(0) : new BigDecimal(100));
        dr.setMessage(!error ? "Transacción Exitosa" : errorMsgs.toString());

        return Response.status(Status.OK).entity(dr).build();
    }

}
