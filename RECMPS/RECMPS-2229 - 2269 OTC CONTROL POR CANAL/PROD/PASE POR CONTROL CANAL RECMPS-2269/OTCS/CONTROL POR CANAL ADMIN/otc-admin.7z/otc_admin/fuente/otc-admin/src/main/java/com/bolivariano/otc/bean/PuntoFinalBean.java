package com.bolivariano.otc.bean;

import java.io.Serializable;


/**
 * The persistent class for the OTC_M_PUNTO_FINAL database table.
 * 
 */

public class PuntoFinalBean implements Serializable {
	private static final long serialVersionUID = 1L;


	private Long id;

	private String nombre;

	private String operacion;

	private String peticion;
	
	private String puntoFinal;

	private String repositorioPeticion;

	private String repositorioRespuesta;

	private String respuesta;

	private String ambiente;


	public PuntoFinalBean() {
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getOperacion() {
		return operacion;
	}


	public void setOperacion(String operacion) {
		this.operacion = operacion;
	}


	public String getPeticion() {
		return peticion;
	}


	public void setPeticion(String peticion) {
		this.peticion = peticion;
	}


	public String getPuntoFinal() {
		return puntoFinal;
	}


	public void setPuntoFinal(String puntoFinal) {
		this.puntoFinal = puntoFinal;
	}


	public String getRepositorioPeticion() {
		return repositorioPeticion;
	}


	public void setRepositorioPeticion(String repositorioPeticion) {
		this.repositorioPeticion = repositorioPeticion;
	}


	public String getRepositorioRespuesta() {
		return repositorioRespuesta;
	}


	public void setRepositorioRespuesta(String repositorioRespuesta) {
		this.repositorioRespuesta = repositorioRespuesta;
	}


	public String getRespuesta() {
		return respuesta;
	}


	public void setRespuesta(String respuesta) {
		this.respuesta = respuesta;
	}

	public String getAmbiente() {
		return ambiente;
	}

	public void setAmbiente(String ambiente) {
		this.ambiente = ambiente;
	}

	@Override
	public String toString() {
		return "PuntoFinalBean{" +
				"id=" + id +
				", nombre='" + nombre + '\'' +
				", operacion='" + operacion + '\'' +
				", peticion='" + peticion + '\'' +
				", puntoFinal='" + puntoFinal + '\'' +
				", repositorioPeticion='" + repositorioPeticion + '\'' +
				", repositorioRespuesta='" + repositorioRespuesta + '\'' +
				", respuesta='" + respuesta + '\'' +
				", ambiente='" + ambiente + '\'' +
				'}';
	}
}