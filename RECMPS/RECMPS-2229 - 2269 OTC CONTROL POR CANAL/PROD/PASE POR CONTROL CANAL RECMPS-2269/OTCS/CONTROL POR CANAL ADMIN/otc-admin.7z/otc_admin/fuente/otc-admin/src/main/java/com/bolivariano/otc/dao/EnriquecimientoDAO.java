package com.bolivariano.otc.dao;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.bolivariano.otc.MapperUtil;
import com.bolivariano.otc.bean.DatabaseResponse;
import com.bolivariano.otc.bean.EnriquecimientoBusqueda;
import com.bolivariano.otc.bean.PaginatedListServicioEnriquecimiento;
import com.bolivariano.otc.bean.PaginationRequest;
import com.bolivariano.otc.bean.SelectItemBean;
import com.bolivariano.otc.bean.ServicioEnriquecimientoBean;
import com.bolivariano.otc.enumerators.RegisterStatus;
import com.bolivariano.otc.exception.OTCAdminException;

import oracle.jdbc.OracleTypes;

@Repository
public class EnriquecimientoDAO {
	
    private static final Logger log = LoggerFactory.getLogger(EnriquecimientoDAO.class);
    private static final String S_RESPUESTA = "S_RESPUESTA";
    private static final String E_ES_NOMBRE = "e_ES_NOMBRE";
    private static final String E_ES_ENDPOINT = "e_ES_ENDPOINT";
    private static final String E_ES_PETICION = "e_ES_PETICION";
    private static final String E_ES_OPERACION = "e_ES_OPERACION";	
    private static final String E_ES_ESTADO = "e_ES_ESTADO";
    private static final String E_ES_DESCRIPCION = "e_ES_DESCRIPCION";
    private static final String E_ES_FECHA_REGISTRO = "e_ES_FECHA_REGISTRO";
    private static final String S_AFECTADOS = "s_afectados";
    private static final String S_CODIGO_ERROR = "s_codigo_error";
    private static final String S_MENSAJE = "s_mensaje";
    private static final String S_RESULT = "s_result";
    
    @Autowired
	MapperUtil<ServicioEnriquecimientoBean> enriquecimientoMapper;
    @Autowired
	MapperUtil<SelectItemBean> selectMapper;
	
	public DatabaseResponse insert(JdbcTemplate jdbcTemplate, ServicioEnriquecimientoBean servicioEnriquecimiento) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_ISERVENR")
					.declareParameters(new SqlParameter(E_ES_NOMBRE, Types.VARCHAR),
							new SqlParameter(E_ES_ENDPOINT, Types.VARCHAR), 
							new SqlParameter(E_ES_PETICION, Types.VARCHAR),
							new SqlParameter(E_ES_OPERACION, Types.VARCHAR),
							new SqlParameter(E_ES_FECHA_REGISTRO, Types.DATE),
							new SqlParameter(E_ES_DESCRIPCION, Types.VARCHAR),
							new SqlParameter(E_ES_ESTADO, Types.CHAR),
							new SqlOutParameter("s_secuencia", Types.NUMERIC),
							new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
							new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
							new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue(E_ES_NOMBRE, servicioEnriquecimiento.getNombre());
			source.addValue(E_ES_ENDPOINT, servicioEnriquecimiento.getEndpoint());
			source.addValue(E_ES_PETICION, servicioEnriquecimiento.getPeticion());
			source.addValue(E_ES_OPERACION, servicioEnriquecimiento.getOperacion());		
			source.addValue(E_ES_FECHA_REGISTRO, Date.valueOf(LocalDate.now()));	
			source.addValue(E_ES_DESCRIPCION, servicioEnriquecimiento.getDescripcion());	
			source.addValue(E_ES_ESTADO, RegisterStatus.Activo.getValue());	
			Map<String, Object> out = simpleJdbcCall.execute(source);			
			dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
			dr.setMessage((String) out.get(S_MENSAJE));
			dr.setSequence((BigDecimal) out.get("s_secuencia"));
			dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}
	
	public DatabaseResponse update(JdbcTemplate jdbcTemplate, ServicioEnriquecimientoBean servicioEnriquecimiento) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_ASERVENR")
					.declareParameters(new SqlParameter("e_ES_ID", Types.NUMERIC),
							new SqlParameter(E_ES_NOMBRE, Types.VARCHAR),
							new SqlParameter(E_ES_ENDPOINT, Types.VARCHAR), 
							new SqlParameter(E_ES_PETICION, Types.VARCHAR),
							new SqlParameter(E_ES_OPERACION, Types.VARCHAR),
							new SqlParameter(E_ES_FECHA_REGISTRO, Types.DATE),
							new SqlParameter(E_ES_DESCRIPCION, Types.VARCHAR),
							new SqlParameter(E_ES_ESTADO, Types.CHAR),
							new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
							new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
							new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_ES_ID", servicioEnriquecimiento.getId());
			source.addValue(E_ES_NOMBRE, servicioEnriquecimiento.getNombre());
			source.addValue(E_ES_ENDPOINT, servicioEnriquecimiento.getEndpoint());
			source.addValue(E_ES_PETICION, servicioEnriquecimiento.getPeticion());
			source.addValue(E_ES_OPERACION, servicioEnriquecimiento.getOperacion());		
			source.addValue(E_ES_FECHA_REGISTRO, servicioEnriquecimiento.getFechaRegistro());	
			source.addValue(E_ES_DESCRIPCION, servicioEnriquecimiento.getDescripcion());	
			source.addValue(E_ES_ESTADO, servicioEnriquecimiento.getEstado());	
			Map<String, Object> out = simpleJdbcCall.execute(source);			
			dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
			dr.setMessage((String) out.get(S_MENSAJE));
			dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}
	
	
	public PaginatedListServicioEnriquecimiento findAll(PaginationRequest pr,  Connection conn) throws SQLException, NoSuchMethodException {
     
        CallableStatement procStmt = null;
        StringBuilder sql = new StringBuilder();
        ResultSet rs;
        List<ServicioEnriquecimientoBean> endpoints = null;
        PaginatedListServicioEnriquecimiento pagedEndpoints;

        try {
            sql.append(" { call pa_otc_GSERVENR(?,?,?,?,?) }");
            procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
            procStmt.setInt("e_size", pr.getSize());
            procStmt.setInt("e_page", pr.getPage());
            procStmt.setString("e_sort", pr.getSortBy());
            procStmt.registerOutParameter("s_totalRecord", Types.NUMERIC);
            procStmt.registerOutParameter(S_RESULT, OracleTypes.CURSOR);
            procStmt.executeUpdate();
            rs = (ResultSet) procStmt.getObject(S_RESULT);
            if (rs!= null && rs.isBeforeFirst()) {
                endpoints = enriquecimientoMapper.mapResultSetToObject(rs, ServicioEnriquecimientoBean.class);
                pagedEndpoints = new PaginatedListServicioEnriquecimiento();
                pagedEndpoints.setRecordsFiltered(pr.getSize());
                pagedEndpoints.setRecordsTotal(procStmt.getBigDecimal("s_totalRecord").longValue());
                pagedEndpoints.setData(endpoints);
                rs.close();
                procStmt.close();
                return pagedEndpoints;
            } else {
                return null;
            }

        } catch (SQLException e) {
            log.error("Error al consultar servicios: " + e.getMessage(), e);
            throw new SQLException("Error al consultar servicios: " + e.getMessage(), e);
        } finally {
            if (procStmt != null)
                procStmt.close();
            if (conn != null)
                conn.close();
        }
    }
	
	public ServicioEnriquecimientoBean findById(Connection conn, Long id) throws OTCAdminException, SQLException {

		List<ServicioEnriquecimientoBean> endpoints = null;
		StringBuilder sql = new StringBuilder();
		ResultSet rset = null;
		sql.append(" { call PA_OTC_CSERVENR_ID(?,?) }");
		try(CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);){
			procStmt.setLong("e_id ", id);
			procStmt.registerOutParameter(S_RESPUESTA, OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject(S_RESPUESTA);
			if (rset!= null && rset.isBeforeFirst()) {
				endpoints = enriquecimientoMapper.mapResultSetToObject(rset, ServicioEnriquecimientoBean.class);
				return endpoints.get(0);
			}
			
		} catch (Exception e) {
			log.error("Error en el proceso" + e.getMessage(), e);
			
		}finally {
			if (rset != null) {
				rset.close();
			}
		}
		return null;
	}
	
	public List<SelectItemBean> findSelectEnriquecimientos(Connection conn) throws OTCAdminException, SQLException {

		List<SelectItemBean> enriquecimientos = null;
		StringBuilder sql = new StringBuilder();
		ResultSet rset = null;
		sql.append(" { call PA_OTC_CSERVENR_SELECT(?) }");
		try(CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);){
			procStmt.registerOutParameter(S_RESPUESTA, OracleTypes.CURSOR);
			procStmt.executeUpdate();
			rset = (ResultSet) procStmt.getObject(S_RESPUESTA);
			if (rset.isBeforeFirst()) {
				enriquecimientos = selectMapper.mapResultSetToObject(rset, SelectItemBean.class);
			}
			return enriquecimientos;
		} catch (Exception e) {
			log.error("Error en el proceso" + e.getMessage(), e);
			
		} finally {
			if (rset != null) {
				rset.close();
			}
		}
		return Collections.emptyList();
	}
	
	 public DatabaseResponse delete(JdbcTemplate jdbcTemplate, Long servicioId) throws OTCAdminException {
			DatabaseResponse dr = new DatabaseResponse();
			try {
				SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_ESRVENR")
						.declareParameters(new SqlParameter("e_es_id", Types.NUMERIC),
								new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
								new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
								new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
				MapSqlParameterSource source = new MapSqlParameterSource();
				source.addValue("e_es_id", servicioId);
				Map<String, Object> out = simpleJdbcCall.execute(source);
				dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
				dr.setMessage((String) out.get(S_MENSAJE));
				dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
			} catch (Exception ex) {
				throw new OTCAdminException(ex.getMessage(), ex);
			}
			return dr;
		}
	 
	 
	 public List<ServicioEnriquecimientoBean> search(Connection conn, EnriquecimientoBusqueda busqueda) throws OTCAdminException, NoSuchMethodException, SQLException {
			CallableStatement procStmt = null;
			StringBuilder sql = new StringBuilder();
			ResultSet rset = null;
			List<ServicioEnriquecimientoBean> canales = null;
			try {
				sql.append(" { call pa_otc_cservenr(?,?,?) }");
				log.info(busqueda.toString());
				procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
				procStmt.setString("e_operacion", busqueda.getOperacion());
				procStmt.setString("e_nombre", busqueda.getNombre());
				procStmt.registerOutParameter(S_RESULT, OracleTypes.CURSOR);
				procStmt.executeUpdate();
				rset = (ResultSet) procStmt.getObject(S_RESULT);
				if (rset.isBeforeFirst()) {
					canales = enriquecimientoMapper.mapResultSetToObject(rset, ServicioEnriquecimientoBean.class);
					rset.close();
					procStmt.close();
					return canales;
				} else {
					return Collections.emptyList();
				}

			} catch (SQLException e) {
				log.error("Error al consultar enriquecimientos: " + e.getMessage(), e);
				throw new SQLException("Error al consultar enriquecimientos: " + e.getMessage(), e);
			} finally {
				if (procStmt != null)
					procStmt.close();
				if (conn != null)
					conn.close();
			}
		}


}
