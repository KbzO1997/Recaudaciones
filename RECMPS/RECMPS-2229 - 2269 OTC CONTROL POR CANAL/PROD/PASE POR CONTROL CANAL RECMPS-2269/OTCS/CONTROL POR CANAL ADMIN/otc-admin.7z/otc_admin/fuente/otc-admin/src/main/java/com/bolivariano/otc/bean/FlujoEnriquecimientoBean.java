package com.bolivariano.otc.bean;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * The persistent class for the OTC_M_FLUJO database table.
 */
@JsonInclude(Include.NON_NULL)
public class FlujoEnriquecimientoBean implements Serializable {
    private static final long serialVersionUID = 1L;


    private Long id;
    private Long flujoId;
    private Long enriquecimientoId;
    
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getFlujoId() {
		return flujoId;
	}
	public void setFlujoId(Long flujoId) {
		this.flujoId = flujoId;
	}
	public Long getEnriquecimientoId() {
		return enriquecimientoId;
	}
	public void setEnriquecimientoId(Long enriquecimientoId) {
		this.enriquecimientoId = enriquecimientoId;
	}	
	
	public FlujoEnriquecimientoBean() {
	}
	public FlujoEnriquecimientoBean(Long flujoId, Long enriquecimientoId) {
		this.flujoId = flujoId;
		this.enriquecimientoId = enriquecimientoId;
	}
	@Override
	public String toString() {
		return "FlujoEnriquecimientoBean [id=" + id + ", flujoId=" + flujoId + ", enriquecimientoId="
				+ enriquecimientoId + "]";
	}
}