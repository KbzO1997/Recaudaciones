/*
 * Copyright (c) 2018. Banco Bolivariano.
 */

package com.bolivariano.otc.bean;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import java.io.Serializable;

/**
 * The type Select item dto.
 */
@JsonInclude(Include.NON_NULL)
public class SelectItemBean implements Serializable {

    private static final long serialVersionUID = -1567211600953993171L;

    /**
     * The Label.
     */
    String label;
    /**
     * The Value.
     */
    Object value;

    /**
     * Instantiates a new Select item dto.
     */
    public SelectItemBean() {
    }

    /**
     * Instantiates a new Select item dto.
     *
     * @param label the label
     * @param value the value
     */
    public SelectItemBean(String label, Object value) {
        this.label = label;
        this.value = value;
    }

    /**
     * Gets label.
     *
     * @return the label
     */
    public String getLabel() {
        return label;
    }

    /**
     * Sets label.
     *
     * @param label the label
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * Gets value.
     *
     * @return the value
     */
    public Object getValue() {
        return value;
    }

    /**
     * Sets value.
     *
     * @param value the value
     */
    public void setValue(Object value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "SelectItemDTO [label=" + label + ", value=" + value + "]";
    }


}
