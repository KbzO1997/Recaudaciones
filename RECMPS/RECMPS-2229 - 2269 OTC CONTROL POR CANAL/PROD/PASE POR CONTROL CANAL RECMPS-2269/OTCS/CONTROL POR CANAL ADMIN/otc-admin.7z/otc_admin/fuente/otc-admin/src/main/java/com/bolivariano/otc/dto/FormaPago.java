package com.bolivariano.otc.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;

/**
 * The persistent class for the OTC_D_FORMA_PAGO database table.
 *
 */

public class FormaPago implements Serializable {
    private static final long serialVersionUID = 1L;

    private Long id;

    private String nombre;

    private Double interes;

    private Integer cuotas;

    private String medio;

    private String etiqueta;

    private Convenio convenio;

    @JsonIgnore
    private Integer editableInt;

    @JsonIgnore
    private Integer visibleInt;

    public FormaPago() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Double getInteres() {
        return interes;
    }

    public void setInteres(Double interes) {
        this.interes = interes;
    }

    public Integer getCuotas() {
        return cuotas;
    }

    public void setCuotas(Integer cuotas) {
        this.cuotas = cuotas;
    }

    public String getMedio() {
        return medio;
    }

    public void setMedio(String medio) {
        this.medio = medio;
    }

    public String getEtiqueta() {
        return etiqueta;
    }

    public void setEtiqueta(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    

    public Integer getEditableInt() {
        return editableInt;
    }

    public void setEditableInt(Integer editableInt) {
        this.editableInt = editableInt;
    }

    public Integer getVisibleInt() {
        return visibleInt;
    }

    public void setVisibleInt(Integer visibleInt) {
        this.visibleInt = visibleInt;
    }

public Convenio getConvenio() {
        return convenio;
    }

	public void setConvenio(Convenio convenio) {
		this.convenio = convenio;
	}

	@Override
	public String toString() {
		return "FormaPago [id=" + id + ", nombre=" + nombre + ", interes=" + interes + ", cuotas=" + cuotas + ", medio="
				+ medio + ", etiqueta=" + etiqueta + ", convenio=" + convenio + ", editableInt=" + editableInt
				+ ", visibleInt=" + visibleInt + "]";
	}


}