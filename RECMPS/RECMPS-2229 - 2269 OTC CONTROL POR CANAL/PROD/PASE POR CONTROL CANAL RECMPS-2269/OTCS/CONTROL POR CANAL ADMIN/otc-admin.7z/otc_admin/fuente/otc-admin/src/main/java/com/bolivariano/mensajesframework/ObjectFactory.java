
package com.bolivariano.mensajesframework;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.bolivariano.mensajesframework package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _MensajeEntradaDecodificarTokenSesionXML_QNAME = new QName("http://www.bolivariano.com/MensajesFramework", "mensajeEntradaDecodificarTokenSesionXML");
    private final static QName _MensajeSalidaDecodificarTokenSesionXML_QNAME = new QName("http://www.bolivariano.com/MensajesFramework", "mensajeSalidaDecodificarTokenSesionXML");
    private final static QName _MensajeSalidaObtenerTokenSesionXML_QNAME = new QName("http://www.bolivariano.com/MensajesFramework", "mensajeSalidaObtenerTokenSesionXML");
    private final static QName _MensajeSalidaObtenerLlaveEspecifica_QNAME = new QName("http://www.bolivariano.com/MensajesFramework", "mensajeSalidaObtenerLlaveEspecifica");
    private final static QName _MensajeEntradaObtenerTokenSesionXML_QNAME = new QName("http://www.bolivariano.com/MensajesFramework", "mensajeEntradaObtenerTokenSesionXML");
    private final static QName _MensajeEntradaObtenerLlaveEspecifica_QNAME = new QName("http://www.bolivariano.com/MensajesFramework", "mensajeEntradaObtenerLlaveEspecifica");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.bolivariano.mensajesframework
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link MensajeEntradaObtenerTokenSesionXML }
     * 
     */
    public MensajeEntradaObtenerTokenSesionXML createMensajeEntradaObtenerTokenSesionXML() {
        return new MensajeEntradaObtenerTokenSesionXML();
    }

    /**
     * Create an instance of {@link MensajeSalidaDecodificarTokenSesionXML }
     * 
     */
    public MensajeSalidaDecodificarTokenSesionXML createMensajeSalidaDecodificarTokenSesionXML() {
        return new MensajeSalidaDecodificarTokenSesionXML();
    }

    /**
     * Create an instance of {@link MensajeSalidaObtenerTokenSesionXML }
     * 
     */
    public MensajeSalidaObtenerTokenSesionXML createMensajeSalidaObtenerTokenSesionXML() {
        return new MensajeSalidaObtenerTokenSesionXML();
    }

    /**
     * Create an instance of {@link MensajeEntradaDecodificarTokenSesionXML }
     * 
     */
    public MensajeEntradaDecodificarTokenSesionXML createMensajeEntradaDecodificarTokenSesionXML() {
        return new MensajeEntradaDecodificarTokenSesionXML();
    }

    /**
     * Create an instance of {@link MensajeEntradaObtenerLlaveEspecifica }
     * 
     */
    public MensajeEntradaObtenerLlaveEspecifica createMensajeEntradaObtenerLlaveEspecifica() {
        return new MensajeEntradaObtenerLlaveEspecifica();
    }

    /**
     * Create an instance of {@link MensajeSalidaObtenerLlaveEspecifica }
     * 
     */
    public MensajeSalidaObtenerLlaveEspecifica createMensajeSalidaObtenerLlaveEspecifica() {
        return new MensajeSalidaObtenerLlaveEspecifica();
    }

    /**
     * Create an instance of {@link MensajeEntradaObtenerTokenSesionXML.Parametros }
     * 
     */
    public MensajeEntradaObtenerTokenSesionXML.Parametros createMensajeEntradaObtenerTokenSesionXMLParametros() {
        return new MensajeEntradaObtenerTokenSesionXML.Parametros();
    }

    /**
     * Create an instance of {@link MensajeSalidaDecodificarTokenSesionXML.Parametros }
     * 
     */
    public MensajeSalidaDecodificarTokenSesionXML.Parametros createMensajeSalidaDecodificarTokenSesionXMLParametros() {
        return new MensajeSalidaDecodificarTokenSesionXML.Parametros();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MensajeEntradaDecodificarTokenSesionXML }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.bolivariano.com/MensajesFramework", name = "mensajeEntradaDecodificarTokenSesionXML")
    public JAXBElement<MensajeEntradaDecodificarTokenSesionXML> createMensajeEntradaDecodificarTokenSesionXML(MensajeEntradaDecodificarTokenSesionXML value) {
        return new JAXBElement<MensajeEntradaDecodificarTokenSesionXML>(_MensajeEntradaDecodificarTokenSesionXML_QNAME, MensajeEntradaDecodificarTokenSesionXML.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MensajeSalidaDecodificarTokenSesionXML }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.bolivariano.com/MensajesFramework", name = "mensajeSalidaDecodificarTokenSesionXML")
    public JAXBElement<MensajeSalidaDecodificarTokenSesionXML> createMensajeSalidaDecodificarTokenSesionXML(MensajeSalidaDecodificarTokenSesionXML value) {
        return new JAXBElement<MensajeSalidaDecodificarTokenSesionXML>(_MensajeSalidaDecodificarTokenSesionXML_QNAME, MensajeSalidaDecodificarTokenSesionXML.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MensajeSalidaObtenerTokenSesionXML }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.bolivariano.com/MensajesFramework", name = "mensajeSalidaObtenerTokenSesionXML")
    public JAXBElement<MensajeSalidaObtenerTokenSesionXML> createMensajeSalidaObtenerTokenSesionXML(MensajeSalidaObtenerTokenSesionXML value) {
        return new JAXBElement<MensajeSalidaObtenerTokenSesionXML>(_MensajeSalidaObtenerTokenSesionXML_QNAME, MensajeSalidaObtenerTokenSesionXML.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MensajeSalidaObtenerLlaveEspecifica }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.bolivariano.com/MensajesFramework", name = "mensajeSalidaObtenerLlaveEspecifica")
    public JAXBElement<MensajeSalidaObtenerLlaveEspecifica> createMensajeSalidaObtenerLlaveEspecifica(MensajeSalidaObtenerLlaveEspecifica value) {
        return new JAXBElement<MensajeSalidaObtenerLlaveEspecifica>(_MensajeSalidaObtenerLlaveEspecifica_QNAME, MensajeSalidaObtenerLlaveEspecifica.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MensajeEntradaObtenerTokenSesionXML }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.bolivariano.com/MensajesFramework", name = "mensajeEntradaObtenerTokenSesionXML")
    public JAXBElement<MensajeEntradaObtenerTokenSesionXML> createMensajeEntradaObtenerTokenSesionXML(MensajeEntradaObtenerTokenSesionXML value) {
        return new JAXBElement<MensajeEntradaObtenerTokenSesionXML>(_MensajeEntradaObtenerTokenSesionXML_QNAME, MensajeEntradaObtenerTokenSesionXML.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MensajeEntradaObtenerLlaveEspecifica }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.bolivariano.com/MensajesFramework", name = "mensajeEntradaObtenerLlaveEspecifica")
    public JAXBElement<MensajeEntradaObtenerLlaveEspecifica> createMensajeEntradaObtenerLlaveEspecifica(MensajeEntradaObtenerLlaveEspecifica value) {
        return new JAXBElement<MensajeEntradaObtenerLlaveEspecifica>(_MensajeEntradaObtenerLlaveEspecifica_QNAME, MensajeEntradaObtenerLlaveEspecifica.class, null, value);
    }

}
