package com.bolivariano.otc.service;

import com.bolivariano.otc.bean.*;
import com.bolivariano.otc.dao.CatalogoDAO;
import com.bolivariano.otc.dao.CatalogoDetalleDAO;
import com.bolivariano.otc.enumerators.RegisterStatus;
import com.bolivariano.otc.exception.OTCAdminException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Service
public class CatalogoService {

    @Autowired
    CatalogoDetalleDAO detalleDAO;

    @Autowired
    CatalogoDAO catalogoDAO;

    @Autowired
    JdbcTemplate jdbcTemplate;

    private static final Logger log = LoggerFactory.getLogger(CatalogoService.class);

    public List<DetalleCatalogoBean> findDetallesByCode(String code) {
        List<DetalleCatalogoBean> detalles = null;
        try {
            detalles = detalleDAO.findByCode(jdbcTemplate.getDataSource().getConnection(), code);
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
        }
        return detalles;
    }

    @Transactional(propagation = Propagation.REQUIRED)
    public DatabaseResponse insert(CatalogoBean catalogo) throws Exception {
        DatabaseResponse dr = null;
        DatabaseResponse drService = null;
        try {
            dr = catalogoDAO.insert(jdbcTemplate, catalogo);
            if (dr.getAffectedRows().intValue() == 0 || dr.getSequence().intValue() == 0
                    || dr.getSqlCode().intValue() != 0) {
                throw new RuntimeException("Error al insertar catalogo: " + dr.getMessage());
            }
            for (DetalleCatalogoBean detalle : catalogo.getDetalles()) {
                detalle.setCatalogoId(dr.getSequence().longValue());
                drService = detalleDAO.insert(jdbcTemplate, detalle);
                if (!(drService.getAffectedRows().intValue() > 0 && drService.getSequence().intValue() > 0
                        && drService.getSqlCode().intValue() == 0)) {
                    throw new RuntimeException("Error al insertar catalogo: " + drService.getMessage());
                }
            }
            return dr;
        } catch (Exception ex) {
            throw new RuntimeException(ex.getMessage(), ex);
        }
    }

    @Transactional(propagation = Propagation.REQUIRED)
    public DatabaseResponse update(CatalogoBean catalogo) throws Exception {
        DatabaseResponse dr = null;
        DatabaseResponse drDetail = null;
        try {
            dr = catalogoDAO.update(jdbcTemplate, catalogo);
            if (dr.getAffectedRows().intValue() == 0 || dr.getSqlCode().intValue() != 0) {
                throw new RuntimeException("Error al actualizar grupo-servicio: " + dr.getMessage());
            }
            for (DetalleCatalogoBean detalle : catalogo.getDetalles()) {
                if (detalle.getId() == null) {
                    detalle.setCatalogoId((catalogo.getId()));
                    drDetail = detalleDAO.insert(jdbcTemplate, detalle);
                    if (!(drDetail.getAffectedRows().intValue() > 0 && drDetail.getSqlCode().intValue() == 0)) {
                        throw new RuntimeException("Error al actualizar catálogo: " + drDetail.getMessage());
                    }
                } else {
                    if (detalle.getEstado() != null && detalle.getEstado().equals(RegisterStatus.Inactivo.getValue())) {
                        drDetail = detalleDAO.delete(jdbcTemplate, detalle.getId());
                        // delete
                        if (!(drDetail.getAffectedRows().intValue() > 0 && drDetail.getSqlCode().intValue() == 0)) {
                            throw new RuntimeException("Error al actualizar catálogo: " + drDetail.getMessage());
                        }
                    } else {
                        drDetail = detalleDAO.update(jdbcTemplate, detalle);
                        if (!(drDetail.getAffectedRows().intValue() > 0 && drDetail.getSqlCode().intValue() == 0)) {
                            throw new RuntimeException("Error al actualizar catálogo: " + drDetail.getMessage());
                        }
                    }

                }
            }
            return dr;
        } catch (Exception ex) {
            throw new RuntimeException(ex.getMessage(), ex);
        }
    }

    public PaginatedListCatalogo findAll(PaginationRequest pr) throws Exception {

        PaginatedListCatalogo pagedCatalogos = null;
        if (pr.getSortBy() == null || pr.getSortBy().isEmpty())
            pr.setSortBy("id");
        try {
            pagedCatalogos = catalogoDAO.findAll(pr, jdbcTemplate.getDataSource().getConnection());
            return pagedCatalogos;

        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new RuntimeException(ex.getMessage());
        }
    }

    public CatalogoBean findById(Long id) throws Exception {
        CatalogoBean catalogo = null;
        List<DetalleCatalogoBean> detalles = null;
        try {
            catalogo = catalogoDAO.findById(jdbcTemplate.getDataSource().getConnection(), id);
            if (catalogo == null) {
                return null;
            }
            detalles = detalleDAO.findByCatalogueId(jdbcTemplate.getDataSource().getConnection(), id);
            catalogo.setDetalles(detalles);
            return catalogo;

        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new Exception(ex.getMessage());
        }
    }

    public Integer countCode(String code) throws Exception {
        Integer count = null;
        // List<ServicioCanalBean> servicioCanales = null;
        try {
            count = catalogoDAO.countCode(jdbcTemplate, code);
            return count;

        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new Exception(ex.getMessage());
        }
    }


    @Transactional(propagation = Propagation.REQUIRED)
    public DatabaseResponse delete(Long endpointId) throws OTCAdminException {
        DatabaseResponse dr = catalogoDAO.delete(jdbcTemplate, endpointId);
        if (dr.getSqlCode().longValue() == 0L) {
            log.info(dr.getMessage());

        } else {
            log.error("Error en la transacción: " + dr.getMessage());
        }
        return dr;

    }

    public List<CatalogoBean> search(CatalogoBusqueda busqueda) throws Exception {
        List<CatalogoBean> catalogos = null;
        try {
            catalogos = catalogoDAO.search(jdbcTemplate.getDataSource().getConnection(), busqueda);
            return catalogos;

        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new Exception(ex.getMessage());
        }
    }


    @Transactional(propagation = Propagation.REQUIRED)
    public List<DatabaseResponse> deleteMany(Long... ids) throws OTCAdminException {

        List<DatabaseResponse> responses = new ArrayList<DatabaseResponse>();
        DatabaseResponse dr = null;
        for (Long id : ids) {
            dr = catalogoDAO.delete(jdbcTemplate, id);
            dr.setSequence(new BigDecimal(id));
            responses.add(dr);

            if (dr.getSqlCode().longValue() == 0L) {
                log.info(dr.getMessage());

            } else {
                log.error("Error en la transacción: " + dr.getMessage());
            }
        }
        return responses;
    }
}
