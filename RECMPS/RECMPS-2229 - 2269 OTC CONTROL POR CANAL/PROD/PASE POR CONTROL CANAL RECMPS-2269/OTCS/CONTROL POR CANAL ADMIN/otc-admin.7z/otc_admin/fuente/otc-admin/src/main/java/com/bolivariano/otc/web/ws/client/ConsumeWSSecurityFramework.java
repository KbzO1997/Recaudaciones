package com.bolivariano.otc.web.ws.client;


import com.bolivariano.frameworkseguridadtypes.LoginAplicacionIn;
import com.bolivariano.frameworkseguridadtypes.LoginAplicacionOut;
import com.bolivariano.frameworkseguridadtypes.LoginAplicacionTypeIn;
import com.bolivariano.frameworkseguridadtypes.LoginAplicacionTypeOut2;
import com.oracle.xmlns.sca_bloqueologinusuario.frameworkseguridad.frameworkmediator.FrameworkMediatorEp;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.net.URL;


/**
 * The type Consume ws security framework.
 */
@Component
public class ConsumeWSSecurityFramework {

    
    @Value("${otc.fmUrl}")
    private String urlSecurityFramework;
    @Value("${cacerts.path}")
    private String pathCacerts;
    @Value("${cacerts.password}")
    private String passwordCacerts;

    /**
     * Consume ws security framework.
     *
     * @param applicationId   the application id
     * @param applicationUser the application user
     * @return the security framework
     * @throws Exception the exception
     */
    public SecurityFramework consumeWS(String applicationId, String applicationUser) throws Exception {

        SecurityFramework objSecurityFramework = null;
        System.setProperty("javax.net.ssl.trustStore", pathCacerts);
        System.setProperty("javax.net.ssl.trustStorePassword", passwordCacerts);

        LoginAplicacionIn blrequest = new LoginAplicacionIn();
        LoginAplicacionTypeIn loginAplicacionIn = new LoginAplicacionTypeIn();

        loginAplicacionIn.setIdAplicacion(applicationId);
        loginAplicacionIn.setUsuario(applicationUser);

        blrequest.setLoginAplicacionIn(loginAplicacionIn);

        URL wsdlLocation = new URL(urlSecurityFramework);
        FrameworkMediatorEp ws = new FrameworkMediatorEp(wsdlLocation);

        LoginAplicacionOut loginAplicacionOut = ws.getFrameworkPt().loginAplicacion(blrequest);

        if (loginAplicacionOut != null && loginAplicacionOut.getLoginAplicacionOut() != null && loginAplicacionOut.getLoginAplicacionOut().getCampo() != null) {
            objSecurityFramework = new SecurityFramework();
            for (LoginAplicacionTypeOut2.Campo campo : loginAplicacionOut.getLoginAplicacionOut().getCampo()) {
                if ("usuario".equals(campo.getNombre())) {
                    objSecurityFramework.setUser(campo.getValue());
                }
                if ("clave".equals(campo.getNombre())) {
                    objSecurityFramework.setPassword(campo.getValue());
                }
                if ("ip".equals(campo.getNombre())) {
                    objSecurityFramework.setServer(campo.getValue());
                }
                if ("puerto".equals(campo.getNombre())) {
                    objSecurityFramework.setPort(campo.getValue());
                }
                if ("SID".equals(campo.getNombre())) {
                    objSecurityFramework.setDatabasename(campo.getValue());
                }
                if ("servidorStdby".equals(campo.getNombre())){
                	objSecurityFramework.setSwserver(campo.getValue());
                }
                if("puertoStdby".equals(campo.getNombre())) {
                	objSecurityFramework.setSwport(campo.getValue());
                }
                if("servicioStdby".equals(campo.getNombre())) {
                	objSecurityFramework.setService(campo.getValue());
                }

            }
        }

        return objSecurityFramework;


    }

}
