
package com.bolivariano.mensajesframework;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.bolivariano.mensajebolivariano.MensajeEntrada;


/**
 * <p>Java class for MensajeEntradaDecodificarTokenSesionXML complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MensajeEntradaDecodificarTokenSesionXML">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.bolivariano.com/MensajeBolivariano}MensajeEntrada">
 *       &lt;sequence>
 *         &lt;element name="aplicacion" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="token" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="semilla" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MensajeEntradaDecodificarTokenSesionXML", propOrder = {
    "aplicacion",
    "token",
    "semilla"
})
public class MensajeEntradaDecodificarTokenSesionXML
    extends MensajeEntrada
{

    @XmlElement(required = true)
    protected String aplicacion;
    @XmlElement(required = true)
    protected String token;
    @XmlElement(required = true)
    protected String semilla;

    /**
     * Gets the value of the aplicacion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAplicacion() {
        return aplicacion;
    }

    /**
     * Sets the value of the aplicacion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAplicacion(String value) {
        this.aplicacion = value;
    }

    /**
     * Gets the value of the token property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getToken() {
        return token;
    }

    /**
     * Sets the value of the token property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setToken(String value) {
        this.token = value;
    }

    /**
     * Gets the value of the semilla property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSemilla() {
        return semilla;
    }

    /**
     * Sets the value of the semilla property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSemilla(String value) {
        this.semilla = value;
    }

}
