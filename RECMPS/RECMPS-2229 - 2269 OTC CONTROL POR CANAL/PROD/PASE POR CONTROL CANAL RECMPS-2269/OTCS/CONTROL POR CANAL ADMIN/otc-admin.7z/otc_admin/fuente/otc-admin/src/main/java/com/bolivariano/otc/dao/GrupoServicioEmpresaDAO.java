package com.bolivariano.otc.dao;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.bolivariano.otc.MapperUtil;
import com.bolivariano.otc.bean.DatabaseResponse;
import com.bolivariano.otc.dto.Empresa;
import com.bolivariano.otc.dto.GrupoServicio;
import com.bolivariano.otc.exception.OTCAdminException;

import oracle.jdbc.OracleTypes;

@Repository
public class GrupoServicioEmpresaDAO {

    private static final Logger log = LoggerFactory.getLogger(GrupoServicioEmpresaDAO.class);
    private static final String ERROR_PROCESO = "Error en el proceso";
    
    @Autowired
    MapperUtil<GrupoServicio> selectMapper;

    public List<GrupoServicio> obtenerGruposServicio(Connection conn, String tipoBanca, String tipoServicio, String empresa) throws OTCAdminException, SQLException {

        List<GrupoServicio> grupos = null;
        StringBuilder sql = new StringBuilder();
        ResultSet rset = null;
        sql.append(" { call PA_OTC_CGRUPO_TIPO_EMP(?,?,?,?) }");
        try(CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);){
            procStmt.setString(1, tipoBanca);
            procStmt.setString(2, tipoServicio);
            procStmt.setString(3, empresa);
            procStmt.registerOutParameter(4, OracleTypes.CURSOR);
            procStmt.executeUpdate();
            rset = (ResultSet) procStmt.getObject(4);

            if (rset.isBeforeFirst()) {
                grupos = selectMapper.mapResultSetToObject(rset, GrupoServicio.class);
            }

        } catch (Exception e) {
            log.error(ERROR_PROCESO + e.getMessage(),e);
        } finally {
            if (rset != null) {
                rset.close();
            }
        }
        return grupos;
    }

    public List<GrupoServicio> obtenerGrupoServicioEmpresaCodigo(Connection conn, String tipoBanca, String tipoServicio, String codigoEmpresa) throws OTCAdminException, SQLException {

        List<GrupoServicio> grps = null;
        StringBuilder sql = new StringBuilder();
        ResultSet rset = null;
        sql.append(" { call PA_OTC_CGRUPO_TIPO_COD_EMP(?,?,?,?) }");
        try(CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);){
            procStmt.setString(1, tipoBanca);
            procStmt.setString(2, tipoServicio);
            procStmt.setString(3, codigoEmpresa);
            procStmt.registerOutParameter(4, OracleTypes.CURSOR);
            procStmt.executeUpdate();
            rset = (ResultSet) procStmt.getObject(4);
            if (rset.isBeforeFirst()) {
                grps = selectMapper.mapResultSetToObject(rset, GrupoServicio.class);
            }

			
        } catch (Exception e) {
            log.error(ERROR_PROCESO + e.getMessage(),e);
        } finally {
            if (rset != null) {
                rset.close();
            }
        }


        return grps;
    }

    public List<GrupoServicio> obtenerGruposServicio(Connection conn, String tipoBanca, String tipoServicio) throws OTCAdminException, SQLException {

        List<GrupoServicio> grupos = null;
        StringBuilder sql = new StringBuilder();
        ResultSet rset = null;
        sql.append(" { call PA_OTC_CGRUPOSERVICIO_TIPO(?,?,?) }");
        try(CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);){
            procStmt.setString(1, tipoBanca);
            procStmt.setString(2, tipoServicio);
            procStmt.registerOutParameter(3, OracleTypes.CURSOR);
            procStmt.executeUpdate();
            rset = (ResultSet) procStmt.getObject(3);

            if (rset.isBeforeFirst()) {
                grupos = selectMapper.mapResultSetToObject(rset, GrupoServicio.class);
            }

        } catch (Exception e) {
            log.error(ERROR_PROCESO + e.getMessage(),e);
        } finally {
            if (rset != null) {
                rset.close();
            }
        }


        return grupos;
    }
    
   
	
	public DatabaseResponse actualizarEmpresa(JdbcTemplate jdbcTemplate, Empresa empresa) {
		DatabaseResponse dr = new DatabaseResponse();
		try {
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("pa_otc_aempresa")
					.declareParameters(new SqlParameter("e_emp_id", Types.NUMERIC),
							new SqlParameter("e_emp_identificacion", Types.VARCHAR),
							new SqlParameter("e_emp_nombre", Types.VARCHAR), 
							new SqlParameter("e_EMP_CODIGO", Types.VARCHAR),
							new SqlParameter("e_EMP_DESCRIPCION", Types.VARCHAR),
							new SqlOutParameter("s_afectados", Types.INTEGER),
							new SqlOutParameter("s_codigo_error", Types.NUMERIC),
							new SqlOutParameter("s_mensaje", Types.VARCHAR));
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("e_EMP_ID", empresa.getId());
			source.addValue("e_EMP_IDENTIFICACION", empresa.getIdentificacion());
			source.addValue("e_EMP_NOMBRE", empresa.getNombre());
			source.addValue("e_EMP_CODIGO", empresa.getCodigo());
			source.addValue("e_EMP_DESCRIPCION", empresa.getDescripcion());			
			Map<String, Object> out = simpleJdbcCall.execute(source);			
			dr.setAffectedRows((Integer) out.get("s_afectados"));
			dr.setMessage((String) out.get("s_mensaje"));
			dr.setSqlCode((BigDecimal) out.get("s_codigo_error"));
		} catch (Exception ex) {
			log.error(ex.getMessage(), ex);
		}
		return dr;
	}
}
