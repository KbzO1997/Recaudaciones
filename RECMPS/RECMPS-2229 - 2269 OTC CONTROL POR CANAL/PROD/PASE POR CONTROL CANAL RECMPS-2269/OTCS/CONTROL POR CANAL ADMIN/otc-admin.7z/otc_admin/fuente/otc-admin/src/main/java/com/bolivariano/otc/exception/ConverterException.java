package com.bolivariano.otc.exception;

public class ConverterException extends Exception {
	private static final long serialVersionUID = -7100096136236248627L;

	public ConverterException(final String arg0, final Throwable arg1) {
		super(arg0, arg1);
	}

	public ConverterException(final String arg0) {
		super(arg0);
	}

	public ConverterException(final Throwable arg0) {
		super(arg0);
	}
}
