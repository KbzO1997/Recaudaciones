package com.bolivariano.otc.dto;

import java.io.Serializable;


/**
 * The persistent class for the OTC_M_FLUJO database table.
 * 
 */

public class ListaSeleccion implements Serializable {
	private static final long serialVersionUID = 1L;


	private Long id;

	private String codigo;

	private String etiqueta;

	public ListaSeleccion() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getEtiqueta() {
		return etiqueta;
	}

	public void setEtiqueta(String etiqueta) {
		this.etiqueta = etiqueta;
	}

	@Override
	public String toString() {
		return "ListaSeleccion{" +
				"id=" + id +
				", codigo='" + codigo + '\'' +
				", etiqueta='" + etiqueta + '\'' +
				'}';
	}
}