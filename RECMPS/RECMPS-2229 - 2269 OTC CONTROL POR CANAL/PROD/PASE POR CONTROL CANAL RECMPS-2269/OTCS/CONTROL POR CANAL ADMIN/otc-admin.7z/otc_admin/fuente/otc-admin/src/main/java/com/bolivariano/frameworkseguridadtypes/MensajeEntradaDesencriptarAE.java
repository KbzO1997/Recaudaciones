
package com.bolivariano.frameworkseguridadtypes;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for MensajeEntradaDesencriptarAE complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MensajeEntradaDesencriptarAE">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="encData" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MensajeEntradaDesencriptarAE", propOrder = {
    "encData"
})
public class MensajeEntradaDesencriptarAE {

    protected String encData;

    /**
     * Gets the value of the encData property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEncData() {
        return encData;
    }

    /**
     * Sets the value of the encData property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEncData(String value) {
        this.encData = value;
    }

}
