package com.bolivariano.otc.dto;

import java.io.Serializable;
import java.util.List;


/**
 * The persistent class for the OTC_D_SERVICIO database table.
 * 
 */
public class Servicio implements Serializable {
	private static final long serialVersionUID = 1L;

	
	private Long id;

	private GrupoServicio grupoServicio;

	private String nombre;

	private Convenio convenio;
	
	private List<ServicioCanal> serviciosCanales;
	
	public List<ServicioCanal> getServiciosCanales() {
		return serviciosCanales;
	}

	public void setServiciosCanales(List<ServicioCanal> serviciosCanales) {
		this.serviciosCanales = serviciosCanales;
	}

	//transiente
	private Long convenioId;

	
	public Long getConvenioId() {
		return convenioId;
	}

	public void setConvenioId(Long convenioId) {
		this.convenioId = convenioId;
	}

	public Servicio() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public GrupoServicio getGrupoServicio() {
		return grupoServicio;
	}

	public void setGrupoServicio(GrupoServicio grupoServicio) {
		this.grupoServicio = grupoServicio;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Convenio getConvenio() {
		return convenio;
	}

	public void setConvenio(Convenio convenio) {
		this.convenio = convenio;
	}

	@Override
	public String toString() {
		return "Servicio{" +
				"id=" + id +
				", grupoServicio=" + grupoServicio +
				", nombre='" + nombre + '\'' +
				", convenio=" + convenio +
				'}';
	}
}