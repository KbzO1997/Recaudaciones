package com.bolivariano.otc.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;
import java.util.List;


/**
 * The persistent class for the OTC_D_DATOS_ADICIONALES database table.
 *
 */

public class DatoAdicional implements Serializable {
    private static final long serialVersionUID = 1L;

    private Long id;

    private String codigo;

    private String etiqueta;

    private Boolean editable;

    private String formato;

    private List<ListaSeleccion> listasSeleccion;

    private String Longitud;

    private String mascara;

    private String regexp;

    private String tipo;

    private String valor;

    private Boolean visible;

    private Convenio convenio;

    @JsonIgnore
    private Integer editableInt;

    @JsonIgnore
    private Integer visibleInt;

    public DatoAdicional() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getEtiqueta() {
        return etiqueta;
    }

    public void setEtiqueta(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    public Boolean getEditable() {
        return editable;
    }

    public void setEditable(Boolean editable) {
        this.editable = editable;
    }

    public String getFormato() {
        return formato;
    }

    public void setFormato(String formato) {
        this.formato = formato;
    }

    public List<ListaSeleccion> getListasSeleccion() {
        return listasSeleccion;
    }

    public void setListasSeleccion(List<ListaSeleccion> listasSeleccion) {
        this.listasSeleccion = listasSeleccion;
    }

    public String getLongitud() {
        return Longitud;
    }

    public void setLongitud(String longitud) {
        Longitud = longitud;
    }

    public String getMascara() {
        return mascara;
    }

    public void setMascara(String mascara) {
        this.mascara = mascara;
    }

    public String getRegexp() {
        return regexp;
    }

    public void setRegexp(String regexp) {
        this.regexp = regexp;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }

    public Boolean getVisible() {
        return visible;
    }

    public void setVisible(Boolean visible) {
        this.visible = visible;
    }

    public Convenio getConvenio() {
        return convenio;
    }

    public void setConvenio(Convenio convenio) {
        this.convenio = convenio;
    }

    public Integer getEditableInt() {
        return editableInt;
    }

    public void setEditableInt(Integer editableInt) {
        this.editableInt = editableInt;
    }

    public Integer getVisibleInt() {
        return visibleInt;
    }

    public void setVisibleInt(Integer visibleInt) {
        this.visibleInt = visibleInt;
    }

    @Override
    public String toString() {
        return "DatoAdicional{" +
                "id=" + id +
                ", codigo='" + codigo + '\'' +
                ", etiqueta='" + etiqueta + '\'' +
                ", editable=" + editable +
                ", formato='" + formato + '\'' +
                ", listasSeleccion=" + listasSeleccion +
                ", Longitud='" + Longitud + '\'' +
                ", mascara='" + mascara + '\'' +
                ", regexp='" + regexp + '\'' +
                ", tipo='" + tipo + '\'' +
                ", valor='" + valor + '\'' +
                ", visible=" + visible +
                ", convenio=" + convenio +
                '}';
    }
}