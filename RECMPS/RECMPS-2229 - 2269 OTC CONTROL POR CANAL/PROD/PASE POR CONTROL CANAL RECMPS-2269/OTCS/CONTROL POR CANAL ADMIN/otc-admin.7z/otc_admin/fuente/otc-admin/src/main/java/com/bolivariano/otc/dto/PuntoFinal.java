package com.bolivariano.otc.dto;

import java.io.Serializable;


/**
 * The persistent class for the OTC_M_PUNTO_FINAL database table.
 * 
 */

public class PuntoFinal implements Serializable {
	private static final long serialVersionUID = 1L;


	private Long id;

	private String nombre;

	private String operacion;

	private String transformacionPeticion;
	
	private String puntoFinal;

	private String repositorioPeticion;

	private String repositorioRespuesta;

	private String transformacionRespuesta;

	private String ambiente;


	public PuntoFinal() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getOperacion() {
		return operacion;
	}

	public void setOperacion(String operacion) {
		this.operacion = operacion;
	}

	public String getTransformacionPeticion() {
		return transformacionPeticion;
	}

	public void setTransformacionPeticion(String transformacionPeticion) {
		this.transformacionPeticion = transformacionPeticion;
	}

	public String getPuntoFinal() {
		return puntoFinal;
	}

	public void setPuntoFinal(String puntoFinal) {
		this.puntoFinal = puntoFinal;
	}

	public String getRepositorioPeticion() {
		return repositorioPeticion;
	}

	public void setRepositorioPeticion(String repositorioPeticion) {
		this.repositorioPeticion = repositorioPeticion;
	}

	public String getRepositorioRespuesta() {
		return repositorioRespuesta;
	}

	public void setRepositorioRespuesta(String repositorioRespuesta) {
		this.repositorioRespuesta = repositorioRespuesta;
	}

	public String getTransformacionRespuesta() {
		return transformacionRespuesta;
	}

	public void setTransformacionRespuesta(String transformacionRespuesta) {
		this.transformacionRespuesta = transformacionRespuesta;
	}

	public String getAmbiente() {
		return ambiente;
	}

	public void setAmbiente(String ambiente) {
		this.ambiente = ambiente;
	}

	@Override
	public String toString() {
		return "PuntoFinal{" +
				"id=" + id +
				", nombre='" + nombre + '\'' +
				", operacion='" + operacion + '\'' +
				", transformacionPeticion='" + transformacionPeticion + '\'' +
				", puntoFinal='" + puntoFinal + '\'' +
				", repositorioPeticion='" + repositorioPeticion + '\'' +
				", repositorioRespuesta='" + repositorioRespuesta + '\'' +
				", transformacionRespuesta='" + transformacionRespuesta + '\'' +
				", ambiente='" + ambiente + '\'' +
				'}';
	}
}