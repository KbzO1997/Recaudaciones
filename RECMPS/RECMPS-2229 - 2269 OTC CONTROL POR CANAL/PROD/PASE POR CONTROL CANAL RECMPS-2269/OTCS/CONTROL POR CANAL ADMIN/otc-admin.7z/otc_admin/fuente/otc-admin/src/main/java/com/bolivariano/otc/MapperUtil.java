package com.bolivariano.otc;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class MapperUtil<T> {

    private static final Logger log = LoggerFactory.getLogger(MapperUtil.class);

    @SuppressWarnings("unchecked")
    public List<T> mapResultToObject(Map<String, Object> rs, Class<?> outputClass) throws NoSuchMethodException {

        List<T> outputList = null;
        try {
            if (rs != null) {
                Field[] fields = outputClass.getDeclaredFields();
                for (Entry<String, Object> e : rs.entrySet()) {
                    T bean = (T) outputClass.newInstance();

                    // getting the SQL column name
                    String columnName = e.getKey();
                    // reading the value of the SQL column
                    Object columnValue = e.getValue();
                    // iterating over outputClass attributes to check if any attribute has 'Column'
                    // annotation with matching 'name' value
                    for (Field field : fields) {
                        if (columnName.equalsIgnoreCase(field.getName()) && columnValue != null) {
                            BeanUtils.setProperty(bean, field.getName(), columnValue);
                            break;
                        }


                    }
                    if (outputList == null) {
                        outputList = new ArrayList<T>();
                    }
                    outputList.add(bean);
                }

            } else {
                return null;
            }
        } catch (InvocationTargetException e) {
            log.error("Error en el proceso" + e.getMessage(), e);
        } catch (IllegalAccessException e) {
            log.error("Error en el proceso" + e.getMessage(), e);
        } catch (InstantiationException e) {
            log.error("Error en el proceso" + e.getMessage(), e);
        }
        return outputList;
    }

    public List<T> mapResultSetToObject(ResultSet rs, Class<?> outputClass) throws NoSuchMethodException {
        List<T> outputList = null;
        try {
            // make sure resultset is not null
            if (rs != null) {
                // check if outputClass has 'Entity' annotation
                //if (outputClass.isAnnotationPresent(Entity.class)) {
                // get the resultset metadata
                ResultSetMetaData rsmd = rs.getMetaData();
                // get all the attributes of outputClass
                Field[] fields = outputClass.getDeclaredFields();
                while (rs.next()) {
                    T bean = (T) outputClass.newInstance();
                    for (int _iterator = 0; _iterator < rsmd.getColumnCount(); _iterator++) {
                        // getting the SQL column name
                        String columnName = rsmd.getColumnLabel(_iterator + 1);
                        // reading the value of the SQL column
                        Object columnValue = rs.getObject(_iterator + 1);
                        // iterating over outputClass attributes to check if any attribute has 'Column'
                        // annotation with matching 'name' value
                        for (Field field : fields) {

                            if (columnName.equalsIgnoreCase(field.getName()) && columnValue != null) {
                                BeanUtils.setProperty(bean, field.getName(), columnValue);
                                break;
                            }

/*								if (field.isAnnotationPresent(Column.class)) {
                                    Column column = field.getAnnotation(Column.class);
									
									log.info("field: " + column.name() + " columnName: " + columnName);
									
									if (column.name().equalsIgnoreCase(columnName) && columnValue != null) {
										BeanUtils.setProperty(bean, field.getName(), columnValue);
										break;
									}
								}*/
                        }
                    }
                    if (outputList == null) {
                        outputList = new ArrayList<T>();
                    }
                    outputList.add(bean);
                }

                //} else {
                // throw some error
                //}
            } else {
                return null;
            }
        } catch (IllegalAccessException e) {
            log.error("Error en el proceso" + e.getMessage(), e);
        } catch (SQLException e) {
            log.error("Error en el proceso" + e.getMessage(), e);
        } catch (InstantiationException e) {
            log.error("Error en el proceso" + e.getMessage(), e);
        } catch (InvocationTargetException e) {
            log.error("Error en el proceso" + e.getMessage(), e);
        }
        return outputList;
    }
}
