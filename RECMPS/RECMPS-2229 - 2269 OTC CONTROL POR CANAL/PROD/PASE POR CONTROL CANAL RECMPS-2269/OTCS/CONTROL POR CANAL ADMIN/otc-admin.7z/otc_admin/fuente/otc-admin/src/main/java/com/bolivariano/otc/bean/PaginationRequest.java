/*
 * Copyright (c) 2018. Banco Bolivariano.
 */

package com.bolivariano.otc.bean;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * The type Pagination request.
 */
@JsonInclude(Include.NON_NULL)
public class PaginationRequest implements Serializable {

    private static final long serialVersionUID = -8533014651318594825L;

    /**
     * The Page.
     */
    Integer page;
    /**
     * The Size.
     */
    Integer size;
    /**
     * The Sort.
    /**
     * The Sort by.
     */
    String sortBy;

    /**
     * Instantiates a new Pagination request.
     */
    public PaginationRequest() {
    }

    /**
     * Instantiates a new Pagination request.
     *
     * @param page   the page
     * @param size   the size
     * @param sortBy the sort by
     */
    public PaginationRequest(Integer page, Integer size, String sortBy) {
        super();
        this.page = page;
        this.size = size;
        this.sortBy = sortBy;
    }

    /**
     * Gets page.
     *
     * @return the page
     */
    public Integer getPage() {
        return page;
    }

    /**
     * Sets page.
     *
     * @param page the page
     */
    public void setPage(Integer page) {
        this.page = page;
    }

    /**
     * Gets size.
     *
     * @return the size
     */
    public Integer getSize() {
        return size;
    }

    /**
     * Sets size.
     *
     * @param size the size
     */
    public void setSize(Integer size) {
        this.size = size;
    }

    /**
     * Gets sort.
     *
     * @return the sort
     */
  
    /**
     * Gets sort by.
     *
     * @return the sort by
     */
    public String getSortBy() {
        return sortBy;
    }

    /**
     * Sets sort by.
     *
     * @param sortBy the sort by
     */
    public void setSortBy(String sortBy) {
        this.sortBy = sortBy;
    }

    @Override
    public String toString() {
        return "PaginationRequest [page=" + page + ", size=" + size + ", sortBy=" + sortBy + "]";
    }
}

