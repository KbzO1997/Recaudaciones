package com.bolivariano.otc.bean;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import java.io.Serializable;
import java.math.BigDecimal;

@JsonInclude(Include.NON_NULL)
public class DatabaseResponse implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private String message;
    private BigDecimal sequence;
    private Integer affectedRows;
    private BigDecimal sqlCode;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public BigDecimal getSequence() {
        return sequence;
    }

    public void setSequence(BigDecimal sequence) {
        this.sequence = sequence;
    }

    public Integer getAffectedRows() {
        return affectedRows;
    }

    public void setAffectedRows(Integer affectedRows) {
        this.affectedRows = affectedRows;
    }

    public BigDecimal getSqlCode() {
        return sqlCode;
    }

    public void setSqlCode(BigDecimal sqlCode) {
        this.sqlCode = sqlCode;
    }

    @Override
    public String toString() {
        return "DatabaseResponse [message=" + message + ", sequence=" + sequence + ", affectedRows=" + affectedRows
                + ", sqlCode=" + sqlCode + "]";
    }

}
