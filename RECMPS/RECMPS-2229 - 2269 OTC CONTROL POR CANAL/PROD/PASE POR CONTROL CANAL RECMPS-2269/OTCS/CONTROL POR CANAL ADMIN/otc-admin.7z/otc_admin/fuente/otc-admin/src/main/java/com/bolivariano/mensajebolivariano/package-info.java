@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.bolivariano.com/MensajeBolivariano")
package com.bolivariano.mensajebolivariano;
