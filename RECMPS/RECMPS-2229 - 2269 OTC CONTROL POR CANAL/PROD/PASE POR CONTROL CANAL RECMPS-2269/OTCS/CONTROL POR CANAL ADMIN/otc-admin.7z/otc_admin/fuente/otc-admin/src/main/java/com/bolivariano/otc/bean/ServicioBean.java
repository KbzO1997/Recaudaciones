package com.bolivariano.otc.bean;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * The persistent class for the OTC_D_SERVICIO database table.
 * 
 */
@JsonInclude(Include.NON_NULL)
public class ServicioBean implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private Long id;

	private Long grupoServicioId;

	private String nombre;

	private Long convenioId;
	
	private List<ServicioCanalBean> servicioCanales;
	
	private List<Long> canalesId;
	
	private String estado;

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public List<Long> getCanalesId() {
		return canalesId;
	}

	public void setCanalesId(List<Long> canalesId) {
		this.canalesId = canalesId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getGrupoServicioId() {
		return grupoServicioId;
	}

	public void setGrupoServicioId(Long grupoServicioId) {
		this.grupoServicioId = grupoServicioId;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Long getConvenioId() {
		return convenioId;
	}

	public void setConvenioId(Long convenioId) {
		this.convenioId = convenioId;
	}

	public List<ServicioCanalBean> getServicioCanales() {
		return servicioCanales;
	}

	public void setServicioCanales(List<ServicioCanalBean> servicioCanales) {
		this.servicioCanales = servicioCanales;
	}

	@Override
	public String toString() {
		return "ServicioBean [id=" + id + ", grupoServicioId=" + grupoServicioId + ", nombre=" + nombre
				+ ", convenioId=" + convenioId + "]";
	}
}