
package com.bolivariano.mensajesframework;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.bolivariano.filagenerica.FilaGenerica;
import com.bolivariano.mensajebolivariano.MensajeEntrada;


/**
 * <p>Java class for MensajeEntradaObtenerTokenSesionXML complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MensajeEntradaObtenerTokenSesionXML">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.bolivariano.com/MensajeBolivariano}MensajeEntrada">
 *       &lt;sequence>
 *         &lt;element name="parametros">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="parametro" type="{http://www.bolivariano.com/FilaGenerica}FilaGenerica" maxOccurs="unbounded"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="aplicacion">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="ESTADO_CTA"/>
 *               &lt;enumeration value="ESTADO_TC"/>
 *               &lt;enumeration value="FORMS"/>
 *               &lt;enumeration value="DOCSOPER"/>
 *               &lt;enumeration value="DEPEXPRESS"/>
 *               &lt;enumeration value="OTROS"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MensajeEntradaObtenerTokenSesionXML", propOrder = {
    "parametros",
    "aplicacion"
})
public class MensajeEntradaObtenerTokenSesionXML
    extends MensajeEntrada
{

    @XmlElement(required = true)
    protected MensajeEntradaObtenerTokenSesionXML.Parametros parametros;
    @XmlElement(required = true)
    protected String aplicacion;

    /**
     * Gets the value of the parametros property.
     * 
     * @return
     *     possible object is
     *     {@link MensajeEntradaObtenerTokenSesionXML.Parametros }
     *     
     */
    public MensajeEntradaObtenerTokenSesionXML.Parametros getParametros() {
        return parametros;
    }

    /**
     * Sets the value of the parametros property.
     * 
     * @param value
     *     allowed object is
     *     {@link MensajeEntradaObtenerTokenSesionXML.Parametros }
     *     
     */
    public void setParametros(MensajeEntradaObtenerTokenSesionXML.Parametros value) {
        this.parametros = value;
    }

    /**
     * Gets the value of the aplicacion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAplicacion() {
        return aplicacion;
    }

    /**
     * Sets the value of the aplicacion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAplicacion(String value) {
        this.aplicacion = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="parametro" type="{http://www.bolivariano.com/FilaGenerica}FilaGenerica" maxOccurs="unbounded"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "parametro"
    })
    public static class Parametros {

        @XmlElement(required = true)
        protected List<FilaGenerica> parametro;

        /**
         * Gets the value of the parametro property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the parametro property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getParametro().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link FilaGenerica }
         * 
         * 
         */
        public List<FilaGenerica> getParametro() {
            if (parametro == null) {
                parametro = new ArrayList<FilaGenerica>();
            }
            return this.parametro;
        }

    }

}
