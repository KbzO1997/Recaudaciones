package com.bolivariano.otc.exception;

public class OTCAdminException  extends Exception{

	private static final long serialVersionUID = 3753893500371889141L;

	public OTCAdminException() {
		
	}
	
	public OTCAdminException(String message) {
		super(message);
	}
	
	public OTCAdminException(Exception ex) {
		super(ex);
	}
	
	public OTCAdminException(String message, Exception ex) {
		super(message, ex);
	}
	
}
