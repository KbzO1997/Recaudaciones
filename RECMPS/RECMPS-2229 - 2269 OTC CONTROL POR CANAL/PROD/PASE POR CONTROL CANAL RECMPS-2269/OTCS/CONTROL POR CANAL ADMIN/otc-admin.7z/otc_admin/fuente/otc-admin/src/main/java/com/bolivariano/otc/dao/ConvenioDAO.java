package com.bolivariano.otc.dao;

import com.bolivariano.otc.MapperUtil;
import com.bolivariano.otc.bean.*;
import com.bolivariano.otc.dto.Convenio;
import com.bolivariano.otc.exception.OTCAdminException;

import oracle.jdbc.OracleTypes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.*;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@Repository
public class ConvenioDAO {

    private static final Logger log = LoggerFactory.getLogger(ConvenioDAO.class);
    private static final String ERROR_PROCESO = "Error en el proceso: ";
    private static final String S_RESPUESTA = "S_RESPUESTA";
    private static final String S_RESULT = "s_result";
    private static final String ERROR_CONSULTA = "Error al consultar convenios: ";
    private static final String S_AFECTADOS = "s_afectados";
    private static final String S_CODIGO_ERROR = "s_codigo_error";
    private static final String S_MENSAJE = "s_mensaje";
    private static final String E_CODIGO = "e_codigo";
    private static final String E_CNV_ETIQUETA_CODIGO = "e_CNV_ETIQUETA_CODIGO";
    private static final String E_CNV_CODIGO = "e_CNV_CODIGO";
    private static final String E_CNV_VISIBLE = "e_CNV_VISIBLE";
    
    @Autowired
    MapperUtil<Convenio> convenioMapper;

    @Autowired
    MapperUtil<ConvenioBean> convenioBeanMapper;

    @Autowired
    MapperUtil<SelectItemBean> selectMapper;

    public Convenio obtenerConvenio(Connection conn, Long idConvenio) throws OTCAdminException {
        List<Convenio> convenios = null;
        StringBuilder sql = new StringBuilder();
        ResultSet rset = null;
        sql.append(" { call PA_OTC_CCONVENIO(?,?) }");
        try(CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);){
            procStmt.setLong(1, idConvenio);
            procStmt.registerOutParameter(2, OracleTypes.CURSOR);
            procStmt.executeUpdate();
            rset = (ResultSet) procStmt.getObject(2);

            if (rset.isBeforeFirst()) {
                convenios = convenioMapper.mapResultSetToObject(rset, Convenio.class);
            }
			
        } catch (Exception e) {
            log.error(ERROR_PROCESO + e.getMessage(), e);        
        }


        return convenios != null ? convenios.get(0) : null;
    }

    public List<SelectItemBean> findSelectConvenios(Connection conn) throws OTCAdminException {

        List<SelectItemBean> convenios = null;
        StringBuilder sql = new StringBuilder();
        ResultSet rset = null;
        sql.append(" { call PA_OTC_CCONVENIO_SELECT(?) }");
        try(CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);){
            procStmt.registerOutParameter(S_RESPUESTA, OracleTypes.CURSOR);
            procStmt.executeUpdate();
            rset = (ResultSet) procStmt.getObject(S_RESPUESTA);
            if (rset.isBeforeFirst()) {
                convenios = selectMapper.mapResultSetToObject(rset, SelectItemBean.class);
            }
            return convenios;
        } catch (Exception e) {
            log.error(ERROR_PROCESO + e.getMessage(), e);

        }
        return Collections.emptyList();
    }

    public PaginatedListConvenio findAll(PaginationRequest pr, Connection conn) throws SQLException, NoSuchMethodException {

        StringBuilder sql = new StringBuilder();
        ResultSet rs;
        List<ConvenioBean> convenios = null;
        PaginatedListConvenio pagedConvenios;
        sql.append(" { call pa_otc_gconvenio(?,?,?,?,?) }");
        try(CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);){
            procStmt.setInt("e_size", pr.getSize());
            procStmt.setInt("e_page", pr.getPage());
            procStmt.setString("e_sort", pr.getSortBy());
            procStmt.registerOutParameter("s_totalRecord", Types.NUMERIC);
            procStmt.registerOutParameter(S_RESULT, OracleTypes.CURSOR);
            procStmt.executeUpdate();
            rs = (ResultSet) procStmt.getObject(S_RESULT);
            if (rs != null && rs.isBeforeFirst()) {
                convenios = convenioBeanMapper.mapResultSetToObject(rs, ConvenioBean.class);
                pagedConvenios = new PaginatedListConvenio();
                pagedConvenios.setRecordsFiltered(pr.getSize());
                pagedConvenios.setRecordsTotal(procStmt.getBigDecimal("s_totalRecord").longValue());
                pagedConvenios.setData(convenios);
                rs.close();
                
                return pagedConvenios;
            } else {
                return null;
            }

        } catch (SQLException e) {
            log.error(ERROR_CONSULTA + e.getMessage(), e);
            throw new SQLException(ERROR_CONSULTA + e.getMessage(), e);
        }
    }

    public DatabaseResponse insert(JdbcTemplate jdbcTemplate, ConvenioBean convenio) {
        DatabaseResponse dr = new DatabaseResponse();
        try {
            SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("pa_otc_iconvenio")
                    .declareParameters(new SqlParameter(E_CNV_ETIQUETA_CODIGO, Types.VARCHAR),
                            new SqlParameter(E_CNV_CODIGO, Types.VARCHAR),
                            new SqlParameter(E_CNV_VISIBLE, Types.NUMERIC),
                            new SqlOutParameter("s_secuencia", Types.NUMERIC),
                            new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
                            new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
                            new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
            MapSqlParameterSource source = new MapSqlParameterSource();
            source.addValue(E_CNV_ETIQUETA_CODIGO, convenio.getEtiquetaCodigo());
            source.addValue(E_CNV_CODIGO, convenio.getCodigo());
            source.addValue(E_CNV_VISIBLE, convenio.getVisible());
            Map<String, Object> out = simpleJdbcCall.execute(source);

            dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
            dr.setMessage((String) out.get(S_MENSAJE));
            dr.setSequence((BigDecimal) out.get("s_secuencia"));
            dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
        }
        return dr;
    }

    public DatabaseResponse update(JdbcTemplate jdbcTemplate, ConvenioBean convenio) {
        DatabaseResponse dr = new DatabaseResponse();
        try {
            SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("pa_otc_aconvenio")
                    .declareParameters(new SqlParameter(E_CNV_ETIQUETA_CODIGO, Types.VARCHAR),
                            new SqlParameter(E_CNV_CODIGO, Types.VARCHAR),
                            new SqlParameter(E_CNV_VISIBLE, Types.NUMERIC),
                            new SqlParameter("e_CNV_ID", Types.NUMERIC),
                            new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
                            new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
                            new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
            MapSqlParameterSource source = new MapSqlParameterSource();
            source.addValue(E_CNV_ETIQUETA_CODIGO, convenio.getEtiquetaCodigo());
            source.addValue(E_CNV_CODIGO, convenio.getCodigo());
            source.addValue(E_CNV_VISIBLE, convenio.getVisible());
            source.addValue("e_CNV_ID", convenio.getId());
            Map<String, Object> out = simpleJdbcCall.execute(source);
            dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
            dr.setMessage((String) out.get(S_MENSAJE));
            dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
        }
        return dr;
    }


    public ConvenioBean findById(Connection conn, Long id) throws OTCAdminException {

        List<ConvenioBean> convenios = null;
        StringBuilder sql = new StringBuilder();
        ResultSet rset = null;
        sql.append(" { call PA_OTC_CCONVENIO_ID(?,?) }");
        try(CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);){
            procStmt.setLong("e_id ", id);
            procStmt.registerOutParameter(S_RESPUESTA, OracleTypes.CURSOR);
            procStmt.executeUpdate();
            rset = (ResultSet) procStmt.getObject(S_RESPUESTA);
            if (rset != null && rset.isBeforeFirst()) {
                convenios = convenioBeanMapper.mapResultSetToObject(rset, ConvenioBean.class);
                return convenios.get(0);
            }

        } catch (Exception e) {
            log.error(ERROR_PROCESO + e.getMessage(), e);

        }
        return null;
    }

    public Integer countCode(JdbcTemplate jdbcTemplate, String code) {
        Integer count = null;
        try {
            SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_PCONTAR_CODCONV")
                    .declareParameters(new SqlParameter(E_CODIGO, Types.VARCHAR),
                            new SqlOutParameter("s_cantidad", Types.INTEGER));
            MapSqlParameterSource source = new MapSqlParameterSource();
            source.addValue(E_CODIGO, code);
            Map<String, Object> out = simpleJdbcCall.execute(source);
            count = (Integer) out.get("s_cantidad");
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
        }
        return count;
    }

    public DatabaseResponse delete(JdbcTemplate jdbcTemplate, Long convenioId) {
        DatabaseResponse dr = new DatabaseResponse();
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("PA_OTC_ECONVENIO")
                .declareParameters(new SqlParameter("e_cnv_id", Types.NUMERIC),
                		new SqlOutParameter(S_AFECTADOS, Types.INTEGER),
                		new SqlOutParameter(S_CODIGO_ERROR, Types.NUMERIC),
                		new SqlOutParameter(S_MENSAJE, Types.VARCHAR));
        MapSqlParameterSource source = new MapSqlParameterSource();
        source.addValue("e_cnv_id", convenioId);
        Map<String, Object> out = simpleJdbcCall.execute(source);
        dr.setAffectedRows((Integer) out.get(S_AFECTADOS));
        dr.setMessage((String) out.get(S_MENSAJE));
        dr.setSqlCode((BigDecimal) out.get(S_CODIGO_ERROR));

        return dr;
    }

    public List<ConvenioBean> search(Connection conn, ConvenioBusqueda busqueda) throws OTCAdminException, SQLException, NoSuchMethodException {
        StringBuilder sql = new StringBuilder();
        ResultSet rset = null;
        List<ConvenioBean> catalogos = null;
        sql.append(" { call PA_OTC_CCONVENIO_SEARCH(?,?,?) }");
        try(CallableStatement procStmt = conn.prepareCall(sql.toString(), ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);){	
            log.info(busqueda.toString());
            procStmt.setString(E_CODIGO, busqueda.getCodigo());
            procStmt.setString("e_etiqueta", busqueda.getEtiquetaCodigo());
            procStmt.registerOutParameter(S_RESULT, OracleTypes.CURSOR);
            procStmt.executeUpdate();
            rset = (ResultSet) procStmt.getObject(S_RESULT);
            if (rset.isBeforeFirst()) {
                catalogos = convenioBeanMapper.mapResultSetToObject(rset, ConvenioBean.class);
                rset.close();
                
                return catalogos;
            } else {
                return Collections.emptyList();
            }

        } catch (SQLException e) {
            log.error(ERROR_CONSULTA + e.getMessage(), e);
            throw new SQLException(ERROR_CONSULTA + e.getMessage(), e);
        }
    }

}
