package com.bolivariano.otc.bean;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * The persistent class for the OTC_M_FLUJO database table.
 * 
 */
@JsonInclude(Include.NON_NULL)
public class SeleccionBean implements Serializable {
	private static final long serialVersionUID = 1L;


	private Long id;

	private String codigo;

	private String etiqueta;
	
	private Long datoAdicionalId;
	
	private String estado;

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public Long getDatoAdicionalId() {
		return datoAdicionalId;
	}

	public void setDatoAdicionalId(Long datoAdicionalId) {
		this.datoAdicionalId = datoAdicionalId;
	}

	public SeleccionBean() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getEtiqueta() {
		return etiqueta;
	}

	public void setEtiqueta(String etiqueta) {
		this.etiqueta = etiqueta;
	}

	@Override
	public String toString() {
		return "ListaSeleccion{" +
				"id=" + id +
				", codigo='" + codigo + '\'' +
				", etiqueta='" + etiqueta + '\'' +
				'}';
	}
}