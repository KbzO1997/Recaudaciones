package com.bolivariano.otc.bean;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * The persistent class for the OTC_M_FLUJO database table.
 * 
 */
@JsonInclude(Include.NON_NULL)
public class RegionalAreaBean implements Serializable {
	private static final long serialVersionUID = 1L;


	private Long id;
	
	private Long tipoIdentificadorId;

	private String codigo;

	public RegionalAreaBean() {
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public Long getId() {
		return id;
	}

	public String getCodigo() {
		return codigo;
	}
	

	public Long getTipoIdentificadorId() {
		return tipoIdentificadorId;
	}

	public void setTipoIdentificadorId(Long tipoIdentificadorId) {
		this.tipoIdentificadorId = tipoIdentificadorId;
	}

	public RegionalAreaBean(Long tipoIdentificadorId, String codigo) {
		this.tipoIdentificadorId = tipoIdentificadorId;
		this.codigo = codigo;
	}

	@Override
	public String toString() {
		return "RegionalArea{" +
				"id=" + id +
				", codigo='" + codigo + '\'' +
				'}';
	}
}