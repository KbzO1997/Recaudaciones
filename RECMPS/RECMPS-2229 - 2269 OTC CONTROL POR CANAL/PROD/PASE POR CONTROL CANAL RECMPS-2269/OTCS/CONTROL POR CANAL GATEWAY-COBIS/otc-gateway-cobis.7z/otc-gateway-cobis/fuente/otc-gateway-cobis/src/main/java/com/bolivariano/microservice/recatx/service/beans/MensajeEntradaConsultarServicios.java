package com.bolivariano.microservice.recatx.service.beans;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.processing.Generated;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonValue;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "canal",
        "depuracion",
        "fecha",
        "oficina",
        "secuencial",
        "tipoBanca",
        "tipoMatriculacion",
        "tipoServicio",
        "transaccion",
        "usuario"
})
@Generated("jsonschema2pojo")
public class MensajeEntradaConsultarServicios extends MensajeBaseEntradaConsultar{

  
    /**
     * utilizado para filtrar aquellos servicios que no apliquen a empresas o individuos
     */
    @JsonProperty("tipoBanca")
    @JsonPropertyDescription("utilizado para filtrar aquellos servicios que no apliquen a empresas o individuos")
    private String tipoBanca;
    /**
     * MATRICULABLE, NO_MATRICULABLE
     */
    @JsonProperty("tipoMatriculacion")
    @JsonPropertyDescription("MATRICULABLE, NO_MATRICULABLE")
    private TipoMatriculacion tipoMatriculacion;
    /**
     * tipo de servicio
     */
    @JsonProperty("tipoServicio")
    @JsonPropertyDescription("tipo de servicio")
    private String tipoServicio;
    

    /**
     * utilizado para filtrar aquellos servicios que no apliquen a empresas o individuos
     */
    @JsonProperty("tipoBanca")
    public String getTipoBanca() {
        return tipoBanca;
    }

    /**
     * utilizado para filtrar aquellos servicios que no apliquen a empresas o individuos
     */
    @JsonProperty("tipoBanca")
    public void setTipoBanca(String tipoBanca) {
        this.tipoBanca = tipoBanca;
    }

    /**
     * MATRICULABLE, NO_MATRICULABLE
     */
    @JsonProperty("tipoMatriculacion")
    public TipoMatriculacion getTipoMatriculacion() {
        return tipoMatriculacion;
    }

    /**
     * MATRICULABLE, NO_MATRICULABLE
     */
    @JsonProperty("tipoMatriculacion")
    public void setTipoMatriculacion(TipoMatriculacion tipoMatriculacion) {
        this.tipoMatriculacion = tipoMatriculacion;
    }

    /**
     * tipo de servicio
     */
    @JsonProperty("tipoServicio")
    public String getTipoServicio() {
        return tipoServicio;
    }

    /**
     * tipo de servicio
     */
    @JsonProperty("tipoServicio")
    public void setTipoServicio(String tipoServicio) {
        this.tipoServicio = tipoServicio;
    }

   

    public enum TipoMatriculacion {

        MATRICULABLE("MATRICULABLE"),
        NO_MATRICULABLE("NO_MATRICULABLE");
        private static final Map<String, TipoMatriculacion> CONSTANTS = new HashMap<String, TipoMatriculacion>();

        static {
            for (TipoMatriculacion c : values()) {
                CONSTANTS.put(c.value, c);
            }
        }

        private final String value;

        private TipoMatriculacion(String value) {
            this.value = value;
        }

        @JsonCreator
        public static TipoMatriculacion fromValue(String value) {
            TipoMatriculacion constant = CONSTANTS.get(value);
            if (constant == null) {
                throw new IllegalArgumentException(value);
            } else {
                return constant;
            }
        }

        @Override
        public String toString() {
            return this.value;
        }

        @JsonValue
        public String value() {
            return this.value;
        }

    }

}
