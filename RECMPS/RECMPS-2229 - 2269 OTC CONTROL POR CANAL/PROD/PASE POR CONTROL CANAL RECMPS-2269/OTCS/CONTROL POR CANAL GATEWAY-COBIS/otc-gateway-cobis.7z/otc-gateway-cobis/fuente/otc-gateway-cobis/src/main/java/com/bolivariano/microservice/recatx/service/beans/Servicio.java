package com.bolivariano.microservice.recatx.service.beans;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import javax.annotation.processing.Generated;
import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "codigoConvenio",
        "codigoTipoBanca",
        "codigoTipoIdentificador",
        "datosAdicionales",
        "identificador",
        "codigoTipoServicio"
})
@Generated("jsonschema2pojo")
public class Servicio {

    /**
     * codigo de convenio
     */
    @JsonProperty("codigoConvenio")
    @JsonPropertyDescription("codigo de convenio")
    private String codigoConvenio;
    /**
     * codigo tipo de banca
     */
    @JsonProperty("codigoTipoBanca")
    @JsonPropertyDescription("codigo tipo de banca")
    private String codigoTipoBanca;
    /**
     * codigo tipo identificador
     */
    @JsonProperty("codigoTipoIdentificador")
    @JsonPropertyDescription("codigo tipo identificador")
    private String codigoTipoIdentificador;
    /**
     * datos adicionales
     */
    @JsonProperty("datosAdicionales")
    @JsonPropertyDescription("datos adicionales")
    private List<DatoAdicional> datosAdicionales = new ArrayList<DatoAdicional>();
    /**
     * identificador
     */
    @JsonProperty("identificador")
    @JsonPropertyDescription("identificador")
    private String identificador;
    /**
     * codigo tipo servicio
     */
    @JsonProperty("codigoTipoServicio")
    @JsonPropertyDescription("codigo tipo servicio")
    private String codigoTipoServicio;

    /**
     * codigo de convenio
     */
    @JsonProperty("codigoConvenio")
    public String getCodigoConvenio() {
        return codigoConvenio;
    }

    /**
     * codigo de convenio
     */
    @JsonProperty("codigoConvenio")
    public void setCodigoConvenio(String codigoConvenio) {
        this.codigoConvenio = codigoConvenio;
    }

    /**
     * codigo tipo de banca
     */
    @JsonProperty("codigoTipoBanca")
    public String getCodigoTipoBanca() {
        return codigoTipoBanca;
    }

    /**
     * codigo tipo de banca
     */
    @JsonProperty("codigoTipoBanca")
    public void setCodigoTipoBanca(String codigoTipoBanca) {
        this.codigoTipoBanca = codigoTipoBanca;
    }

    /**
     * codigo tipo identificador
     */
    @JsonProperty("codigoTipoIdentificador")
    public String getCodigoTipoIdentificador() {
        return codigoTipoIdentificador;
    }

    /**
     * codigo tipo identificador
     */
    @JsonProperty("codigoTipoIdentificador")
    public void setCodigoTipoIdentificador(String codigoTipoIdentificador) {
        this.codigoTipoIdentificador = codigoTipoIdentificador;
    }

    /**
     * datos adicionales
     */
    @JsonProperty("datosAdicionales")
    public List<DatoAdicional> getDatosAdicionales() {
        return datosAdicionales;
    }

    /**
     * datos adicionales
     */
    @JsonProperty("datosAdicionales")
    public void setDatosAdicionales(List<DatoAdicional> datosAdicionales) {
        this.datosAdicionales = datosAdicionales;
    }

    /**
     * identificador
     */
    @JsonProperty("identificador")
    public String getIdentificador() {
        return identificador;
    }

    /**
     * identificador
     */
    @JsonProperty("identificador")
    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }

    /**
     * codigo tipo servicio
     */
    @JsonProperty("codigoTipoServicio")
    public String getCodigoTipoServicio() {
        return codigoTipoServicio;
    }

    /**
     * codigo tipo servicio
     */
    @JsonProperty("codigoTipoServicio")
    public void setCodigoTipoServicio(String codigoTipoServicio) {
        this.codigoTipoServicio = codigoTipoServicio;
    }

}
