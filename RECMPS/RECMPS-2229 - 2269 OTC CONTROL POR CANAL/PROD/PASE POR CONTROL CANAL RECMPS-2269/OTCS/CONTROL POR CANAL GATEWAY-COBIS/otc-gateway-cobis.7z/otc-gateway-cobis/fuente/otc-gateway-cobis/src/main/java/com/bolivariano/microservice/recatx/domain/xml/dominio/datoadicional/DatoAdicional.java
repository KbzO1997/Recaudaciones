package com.bolivariano.microservice.recatx.domain.xml.dominio.datoadicional;

import com.bolivariano.microservice.recatx.domain.xml.dominio.listaseleccion.ListaSeleccion;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>Clase Java para datoAdicional complex type.
 *
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 *
 * <pre>
 * &lt;complexType name="datoAdicional">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codigo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="etiqueta" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="editable" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="formato" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="listasSeleccion" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="listaSeleccion" type="{http://www.bolivariano.com/dominio/ListaSeleccion}listaSeleccion" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="longitud" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="mascara" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="regexp" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tipo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="valor" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="visible" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "datoAdicional", propOrder = {
        "codigo",
        "etiqueta",
        "editable",
        "formato",
        "listasSeleccion",
        "longitud",
        "mascara",
        "regexp",
        "tipo",
        "valor",
        "visible"
})
public class DatoAdicional {

    protected String codigo;
    protected String etiqueta;
    protected Boolean editable;
    protected String formato;
    protected ListasSeleccion listasSeleccion;
    protected String longitud;
    protected String mascara;
    protected String regexp;
    protected String tipo;
    protected String valor;
    protected Boolean visible;

    /**
     * Obtiene el valor de la propiedad codigo.
     *
     * @return possible object is
     * {@link String }
     */
    public String getCodigo() {
        return codigo;
    }

    /**
     * Define el valor de la propiedad codigo.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setCodigo(String value) {
        this.codigo = value;
    }

    /**
     * Obtiene el valor de la propiedad etiqueta.
     *
     * @return possible object is
     * {@link String }
     */
    public String getEtiqueta() {
        return etiqueta;
    }

    /**
     * Define el valor de la propiedad etiqueta.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setEtiqueta(String value) {
        this.etiqueta = value;
    }

    /**
     * Obtiene el valor de la propiedad editable.
     *
     * @return possible object is
     * {@link Boolean }
     */
    public Boolean isEditable() {
        return editable;
    }

    /**
     * Define el valor de la propiedad editable.
     *
     * @param value allowed object is
     *              {@link Boolean }
     */
    public void setEditable(Boolean value) {
        this.editable = value;
    }

    /**
     * Obtiene el valor de la propiedad formato.
     *
     * @return possible object is
     * {@link String }
     */
    public String getFormato() {
        return formato;
    }

    /**
     * Define el valor de la propiedad formato.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setFormato(String value) {
        this.formato = value;
    }

    /**
     * Obtiene el valor de la propiedad listasSeleccion.
     *
     * @return possible object is
     * {@link ListasSeleccion }
     */
    public ListasSeleccion getListasSeleccion() {
        return listasSeleccion;
    }

    /**
     * Define el valor de la propiedad listasSeleccion.
     *
     * @param value allowed object is
     *              {@link ListasSeleccion }
     */
    public void setListasSeleccion(ListasSeleccion value) {
        this.listasSeleccion = value;
    }

    /**
     * Obtiene el valor de la propiedad longitud.
     *
     * @return possible object is
     * {@link String }
     */
    public String getLongitud() {
        return longitud;
    }

    /**
     * Define el valor de la propiedad longitud.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setLongitud(String value) {
        this.longitud = value;
    }

    /**
     * Obtiene el valor de la propiedad mascara.
     *
     * @return possible object is
     * {@link String }
     */
    public String getMascara() {
        return mascara;
    }

    /**
     * Define el valor de la propiedad mascara.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setMascara(String value) {
        this.mascara = value;
    }

    /**
     * Obtiene el valor de la propiedad regexp.
     *
     * @return possible object is
     * {@link String }
     */
    public String getRegexp() {
        return regexp;
    }

    /**
     * Define el valor de la propiedad regexp.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setRegexp(String value) {
        this.regexp = value;
    }

    /**
     * Obtiene el valor de la propiedad tipo.
     *
     * @return possible object is
     * {@link String }
     */
    public String getTipo() {
        return tipo;
    }

    /**
     * Define el valor de la propiedad tipo.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setTipo(String value) {
        this.tipo = value;
    }

    /**
     * Obtiene el valor de la propiedad valor.
     *
     * @return possible object is
     * {@link String }
     */
    public String getValor() {
        return valor;
    }

    /**
     * Define el valor de la propiedad valor.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setValor(String value) {
        this.valor = value;
    }

    /**
     * Obtiene el valor de la propiedad visible.
     *
     * @return possible object is
     * {@link Boolean }
     */
    public Boolean isVisible() {
        return visible;
    }

    /**
     * Define el valor de la propiedad visible.
     *
     * @param value allowed object is
     *              {@link Boolean }
     */
    public void setVisible(Boolean value) {
        this.visible = value;
    }


    /**
     * <p>Clase Java para anonymous complex type.
     *
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     *
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="listaSeleccion" type="{http://www.bolivariano.com/dominio/ListaSeleccion}listaSeleccion" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
            "listaSeleccion"
    })
    public static class ListasSeleccion {

        @XmlElement(nillable = true)
        protected List<ListaSeleccion> listaSeleccion;

        /**
         * Gets the value of the listaSeleccion property.
         *
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the listaSeleccion property.
         *
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getListaSeleccion().add(newItem);
         * </pre>
         *
         *
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link ListaSeleccion }
         */
        public List<ListaSeleccion> getListaSeleccion() {
            if (listaSeleccion == null) {
                listaSeleccion = new ArrayList<>();
            }
            return this.listaSeleccion;
        }

    }

}
