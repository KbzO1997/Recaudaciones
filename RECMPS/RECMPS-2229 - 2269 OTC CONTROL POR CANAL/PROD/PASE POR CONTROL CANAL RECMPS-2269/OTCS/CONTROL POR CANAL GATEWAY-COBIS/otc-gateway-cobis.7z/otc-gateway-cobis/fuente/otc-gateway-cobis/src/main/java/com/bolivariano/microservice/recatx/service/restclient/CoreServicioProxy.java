package com.bolivariano.microservice.recatx.service.restclient;

import com.bolivariano.microservice.recatx.service.restclient.message.MensajeEntradaProcesar;
import com.bolivariano.microservice.recatx.service.restclient.message.MensajeSalidaProcesar;
import org.eclipse.microprofile.rest.client.annotation.RegisterClientHeaders;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import javax.ws.rs.POST;
import javax.ws.rs.Path;

@Path("/engine")
@RegisterRestClient
@RegisterClientHeaders(RequestUUIDHeaderFactory.class)
public interface CoreServicioProxy {

    @POST
    MensajeSalidaProcesar procesar(MensajeEntradaProcesar peticionObj);
}
