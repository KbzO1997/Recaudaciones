@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.bolivariano.com/dominio/TipoIdentificador")
package com.bolivariano.microservice.recatx.domain.xml.dominio.tipoidentificador;
