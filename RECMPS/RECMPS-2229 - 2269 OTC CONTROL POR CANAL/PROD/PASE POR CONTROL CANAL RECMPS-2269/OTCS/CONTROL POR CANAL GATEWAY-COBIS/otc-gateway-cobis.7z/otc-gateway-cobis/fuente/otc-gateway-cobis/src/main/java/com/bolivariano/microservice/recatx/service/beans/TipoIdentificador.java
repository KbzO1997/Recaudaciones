package com.bolivariano.microservice.recatx.service.beans;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import javax.annotation.processing.Generated;
import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "codigo",
        "datosAdicionales",
        "regionalAreas"
})
@Generated("jsonschema2pojo")
public class TipoIdentificador {

    /**
     * codigo
     */
    @JsonProperty("codigo")
    @JsonPropertyDescription("codigo")
    private String codigo;
    /**
     * datos adicionales
     */
    @JsonProperty("datosAdicionales")
    @JsonPropertyDescription("datos adicionales")
    private List<DatoAdicional> datosAdicionales = new ArrayList<DatoAdicional>();
    /**
     * regionales areas
     */
    @JsonProperty("regionalAreas")
    @JsonPropertyDescription("regionales areas")
    private List<RegionalArea> regionalAreas = new ArrayList<RegionalArea>();

    /**
     * codigo
     */
    @JsonProperty("codigo")
    public String getCodigo() {
        return codigo;
    }

    /**
     * codigo
     */
    @JsonProperty("codigo")
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    /**
     * datos adicionales
     */
    @JsonProperty("datosAdicionales")
    public List<DatoAdicional> getDatosAdicionales() {
        return datosAdicionales;
    }

    /**
     * datos adicionales
     */
    @JsonProperty("datosAdicionales")
    public void setDatosAdicionales(List<DatoAdicional> datosAdicionales) {
        this.datosAdicionales = datosAdicionales;
    }

    /**
     * regionales areas
     */
    @JsonProperty("regionalAreas")
    public List<RegionalArea> getRegionalAreas() {
        return regionalAreas;
    }

    /**
     * regionales areas
     */
    @JsonProperty("regionalAreas")
    public void setRegionalAreas(List<RegionalArea> regionalAreas) {
        this.regionalAreas = regionalAreas;
    }

}
