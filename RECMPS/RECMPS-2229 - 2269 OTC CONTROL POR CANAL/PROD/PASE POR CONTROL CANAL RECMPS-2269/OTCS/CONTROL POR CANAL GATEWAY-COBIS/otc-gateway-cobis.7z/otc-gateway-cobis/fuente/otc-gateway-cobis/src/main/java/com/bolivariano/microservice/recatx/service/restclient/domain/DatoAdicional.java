package com.bolivariano.microservice.recatx.service.restclient.domain;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;


/**
 * The persistent class for the OTC_D_DATOS_ADICIONALES database table.
 */

@Data
@NoArgsConstructor
public class DatoAdicional implements Serializable {
    private static final long serialVersionUID = 1L;

    private Long id;

    private String codigo;

    private String etiqueta;

    private Boolean editable;

    private String formato;

    private List<ListaSeleccion> listasSeleccion;

    private String Longitud;

    private String mascara;

    private String regexp;

    private String tipo;

    private String valor;

    private Boolean visible;

    private Convenio convenio;

}