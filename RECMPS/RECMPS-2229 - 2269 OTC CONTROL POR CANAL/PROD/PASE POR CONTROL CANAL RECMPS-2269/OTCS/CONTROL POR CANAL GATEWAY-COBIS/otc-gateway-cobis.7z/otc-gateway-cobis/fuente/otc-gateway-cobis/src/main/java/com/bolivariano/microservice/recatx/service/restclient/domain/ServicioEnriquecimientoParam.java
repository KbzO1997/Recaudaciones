package com.bolivariano.microservice.recatx.service.restclient.domain;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;


/**
 * The persistent class for the OTC_P_SERV_ENRIQ_PARAM database table.
 */
@Data
@NoArgsConstructor
public class ServicioEnriquecimientoParam implements Serializable {
    private static final long serialVersionUID = 1L;

    private Long id;

    private ServicioEnriquecimiento servicioEnriquecimiento;

    private String alias;

    private String estado;

    private Date fechaRegistro;

    private String tipo;

}