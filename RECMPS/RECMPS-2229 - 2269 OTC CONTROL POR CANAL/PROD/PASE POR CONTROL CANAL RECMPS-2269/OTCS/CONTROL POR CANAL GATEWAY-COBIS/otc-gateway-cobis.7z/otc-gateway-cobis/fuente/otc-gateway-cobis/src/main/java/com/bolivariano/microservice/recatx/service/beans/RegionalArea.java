package com.bolivariano.microservice.recatx.service.beans;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import javax.annotation.processing.Generated;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "codigo",
        "identificador"
})
@Generated("jsonschema2pojo")
public class RegionalArea {

    /**
     * codigo de regional area
     */
    @JsonProperty("codigo")
    @JsonPropertyDescription("codigo de regional area")
    private String codigo;
    /**
     * Identificador para canal
     */
    @JsonProperty("identificador")
    @JsonPropertyDescription("Identificador para canal")
    private String identificador;

    /**
     * codigo de regional area
     */
    @JsonProperty("codigo")
    public String getCodigo() {
        return codigo;
    }

    /**
     * codigo de regional area
     */
    @JsonProperty("codigo")
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    /**
     * Identificador para canal
     */
    @JsonProperty("identificador")
    public String getIdentificador() {
        return identificador;
    }

    /**
     * Identificador para canal
     */
    @JsonProperty("identificador")
    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }

}
