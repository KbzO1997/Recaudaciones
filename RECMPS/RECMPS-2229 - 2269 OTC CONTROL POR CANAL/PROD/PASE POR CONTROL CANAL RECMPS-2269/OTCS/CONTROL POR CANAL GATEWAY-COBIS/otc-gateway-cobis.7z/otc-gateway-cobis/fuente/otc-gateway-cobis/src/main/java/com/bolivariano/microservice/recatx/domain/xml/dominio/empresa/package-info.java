@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.bolivariano.com/dominio/Empresa")
package com.bolivariano.microservice.recatx.domain.xml.dominio.empresa;
