package com.bolivariano.microservice.recatx.service.restclient.domain;


import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;


/**
 * The persistent class for the OTC_D_FORMA_PAGO database table.
 */
@Data
@NoArgsConstructor
public class FormaPago implements Serializable {
    private static final long serialVersionUID = 1L;

    private Long id;

    private String nombre;

    private Double interes;

    private Integer cuotas;

    private String medio;

    private String etiqueta;

    private Convenio convenio;

}