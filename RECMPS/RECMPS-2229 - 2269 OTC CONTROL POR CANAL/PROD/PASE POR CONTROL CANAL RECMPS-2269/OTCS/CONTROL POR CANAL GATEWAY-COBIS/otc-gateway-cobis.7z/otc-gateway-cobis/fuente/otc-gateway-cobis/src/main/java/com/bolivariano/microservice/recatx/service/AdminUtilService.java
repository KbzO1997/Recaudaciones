package com.bolivariano.microservice.recatx.service;

import com.bolivariano.microservice.recatx.service.restclient.GrupoServicioProxy;
import com.bolivariano.microservice.recatx.service.restclient.domain.*;
import com.bolivariano.microservice.recatx.service.restclient.message.MensajeEntradaConsultarGrupoServicio;
import com.bolivariano.microservice.recatx.service.restclient.message.MensajeEntradaConsultarGrupoServicioOBS;
import com.bolivariano.microservice.recatx.service.restclient.message.MensajeSalidaConsultarGrupoServicio;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.jboss.logging.Logger;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.List;

@ApplicationScoped
public class AdminUtilService {

    @Inject
    @RestClient
    GrupoServicioProxy proxyAdmin;

    @Inject
    Logger log;

    @Inject
    CacheService cacheService;

    public Flujo obtenerFlujo(String convenio, String codigoEmpresa, String tipoServicio, String tipoBanca, String tipoFlujo, Boolean recaudador, String canal) throws JsonProcessingException {
        tipoBanca = (tipoBanca != null) ? tipoBanca : "BP";
        MensajeSalidaConsultarGrupoServicio respuestaObj = null;
        ObjectMapper mapper = new ObjectMapper();
        String mscgsJson;

        log.info("CONVENIO: " + convenio);

        if (recaudador.booleanValue()) {
            MensajeEntradaConsultarGrupoServicio peticionObj = new MensajeEntradaConsultarGrupoServicio();
            peticionObj.setTipoServicio(tipoServicio);
            peticionObj.setTipoBanca(tipoBanca);
            peticionObj.setCodigoEmpresa(codigoEmpresa);
            peticionObj.setCanal(canal);

            //mensaje cache
            mscgsJson = cacheService.get(generarCacheKey("obtenerGrupoServicio",peticionObj.getCodigoEmpresa(),peticionObj.getTipoBanca(),peticionObj.getTipoServicio(),peticionObj.getMatriculable()).toString());

            if (mscgsJson != null) {
                respuestaObj = mapper.readValue(mscgsJson, MensajeSalidaConsultarGrupoServicio.class);
            }

            if (respuestaObj == null || respuestaObj.getCodigo() == null || respuestaObj.getCodigo().isEmpty()) {
                respuestaObj = proxyAdmin.obtenerGrupoServicio(peticionObj);
                //setea en cache
                cacheService.setex(generarCacheKey("obtenerGrupoServicio",peticionObj.getCodigoEmpresa(),peticionObj.getTipoBanca(),peticionObj.getTipoServicio(),peticionObj.getMatriculable()).toString(), mapper.writeValueAsString(respuestaObj));
            }


        } else {
            MensajeEntradaConsultarGrupoServicioOBS peticionObj = new MensajeEntradaConsultarGrupoServicioOBS();
            peticionObj.setTipoServicio(tipoServicio);
            peticionObj.setTipoBanca(tipoBanca);
            peticionObj.setCanal(canal);

            //mensaje cache
            mscgsJson = cacheService.get(generarCacheKey("obtenerGrupoServicioOBS","001",peticionObj.getTipoBanca(),peticionObj.getTipoServicio(),peticionObj.getMatriculable()).toString());

            if (mscgsJson != null) {
                respuestaObj = mapper.readValue(mscgsJson, MensajeSalidaConsultarGrupoServicio.class);
            }

            if (respuestaObj == null || respuestaObj.getCodigo() == null || respuestaObj.getCodigo().isEmpty()) {
                respuestaObj = proxyAdmin.obtenerGrupoServicioOBS(peticionObj);
                //setea en cache
                cacheService.setex(generarCacheKey("obtenerGrupoServicioOBS","001",peticionObj.getTipoBanca(),peticionObj.getTipoServicio(),peticionObj.getMatriculable()).toString(), mapper.writeValueAsString(respuestaObj));
            }

        }

        List<GrupoServicio> grupoServicios = respuestaObj.getMensaje();

        log.info("RESPUESTA FLUJO: " + respuestaObj);
        log.info("GRUPOS FLUJO: " + grupoServicios);
        return obtieneFlujoGruposServicio(grupoServicios, tipoFlujo, convenio);

    }

    private Flujo obtieneFlujoGruposServicio(List<GrupoServicio> grupoServicios, String tipoFlujo, String convenio){
        Flujo flujoObj;
        if (grupoServicios != null && !grupoServicios.isEmpty()) {
            for (GrupoServicio grupoServicio : grupoServicios) {
                log.info("GRUPO FLUJO: " + grupoServicio);
                if (grupoServicio.getServicios() != null && !grupoServicio.getServicios().isEmpty()) {
                    flujoObj = obtieneFlujoGrupoServicio(grupoServicio, tipoFlujo, convenio);
                    if (flujoObj != null) return flujoObj;

                }
            }
        }
        return null;
    }
    private Flujo obtieneFlujoGrupoServicio(GrupoServicio grupoServicio, String tipoFlujo, String convenio){
        Flujo flujoObj;
        for (Servicio servicio : grupoServicio.getServicios()) {
            log.info("SERVICIO FLUJO: " + servicio);
            if (servicio.getConvenio() != null && servicio.getConvenio().getFlujos() != null && !servicio.getConvenio().getFlujos().isEmpty() && convenio.equals(servicio.getConvenio().getCodigo())) {
                log.info("CONVENIO FLUJO: " + servicio.getConvenio());
                flujoObj = obtieneFlujoServicio(servicio, tipoFlujo);
                if (flujoObj != null) return flujoObj;
            }
        }
        return null;
    }

    private Flujo obtieneFlujoServicio(Servicio servicio, String tipoFlujo){
        for (Flujo flujo : servicio.getConvenio().getFlujos()) {
            log.info(" FLUJO: " + flujo);
            log.info(flujo.getOperacion().getCodigo());
            if (flujo.getOperacion() != null && tipoFlujo.equals(flujo.getOperacion().getCodigo())) {
                log.info(" FLUJO_1: " + flujo);
                return flujo;
            }
        }
        return null;
    }
    
    private StringBuilder generarCacheKey(String nombreCache, String codigoEmpresa,String tipoBanca,String tipoServicio,Boolean matriculable){

        StringBuilder cacheKey = new StringBuilder();
        cacheKey.append(nombreCache);
        cacheKey.append("|");
        cacheKey.append(codigoEmpresa);
        cacheKey.append(tipoBanca);
        cacheKey.append("|");
        cacheKey.append(tipoServicio);
        cacheKey.append("|");
        cacheKey.append(matriculable);
        
        return cacheKey;
    }
}
