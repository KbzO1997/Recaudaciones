package com.bolivariano.microservice.recatx.configuration;

import io.quarkus.runtime.annotations.StaticInitSafe;
import io.smallrye.config.ConfigMapping;
import io.smallrye.config.ConfigMapping.NamingStrategy;

import javax.inject.Named;

/**
 * @author Gizlo-Fernando Andrade
 * <p>
 * Interface para mapear los properties con el prefijo mi-claro-app-api
 */
@StaticInitSafe
@ConfigMapping(prefix = "atx", namingStrategy = NamingStrategy.VERBATIM)
@Named("applicationConfig")
public interface ApplicationProperties {

	MQ mq();

	FrameworkSeguridad frameworkSeguridad();

	Truststore truststore();

	interface MQ {
		String host();

		Integer port();

		String channel();

		String queueManager();

		String queueRequest();

		String queueReplay();

		Integer poolJms();

		Integer delayReconnect();

		Long timeToLive();
	}

	interface Truststore {

		String path();

		String password();

		String type();

	}

	interface FrameworkSeguridad {
		String url();

		int connTimeout();

		int readTimeout();

		int idAplicacion();

		String usuarioApl();

	}

}
