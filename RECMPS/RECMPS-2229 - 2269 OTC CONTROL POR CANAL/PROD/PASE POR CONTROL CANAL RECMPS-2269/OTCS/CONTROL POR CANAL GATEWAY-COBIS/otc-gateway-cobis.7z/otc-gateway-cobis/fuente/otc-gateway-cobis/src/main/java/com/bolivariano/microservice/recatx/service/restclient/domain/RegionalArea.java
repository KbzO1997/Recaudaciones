package com.bolivariano.microservice.recatx.service.restclient.domain;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;


/**
 * The persistent class for the OTC_M_FLUJO database table.
 */
@Data
@NoArgsConstructor
public class RegionalArea implements Serializable {
    private static final long serialVersionUID = 1L;

    private Long id;

    private String codigo;

    private String identificador;

}