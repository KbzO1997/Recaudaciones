package com.bolivariano.microservice.recatx.service.restclient.domain;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;


/**
 * The persistent class for the OTC_M_CONVENIO database table.
 */
@Data
@NoArgsConstructor
public class Convenio implements Serializable {
    private static final long serialVersionUID = 1L;

    private Long id;

    private String codigo;

    private String etiquetaCodigo;

    private Boolean visible;

    private List<Flujo> flujos;

    private List<TipoIdentificador> tipoIdentificadores;


}