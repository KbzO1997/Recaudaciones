package com.bolivariano.microservice.recatx.utils;

import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.bolivariano.microservice.recatx.domain.cts.request.CTSMessage;

public class GeneralUtils {

	private static final String FORMATOFECHA_MDY ="MM/dd/yyyy";

	private GeneralUtils() {
	}

	public static String obtenerValorField(String clave, List<CTSMessage.CTSHeader.Field> params ) {
		CTSMessage.CTSHeader.Field resultParam = params.parallelStream().filter(x -> x.getName().equals(clave) && x.getValue() != null && !x.getValue().isEmpty() ).findFirst().orElse(null);
		//SI EXISTE ALGUNO BUSCA EL ULTIMO
		if (resultParam != null){
			int lastIndex = params.parallelStream().filter(x -> x.getName().equals(clave) && x.getValue() != null && !x.getValue().isEmpty() )
					.mapToInt(params::indexOf).max().getAsInt();
			resultParam = params.get(lastIndex);

		}
		return resultParam != null?resultParam.getValue():"";
	}

	public static String obtenerValorParam(String clave, List<CTSMessage.Data.ProcedureRequest.Param> params) {
		CTSMessage.Data.ProcedureRequest.Param resultParam = params.parallelStream().filter(x -> x.getName().equals(clave) && x.getValue() != null && !x.getValue().isEmpty() ).findFirst().orElse(null);
		//SI EXISTE ALGUNO BUSCA EL ULTIMO
		if (resultParam != null){
			int lastIndex = params.parallelStream().filter(x -> x.getName().equals(clave) && x.getValue() != null && !x.getValue().isEmpty() )
					.mapToInt(params::indexOf).max().getAsInt();
			resultParam = params.get(lastIndex);

		}
		return resultParam != null?resultParam.getValue():"";
	}

	public static Date strParseDate(String fecha)
	{
		SimpleDateFormat formato = new SimpleDateFormat(FORMATOFECHA_MDY);
		Date fechaDate = null;
		try {
			fechaDate = formato.parse(fecha);
		} catch (ParseException e) {
			throw new IllegalArgumentException(e);
		}
		return fechaDate;
	}
	
	public static String verificarValor(Object valorVerificable,String valorPorDefecto ) {
		return valorVerificable != null?valorVerificable.toString():valorPorDefecto;
	}

	
	public static com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.CTSHeader.Field generateField(String name, String type,  String value) {
		
		com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.CTSHeader.Field field = new com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.CTSHeader.Field();
		
		field.setName(name);
        field.setType(type);
        field.setValue(value);
        
		return field;
	}
	
	public static com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.ResultSet.Header.Col generateCol(String name, BigInteger type){
		
		com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.ResultSet.Header.Col col = new com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.ResultSet.Header.Col();
		
		col.setName(name);
        col.setType(type);
        
		return col;
	}
	
	public static com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.OutputParams.Param  generateParam(String name, String type,  String value){
		
		com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.OutputParams.Param param = new com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.OutputParams.Param();
		
		param.setName(name);
        param.setType(type);
        param.setValue(value);
        
		return param;
	}
	
	public static com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.ResultSet.Rw generateRw2Cd(String cd1, String cd2){
		
		com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.ResultSet.Rw rw = new com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.ResultSet.Rw();
		
		rw.getCd().add(cd1);
		rw.getCd().add(cd2);
        
		return rw;
	}
	
}
