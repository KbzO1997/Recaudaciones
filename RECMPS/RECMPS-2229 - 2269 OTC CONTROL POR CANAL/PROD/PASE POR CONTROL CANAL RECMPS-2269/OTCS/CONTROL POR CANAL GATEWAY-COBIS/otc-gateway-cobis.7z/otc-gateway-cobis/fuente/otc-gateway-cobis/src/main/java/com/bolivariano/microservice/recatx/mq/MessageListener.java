package com.bolivariano.microservice.recatx.mq;

import com.bolivariano.microservice.recatx.configuration.ApplicationProperties;
import com.bolivariano.microservice.recatx.configuration.MQConnectionFactoryData;
import com.bolivariano.microservice.recatx.domain.MessageProcess;
import com.bolivariano.microservice.recatx.service.CobisGatewayService;
import com.ibm.msg.client.jms.JmsConstants;
import io.quarkus.runtime.ShutdownEvent;
import io.quarkus.runtime.StartupEvent;
import org.jboss.logging.Logger;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.event.Observes;
import javax.inject.Inject;
import javax.jms.*;
import java.io.UnsupportedEncodingException;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

@ApplicationScoped
public class MessageListener implements Runnable {

    @Inject
    Logger log;

    @Inject
    ApplicationProperties applicationProperties;

    @Inject
    @MQConnectionFactoryData
    ConnectionFactory connectionFactory;

    @Inject
    CobisGatewayService cobisGatewayService;

    private ExecutorService scheduler;

    void onStart(@Observes StartupEvent event) {
        int maxThread = applicationProperties.mq().poolJms().intValue();
        scheduler = Executors.newFixedThreadPool(maxThread);
        for (int i = 0; i < maxThread; i++) {
            scheduler.submit(this);
        }
    }
    void onStop(@Observes ShutdownEvent event) {
        scheduler.shutdown();
    }

    @Override
    public void run() {
        log.info("INICIA THREAD LISTENER");
        log.info("CONFIG --> " + connectionFactory);
        log.info("COLA MQ --> " + applicationProperties.mq().queueRequest());

        JMSConsumer consumer = null;

        try (JMSContext context = connectionFactory.createContext(Session.AUTO_ACKNOWLEDGE)) {
            log.info("COLA MQ --> " + applicationProperties.mq().queueRequest());
            Queue queue = context.createQueue(applicationProperties.mq().queueRequest());
            consumer = context.createConsumer(queue);

            while (true) {
                Message message = consumer.receive();
                log.info("JMS --> " + message);
                if (Objects.isNull(message)) return;

                String mensajeJMS;
                if (message instanceof BytesMessage) {
                    mensajeJMS = readIbmMqMessageAsString((BytesMessage) message);
                } else {
                    mensajeJMS = message.getBody(String.class);
                }
                String correlationId = message.getJMSCorrelationID();
                if (correlationId == null){
                    correlationId = message.getJMSMessageID();
                }

                log.info("correlation ID: " + correlationId);
                log.info("MENSAJE ENVIADO--> " + mensajeJMS);

                cobisGatewayService.cobisGateway(new MessageProcess(mensajeJMS, correlationId));
             }
        } catch (Exception e) {
            log.error("Error en consumo de servicio JMS -->", e);
        } finally {
            if (consumer != null) {
                consumer.close();
            }
            Runnable runnableTask = () -> {
                try {
                	log.info("THREAD DELAY --> " + applicationProperties.mq().delayReconnect());
                    TimeUnit.MILLISECONDS.sleep(applicationProperties.mq().delayReconnect());
                } catch (InterruptedException e) {
                    log.error("Error en setear DELAY RECONNECT --> ", e);
                    Thread.currentThread().interrupt();
                }
            };
            new Thread(runnableTask).start();
            scheduler.submit(this);
        }
    }

    public String readIbmMqMessageAsString(BytesMessage message) throws JMSException, UnsupportedEncodingException {
        message.reset();
        int msgLength = ((int) message.getBodyLength());
        byte[] msgBytes = new byte[msgLength];
        message.readBytes(msgBytes, msgLength);
        String encoding = message.getStringProperty(JmsConstants.JMS_IBM_CHARACTER_SET);
        return new String(msgBytes, encoding).trim();
    }
}