package com.bolivariano.microservice.recatx.service.restclient.message;

import com.bolivariano.microservice.recatx.domain.xml.mensaje.MensajeSalidaConsultarDeuda;
import com.bolivariano.microservice.recatx.domain.xml.mensaje.MensajeSalidaEjecutarPago;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
public class MensajeSalidaProcesar implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 2703402030084883420L;
	private String codigo;
    private String mensajeUsuario;
    private String estado;
    private MensajeSalidaEjecutarPago mensajeSalidaEjecutarPago;
    private MensajeSalidaConsultarDeuda mensajeSalidaConsultarDeuda;

}
