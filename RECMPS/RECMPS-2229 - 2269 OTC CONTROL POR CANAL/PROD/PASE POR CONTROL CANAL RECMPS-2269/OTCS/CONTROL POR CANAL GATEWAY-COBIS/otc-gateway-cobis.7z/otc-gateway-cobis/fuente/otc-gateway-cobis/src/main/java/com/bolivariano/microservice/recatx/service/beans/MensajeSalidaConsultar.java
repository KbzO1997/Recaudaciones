package com.bolivariano.microservice.recatx.service.beans;

import com.fasterxml.jackson.annotation.*;

import javax.annotation.processing.Generated;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "datosAdicionales",
        "fechaVencimiento",
        "formaPago",
        "formaPagoRecibos",
        "identificadorDeuda",
        "limiteMontoMaximo",
        "limiteMontoMinimo",
        "mensajeUsuario",
        "montoMinimo",
        "montoTotal",
        "nombreCliente",
        "recibos",
        "textoAyuda",
        "codigoRespuesta"
})
@Generated("jsonschema2pojo")
public class MensajeSalidaConsultar {

    /**
     * Lista de detalles(datos extras)
     */
    @JsonProperty("datosAdicionales")
    @JsonPropertyDescription("Lista de detalles(datos extras)")
    private List<DatoAdicional> datosAdicionales = new ArrayList<DatoAdicional>();
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "America/Guayaquil")
    @JsonProperty("fechaVencimiento")
    private Date fechaVencimiento;
    /**
     * Cuando es combo se arma un listado con lo que se recibe en recibos usando el campo totalAPagar de cada recibo(ejemplo recarga celular)
     */
    @JsonProperty("formaPago")
    @JsonPropertyDescription("Cuando es combo se arma un listado con lo que se recibe en recibos usando el campo totalAPagar de cada recibo(ejemplo recarga celular)")
    private String formaPago;
    /**
     * En el caso de que se esta trabajando con un servicio con multiples facturas, se indica como el la forma de seleccion de las mismas
     */
    @JsonProperty("formaPagoRecibos")
    @JsonPropertyDescription("En el caso de que se esta trabajando con un servicio con multiples facturas, se indica como el la forma de seleccion de las mismas")
    private String formaPagoRecibos;
    /**
     * Identificador unico de la deuda
     */
    @JsonProperty("identificadorDeuda")
    @JsonPropertyDescription("Identificador unico de la deuda")
    private String identificadorDeuda;
    /**
     * indica si se debe validar un monto minimo, por defecto se valida que sea mayor a cero.
     */
    @JsonProperty("limiteMontoMaximo")
    @JsonPropertyDescription("indica si se debe validar un monto minimo, por defecto se valida que sea mayor a cero.")
    private Double limiteMontoMaximo;
    /**
     * indica si se debe validar un monto minimo, por defecto se valida que sea mayor a cero.
     */
    @JsonProperty("limiteMontoMinimo")
    @JsonPropertyDescription("indica si se debe validar un monto minimo, por defecto se valida que sea mayor a cero.")
    private Double limiteMontoMinimo;
    /**
     * mensaje de usuario
     */
    @JsonProperty("mensajeUsuario")
    @JsonPropertyDescription("mensaje de usuario")
    private String mensajeUsuario;
    /**
     * monto minimo
     */
    @JsonProperty("montoMinimo")
    @JsonPropertyDescription("monto minimo")
    private Double montoMinimo;
    /**
     * monto total a pagar
     */
    @JsonProperty("montoTotal")
    @JsonPropertyDescription("monto total a pagar")
    private Double montoTotal;
    @JsonProperty("nombreCliente")
    private String nombreCliente;
    /**
     * lista de recibos pendientes
     */
    @JsonProperty("recibos")
    @JsonPropertyDescription("lista de recibos pendientes")
    private List<Recibo> recibos = new ArrayList<Recibo>();
    /**
     * Codigo de texto de ayuda para ser mostrado al cliente
     */
    @JsonProperty("textoAyuda")
    @JsonPropertyDescription("Codigo de texto de ayuda para ser mostrado al cliente")
    private String textoAyuda;
    /**
     * codigo de respuesta
     */
    @JsonProperty("codigoRespuesta")
    @JsonPropertyDescription("codigo de respuesta")
    private String codigoRespuesta;

    /**
     * Lista de detalles(datos extras)
     */
    @JsonProperty("datosAdicionales")
    public List<DatoAdicional> getDatosAdicionales() {
        return datosAdicionales;
    }

    /**
     * Lista de detalles(datos extras)
     */
    @JsonProperty("datosAdicionales")
    public void setDatosAdicionales(List<DatoAdicional> datosAdicionales) {
        this.datosAdicionales = datosAdicionales;
    }

    @JsonProperty("fechaVencimiento")
    public Date getFechaVencimiento() {
        return fechaVencimiento;
    }

    @JsonProperty("fechaVencimiento")
    public void setFechaVencimiento(Date fechaVencimiento) {
        this.fechaVencimiento = fechaVencimiento;
    }

    /**
     * Cuando es combo se arma un listado con lo que se recibe en recibos usando el campo totalAPagar de cada recibo(ejemplo recarga celular)
     */
    @JsonProperty("formaPago")
    public String getFormaPago() {
        return formaPago;
    }

    /**
     * Cuando es combo se arma un listado con lo que se recibe en recibos usando el campo totalAPagar de cada recibo(ejemplo recarga celular)
     */
    @JsonProperty("formaPago")
    public void setFormaPago(String formaPago) {
        this.formaPago = formaPago;
    }

    /**
     * En el caso de que se esta trabajando con un servicio con multiples facturas, se indica como el la forma de seleccion de las mismas
     */
    @JsonProperty("formaPagoRecibos")
    public String getFormaPagoRecibos() {
        return formaPagoRecibos;
    }

    /**
     * En el caso de que se esta trabajando con un servicio con multiples facturas, se indica como el la forma de seleccion de las mismas
     */
    @JsonProperty("formaPagoRecibos")
    public void setFormaPagoRecibos(String formaPagoRecibos) {
        this.formaPagoRecibos = formaPagoRecibos;
    }

    /**
     * Identificador unico de la deuda
     */
    @JsonProperty("identificadorDeuda")
    public String getIdentificadorDeuda() {
        return identificadorDeuda;
    }

    /**
     * Identificador unico de la deuda
     */
    @JsonProperty("identificadorDeuda")
    public void setIdentificadorDeuda(String identificadorDeuda) {
        this.identificadorDeuda = identificadorDeuda;
    }

    /**
     * indica si se debe validar un monto minimo, por defecto se valida que sea mayor a cero.
     */
    @JsonProperty("limiteMontoMaximo")
    public Double getLimiteMontoMaximo() {
        return limiteMontoMaximo;
    }

    /**
     * indica si se debe validar un monto minimo, por defecto se valida que sea mayor a cero.
     */
    @JsonProperty("limiteMontoMaximo")
    public void setLimiteMontoMaximo(Double limiteMontoMaximo) {
        this.limiteMontoMaximo = limiteMontoMaximo;
    }

    /**
     * indica si se debe validar un monto minimo, por defecto se valida que sea mayor a cero.
     */
    @JsonProperty("limiteMontoMinimo")
    public Double getLimiteMontoMinimo() {
        return limiteMontoMinimo;
    }

    /**
     * indica si se debe validar un monto minimo, por defecto se valida que sea mayor a cero.
     */
    @JsonProperty("limiteMontoMinimo")
    public void setLimiteMontoMinimo(Double limiteMontoMinimo) {
        this.limiteMontoMinimo = limiteMontoMinimo;
    }

    /**
     * mensaje de usuario
     */
    @JsonProperty("mensajeUsuario")
    public String getMensajeUsuario() {
        return mensajeUsuario;
    }

    /**
     * mensaje de usuario
     */
    @JsonProperty("mensajeUsuario")
    public void setMensajeUsuario(String mensajeUsuario) {
        this.mensajeUsuario = mensajeUsuario;
    }

    /**
     * monto minimo
     */
    @JsonProperty("montoMinimo")
    public Double getMontoMinimo() {
        return montoMinimo;
    }

    /**
     * monto minimo
     */
    @JsonProperty("montoMinimo")
    public void setMontoMinimo(Double montoMinimo) {
        this.montoMinimo = montoMinimo;
    }

    /**
     * monto total a pagar
     */
    @JsonProperty("montoTotal")
    public Double getMontoTotal() {
        return montoTotal;
    }

    /**
     * monto total a pagar
     */
    @JsonProperty("montoTotal")
    public void setMontoTotal(Double montoTotal) {
        this.montoTotal = montoTotal;
    }

    @JsonProperty("nombreCliente")
    public String getNombreCliente() {
        return nombreCliente;
    }

    @JsonProperty("nombreCliente")
    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    /**
     * lista de recibos pendientes
     */
    @JsonProperty("recibos")
    public List<Recibo> getRecibos() {
        return recibos;
    }

    /**
     * lista de recibos pendientes
     */
    @JsonProperty("recibos")
    public void setRecibos(List<Recibo> recibos) {
        this.recibos = recibos;
    }

    /**
     * Codigo de texto de ayuda para ser mostrado al cliente
     */
    @JsonProperty("textoAyuda")
    public String getTextoAyuda() {
        return textoAyuda;
    }

    /**
     * Codigo de texto de ayuda para ser mostrado al cliente
     */
    @JsonProperty("textoAyuda")
    public void setTextoAyuda(String textoAyuda) {
        this.textoAyuda = textoAyuda;
    }

    /**
     * codigo de respuesta
     */
    @JsonProperty("codigoRespuesta")
    public String getCodigoRespuesta() {
        return codigoRespuesta;
    }

    /**
     * codigo de respuesta
     */
    @JsonProperty("codigoRespuesta")
    public void setCodigoRespuesta(String codigoRespuesta) {
        this.codigoRespuesta = codigoRespuesta;
    }

}
