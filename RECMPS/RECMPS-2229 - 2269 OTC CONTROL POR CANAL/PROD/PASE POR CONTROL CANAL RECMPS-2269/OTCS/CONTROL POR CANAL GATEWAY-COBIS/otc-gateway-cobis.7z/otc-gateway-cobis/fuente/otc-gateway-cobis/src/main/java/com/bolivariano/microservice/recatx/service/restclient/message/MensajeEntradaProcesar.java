package com.bolivariano.microservice.recatx.service.restclient.message;


import com.bolivariano.microservice.recatx.domain.xml.mensaje.MensajeEntradaConsultarDeuda;
import com.bolivariano.microservice.recatx.domain.xml.mensaje.MensajeEntradaEjecutarPago;
import com.bolivariano.microservice.recatx.domain.xml.mensaje.MensajeEntradaEjecutarReverso;
import com.bolivariano.microservice.recatx.service.restclient.domain.Flujo;
import com.bolivariano.microservice.recatx.service.restclient.enumeration.TipoFlujo;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
public class MensajeEntradaProcesar implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = -8846446458771528433L;
	private Flujo flujo;
    private TipoFlujo tipoFlujo;
    private MensajeEntradaEjecutarReverso mensajeEntradaEjecutarReverso;
    private MensajeEntradaEjecutarPago mensajeEntradaEjecutarPago;
    private MensajeEntradaConsultarDeuda mensajeEntradaConsultarDeuda;

}
