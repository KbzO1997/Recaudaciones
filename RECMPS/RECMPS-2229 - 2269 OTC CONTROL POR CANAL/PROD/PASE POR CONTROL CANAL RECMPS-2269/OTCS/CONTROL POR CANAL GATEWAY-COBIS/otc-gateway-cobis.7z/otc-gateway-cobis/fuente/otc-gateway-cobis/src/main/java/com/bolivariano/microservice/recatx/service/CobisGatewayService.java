package com.bolivariano.microservice.recatx.service;

import com.bolivariano.microservice.recatx.domain.MessageProcess;
import com.bolivariano.microservice.recatx.domain.cts.request.CTSMessage;
import com.bolivariano.microservice.recatx.domain.xml.dominio.datoadicional.DatoAdicional;
import com.bolivariano.microservice.recatx.domain.xml.dominio.recibo.Recibo;
import com.bolivariano.microservice.recatx.domain.xml.mensaje.*;
import com.bolivariano.microservice.recatx.exception.BusinessException;
import com.bolivariano.microservice.recatx.mq.MessageSender;
import com.bolivariano.microservice.recatx.service.beans.MensajeFlujoGenericDTO;
import com.bolivariano.microservice.recatx.service.restclient.CoreServicioProxy;
import com.bolivariano.microservice.recatx.service.restclient.FlujoTransaccionProxy;
import com.bolivariano.microservice.recatx.service.restclient.domain.Flujo;
import com.bolivariano.microservice.recatx.service.restclient.enumeration.TipoFlujo;
import com.bolivariano.microservice.recatx.service.restclient.message.DatoAtxBean;
import com.bolivariano.microservice.recatx.service.restclient.message.FlujoTransformacionBean;
import com.bolivariano.microservice.recatx.service.restclient.message.MensajeEntradaProcesar;
import com.bolivariano.microservice.recatx.service.restclient.message.MensajeSalidaProcesar;
import com.bolivariano.microservice.recatx.utils.ContentTypeEnum;
import com.bolivariano.microservice.recatx.utils.Converter;
import com.bolivariano.microservice.recatx.utils.ConverterFactory;
import com.bolivariano.microservice.recatx.utils.GeneralUtils;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.jboss.logging.Logger;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@ApplicationScoped
public class CobisGatewayService {

    private static final String OTC_GTW_05 = "OTC_GTW_05";
    private static final String COD_70001 = "70001";

    private static final String CONVENIO = "convenio";
    private static final String EMPRESA = "empresa";
    private static final String TIPOBANCA = "tipoBanca";
    private static final String TIPOSERVICIO = "tipoServicio";

    private static final String MENSAJE_PROCESADO = "Mensaje Procesado";
    private static final String REFERENCIA = "referencia";
    private static final String NAME = "name";
    private static final String VALUE = "value";
    private static final String PREFIJO = "@";
    private static final String T_TRM = "@i_trn";
    private static final String S_USER = "@s_user";
    private static final String S_SSN = "@s_ssn";
    private static final String S_TERM = "@s_term";
    private static final String E_EMPRESA = "@e_empresa";
    private static final String E_CONVENIO = "@e_convenio";
    private static final String E_TIPO_SERVICIO = "@e_tipo_servicio";
    private static final String E_TIPO_BANCA = "@e_tipo_banca";
    private static final String MSJ_TRANSACCION_VACIO = "Transaccion (@i_trn) es vacio!";
    private static final String E_CANAL = "@e_canal";
    private static final String DEPURACION = "@depuracion";
    private static final String S_OFI = "@s_ofi";
    private static final String E_IDENTIFICATION = "@e_identificacion";
    private static final String E_TIPO_IDENTIFICADOR = "@e_tipo_identificador";
    private static final String E_FECHA_REAL = "@e_fecha_real";
    private static final String TXT_CODIGO_RESPUESTA = "codigoRespuesta";
    private static final String TXT_MENSAJE_USUARIO = "mensajeUsuario";
    private static final String MSG_NO_EXISTE_FLUJO = "La recaudacion no se encuentra disponible por el momento.";
    private static final String OTC_GWT_02 = "OTC_GWT_02";
    private static final String TXT_MONTO_TOTAL = "montoTotal";
    private static final String MSJ_NO_EXISTE_RESPUESTA = "Error: No existe mensaje de respuesta.";

    @Inject
    Logger log;
    @Inject
    MessageSender senderService;
    @Inject
    @RestClient
    FlujoTransaccionProxy flujoTransaccionProxy;
    @Inject
    @RestClient
    CoreServicioProxy proxyCore;
    @Inject
    AdminUtilService adminUtilService;

    public void cobisGateway(MessageProcess message) {
        try {
            Converter converter = ConverterFactory.getConverter(ContentTypeEnum.XML);
            com.bolivariano.microservice.recatx.domain.cts.request.CTSMessage mensajeEntradaGateway = converter.convertirAObjeto(message.getMessage(), com.bolivariano.microservice.recatx.domain.cts.request.CTSMessage.class);

            if (mensajeEntradaGateway == null) {
                throw new BusinessException("Mensaje de Entrada VACIO");
            }

            com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage mensajeSalidaGateway;
            String proceso = mensajeEntradaGateway.getData().getProcedureRequest().getSpName();

            if (proceso.contains("consulta")) {
                mensajeSalidaGateway = procesar(mensajeEntradaGateway, TipoFlujo.CONSULTA);

            } else if (proceso.contains("pago")) {
                mensajeSalidaGateway = procesar(mensajeEntradaGateway, TipoFlujo.PAGO);

            } else if (proceso.contains("reverso")) {
                mensajeSalidaGateway = procesar(mensajeEntradaGateway, TipoFlujo.REVERSO);

            } else {
                throw new BusinessException("PROCESO NO IMPLEMENTADO --> " + proceso);
            }

            if (mensajeSalidaGateway != null){
                List<CTSMessage.CTSHeader.Field> fields = mensajeEntradaGateway.getCTSHeader().getField();
                List<CTSMessage.Data.ProcedureRequest.Param> params = mensajeEntradaGateway.getData().getProcedureRequest().getParam();

                if (mensajeSalidaGateway.getCTSHeader() == null){
                    com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.CTSHeader header = new com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.CTSHeader();
                    mensajeSalidaGateway.setCTSHeader(header);
                }
                
                mensajeSalidaGateway.getCTSHeader().getField().add(GeneralUtils.generateField("kernelHeader","S",GeneralUtils.obtenerValorField("kernelHeader",fields)));
                mensajeSalidaGateway.getCTSHeader().getField().add(GeneralUtils.generateField("fromServer","S",GeneralUtils.obtenerValorField("fromServer",fields)));
                mensajeSalidaGateway.getCTSHeader().getField().add(GeneralUtils.generateField("srv","S",GeneralUtils.obtenerValorField("srv",fields)));
                mensajeSalidaGateway.getCTSHeader().getField().add(GeneralUtils.generateField("sesn","N",GeneralUtils.obtenerValorField("sesn",fields)));
                mensajeSalidaGateway.getCTSHeader().getField().add(GeneralUtils.generateField("transaccion","S",GeneralUtils.obtenerValorParam(T_TRM,params)));
                mensajeSalidaGateway.getCTSHeader().getField().add(GeneralUtils.generateField("usuario","S",GeneralUtils.obtenerValorParam(S_USER,params)));
                mensajeSalidaGateway.getCTSHeader().getField().add(GeneralUtils.generateField("secuencial","S",GeneralUtils.obtenerValorParam(S_SSN,params)));
                mensajeSalidaGateway.getCTSHeader().getField().add(GeneralUtils.generateField("terminal","S",GeneralUtils.obtenerValorParam(S_TERM,params)));
                
            }

            log.info("ENVIA RESPUESTA A ... ");
            senderService.sendMQMessage(converter.convertirDeObjeto(mensajeSalidaGateway), message.getCorrelationId());

        } catch (Exception e) {
            log.error("ERROR AL PROCESA MENSAJE DE ENTRADA: " + e.getMessage(), e);
            sendError(e.getMessage(),  message.getCorrelationId());
        }

    }

    public com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage procesar(CTSMessage peticion, TipoFlujo tipoFlujo) {
        com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage respuesta = new com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage();
        com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data data = new com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data();
        com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse pr = new com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse();

        try {
            MensajeEntradaProcesar peticionObj = new MensajeEntradaProcesar();
            peticionObj.setTipoFlujo(tipoFlujo);

            List<CTSMessage.Data.ProcedureRequest.Param> params = peticion.getData().getProcedureRequest().getParam();

            String transaccion = GeneralUtils.obtenerValorParam(T_TRM, params);
            String empresa = GeneralUtils.obtenerValorParam(E_EMPRESA, params);
            String convenio = GeneralUtils.obtenerValorParam(E_CONVENIO, params);
            String tipoServicio = GeneralUtils.obtenerValorParam(E_TIPO_SERVICIO, params);
            String tipoBanca = GeneralUtils.obtenerValorParam(E_TIPO_BANCA, params);
            String canal = GeneralUtils.obtenerValorParam(E_CANAL, params);

            validateTransation(transaccion);
            Map<String,String > parameters = updateParameters(convenio, tipoServicio, tipoBanca, empresa, transaccion);

            convenio = parameters.get(CONVENIO);
            empresa = parameters.get(EMPRESA);
            tipoBanca = parameters.get(TIPOBANCA);
            tipoServicio = parameters.get(TIPOSERVICIO);

            log.info("convenio  --> " + convenio);
            log.info("tipoServicio  --> " + tipoServicio);
            log.info("empresa  --> " + empresa);
            log.info("tipoBanca  --> " + tipoBanca);

            log.info("tipoFlujo  --> " + tipoFlujo.name());
            log.info("canal  --> " + canal);

            Flujo flujo = adminUtilService.obtenerFlujo(convenio, empresa, tipoServicio, tipoBanca, tipoFlujo.name(), Boolean.TRUE, canal);
            peticionObj.setFlujo(flujo);

            if (peticionObj.getFlujo() == null) {
                return getCtsMessageError(respuesta, data, pr, OTC_GWT_02, MSG_NO_EXISTE_FLUJO);
            }

            String valorComision = GeneralUtils.obtenerValorParam("@e_comision_tot", params);
            String valorPago = GeneralUtils.obtenerValorParam("@e_total", params);
            
            MensajeFlujoGenericDTO mensajeFlujo = new MensajeFlujoGenericDTO();
            mensajeFlujo.setConvenio(convenio);
            mensajeFlujo.setData(data);
            mensajeFlujo.setEmpresa(empresa);
            mensajeFlujo.setParams(params);
            mensajeFlujo.setPeticionObj(peticionObj);
            mensajeFlujo.setPr(pr);
            mensajeFlujo.setRespuesta(respuesta);
            mensajeFlujo.setTipoBanca(tipoBanca);
            mensajeFlujo.setTipoServicio(tipoServicio);
            mensajeFlujo.setValorComision(valorComision);
            mensajeFlujo.setValorPago(valorPago);
            
            switch (tipoFlujo){
                case CONSULTA:
                    return query(mensajeFlujo);
                case PAGO:
                    return payment(mensajeFlujo);
                case REVERSO:
                    return reverse(mensajeFlujo);
                default:
                    throw new BusinessException("Transaccion no implentada");
              }

        } catch (Exception e) {
            log.error("Error en el proceso consultar --> " + e.getMessage(), e);

            com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.Message msg = new com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.Message();
            msg.setMsgNo(COD_70001);
            msg.setType("3");
            msg.setValue("(OTC_GTW_04) Error no controlado en consultar:  " + e.getMessage());

            pr.setReturn(COD_70001);
            pr.setMessage(msg);
            data.setProcedureResponse(pr);
            respuesta.setData(data);
            return respuesta;
        }

    }

    private com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage reverse(MensajeFlujoGenericDTO mensajeFlujo ) {
    	
        MensajeEntradaEjecutarReverso meej = new MensajeEntradaEjecutarReverso();
        meej.setCanal(GeneralUtils.obtenerValorParam(E_CANAL, mensajeFlujo.getParams()));
        meej.setDepuracion(GeneralUtils.obtenerValorParam(DEPURACION, mensajeFlujo.getParams()));
        meej.setOficina(GeneralUtils.obtenerValorParam(S_OFI, mensajeFlujo.getParams()));
        meej.setSecuencial(GeneralUtils.obtenerValorParam(S_SSN, mensajeFlujo.getParams()));
        meej.setTransaccion(GeneralUtils.obtenerValorParam(T_TRM, mensajeFlujo.getParams()));
        meej.setUsuario(GeneralUtils.obtenerValorParam(S_USER, mensajeFlujo.getParams()));

        meej.setCuenta(GeneralUtils.obtenerValorParam("@e_cuenta", mensajeFlujo.getParams()));
        meej.setEsquemaFirma(GeneralUtils.obtenerValorParam("@s_esquema_firma", mensajeFlujo.getParams()));
        meej.setMoneda(GeneralUtils.obtenerValorParam("@e_moneda", mensajeFlujo.getParams()));
        meej.setNombreCliente(GeneralUtils.obtenerValorParam("@e_nombre", mensajeFlujo.getParams()));
        meej.setValorComision(mensajeFlujo.getValorComision() != null && !mensajeFlujo.getValorComision().isEmpty()? Double.parseDouble(mensajeFlujo.getValorComision()) : 0d);
        meej.setValorPago(mensajeFlujo.getValorPago() != null && !mensajeFlujo.getValorPago().isEmpty() ? Double.parseDouble(mensajeFlujo.getValorPago()) : 0d);
        meej.setTipoCuenta(GeneralUtils.obtenerValorParam("@e_tipocta", mensajeFlujo.getParams()));

        com.bolivariano.microservice.recatx.domain.xml.dominio.servicio.Servicio servicioObj = new com.bolivariano.microservice.recatx.domain.xml.dominio.servicio.Servicio();
        servicioObj.setCodigoConvenio(mensajeFlujo.getConvenio());
        servicioObj.setCodTipoServicio(mensajeFlujo.getTipoServicio());
        servicioObj.setCodigoEmpresa(mensajeFlujo.getEmpresa());
        servicioObj.setIdentificador(GeneralUtils.obtenerValorParam(E_IDENTIFICATION, mensajeFlujo.getParams()));
        servicioObj.setCodigoTipoBanca(mensajeFlujo.getTipoBanca());
        servicioObj.setCodigoTipoIdentificador(GeneralUtils.obtenerValorParam(E_TIPO_IDENTIFICADOR, mensajeFlujo.getParams()));

        meej.setDatosAdicionales(getReverseDatosAdicionales(mensajeFlujo.getParams()));
        meej.setRecibos(getReverseRecibos(mensajeFlujo.getParams()));
        servicioObj.setDatosAdicionales(getDatosAdicionales(mensajeFlujo.getParams()));
        meej.setServicio(servicioObj);

        String dateInString = GeneralUtils.obtenerValorParam(E_FECHA_REAL, mensajeFlujo.getParams());
        meej.setFechaPago(parserFechaWithCalendar(dateInString));

        log.info("PETICION REVERSO: " + meej);
        mensajeFlujo.getPeticionObj().setMensajeEntradaEjecutarReverso(meej);
        //Se setea mensaje de Enriquecimiento NULL
        mensajeFlujo.getPeticionObj().getFlujo().setServicioEnriquecimiento(null);

        MensajeSalidaProcesar respuestaObj = proxyCore.procesar(mensajeFlujo.getPeticionObj());
        MensajeSalidaEjecutarPago mseor = respuestaObj.getMensajeSalidaEjecutarPago();

        if (mseor == null) {
            return getCtsMessageError(mensajeFlujo.getRespuesta(), mensajeFlujo.getData(), mensajeFlujo.getPr(), OTC_GTW_05, MSJ_NO_EXISTE_RESPUESTA);
        }

        log.info("CODIGO RESPUESTA -->" + mseor.getCodigoError());
        log.info("MENSAJE RESPUESTA -->" + mseor.getMensajeUsuario());

        if (!"0".equals(mseor.getCodigoError())) {
            return getCtsMessageError(mensajeFlujo.getRespuesta(), mensajeFlujo.getData(), mensajeFlujo.getPr(),  mseor.getCodigoError(),  (mseor.getMensajeUsuario() != null && !mseor.getMensajeUsuario().isEmpty())?mseor.getMensajeUsuario():mseor.getMensajeSistema());
        }
        mensajeFlujo.setRespuesta(new com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage());
        
        com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.ResultSet rs = new com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.ResultSet();
        com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.ResultSet.Header headerRs = new com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.ResultSet.Header();

        headerRs.getCol().add(GeneralUtils.generateCol(NAME, BigInteger.valueOf(39)));

        headerRs.getCol().add(GeneralUtils.generateCol(VALUE, BigInteger.valueOf(39)));

        rs.setHeader(headerRs);

        rs.getRw().add(GeneralUtils.generateRw2Cd(PREFIJO + TXT_CODIGO_RESPUESTA, mseor.getCodigoError() != null ? mseor.getCodigoError() : "0"));

        rs.getRw().add(GeneralUtils.generateRw2Cd(PREFIJO + TXT_MENSAJE_USUARIO, mseor.getMensajeUsuario() != null ? mseor.getMensajeUsuario() : MENSAJE_PROCESADO));

        rs.getRw().add(GeneralUtils.generateRw2Cd(PREFIJO + TXT_MONTO_TOTAL, mseor.getMontoTotal() != null ? mseor.getMontoTotal().toString() : "0"));

        rs.getRw().add(GeneralUtils.generateRw2Cd(PREFIJO + "banderaOffline", mseor.getBanderaOffline() != null ? mseor.getBanderaOffline().toString() : ""));

        rs.getRw().add(GeneralUtils.generateRw2Cd(PREFIJO + REFERENCIA, mseor.getReferencia()));

        updateResulSet(mseor, rs);
        mensajeFlujo.getPr().setResultSet(rs);
        mensajeFlujo.getPr().setReturn("0");

        mensajeFlujo.getData().setProcedureResponse(mensajeFlujo.getPr());
        mensajeFlujo.getRespuesta().setData(mensajeFlujo.getData());

        return mensajeFlujo.getRespuesta();
    }

    private com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage payment(MensajeFlujoGenericDTO mensajeFlujo ){

        
        
        MensajeEntradaEjecutarPago mejp = new MensajeEntradaEjecutarPago();
        mejp.setCanal(GeneralUtils.obtenerValorParam(E_CANAL, mensajeFlujo.getParams()));
        mejp.setDepuracion(GeneralUtils.obtenerValorParam(DEPURACION, mensajeFlujo.getParams()));
        mejp.setOficina(GeneralUtils.obtenerValorParam(S_OFI, mensajeFlujo.getParams()));
        mejp.setSecuencial(GeneralUtils.obtenerValorParam(S_SSN, mensajeFlujo.getParams()));
        mejp.setTransaccion(GeneralUtils.obtenerValorParam(T_TRM, mensajeFlujo.getParams()));
        mejp.setUsuario(GeneralUtils.obtenerValorParam(S_USER, mensajeFlujo.getParams()));

        mejp.setCuenta(GeneralUtils.obtenerValorParam("@e_cuenta", mensajeFlujo.getParams()));
        mejp.setEsquemaFirma(GeneralUtils.obtenerValorParam("@s_esquema_firma", mensajeFlujo.getParams()));
        mejp.setMoneda(GeneralUtils.obtenerValorParam("@e_moneda", mensajeFlujo.getParams()));
        mejp.setNombreCliente(GeneralUtils.obtenerValorParam("@e_nombre", mensajeFlujo.getParams()));
        mejp.setValorComision(mensajeFlujo.getValorComision() != null && !mensajeFlujo.getValorComision().isEmpty()? Double.parseDouble(mensajeFlujo.getValorComision()) : 0d);
        mejp.setValorPago(mensajeFlujo.getValorPago() != null && !mensajeFlujo.getValorPago().isEmpty() ? Double.parseDouble(mensajeFlujo.getValorPago()) : 0d);
        mejp.setTipoCuenta(GeneralUtils.obtenerValorParam("@e_tipocta", mensajeFlujo.getParams()));

        com.bolivariano.microservice.recatx.domain.xml.dominio.servicio.Servicio servicioObj = new com.bolivariano.microservice.recatx.domain.xml.dominio.servicio.Servicio();
        servicioObj.setCodigoConvenio(mensajeFlujo.getConvenio());
        servicioObj.setCodTipoServicio(mensajeFlujo.getTipoServicio());
        servicioObj.setCodigoEmpresa(mensajeFlujo.getEmpresa());
        servicioObj.setIdentificador(GeneralUtils.obtenerValorParam(E_IDENTIFICATION, mensajeFlujo.getParams()));
        servicioObj.setCodigoTipoBanca(mensajeFlujo.getTipoBanca());
        servicioObj.setCodigoTipoIdentificador(GeneralUtils.obtenerValorParam(E_TIPO_IDENTIFICADOR, mensajeFlujo.getParams()));

        mejp.setDatosAdicionales(getPaymentDatosAdicionales(mensajeFlujo.getParams()));
        mejp.setRecibos(getPaymentRecibos(mensajeFlujo.getParams()));
        servicioObj.setDatosAdicionales(getDatosAdicionales(mensajeFlujo.getParams()));
        mejp.setServicio(servicioObj);
        String dateInString = GeneralUtils.obtenerValorParam(E_FECHA_REAL, mensajeFlujo.getParams());

        XMLGregorianCalendar xmlDate = parserFechaWithCalendar(dateInString);
        mejp.setFecha(xmlDate);
        mejp.setFechaPago(xmlDate);

        mensajeFlujo.getPeticionObj().setMensajeEntradaEjecutarPago(mejp);
        //Se setea mensaje de Enriquecimiento NULL
        mensajeFlujo.getPeticionObj().getFlujo().setServicioEnriquecimiento(null);

        MensajeSalidaProcesar respuestaObj = proxyCore.procesar(mensajeFlujo.getPeticionObj());
        MensajeSalidaEjecutarPago mseop = respuestaObj.getMensajeSalidaEjecutarPago();

        if (mseop == null) {
            log.info("RESPUESTA NULL ES NULL");
            return getCtsMessageError(mensajeFlujo.getRespuesta(), mensajeFlujo.getData(), mensajeFlujo.getPr(), OTC_GTW_05, MSJ_NO_EXISTE_RESPUESTA);
        }

        log.info("CODIGO RESPUESTA -->" + mseop.getCodigoError());
        log.info("MENSAJE RESPUESTA --> " + mseop.getMensajeUsuario());
        log.info("MENSAJE RESPUESTA -->  " + mseop.getMensajeSistema());

        if (!"0".equals(mseop.getCodigoError())) {
            return getCtsMessageError(mensajeFlujo.getRespuesta(), mensajeFlujo.getData(), mensajeFlujo.getPr(),  mseop.getCodigoError(),  (mseop.getMensajeUsuario() != null && !mseop.getMensajeUsuario().isEmpty())?mseop.getMensajeUsuario():mseop.getMensajeSistema());
        }
        mensajeFlujo.setRespuesta(new com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage());
        

        com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.ResultSet rs = new com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.ResultSet();
        com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.ResultSet.Header headerRs = new com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.ResultSet.Header();

        headerRs.getCol().add(GeneralUtils.generateCol(NAME, BigInteger.valueOf(39)));

        headerRs.getCol().add(GeneralUtils.generateCol(VALUE, BigInteger.valueOf(39)));

        rs.setHeader(headerRs);

        rs.getRw().add(GeneralUtils.generateRw2Cd(PREFIJO + TXT_CODIGO_RESPUESTA, mseop.getCodigoError() != null ? mseop.getCodigoError() : "0"));

        rs.getRw().add(GeneralUtils.generateRw2Cd(PREFIJO + TXT_MENSAJE_USUARIO, mseop.getMensajeUsuario() != null ? mseop.getMensajeUsuario() : MENSAJE_PROCESADO));

        rs.getRw().add(GeneralUtils.generateRw2Cd(PREFIJO + TXT_MONTO_TOTAL, mseop.getMontoTotal() != null ? mseop.getMontoTotal().toString() : "0"));

        rs.getRw().add(GeneralUtils.generateRw2Cd(PREFIJO + "banderaOffline", mseop.getBanderaOffline() != null ? mseop.getBanderaOffline().toString() : ""));

        rs.getRw().add(GeneralUtils.generateRw2Cd(PREFIJO + REFERENCIA, mseop.getReferencia()));

        updateResulSet(mseop, rs);
        mensajeFlujo.getPr().setResultSet(rs);
        mensajeFlujo.getPr().setReturn("0");

        mensajeFlujo.getData().setProcedureResponse(mensajeFlujo.getPr());
        mensajeFlujo.getRespuesta().setData(mensajeFlujo.getData());
        return mensajeFlujo.getRespuesta();

    }

    private com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage query(MensajeFlujoGenericDTO mensajeFlujo ){
    	
        
        MensajeEntradaConsultarDeuda mecd = new MensajeEntradaConsultarDeuda();
        mecd.setCanal(GeneralUtils.obtenerValorParam(E_CANAL, mensajeFlujo.getParams()));
        mecd.setDepuracion(GeneralUtils.obtenerValorParam(DEPURACION, mensajeFlujo.getParams()));
        mecd.setOficina(GeneralUtils.obtenerValorParam(S_OFI, mensajeFlujo.getParams()));
        mecd.setSecuencial(GeneralUtils.obtenerValorParam(S_SSN, mensajeFlujo.getParams()));
        mecd.setTransaccion(GeneralUtils.obtenerValorParam(T_TRM, mensajeFlujo.getParams()));
        mecd.setUsuario(GeneralUtils.obtenerValorParam(S_USER, mensajeFlujo.getParams()));
        log.info("Inicia mapeo de informacion para consulta  ... ");

        com.bolivariano.microservice.recatx.domain.xml.dominio.servicio.Servicio servicioObj = new com.bolivariano.microservice.recatx.domain.xml.dominio.servicio.Servicio();
        servicioObj.setCodigoConvenio(mensajeFlujo.getConvenio());
        servicioObj.setCodTipoServicio(mensajeFlujo.getTipoServicio());
        servicioObj.setCodigoEmpresa(mensajeFlujo.getEmpresa());
        servicioObj.setIdentificador(GeneralUtils.obtenerValorParam(E_IDENTIFICATION, mensajeFlujo.getParams()));
        servicioObj.setCodigoTipoBanca(mensajeFlujo.getTipoBanca());
        servicioObj.setCodigoTipoIdentificador(GeneralUtils.obtenerValorParam(E_TIPO_IDENTIFICADOR, mensajeFlujo.getParams()));

        servicioObj.setDatosAdicionales(getDatosAdicionales(mensajeFlujo.getParams()));
        mecd.setServicio(servicioObj);

        String dateInString = GeneralUtils.obtenerValorParam(E_FECHA_REAL, mensajeFlujo.getParams());
        mecd.setFecha(parserFechaWithCalendar(dateInString));

        log.info("Finaliza mapeo de informacion para consulta  ... ");
        mensajeFlujo.getPeticionObj().setMensajeEntradaConsultarDeuda(mecd);
        //Se setea mensaje de Enriquecimiento NULL
        mensajeFlujo.getPeticionObj().getFlujo().setServicioEnriquecimiento(null);

        log.info("Invoca Core OTC  ... ");
        MensajeSalidaProcesar respuestaObj = proxyCore.procesar(mensajeFlujo.getPeticionObj());
        MensajeSalidaConsultarDeuda mscd = respuestaObj.getMensajeSalidaConsultarDeuda();
        log.info("Obtiene informacion de  Core OTC  ... ");

        if (mscd == null) {
            return getCtsMessageError(mensajeFlujo.getRespuesta(), mensajeFlujo.getData(), mensajeFlujo.getPr(), OTC_GTW_05, MSJ_NO_EXISTE_RESPUESTA);
        }

        if (!"0".equals(mscd.getCodigoError())) {
            return getCtsMessageError(mensajeFlujo.getRespuesta(), mensajeFlujo.getData(), mensajeFlujo.getPr(),  mscd.getCodigoError(),  (mscd.getMensajeUsuario() != null && !mscd.getMensajeUsuario().isEmpty())?mscd.getMensajeUsuario():mscd.getMensajeSistema());
        }

        log.info("Inicia mapeo de informacion para respuesta  ... ");
        mensajeFlujo.setRespuesta(new com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage());
       
        if (mscd.getRecibos() != null && mscd.getRecibos().getRecibo() != null) {
            com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.ResultSet rs = new com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.ResultSet();
            com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.ResultSet.Header headerRs = new com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.ResultSet.Header();

            headerRs.getCol().add(GeneralUtils.generateCol("@comprobante", BigInteger.valueOf(39)));

            headerRs.getCol().add(GeneralUtils.generateCol("@concepto", BigInteger.valueOf(39)));

            headerRs.getCol().add(GeneralUtils.generateCol("@fecha", BigInteger.valueOf(39)));

            headerRs.getCol().add(GeneralUtils.generateCol("@cuota", BigInteger.valueOf(39)));

            headerRs.getCol().add(GeneralUtils.generateCol("@dato1", BigInteger.valueOf(39)));

            headerRs.getCol().add(GeneralUtils.generateCol("@dato2", BigInteger.valueOf(39)));

            headerRs.getCol().add(GeneralUtils.generateCol("@dividendo", BigInteger.valueOf(39)));

            headerRs.getCol().add(GeneralUtils.generateCol("@formaPago", BigInteger.valueOf(39)));

            headerRs.getCol().add(GeneralUtils.generateCol("@identificador", BigInteger.valueOf(39)));

            headerRs.getCol().add(GeneralUtils.generateCol("@interes", BigInteger.valueOf(39)));

            headerRs.getCol().add(GeneralUtils.generateCol("@valor", BigInteger.valueOf(39)));

             headerRs.getCol().add(GeneralUtils.generateCol("@totalAPagar", BigInteger.valueOf(39)));

            headerRs.getCol().add(GeneralUtils.generateCol("@tipoProceso", BigInteger.valueOf(39)));

            headerRs.getCol().add(GeneralUtils.generateCol("@secuencia", BigInteger.valueOf(39)));

            headerRs.getCol().add(GeneralUtils.generateCol(PREFIJO + REFERENCIA, BigInteger.valueOf(39)));

            headerRs.getCol().add(GeneralUtils.generateCol("@pago", BigInteger.valueOf(39)));

            headerRs.getCol().add(GeneralUtils.generateCol("@interesesPagados", BigInteger.valueOf(39)));

            headerRs.getCol().add(GeneralUtils.generateCol("@interesesPendientes", BigInteger.valueOf(39)));

            headerRs.getCol().add(GeneralUtils.generateCol("@numeroPredial", BigInteger.valueOf(39)));

            rs.setHeader(headerRs);
            updateQueryResulSet(mscd, rs);
            mensajeFlujo.getPr().setResultSet(rs);

        }

        com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.OutputParams outputParams = new com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.OutputParams();
        outputParams.getParam().add(GeneralUtils.generateParam(PREFIJO + TXT_CODIGO_RESPUESTA, "39", mscd.getCodigoError() != null ? mscd.getCodigoError() : "0"));

        outputParams.getParam().add(GeneralUtils.generateParam("@nombreCliente", "39", mscd.getNombreCliente()));

        outputParams.getParam().add(GeneralUtils.generateParam("@formaPago", "39", mscd.getFormaPago()));

        outputParams.getParam().add(GeneralUtils.generateParam(PREFIJO + TXT_MONTO_TOTAL, "39", mscd.getMontoTotal() != null ? mscd.getMontoTotal().toString() : "0"));
        
        outputParams.getParam().add(GeneralUtils.generateParam(PREFIJO + TXT_MENSAJE_USUARIO, "39", mscd.getMensajeUsuario() != null ? mscd.getMensajeUsuario() : MENSAJE_PROCESADO));

        outputParams.getParam().add(GeneralUtils.generateParam("@identificadorDeuda", "39", mscd.getIdentificadorDeuda()));

        outputParams.getParam().add(GeneralUtils.generateParam("@formaPagoRecibos", "39", mscd.getFormaPagoRecibos()));

        outputParams.getParam().add(GeneralUtils.generateParam("@limiteMontoMaximo", "39", mscd.getLimiteMontoMaximo() != null ? mscd.getLimiteMontoMaximo().toString() : "0"));

        outputParams.getParam().add(GeneralUtils.generateParam("@limiteMontoMinimo", "39", mscd.getLimiteMontoMinimo() != null ? mscd.getLimiteMontoMinimo().toString() : "0"));

        outputParams.getParam().add(GeneralUtils.generateParam("@montoMinimo", "39", mscd.getMontoMinimo() != null ? mscd.getMontoMinimo().toString() : "0"));

        outputParams.getParam().add(GeneralUtils.generateParam("@textoAyuda", "39", mscd.getTextoAyuda()));

        updateOutputParams(outputParams, mscd);

        mensajeFlujo.getPr().setOutputParams(outputParams);
        mensajeFlujo.getPr().setReturn("0");

        mensajeFlujo.getData().setProcedureResponse(mensajeFlujo.getPr());
        mensajeFlujo.getRespuesta().setData(mensajeFlujo.getData());

        return mensajeFlujo.getRespuesta();
    }

    private void updateOutputParams(com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.OutputParams outputParams, MensajeSalidaConsultarDeuda mscd){
        
        if (mscd.getDatosAdicionales() != null && mscd.getDatosAdicionales().getDatoAdicional() != null) {
            for (com.bolivariano.microservice.recatx.domain.xml.dominio.datoadicional.DatoAdicional datoAdicionalOut : mscd.getDatosAdicionales().getDatoAdicional()) {
                outputParams.getParam().add(GeneralUtils.generateParam(PREFIJO + datoAdicionalOut.getCodigo(), "S", datoAdicionalOut.getValor()));

            }
        }

        if (mscd.getFechaVencimiento() != null) {
             outputParams.getParam().add(GeneralUtils.generateParam("@fechaVencimiento", "S", mscd.getFechaVencimiento().toGregorianCalendar().getTime().toString()));
        }
    }

    private com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage getCtsMessageError(com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage respuesta, com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data data, com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse pr, String codigoError, String mensajeError) {
        com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.Message msg = new com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.Message();
        msg.setMsgNo(COD_70001);
        msg.setType("3");
        String value = "";

        if (mensajeError != null){
            byte[] ptext = mensajeError.getBytes(StandardCharsets.UTF_8);
            value = new String(ptext, StandardCharsets.UTF_8);
        }

        msg.setValue("(" + codigoError +") " + value);

        pr.setReturn(COD_70001);
        pr.setMessage(msg);
        data.setProcedureResponse(pr);
        respuesta.setData(data);
        return respuesta;
    }

    private void validateTransation(String transaccion) throws BusinessException {
        if (transaccion == null || transaccion.isEmpty()) {
            throw new BusinessException(MSJ_TRANSACCION_VACIO);
        }
    }

    private void updateQueryResulSet(MensajeSalidaConsultarDeuda mscd , com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.ResultSet rs) {
        for (com.bolivariano.microservice.recatx.domain.xml.dominio.recibo.Recibo reciboOut : mscd.getRecibos().getRecibo()) {
            com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.ResultSet.Rw  rw = new com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.ResultSet.Rw();
            rw.getCd().add(GeneralUtils.verificarValor(reciboOut.getComprobante(), ""));
            rw.getCd().add(GeneralUtils.verificarValor(reciboOut.getConcepto(), ""));
            rw.getCd().add(GeneralUtils.verificarValor(reciboOut.getFecha(), ""));
            rw.getCd().add(GeneralUtils.verificarValor(reciboOut.getCuota(), ""));
            rw.getCd().add(GeneralUtils.verificarValor(reciboOut.getDato1(), ""));
            rw.getCd().add(GeneralUtils.verificarValor(reciboOut.getDato2(), ""));
            rw.getCd().add(GeneralUtils.verificarValor(reciboOut.getDividendo(), ""));
            rw.getCd().add(GeneralUtils.verificarValor(reciboOut.getFormaPago(), ""));
            rw.getCd().add(GeneralUtils.verificarValor(reciboOut.getIdentificador(), ""));
            rw.getCd().add(GeneralUtils.verificarValor(reciboOut.getInteres(), "0"));
            rw.getCd().add(GeneralUtils.verificarValor(reciboOut.getValor(), "0"));
            rw.getCd().add(GeneralUtils.verificarValor(reciboOut.getTotalAPagar(), "0"));
            rw.getCd().add(GeneralUtils.verificarValor(reciboOut.getTipoProceso(), ""));
            rw.getCd().add(GeneralUtils.verificarValor(reciboOut.getSecuencia(), ""));
            rw.getCd().add(GeneralUtils.verificarValor(reciboOut.getReferencia(), ""));
            rw.getCd().add(GeneralUtils.verificarValor(reciboOut.getPago(), "0"));
            rw.getCd().add(GeneralUtils.verificarValor(reciboOut.getInteresesPagados(), "0") );
            rw.getCd().add(GeneralUtils.verificarValor(reciboOut.getInteresesPendientes(), "0"));
            rw.getCd().add(GeneralUtils.verificarValor(reciboOut.getNumeroPredial(), ""));

            rs.getRw().add(rw);
        }
    }

    private void updateResulSet(MensajeSalidaEjecutarPago mseop, com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.ResultSet rs){
        com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.ResultSet.Rw rw;

        if (mseop.getFechaDebito() != null) {
            rw = new com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.ResultSet.Rw();
            rw.getCd().add(PREFIJO + "fechaDebito");
            rw.getCd().add(mseop.getFechaDebito().toGregorianCalendar().getTime().toString());
            rs.getRw().add(rw);
        }

        if (mseop.getFechaPago() != null) {
            rw = new com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.ResultSet.Rw();
            rw.getCd().add(PREFIJO + "fechaPago");
            rw.getCd().add(mseop.getFechaPago().toGregorianCalendar().getTime().toString());
            rs.getRw().add(rw);
        }

        if (mseop.getDatosAdicionales() != null && mseop.getDatosAdicionales().getDatoAdicional() != null) {
            for (com.bolivariano.microservice.recatx.domain.xml.dominio.datoadicional.DatoAdicional datoAdicionalOut : mseop.getDatosAdicionales().getDatoAdicional()) {
                rw = new com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.ResultSet.Rw();
                rw.getCd().add(PREFIJO + datoAdicionalOut.getCodigo());
                rw.getCd().add(datoAdicionalOut.getValor());

                rs.getRw().add(rw);
            }
        }
    }

    private com.bolivariano.microservice.recatx.domain.xml.dominio.servicio.Servicio.DatosAdicionales getDatosAdicionales( List<CTSMessage.Data.ProcedureRequest.Param> params ){
        com.bolivariano.microservice.recatx.domain.xml.dominio.servicio.Servicio.DatosAdicionales datosAdicionalesObj = new com.bolivariano.microservice.recatx.domain.xml.dominio.servicio.Servicio.DatosAdicionales();
        com.bolivariano.microservice.recatx.domain.xml.dominio.datoadicional.DatoAdicional datoAdicionalObj;

        for (CTSMessage.Data.ProcedureRequest.Param param : params) {
            datoAdicionalObj = new com.bolivariano.microservice.recatx.domain.xml.dominio.datoadicional.DatoAdicional();
            datoAdicionalObj.setCodigo(param.getName() != null?param.getName().replace("@",""):param.getName() );
            datoAdicionalObj.setValor(param.getValue());
            datosAdicionalesObj.getDatoAdicional().add(datoAdicionalObj);
        }

        return datosAdicionalesObj;
    }


    private MensajeEntradaEjecutarPago.Recibos getPaymentRecibos(List<CTSMessage.Data.ProcedureRequest.Param> params){
        MensajeEntradaEjecutarPago.Recibos recibos = new MensajeEntradaEjecutarPago.Recibos();
        Recibo recibo;

        for (CTSMessage.Data.ProcedureRequest.Param param : params) {
            if ("@e_concepto".equals(param.getName())){
                recibo = new Recibo();
                recibo.setConcepto(param.getValue());
                recibos.getRecibo().add(recibo);
                break;
            }
        }

        return recibos;
    }

    private MensajeEntradaEjecutarPago.DatosAdicionales getPaymentDatosAdicionales(List<CTSMessage.Data.ProcedureRequest.Param> params){
        MensajeEntradaEjecutarPago.DatosAdicionales datosAdicionalesMObj = new MensajeEntradaEjecutarPago.DatosAdicionales();
        DatoAdicional datoAdicionalMObj;

        for (CTSMessage.Data.ProcedureRequest.Param param : params) {
            datoAdicionalMObj = new DatoAdicional();
            datoAdicionalMObj.setCodigo(param.getName() != null?param.getName().replace("@",""):param.getName() );
            datoAdicionalMObj.setValor(param.getValue());
            datosAdicionalesMObj.getDatoAdicional().add(datoAdicionalMObj);
        }

        return datosAdicionalesMObj;
    }


    private MensajeEntradaEjecutarReverso.DatosAdicionales getReverseDatosAdicionales(List<CTSMessage.Data.ProcedureRequest.Param> params){
        MensajeEntradaEjecutarReverso.DatosAdicionales datosAdicionalesRMObj = new MensajeEntradaEjecutarReverso.DatosAdicionales();
        DatoAdicional datoAdicionalMObj;

        for (CTSMessage.Data.ProcedureRequest.Param param : params) {
            datoAdicionalMObj = new DatoAdicional();
            datoAdicionalMObj.setCodigo(param.getName() != null?param.getName().replace("@",""):param.getName() );
            datoAdicionalMObj.setValor(param.getValue());
            datosAdicionalesRMObj.getDatoAdicional().add(datoAdicionalMObj);
        }

        return datosAdicionalesRMObj;
    }

    private MensajeEntradaEjecutarReverso.Recibos getReverseRecibos(List<CTSMessage.Data.ProcedureRequest.Param> params){
        MensajeEntradaEjecutarReverso.Recibos recibos = new MensajeEntradaEjecutarReverso.Recibos();
        Recibo recibo;

        for (CTSMessage.Data.ProcedureRequest.Param param : params) {
            if ("@e_concepto".equals(param.getName())){
                recibo = new Recibo();
                recibo.setConcepto(param.getValue());
                recibos.getRecibo().add(recibo);
                break;
            }
        }

        return recibos;
    }

    private Map<String, String> updateParameters(String convenio, String tipoServicio, String tipoBanca, String empresa, String transaccion){
        Map<String, String> parameters = new HashMap<>();
        parameters.put(CONVENIO, convenio);
        parameters.put(TIPOSERVICIO, tipoServicio);
        parameters.put(TIPOBANCA, tipoBanca);
        parameters.put(EMPRESA, empresa);

        if (convenio == null || convenio.isEmpty() || tipoServicio == null || tipoServicio.isEmpty()) {
            FlujoTransformacionBean flujo = flujoTransaccionProxy.consultarFlujoPorTransaccion(Long.valueOf(transaccion));
            DatoAtxBean datos = flujoTransaccionProxy.consultarDatosFlujo((long) flujo.getFlujoId(), tipoBanca != null ? tipoBanca : "BP");

            parameters.put(CONVENIO, datos.getCodigoConvenio());
            parameters.put(TIPOSERVICIO,  datos.getTipoServicio());
            parameters.put(TIPOBANCA, datos.getTipoBanca());
            parameters.put(EMPRESA, datos.getCodigoEmpresa());

        }

        return parameters;
    }
    private XMLGregorianCalendar parserFechaWithCalendar(String dateInString){
        if(dateInString == null) return null;
        try {
            GregorianCalendar calendar = new GregorianCalendar();
            calendar.setTime(GeneralUtils.strParseDate(dateInString));
            return (DatatypeFactory.newInstance().newXMLGregorianCalendar(calendar));

        } catch (Exception ex) {
            log.info("Error al cargar fecha --> " + ex.getMessage());
        }
        return null;
    }

    private void sendError(String exceptionMessage, String correlationId){
        try {
            com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage mensajeSalidaGateway = new com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage();
            com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data data = new com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data();
            com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse pr = new com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse();

            com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.Message msg = new com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse.Message();
            msg.setMsgNo(COD_70001);
            msg.setType("3");
            msg.setValue("(OTC_GTW_04) ERROR NO CONTROLADO EN CONSULTAR: " + exceptionMessage);

            pr.setReturn(COD_70001);
            pr.setMessage(msg);
            data.setProcedureResponse(pr);
            mensajeSalidaGateway.setData(data);

            Converter converter = ConverterFactory.getConverter(ContentTypeEnum.XML);
            senderService.sendMQMessage(converter.convertirDeObjeto(mensajeSalidaGateway), correlationId);

        } catch (Exception ex) {
            log.error("ERROR A ENVIAR RESPUESTA: " + ex.getMessage(), ex);
        }
    }

}