package com.bolivariano.microservice.recatx.service.restclient.message;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@JsonInclude(Include.NON_NULL)
@Data
@NoArgsConstructor
public class MensajeEntradaConsultarGrupoServicioOBS implements Serializable {


    /**
     *
     */
    private static final long serialVersionUID = 5065686930287078082L;
    private String tipoBanca;
    private String tipoServicio;
    private Boolean matriculable;
    private String canal;

}