package com.bolivariano.microservice.recatx.domain.xml.dominio.tipoidentificador;

import com.bolivariano.microservice.recatx.domain.xml.dominio.datoadicional.DatoAdicional;
import com.bolivariano.microservice.recatx.domain.xml.dominio.regionalarea.RegionalArea;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>Clase Java para tipoIdentificador complex type.
 *
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 *
 * <pre>
 * &lt;complexType name="tipoIdentificador">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codigo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="etiquetaCodigo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="concatenadorRegionalArea" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="datosAdicionales" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="datoAdicional" type="{http://www.bolivariano.com/dominio/DatoAdicional}datoAdicional" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="flujoAyuda" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="mascara" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="matriculable" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="programable" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="regexp" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="regionalAreas" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="regionalArea" type="{http://www.bolivariano.com/dominio/RegionalArea}regionalArea" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="textoAyuda" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoIdentificador", propOrder = {
        "codigo",
        "etiquetaCodigo",
        "concatenadorRegionalArea",
        "datosAdicionales",
        "flujoAyuda",
        "mascara",
        "matriculable",
        "programable",
        "regexp",
        "regionalAreas",
        "textoAyuda"
})
public class TipoIdentificador {

    protected String codigo;
    protected String etiquetaCodigo;
    protected String concatenadorRegionalArea;
    protected DatosAdicionales datosAdicionales;
    protected String flujoAyuda;
    protected String mascara;
    protected Boolean matriculable;
    protected Boolean programable;
    protected String regexp;
    protected RegionalAreas regionalAreas;
    protected String textoAyuda;

    /**
     * Obtiene el valor de la propiedad codigo.
     *
     * @return possible object is
     * {@link String }
     */
    public String getCodigo() {
        return codigo;
    }

    /**
     * Define el valor de la propiedad codigo.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setCodigo(String value) {
        this.codigo = value;
    }

    /**
     * Obtiene el valor de la propiedad etiquetaCodigo.
     *
     * @return possible object is
     * {@link String }
     */
    public String getEtiquetaCodigo() {
        return etiquetaCodigo;
    }

    /**
     * Define el valor de la propiedad etiquetaCodigo.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setEtiquetaCodigo(String value) {
        this.etiquetaCodigo = value;
    }

    /**
     * Obtiene el valor de la propiedad concatenadorRegionalArea.
     *
     * @return possible object is
     * {@link String }
     */
    public String getConcatenadorRegionalArea() {
        return concatenadorRegionalArea;
    }

    /**
     * Define el valor de la propiedad concatenadorRegionalArea.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setConcatenadorRegionalArea(String value) {
        this.concatenadorRegionalArea = value;
    }

    /**
     * Obtiene el valor de la propiedad datosAdicionales.
     *
     * @return possible object is
     * {@link DatosAdicionales }
     */
    public DatosAdicionales getDatosAdicionales() {
        return datosAdicionales;
    }

    /**
     * Define el valor de la propiedad datosAdicionales.
     *
     * @param value allowed object is
     *              {@link DatosAdicionales }
     */
    public void setDatosAdicionales(DatosAdicionales value) {
        this.datosAdicionales = value;
    }

    /**
     * Obtiene el valor de la propiedad flujoAyuda.
     *
     * @return possible object is
     * {@link String }
     */
    public String getFlujoAyuda() {
        return flujoAyuda;
    }

    /**
     * Define el valor de la propiedad flujoAyuda.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setFlujoAyuda(String value) {
        this.flujoAyuda = value;
    }

    /**
     * Obtiene el valor de la propiedad mascara.
     *
     * @return possible object is
     * {@link String }
     */
    public String getMascara() {
        return mascara;
    }

    /**
     * Define el valor de la propiedad mascara.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setMascara(String value) {
        this.mascara = value;
    }

    /**
     * Obtiene el valor de la propiedad matriculable.
     *
     * @return possible object is
     * {@link Boolean }
     */
    public Boolean isMatriculable() {
        return matriculable;
    }

    /**
     * Define el valor de la propiedad matriculable.
     *
     * @param value allowed object is
     *              {@link Boolean }
     */
    public void setMatriculable(Boolean value) {
        this.matriculable = value;
    }

    /**
     * Obtiene el valor de la propiedad programable.
     *
     * @return possible object is
     * {@link Boolean }
     */
    public Boolean isProgramable() {
        return programable;
    }

    /**
     * Define el valor de la propiedad programable.
     *
     * @param value allowed object is
     *              {@link Boolean }
     */
    public void setProgramable(Boolean value) {
        this.programable = value;
    }

    /**
     * Obtiene el valor de la propiedad regexp.
     *
     * @return possible object is
     * {@link String }
     */
    public String getRegexp() {
        return regexp;
    }

    /**
     * Define el valor de la propiedad regexp.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setRegexp(String value) {
        this.regexp = value;
    }

    /**
     * Obtiene el valor de la propiedad regionalAreas.
     *
     * @return possible object is
     * {@link RegionalAreas }
     */
    public RegionalAreas getRegionalAreas() {
        return regionalAreas;
    }

    /**
     * Define el valor de la propiedad regionalAreas.
     *
     * @param value allowed object is
     *              {@link RegionalAreas }
     */
    public void setRegionalAreas(RegionalAreas value) {
        this.regionalAreas = value;
    }

    /**
     * Obtiene el valor de la propiedad textoAyuda.
     *
     * @return possible object is
     * {@link String }
     */
    public String getTextoAyuda() {
        return textoAyuda;
    }

    /**
     * Define el valor de la propiedad textoAyuda.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setTextoAyuda(String value) {
        this.textoAyuda = value;
    }


    /**
     * <p>Clase Java para anonymous complex type.
     *
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     *
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="datoAdicional" type="{http://www.bolivariano.com/dominio/DatoAdicional}datoAdicional" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
            "datoAdicional"
    })
    public static class DatosAdicionales {

        @XmlElement(nillable = true)
        protected List<DatoAdicional> datoAdicional;

        /**
         * Gets the value of the datoAdicional property.
         *
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the datoAdicional property.
         *
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDatoAdicional().add(newItem);
         * </pre>
         *
         *
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link DatoAdicional }
         */
        public List<DatoAdicional> getDatoAdicional() {
            if (datoAdicional == null) {
                datoAdicional = new ArrayList<>();
            }
            return this.datoAdicional;
        }

    }


    /**
     * <p>Clase Java para anonymous complex type.
     *
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     *
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="regionalArea" type="{http://www.bolivariano.com/dominio/RegionalArea}regionalArea" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
            "regionalArea"
    })
    public static class RegionalAreas {

        @XmlElement(nillable = true)
        protected List<RegionalArea> regionalArea;

        /**
         * Gets the value of the regionalArea property.
         *
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the regionalArea property.
         *
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getRegionalArea().add(newItem);
         * </pre>
         *
         *
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link RegionalArea }
         */
        public List<RegionalArea> getRegionalArea() {
            if (regionalArea == null) {
                regionalArea = new ArrayList<>();
            }
            return this.regionalArea;
        }

    }

}
