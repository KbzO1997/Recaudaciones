package com.bolivariano.microservice.recatx.service.restclient.domain;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;


/**
 * The persistent class for the OTC_M_SERV_ENRIQUECIMIENTO database table.
 */
@Data
@NoArgsConstructor
public class ServicioEnriquecimiento implements Serializable {
    private static final long serialVersionUID = 1L;


    private Long id;

    private String descripcion;

    private String puntoFinal;

    private String estado;

    private String fechaRegistro;

    private String nombre;

    private String operacion;

    private List<ServicioEnriquecimientoParam> parametros;

    private String peticion;

}