/*
 * Converter.java
 * 
 * Copyright (c) 2012 FARCOMED.
 * Todos los derechos reservados.
 */

package com.bolivariano.microservice.recatx.utils;

import java.io.InputStream;

import com.bolivariano.microservice.recatx.exception.ConverterException;

/**
 * Clase
 * 
 * @author
 * @revision $Revision: 1.1 $
 */
public interface Converter {

	<T> T convertirAObjeto(InputStream valor, Class<T> clase)
			throws  ConverterException;

	<T> T convertirAObjeto(String valor, Class<T> clase)
			throws ConverterException;

	String convertirDeObjeto(Object o) throws ConverterException;

	String convertirDeObjetoFormat(Object o) throws ConverterException;
}
