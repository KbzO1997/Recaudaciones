package com.bolivariano.microservice.recatx.service.beans;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import javax.annotation.processing.Generated;
import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "mensajeUsuario",
        "codigoRespuesta",
        "grupoServicios"
})
@Generated("jsonschema2pojo")
public class MensajeSalidaConsultarServicios {

    /**
     * mensaje para presentar en el canal
     */
    @JsonProperty("mensajeUsuario")
    @JsonPropertyDescription("mensaje para presentar en el canal")
    private String mensajeUsuario;
    /**
     * codigo de respuesta.
     */
    @JsonProperty("codigoRespuesta")
    @JsonPropertyDescription("codigo de respuesta.")
    private String codigoRespuesta;
    /**
     * grupo servicios
     * (Required)
     */
    @JsonProperty("grupoServicios")
    @JsonPropertyDescription("grupo servicios")
    private List<GrupoServicio> grupoServicios = new ArrayList<GrupoServicio>();

    /**
     * mensaje para presentar en el canal
     */
    @JsonProperty("mensajeUsuario")
    public String getMensajeUsuario() {
        return mensajeUsuario;
    }

    /**
     * mensaje para presentar en el canal
     */
    @JsonProperty("mensajeUsuario")
    public void setMensajeUsuario(String mensajeUsuario) {
        this.mensajeUsuario = mensajeUsuario;
    }

    /**
     * codigo de respuesta.
     */
    @JsonProperty("codigoRespuesta")
    public String getCodigoRespuesta() {
        return codigoRespuesta;
    }

    /**
     * codigo de respuesta.
     */
    @JsonProperty("codigoRespuesta")
    public void setCodigoRespuesta(String codigoRespuesta) {
        this.codigoRespuesta = codigoRespuesta;
    }

    /**
     * grupo servicios
     * (Required)
     */
    @JsonProperty("grupoServicios")
    public List<GrupoServicio> getGrupoServicios() {
        return grupoServicios;
    }

    /**
     * grupo servicios
     * (Required)
     */
    @JsonProperty("grupoServicios")
    public void setGrupoServicios(List<GrupoServicio> grupoServicios) {
        this.grupoServicios = grupoServicios;
    }

}
