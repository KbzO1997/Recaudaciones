package com.bolivariano.microservice.recatx.service.restclient.domain;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;


/**
 * The persistent class for the OTC_M_PUNTO_FINAL database table.
 */
@Data
@NoArgsConstructor
public class PuntoFinal implements Serializable {
    private static final long serialVersionUID = 1L;


    private Long id;

    private String nombre;

    private String operacion;

    private String transformacionPeticion;

    private String puntoFinal;

    private String repositorioPeticion;

    private String repositorioRespuesta;

    private String transformacionRespuesta;

    private String ambiente;


}