package com.bolivariano.microservice.recatx.service.beans;

import javax.annotation.processing.Generated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "banderaOffline",
        "datosAdicionales",
        "fechaDebito",
        "fechaPago",
        "mensajeUsuario",
        "montoTotal",
        "referencia",
        "codigoRespuesta"
})
@Generated("jsonschema2pojo")
public class MensajeSalidaReversar extends MensajeBaseSalidaPagoReverso{


}
