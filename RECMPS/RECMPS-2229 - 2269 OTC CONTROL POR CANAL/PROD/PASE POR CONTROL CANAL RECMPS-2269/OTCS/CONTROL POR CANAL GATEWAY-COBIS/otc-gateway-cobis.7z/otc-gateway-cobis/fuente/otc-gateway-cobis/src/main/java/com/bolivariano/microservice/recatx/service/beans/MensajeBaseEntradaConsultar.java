package com.bolivariano.microservice.recatx.service.beans;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "canal",
        "depuracion",
        "fecha",
        "oficina",
        "secuencial",
        "transaccion",
        "usuario"
})
public class MensajeBaseEntradaConsultar {
    /**
     * identificador de Canal
     */
    @JsonProperty("canal")
    @JsonPropertyDescription("identificador de Canal")
    private String canal;
    /**
     * identificador depuracion
     */
    @JsonProperty("depuracion")
    @JsonPropertyDescription("identificador depuracion")
    private String depuracion;
    /**
     * fechas de sistema
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "America/Guayaquil")
    @JsonProperty("fecha")
    @JsonPropertyDescription("fechas de sistema")
    private Date fecha;
    @JsonProperty("oficina")
    private String oficina;
    @JsonProperty("secuencial")
    private String secuencial;
    @JsonProperty("transaccion")
    private String transaccion;  
    @JsonProperty("usuario")
    private String usuario;
    
	public String getCanal() {
		return canal;
	}
	public void setCanal(String canal) {
		this.canal = canal;
	}
	public String getDepuracion() {
		return depuracion;
	}
	public void setDepuracion(String depuracion) {
		this.depuracion = depuracion;
	}
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public String getOficina() {
		return oficina;
	}
	public void setOficina(String oficina) {
		this.oficina = oficina;
	}
	public String getSecuencial() {
		return secuencial;
	}
	public void setSecuencial(String secuencial) {
		this.secuencial = secuencial;
	}
	public String getTransaccion() {
		return transaccion;
	}
	public void setTransaccion(String transaccion) {
		this.transaccion = transaccion;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
    
    
    
}
