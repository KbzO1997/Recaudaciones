package com.bolivariano.microservice.recatx.service.restclient.domain;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;


/**
 * The persistent class for the OTC_D_SERVICIO database table.
 */
@Data
@NoArgsConstructor
public class Servicio implements Serializable {
    private static final long serialVersionUID = 1L;


    private Long id;

    private GrupoServicio grupoServicio;

    private String nombre;

    private Convenio convenio;

    //transiente
    private Long convenioId;


}