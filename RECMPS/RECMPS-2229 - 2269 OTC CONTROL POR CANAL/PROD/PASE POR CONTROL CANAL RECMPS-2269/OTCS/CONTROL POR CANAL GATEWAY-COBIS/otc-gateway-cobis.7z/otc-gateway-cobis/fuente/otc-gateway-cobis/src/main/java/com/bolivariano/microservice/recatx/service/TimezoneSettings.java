package com.bolivariano.microservice.recatx.service;

import io.quarkus.runtime.StartupEvent;

import javax.enterprise.event.Observes;
import javax.inject.Singleton;
import java.util.TimeZone;

@Singleton
public class TimezoneSettings {

    public void setTimezone(@Observes StartupEvent startupEvent) {
        System.setProperty("user.timezone", "America/Guayaquil");
        TimeZone.setDefault(TimeZone.getTimeZone("America/Guayaquil"));
    }
}
