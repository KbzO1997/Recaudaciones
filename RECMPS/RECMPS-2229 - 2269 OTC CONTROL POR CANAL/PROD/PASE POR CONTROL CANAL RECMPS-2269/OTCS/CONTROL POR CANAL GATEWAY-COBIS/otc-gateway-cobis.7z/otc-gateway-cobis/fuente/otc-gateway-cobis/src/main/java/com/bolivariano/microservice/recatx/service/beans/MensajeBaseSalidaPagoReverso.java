package com.bolivariano.microservice.recatx.service.beans;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "banderaOffline",
        "datosAdicionales",
        "fechaDebito",
        "fechaPago",
        "mensajeUsuario",
        "montoTotal",
        "referencia",
        "codigoRespuesta"
})
public class MensajeBaseSalidaPagoReverso {

    @JsonProperty("banderaOffline")
    private Boolean banderaOffline;
    @JsonProperty("datosAdicionales")
    private List<DatoAdicional> datosAdicionales = new ArrayList<>();
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "America/Guayaquil")
    @JsonProperty("fechaDebito")
    private Date fechaDebito;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "America/Guayaquil")
    @JsonProperty("fechaPago")
    private Date fechaPago;
    @JsonProperty("mensajeUsuario")
    private String mensajeUsuario;
    @JsonProperty("montoTotal")
    private Double montoTotal;
    @JsonProperty("referencia")
    private String referencia;
    @JsonProperty("codigoRespuesta")
    private String codigoRespuesta;

    @JsonProperty("banderaOffline")
    public Boolean getBanderaOffline() {
        return banderaOffline;
    }

    @JsonProperty("banderaOffline")
    public void setBanderaOffline(Boolean banderaOffline) {
        this.banderaOffline = banderaOffline;
    }

    @JsonProperty("datosAdicionales")
    public List<DatoAdicional> getDatosAdicionales() {
        return datosAdicionales;
    }

    @JsonProperty("datosAdicionales")
    public void setDatosAdicionales(List<DatoAdicional> datosAdicionales) {
        this.datosAdicionales = datosAdicionales;
    }

    @JsonProperty("fechaDebito")
    public Date getFechaDebito() {
        return fechaDebito;
    }

    @JsonProperty("fechaDebito")
    public void setFechaDebito(Date fechaDebito) {
        this.fechaDebito = fechaDebito;
    }

    @JsonProperty("fechaPago")
    public Date getFechaPago() {
        return fechaPago;
    }

    @JsonProperty("fechaPago")
    public void setFechaPago(Date fechaPago) {
        this.fechaPago = fechaPago;
    }

    @JsonProperty("mensajeUsuario")
    public String getMensajeUsuario() {
        return mensajeUsuario;
    }

    @JsonProperty("mensajeUsuario")
    public void setMensajeUsuario(String mensajeUsuario) {
        this.mensajeUsuario = mensajeUsuario;
    }

    @JsonProperty("montoTotal")
    public Double getMontoTotal() {
        return montoTotal;
    }

    @JsonProperty("montoTotal")
    public void setMontoTotal(Double montoTotal) {
        this.montoTotal = montoTotal;
    }

    @JsonProperty("referencia")
    public String getReferencia() {
        return referencia;
    }

    @JsonProperty("referencia")
    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    @JsonProperty("codigoRespuesta")
    public String getCodigoRespuesta() {
        return codigoRespuesta;
    }

    @JsonProperty("codigoRespuesta")
    public void setCodigoRespuesta(String codigoRespuesta) {
        this.codigoRespuesta = codigoRespuesta;
    }
}
