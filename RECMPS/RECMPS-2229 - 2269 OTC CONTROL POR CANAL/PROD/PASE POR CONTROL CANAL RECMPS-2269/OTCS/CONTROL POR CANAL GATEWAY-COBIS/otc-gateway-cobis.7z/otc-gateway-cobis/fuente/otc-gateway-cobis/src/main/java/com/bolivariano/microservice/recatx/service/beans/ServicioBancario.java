package com.bolivariano.microservice.recatx.service.beans;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import javax.annotation.processing.Generated;


/**
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "convenio",
        "nombre"
})
@Generated("jsonschema2pojo")
public class ServicioBancario {

    /**
     * (Required)
     */
    @JsonProperty("convenio")
    private Convenio convenio;
    /**
     * (Required)
     */
    @JsonProperty("nombre")
    @JsonPropertyDescription("")
    private String nombre;

    /**
     * (Required)
     */
    @JsonProperty("convenio")
    public Convenio getConvenio() {
        return convenio;
    }

    /**
     * (Required)
     */
    @JsonProperty("convenio")
    public void setConvenio(Convenio convenio) {
        this.convenio = convenio;
    }

    /**
     * (Required)
     */
    @JsonProperty("nombre")
    public String getNombre() {
        return nombre;
    }

    /**
     * (Required)
     */
    @JsonProperty("nombre")
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

}
