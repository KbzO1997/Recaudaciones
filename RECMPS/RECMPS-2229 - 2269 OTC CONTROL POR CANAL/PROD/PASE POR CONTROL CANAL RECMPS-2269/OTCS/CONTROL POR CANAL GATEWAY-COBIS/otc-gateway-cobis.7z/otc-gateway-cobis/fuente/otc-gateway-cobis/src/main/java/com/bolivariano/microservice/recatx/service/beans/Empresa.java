package com.bolivariano.microservice.recatx.service.beans;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import javax.annotation.processing.Generated;
import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "codigoEmpresa",
        "etiquetaEmpresa",
        "convenioVisible",
        "convenios",
        "matriculable",
        "matriculacionMultiple",
        "validable"
})
@Generated("jsonschema2pojo")
public class Empresa {

    @JsonProperty("codigoEmpresa")
    private String codigoEmpresa;
    @JsonProperty("etiquetaEmpresa")
    private String etiquetaEmpresa;
    @JsonProperty("convenioVisible")
    private Boolean convenioVisible;
    @JsonProperty("convenios")
    private List<Convenio> convenios = new ArrayList<Convenio>();
    @JsonProperty("matriculable")
    private Boolean matriculable;
    @JsonProperty("matriculacionMultiple")
    private Boolean matriculacionMultiple;
    @JsonProperty("validable")
    private Boolean validable;

    @JsonProperty("codigoEmpresa")
    public String getCodigoEmpresa() {
        return codigoEmpresa;
    }

    @JsonProperty("codigoEmpresa")
    public void setCodigoEmpresa(String codigoEmpresa) {
        this.codigoEmpresa = codigoEmpresa;
    }

    @JsonProperty("etiquetaEmpresa")
    public String getEtiquetaEmpresa() {
        return etiquetaEmpresa;
    }

    @JsonProperty("etiquetaEmpresa")
    public void setEtiquetaEmpresa(String etiquetaEmpresa) {
        this.etiquetaEmpresa = etiquetaEmpresa;
    }

    @JsonProperty("convenioVisible")
    public Boolean getConvenioVisible() {
        return convenioVisible;
    }

    @JsonProperty("convenioVisible")
    public void setConvenioVisible(Boolean convenioVisible) {
        this.convenioVisible = convenioVisible;
    }

    @JsonProperty("convenios")
    public List<Convenio> getConvenios() {
        return convenios;
    }

    @JsonProperty("convenios")
    public void setConvenios(List<Convenio> convenios) {
        this.convenios = convenios;
    }

    @JsonProperty("matriculable")
    public Boolean getMatriculable() {
        return matriculable;
    }

    @JsonProperty("matriculable")
    public void setMatriculable(Boolean matriculable) {
        this.matriculable = matriculable;
    }

    @JsonProperty("matriculacionMultiple")
    public Boolean getMatriculacionMultiple() {
        return matriculacionMultiple;
    }

    @JsonProperty("matriculacionMultiple")
    public void setMatriculacionMultiple(Boolean matriculacionMultiple) {
        this.matriculacionMultiple = matriculacionMultiple;
    }

    @JsonProperty("validable")
    public Boolean getValidable() {
        return validable;
    }

    @JsonProperty("validable")
    public void setValidable(Boolean validable) {
        this.validable = validable;
    }

}
