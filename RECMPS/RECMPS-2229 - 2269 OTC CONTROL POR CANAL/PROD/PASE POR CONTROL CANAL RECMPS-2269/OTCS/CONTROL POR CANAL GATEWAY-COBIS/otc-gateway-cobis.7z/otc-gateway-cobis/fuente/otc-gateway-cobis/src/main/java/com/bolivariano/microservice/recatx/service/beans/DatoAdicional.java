package com.bolivariano.microservice.recatx.service.beans;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import javax.annotation.processing.Generated;
import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "codigo",
        "valor"
})
@Generated("jsonschema2pojo")
public class DatoAdicional {

    @JsonProperty("codigo")
    private String codigo;
    @JsonProperty("valor")
    private String valor;
    @JsonProperty("listasSeleccion")
    private List<ListaSeleccion> listasSeleccion = new ArrayList<ListaSeleccion>();

    @JsonProperty("codigo")
    public String getCodigo() {
        return codigo;
    }

    @JsonProperty("codigo")
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    @JsonProperty("valor")
    public String getValor() {
        return valor;
    }

    @JsonProperty("valor")
    public void setValor(String valor) {
        this.valor = valor;
    }

    @JsonProperty("listasSeleccion")
    public List<ListaSeleccion> getListasSeleccion() {
        return listasSeleccion;
    }

    @JsonProperty("listasSeleccion")
    public void setListasSeleccion(List<ListaSeleccion> listasSeleccion) {
        this.listasSeleccion = listasSeleccion;
    }
}