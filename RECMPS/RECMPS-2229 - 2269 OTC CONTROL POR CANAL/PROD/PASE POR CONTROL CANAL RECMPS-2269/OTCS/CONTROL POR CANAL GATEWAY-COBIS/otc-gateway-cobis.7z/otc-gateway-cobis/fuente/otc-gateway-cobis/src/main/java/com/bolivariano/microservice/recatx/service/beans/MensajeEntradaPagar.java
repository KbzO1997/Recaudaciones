package com.bolivariano.microservice.recatx.service.beans;

import java.util.Date;

import javax.annotation.processing.Generated;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "canal",
        "cuenta",
        "datosAdicionales",
        "depuracion",
        "esquemaFirma",
        "fecha",
        "fechaPago",
        "moneda",
        "nombreCliente",
        "oficina",
        "recibos",
        "secuencial",
        "servicio",
        "tipoCuenta",
        "transaccion",
        "usuario",
        "valorComision",
        "valorPago"
})
@Generated("jsonschema2pojo")
public class MensajeEntradaPagar extends MensajeBaseEntradaPagoReverso {

    /**
     * fecha del sistema
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "America/Guayaquil")
    @JsonProperty("fecha")
    @JsonPropertyDescription("fecha del sistema")
    private Date fecha;

	public Date getFecha() {
		return fecha;
	}

}
