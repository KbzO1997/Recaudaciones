package com.bolivariano.microservice.recatx.service.beans;

import javax.annotation.processing.Generated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "canal",
        "cuenta",
        "datosAdicionales",
        "depuracion",
        "esquemaFirma",
        "fechaPago",
        "moneda",
        "nombreCliente",
        "oficina",
        "recibos",
        "secuencial",
        "servicio",
        "tipoCuenta",
        "transaccion",
        "usuario",
        "valorComision",
        "valorPago"
})
@Generated("jsonschema2pojo")
public class MensajeEntradaReversar extends MensajeBaseEntradaPagoReverso {

    

}
