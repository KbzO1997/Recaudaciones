/****************************************************************************/
/* Archivo:            ccde0002.sql                                    		*/
/* Objeto:             Cambiar de Ambiente Claro Recargas en OTC			*/
/* Base de datos:      DB_OTC                                     			*/
/* Producto:           Recaudaciones                                    	*/
/* Disenado por:       Dario Espinosa                               		*/
/* Fecha de escritura: 21/Enero/2022                                       	*/
/* Descripcion:        RUTEO CLARO RECARGAS A FLUJO 12C 	                */
/****************************************************************************/
/*                               MODIFICACIONES                            	*/
/*   FECHA        TAREA             AUTOR                  RAZON           	*/
/*21/Enero/2021  RECM-485		Dario Espinosa       Emision inicial   		*/
/****************************************************************************/

set serveroutput on;

DECLARE
  LV_AMBIENTE VARCHAR2(10) := '11g';
BEGIN

	DBMS_OUTPUT.put_line('OBTENIENDO AMBIENTE');
	
	select END_AMBIENTE into LV_AMBIENTE from DB_OTC.OTC_M_PUNTO_FINAL where END_ID = 149; 

	IF LV_AMBIENTE = '11g' THEN 
		LV_AMBIENTE := '12c';
		DBMS_OUTPUT.put_line('AMBIENTE ACTUAL 11G CAMBIO A AMBIENTE 12C');
	ELSE 
		LV_AMBIENTE := '11g';
		DBMS_OUTPUT.put_line('AMBIENTE ACTUAL 12C CAMBIO A AMBIENTE 11G');
	END IF;


	Update DB_OTC.OTC_M_PUNTO_FINAL set END_AMBIENTE = LV_AMBIENTE
	where END_ID in (149,150,151);

	COMMIT;
	
	DBMS_OUTPUT.put_line('CAMBIO DE AMBIENTE EXITOSO A: '||LV_AMBIENTE);
	
  EXCEPTION
  WHEN OTHERS THEN
      ROLLBACK;
      DBMS_OUTPUT.put_line(DBMS_UTILITY.format_error_stack);
	
END;
/
