﻿/**************************************************************************/
/* Archivo:            cckb0003.sql		                                  */
/* Objeto:             OTC_M_EMPRESA                                      */
/* Base de datos:      DB_OTC                                     		  */
/* Producto:           Recaudaciones                                      */
/* Disenado por:       Kevin Bastidas                                     */
/* Fecha de escritura: 14/03/2022                                         */
/* Descripcion:        Script para editar el nombre del menu              */
/*                     Impuestos aduaneros  BB.                           */
/**************************************************************************/
/*                            MODIFICACIONES                              */
/*   FECHA     TAREA             AUTOR                  RAZON             */
/*14/03/2022  RECMPS-1370		Kevin Bastidas           Emision inicial  */
/**************************************************************************/

 set serveroutput on;
    DECLARE
    LV_NOMBRE	VARCHAR2(50) := 'Impuestos Aduaneros (SENAE)';
    BEGIN
        update DB_OTC.OTC_M_EMPRESA set emp_nombre = LV_NOMBRE , emp_descripcion = LV_NOMBRE where emp_id = 23;
        DBMS_OUTPUT.put_line('ACTUALIZADO OK');
        COMMIT;

        
    EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      DBMS_OUTPUT.put_line(DBMS_UTILITY.format_error_stack);
END;
/

	SELECT * FROM DB_OTC.OTC_M_EMPRESA WHERE  emp_id = 23;