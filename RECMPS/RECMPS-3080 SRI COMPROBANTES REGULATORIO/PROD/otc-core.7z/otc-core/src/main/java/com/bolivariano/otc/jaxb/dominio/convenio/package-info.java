@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.bolivariano.com/dominio/Convenio")
package com.bolivariano.otc.jaxb.dominio.convenio;
