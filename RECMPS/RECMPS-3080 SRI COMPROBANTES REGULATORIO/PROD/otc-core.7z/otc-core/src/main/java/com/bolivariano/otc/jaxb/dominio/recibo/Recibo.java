
package com.bolivariano.otc.jaxb.dominio.recibo;

import com.bolivariano.otc.jaxb.dominio.datoadicional.DatoAdicional;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>Java class for recibo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="recibo"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="comprobante" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="concepto" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="cuota" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="datosAdicionales" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="datoAdicional" type="{http://www.bolivariano.com/dominio/DatoAdicional}datoAdicional" maxOccurs="unbounded" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="dato1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="dato2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="dividendo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="fecha" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="formaPago" type="{http://www.bolivariano.com/dominio/FormaPago}formaPago" minOccurs="0"/&gt;
 *         &lt;element name="identificador" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="impuesto" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="interes" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="interesesPagados" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="interesesPendientes" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="numeroPredial" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="pago" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="referencia" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="secuencia" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="tipoProceso" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="totalAPagar" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="valor" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "recibo", propOrder = {
    "comprobante",
    "concepto",
    "cuota",
    "datosAdicionales",
    "dato1",
    "dato2",
    "dividendo",
    "fecha",
    "formaPago",
    "identificador",
    "impuesto",
    "interes",
    "interesesPagados",
    "interesesPendientes",
    "numeroPredial",
    "pago",
    "referencia",
    "secuencia",
    "tipoProceso",
    "totalAPagar",
    "valor"
})
public class Recibo {

    protected String comprobante;
    protected String concepto;
    protected String cuota;
    protected Recibo.DatosAdicionales datosAdicionales;
    protected String dato1;
    protected String dato2;
    protected String dividendo;
    protected String fecha;
    protected String formaPago;
    protected String identificador;
    protected String impuesto;
    protected Double interes;
    protected Double interesesPagados;
    protected Double interesesPendientes;
    protected String numeroPredial;
    protected Double pago;
    protected String referencia;
    protected String secuencia;
    protected String tipoProceso;
    protected Double totalAPagar;
    protected Double valor;

    /**
     * Gets the value of the comprobante property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getComprobante() {
        return comprobante;
    }

    /**
     * Sets the value of the comprobante property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setComprobante(String value) {
        this.comprobante = value;
    }

    /**
     * Gets the value of the concepto property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getConcepto() {
        return concepto;
    }

    /**
     * Sets the value of the concepto property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setConcepto(String value) {
        this.concepto = value;
    }

    /**
     * Gets the value of the cuota property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getCuota() {
        return cuota;
    }

    /**
     * Sets the value of the cuota property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setCuota(String value) {
        this.cuota = value;
    }

    /**
     * Gets the value of the datosAdicionales property.
     *
     * @return
     *     possible object is
     *     {@link Recibo.DatosAdicionales }
     *
     */
    public Recibo.DatosAdicionales getDatosAdicionales() {
        return datosAdicionales;
    }

    /**
     * Sets the value of the datosAdicionales property.
     *
     * @param value
     *     allowed object is
     *     {@link Recibo.DatosAdicionales }
     *
     */
    public void setDatosAdicionales(Recibo.DatosAdicionales value) {
        this.datosAdicionales = value;
    }

    /**
     * Gets the value of the dato1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDato1() {
        return dato1;
    }

    /**
     * Sets the value of the dato1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDato1(String value) {
        this.dato1 = value;
    }

    /**
     * Gets the value of the dato2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDato2() {
        return dato2;
    }

    /**
     * Sets the value of the dato2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDato2(String value) {
        this.dato2 = value;
    }

    /**
     * Gets the value of the dividendo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDividendo() {
        return dividendo;
    }

    /**
     * Sets the value of the dividendo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDividendo(String value) {
        this.dividendo = value;
    }

    /**
     * Gets the value of the fecha property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFecha() {
        return fecha;
    }

    /**
     * Sets the value of the fecha property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFecha(String value) {
        this.fecha = value;
    }

    /**
     * Gets the value of the formaPago property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormaPago() {
        return formaPago;
    }

    /**
     * Sets the value of the formaPago property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormaPago(String value) {
        this.formaPago = value;
    }

    /**
     * Gets the value of the identificador property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentificador() {
        return identificador;
    }

    /**
     * Sets the value of the identificador property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentificador(String value) {
        this.identificador = value;
    }

    /**
     * Gets the value of the impuesto property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getImpuesto() {
        return impuesto;
    }

    /**
     * Sets the value of the impuesto property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setImpuesto(String value) {
        this.impuesto = value;
    }

    /**
     * Gets the value of the interes property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getInteres() {
        return interes;
    }

    /**
     * Sets the value of the interes property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setInteres(Double value) {
        this.interes = value;
    }

    /**
     * Gets the value of the interesesPagados property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getInteresesPagados() {
        return interesesPagados;
    }

    /**
     * Sets the value of the interesesPagados property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setInteresesPagados(Double value) {
        this.interesesPagados = value;
    }

    /**
     * Gets the value of the interesesPendientes property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getInteresesPendientes() {
        return interesesPendientes;
    }

    /**
     * Sets the value of the interesesPendientes property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setInteresesPendientes(Double value) {
        this.interesesPendientes = value;
    }

    /**
     * Gets the value of the numeroPredial property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumeroPredial() {
        return numeroPredial;
    }

    /**
     * Sets the value of the numeroPredial property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumeroPredial(String value) {
        this.numeroPredial = value;
    }

    /**
     * Gets the value of the pago property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getPago() {
        return pago;
    }

    /**
     * Sets the value of the pago property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setPago(Double value) {
        this.pago = value;
    }

    /**
     * Gets the value of the referencia property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReferencia() {
        return referencia;
    }

    /**
     * Sets the value of the referencia property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReferencia(String value) {
        this.referencia = value;
    }

    /**
     * Gets the value of the secuencia property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSecuencia() {
        return secuencia;
    }

    /**
     * Sets the value of the secuencia property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSecuencia(String value) {
        this.secuencia = value;
    }

    /**
     * Gets the value of the tipoProceso property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipoProceso() {
        return tipoProceso;
    }

    /**
     * Sets the value of the tipoProceso property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipoProceso(String value) {
        this.tipoProceso = value;
    }

    /**
     * Gets the value of the totalAPagar property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getTotalAPagar() {
        return totalAPagar;
    }

    /**
     * Sets the value of the totalAPagar property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setTotalAPagar(Double value) {
        this.totalAPagar = value;
    }

    /**
     * Gets the value of the valor property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getValor() {
        return valor;
    }

    /**
     * Sets the value of the valor property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setValor(Double value) {
        this.valor = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="datoAdicional" type="{http://www.bolivariano.com/dominio/DatoAdicional}datoAdicional" maxOccurs="unbounded" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "datoAdicional"
    })
    public static class DatosAdicionales {

        @XmlElement(nillable = true)
        protected List<DatoAdicional> datoAdicional;

        /**
         * Gets the value of the datoAdicional property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the datoAdicional property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDatoAdicional().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link DatoAdicional }
         * 
         * 
         */
        public List<DatoAdicional> getDatoAdicional() {
            if (datoAdicional == null) {
                datoAdicional = new ArrayList<>();
            }
            return this.datoAdicional;
        }

    }

}
