package com.bolivariano.otc.message;

import com.bolivariano.otc.domain.Flujo;
import com.bolivariano.otc.enumeration.TipoFlujo;
import com.bolivariano.otc.jaxb.mensajeotc.MensajeEntradaConsultarDeuda;
import com.bolivariano.otc.jaxb.mensajeotc.MensajeEntradaEjecutarPago;
import com.bolivariano.otc.jaxb.mensajeotc.MensajeEntradaEjecutarReverso;

import java.io.Serializable;

public class MensajeEntradaProcesar implements Serializable{

  private Flujo flujo;
  private TipoFlujo tipoFlujo;
  private MensajeEntradaEjecutarReverso mensajeEntradaEjecutarReverso;
  private MensajeEntradaEjecutarPago mensajeEntradaEjecutarPago;
  private MensajeEntradaConsultarDeuda mensajeEntradaConsultarDeuda;

    public MensajeEntradaProcesar() {
        // Do nothing because of X and Y
    }

    public Flujo getFlujo() {
        return flujo;
    }

    public void setFlujo(Flujo flujo) {
        this.flujo = flujo;
    }

    public TipoFlujo getTipoFlujo() {
        return tipoFlujo;
    }

    public void setTipoFlujo(TipoFlujo tipoFlujo) {
        this.tipoFlujo = tipoFlujo;
    }

    public MensajeEntradaEjecutarReverso getMensajeEntradaEjecutarReverso() {
        return mensajeEntradaEjecutarReverso;
    }

    public void setMensajeEntradaEjecutarReverso(MensajeEntradaEjecutarReverso mensajeEntradaEjecutarReverso) {
        this.mensajeEntradaEjecutarReverso = mensajeEntradaEjecutarReverso;
    }

    public MensajeEntradaEjecutarPago getMensajeEntradaEjecutarPago() {
        return mensajeEntradaEjecutarPago;
    }

    public void setMensajeEntradaEjecutarPago(MensajeEntradaEjecutarPago mensajeEntradaEjecutarPago) {
        this.mensajeEntradaEjecutarPago = mensajeEntradaEjecutarPago;
    }

    public MensajeEntradaConsultarDeuda getMensajeEntradaConsultarDeuda() {
        return mensajeEntradaConsultarDeuda;
    }

    public void setMensajeEntradaConsultarDeuda(MensajeEntradaConsultarDeuda mensajeEntradaConsultarDeuda) {
        this.mensajeEntradaConsultarDeuda = mensajeEntradaConsultarDeuda;
    }

    @Override
    public String toString() {
        return "MensajeEntradaProcesar{" +
                "flujo=" + flujo +
                ", tipoFlujo=" + tipoFlujo +
                ", mensajeEntradaEjecutarReverso=" + mensajeEntradaEjecutarReverso +
                ", mensajeEntradaEjecutarPago=" + mensajeEntradaEjecutarPago +
                ", mensajeEntradaConsultarDeuda=" + mensajeEntradaConsultarDeuda +
                '}';
    }
}
