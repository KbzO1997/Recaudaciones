package com.bolivariano.otc.service;

import com.bolivariano.otc.config.RedisConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

@Service
public class CacheService {

    private static final Logger log = LoggerFactory.getLogger(CacheService.class);
    private static final String TABLE_KEY = "SSN-REVERSE|";

    @Value("${spring.cache.expiration}")
    private Integer expiration;

    @Autowired
    private RedisConfig util;

    private JedisPool jedisPool = null;

    public String testConnection() {
        String message = null;
        jedisPool = util.getJedisPool();
        try (Jedis jedis = jedisPool.getResource()) {
            if (jedis.isConnected()) {
                message = "connection successful";
            } else {
                message = "connection failed";
            }
        } catch (Exception e) {
            message = "connection failed";
        }

        return message;
    }

    public String setex(final String key, final String value) {
        String returnCode = "-1";

        try {
            jedisPool = util.getJedisPool();
            try (Jedis jedis = jedisPool.getResource()) {
                String keyfinal = TABLE_KEY + key;

                returnCode = jedis.setex(keyfinal, expiration.intValue(), value);
                log.debug("Data Inserted/Updated Successfully for " + value);
            }
        } catch (Exception ex) {
            log.error("error al procesar CACHE: " + ex.getMessage());
        }


        return returnCode;
    }

    public String get(final String key) {

        try {
            jedisPool = util.getJedisPool();
            try (Jedis jedis = jedisPool.getResource()) {
                String keyfinal = TABLE_KEY + key;
                return jedis.get(keyfinal);
            }
        } catch (Exception ex) {
            log.error("error al procesar CACHE: " + ex.getMessage());
        }

        return null;

    }

}
