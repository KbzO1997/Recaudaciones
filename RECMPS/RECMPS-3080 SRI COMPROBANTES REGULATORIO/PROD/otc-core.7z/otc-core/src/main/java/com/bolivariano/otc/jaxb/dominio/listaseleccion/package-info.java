@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.bolivariano.com/dominio/ListaSeleccion")
package com.bolivariano.otc.jaxb.dominio.listaseleccion;
