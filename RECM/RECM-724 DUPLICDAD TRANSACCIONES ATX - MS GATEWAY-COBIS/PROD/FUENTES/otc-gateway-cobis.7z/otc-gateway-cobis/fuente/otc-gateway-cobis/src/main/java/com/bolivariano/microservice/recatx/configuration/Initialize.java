package com.bolivariano.microservice.recatx.configuration;

import com.bolivariano.microservice.recatx.domain.MessageProcess;
import com.bolivariano.microservice.recatx.service.CobisGatewayService;

import io.quarkus.runtime.ShutdownEvent;

import javax.enterprise.event.Observes;
import javax.inject.Inject;

import org.jboss.logging.Logger;

import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class Initialize implements Runnable{

    @Inject
    CobisGatewayService processorService;

	@Inject
	Logger log;
	
    private ExecutorService scheduler;

    void onStart() {
        scheduler = Executors.newFixedThreadPool(1);
        scheduler.submit(this);
    }

    void onStop(@Observes ShutdownEvent event) {
    	log.info(event);
        scheduler.shutdown();
    }

    @SuppressWarnings("null")
	@Override
    public void run() {
        try {
        	MessageProcess messageProcess = new MessageProcess("");
            String messageMQ = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?><CTSMessage><CTSHeader><Field name=\"kernelHeader\" type=\"S\">FE4E140844100A006E0003FF0000E403</Field><Field name=\"backEndId\" type=\"S\">1</Field><Field name=\"fromServer\" type=\"S\">SRVDESA2</Field><Field name=\"srv\" type=\"S\">SRVDESA2</Field><Field name=\"sesn\" type=\"N\">10</Field></CTSHeader><Data><ProcedureRequest><SpName>cob_procesador..fp_valida_reca_ms</SpName></ProcedureRequest></Data></CTSMessage>";
            String userId = UUID.randomUUID().toString().replace("-", "").substring(0, 12);
            messageProcess.setCorrelationId(userId);
            log.info(messageMQ);
            messageProcess.setMessage(messageMQ);
            processorService.cobisGateway(messageProcess);
        } catch (Exception ignored) {
        	log.info(ignored);
        }finally {
            scheduler.shutdown();
        }
    }

}
