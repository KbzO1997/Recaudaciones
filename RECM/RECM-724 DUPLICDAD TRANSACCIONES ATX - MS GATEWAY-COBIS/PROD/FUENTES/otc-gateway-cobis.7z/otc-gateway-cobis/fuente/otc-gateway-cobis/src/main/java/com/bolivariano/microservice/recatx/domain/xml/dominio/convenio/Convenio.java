package com.bolivariano.microservice.recatx.domain.xml.dominio.convenio;

import com.bolivariano.microservice.recatx.domain.xml.dominio.tipoidentificador.TipoIdentificador;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>Clase Java para convenio complex type.
 *
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 *
 * <pre>
 * &lt;complexType name="convenio">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codigo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="etiquetaCodigo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tipoIdentificadores" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="tipoIdentificador" type="{http://www.bolivariano.com/dominio/TipoIdentificador}tipoIdentificador" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="visible" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "convenio", propOrder = {
        "codigo",
        "etiquetaCodigo",
        "tipoIdentificadores",
        "visible"
})
public class Convenio {

    protected String codigo;
    protected String etiquetaCodigo;
    protected TipoIdentificadores tipoIdentificadores;
    protected Boolean visible;

    /**
     * Obtiene el valor de la propiedad codigo.
     *
     * @return possible object is
     * {@link String }
     */
    public String getCodigo() {
        return codigo;
    }

    /**
     * Define el valor de la propiedad codigo.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setCodigo(String value) {
        this.codigo = value;
    }

    /**
     * Obtiene el valor de la propiedad etiquetaCodigo.
     *
     * @return possible object is
     * {@link String }
     */
    public String getEtiquetaCodigo() {
        return etiquetaCodigo;
    }

    /**
     * Define el valor de la propiedad etiquetaCodigo.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setEtiquetaCodigo(String value) {
        this.etiquetaCodigo = value;
    }

    /**
     * Obtiene el valor de la propiedad tipoIdentificadores.
     *
     * @return possible object is
     * {@link TipoIdentificadores }
     */
    public TipoIdentificadores getTipoIdentificadores() {
        return tipoIdentificadores;
    }

    /**
     * Define el valor de la propiedad tipoIdentificadores.
     *
     * @param value allowed object is
     *              {@link TipoIdentificadores }
     */
    public void setTipoIdentificadores(TipoIdentificadores value) {
        this.tipoIdentificadores = value;
    }

    /**
     * Obtiene el valor de la propiedad visible.
     *
     * @return possible object is
     * {@link Boolean }
     */
    public Boolean isVisible() {
        return visible;
    }

    /**
     * Define el valor de la propiedad visible.
     *
     * @param value allowed object is
     *              {@link Boolean }
     */
    public void setVisible(Boolean value) {
        this.visible = value;
    }


    /**
     * <p>Clase Java para anonymous complex type.
     *
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     *
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="tipoIdentificador" type="{http://www.bolivariano.com/dominio/TipoIdentificador}tipoIdentificador" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
            "tipoIdentificador"
    })
    public static class TipoIdentificadores {

        @XmlElement(nillable = true)
        protected List<TipoIdentificador> tipoIdentificador;

        /**
         * Gets the value of the tipoIdentificador property.
         *
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the tipoIdentificador property.
         *
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getTipoIdentificador().add(newItem);
         * </pre>
         *
         *
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link TipoIdentificador }
         */
        public List<TipoIdentificador> getTipoIdentificador() {
            if (tipoIdentificador == null) {
                tipoIdentificador = new ArrayList<>();
            }
            return this.tipoIdentificador;
        }

    }

}
