package com.bolivariano.microservice.recatx.service.restclient;

import com.bolivariano.microservice.recatx.service.restclient.message.DatoAtxBean;
import com.bolivariano.microservice.recatx.service.restclient.message.FlujoTransformacionBean;
import org.eclipse.microprofile.rest.client.annotation.RegisterClientHeaders;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

@Path("/flujoTransformacion")
@RegisterRestClient
@RegisterClientHeaders(RequestUUIDHeaderFactory.class)
public interface FlujoTransaccionProxy {

    @GET
    @Path("/{transaccion}")
    FlujoTransformacionBean consultarFlujoPorTransaccion(@PathParam("transaccion") Long transaccion);

    @GET
    @Path("/obtenerDatos/{id}/{banca}")
    DatoAtxBean consultarDatosFlujo(@PathParam("id") Long id, @PathParam("banca") String banca);
}
