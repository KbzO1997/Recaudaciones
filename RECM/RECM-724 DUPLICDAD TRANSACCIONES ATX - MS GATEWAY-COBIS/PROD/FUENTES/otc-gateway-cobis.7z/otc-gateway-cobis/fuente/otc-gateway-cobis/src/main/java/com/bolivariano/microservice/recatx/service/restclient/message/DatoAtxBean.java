package com.bolivariano.microservice.recatx.service.restclient.message;


import com.fasterxml.jackson.annotation.JsonInclude;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class DatoAtxBean implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private String codigoConvenio;
    private String codigoEmpresa;
    private String tipoServicio;
    private String tipoBanca;

    public String getCodigoConvenio() {
        return codigoConvenio;
    }

    public void setCodigoConvenio(String codigoConvenio) {
        this.codigoConvenio = codigoConvenio;
    }

    public String getCodigoEmpresa() {
        return codigoEmpresa;
    }

    public void setCodigoEmpresa(String codigoEmpresa) {
        this.codigoEmpresa = codigoEmpresa;
    }

    public String getTipoServicio() {
        return tipoServicio;
    }

    public void setTipoServicio(String tipoServicio) {
        this.tipoServicio = tipoServicio;
    }

    public String getTipoBanca() {
        return tipoBanca;
    }

    public void setTipoBanca(String tipoBanca) {
        this.tipoBanca = tipoBanca;
    }

    @Override
    public String toString() {
        return "DatoAtxBean [codigoConvenio=" + codigoConvenio + ", codigoEmpresa=" + codigoEmpresa + ", tipoServicio="
                + tipoServicio + ", tipoBanca=" + tipoBanca + "]";
    }


}
