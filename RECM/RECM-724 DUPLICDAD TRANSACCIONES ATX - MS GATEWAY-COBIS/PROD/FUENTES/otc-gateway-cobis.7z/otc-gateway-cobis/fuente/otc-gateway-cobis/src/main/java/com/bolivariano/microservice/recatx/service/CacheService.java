package com.bolivariano.microservice.recatx.service;

import io.quarkus.redis.client.RedisClient;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.jboss.logging.Logger;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class CacheService {

    private static final String TABLE_KEY = "GRUPO-SERVICIO|";
    @Inject
    Logger log;
    @Inject
    RedisClient redisClient;
    @ConfigProperty(name = "otc-gateway-rest.cache.expiration")
    private String expiration;

    public String get(String key) {
        try {
            String keyfinal = TABLE_KEY + key;
            return redisClient != null && redisClient.get(keyfinal) != null ? redisClient.get(keyfinal).toString() : null;

        } catch (Exception ex) {
            log.error("ERROR AL PROCESAR CACHE (GET): " + ex.getMessage(), ex);
        }


        return null;
    }

    public void setex(final String key, final String value) {
        try {
            String keyfinal = TABLE_KEY + key;

            log.info("DATA INSERTED/UPDATED SUCCESSFULLY FOR " + value);
            redisClient.setex(keyfinal, expiration, value);

        } catch (Exception ex) {
            log.error("ERROR AL PROCESAR CACHE (PUT): " + ex.getMessage(), ex);
        }
    }
}
