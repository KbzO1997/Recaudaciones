package com.bolivariano.microservice.recatx.service.beans;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import javax.annotation.processing.Generated;
import java.util.ArrayList;
import java.util.List;


/**
 * Grupo de servicios Bancarios
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "servicios",
        "codigoTipoBanca",
        "codigoTipoServicio"
})
@Generated("jsonschema2pojo")
public class GrupoServicio {

    /**
     * servicios bancarios
     * (Required)
     */
    @JsonProperty("servicios")
    @JsonPropertyDescription("servicios bancarios")
    private List<ServicioBancario> servicios = new ArrayList<ServicioBancario>();
    /**
     * tipo Banca
     * (Required)
     */
    @JsonProperty("codigoTipoBanca")
    @JsonPropertyDescription("tipo Banca")
    private String codigoTipoBanca;
    /**
     * tipo servicio
     * (Required)
     */
    @JsonProperty("codigoTipoServicio")
    @JsonPropertyDescription("tipo servicio")
    private String codigoTipoServicio;

    /**
     * servicios bancarios
     * (Required)
     */
    @JsonProperty("servicios")
    public List<ServicioBancario> getServicios() {
        return servicios;
    }

    /**
     * servicios bancarios
     * (Required)
     */
    @JsonProperty("servicios")
    public void setServicios(List<ServicioBancario> servicios) {
        this.servicios = servicios;
    }

    /**
     * tipo Banca
     * (Required)
     */
    @JsonProperty("codigoTipoBanca")
    public String getCodigoTipoBanca() {
        return codigoTipoBanca;
    }

    /**
     * tipo Banca
     * (Required)
     */
    @JsonProperty("codigoTipoBanca")
    public void setCodigoTipoBanca(String codigoTipoBanca) {
        this.codigoTipoBanca = codigoTipoBanca;
    }

    /**
     * tipo servicio
     * (Required)
     */
    @JsonProperty("codigoTipoServicio")
    public String getCodigoTipoServicio() {
        return codigoTipoServicio;
    }

    /**
     * tipo servicio
     * (Required)
     */
    @JsonProperty("codigoTipoServicio")
    public void setCodigoTipoServicio(String codigoTipoServicio) {
        this.codigoTipoServicio = codigoTipoServicio;
    }

}
