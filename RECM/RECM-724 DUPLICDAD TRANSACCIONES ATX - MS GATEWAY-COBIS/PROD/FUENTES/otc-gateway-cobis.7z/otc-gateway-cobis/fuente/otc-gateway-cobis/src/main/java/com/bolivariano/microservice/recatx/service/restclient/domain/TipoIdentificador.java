package com.bolivariano.microservice.recatx.service.restclient.domain;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;


/**
 * The persistent class for the OTC_M_IDENTIFICADOR database table.
 */

@Data
@NoArgsConstructor
public class TipoIdentificador implements Serializable {
    private static final long serialVersionUID = 1L;

    private Long id;

    private String codigo;

    private String etiquetaCodigo;

    private String concatenadorRegionalArea;

    private List<DatoAdicional> datoAdicionales;

    private String flujoAyuda;

    private String mascara;

    private Boolean matriculable;

    private Boolean programable;

    private String regexp;

    private List<RegionalArea> regionalAreas;

    private String textoAyuda;

    private List<FormaPago> formaPagos;

}