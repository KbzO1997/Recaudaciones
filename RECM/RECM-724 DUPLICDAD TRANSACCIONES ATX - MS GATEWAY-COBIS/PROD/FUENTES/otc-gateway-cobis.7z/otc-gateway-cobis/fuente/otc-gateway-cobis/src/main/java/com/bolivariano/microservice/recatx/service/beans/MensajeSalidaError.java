package com.bolivariano.microservice.recatx.service.beans;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import javax.annotation.processing.Generated;
import java.util.ArrayList;
import java.util.List;


/**
 * Una serie de c\u00f3digos de error detallados, mensajes y URL a la documentaci\u00f3n para ayudar a solucionarlos.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "codigo",
        "id",
        "mensaje",
        "errores"
})
@Generated("jsonschema2pojo")
public class MensajeSalidaError {

    /**
     * C\u00f3digo de error textual de alto nivel, para ayudar a categorizar los errores.
     * (Required)
     */
    @JsonProperty("codigo")
    @JsonPropertyDescription("C\u00f3digo de error textual de alto nivel, para ayudar a categorizar los errores.")
    private String codigo;
    /**
     * Una referencia \u00fanica para la instancia de error, para fines de auditor\u00eda, en caso de errores desconocidos / no clasificados.
     */
    @JsonProperty("id")
    @JsonPropertyDescription("Una referencia \u00fanica para la instancia de error, para fines de auditor\u00eda, en caso de errores desconocidos / no clasificados.")
    private String id;
    /**
     * Breve mensaje de error, por ejemplo, "Hay alg\u00fan problema con los par\u00e1metros de solicitud proporcionados'
     * (Required)
     */
    @JsonProperty("mensaje")
    @JsonPropertyDescription("Breve mensaje de error, por ejemplo, \"Hay alg\u00fan problema con los par\u00e1metros de solicitud proporcionados'")
    private String mensaje;
    /**
     * (Required)
     */
    @JsonProperty("errores")
    private List<OBSError> errores = new ArrayList<OBSError>();

    /**
     * C\u00f3digo de error textual de alto nivel, para ayudar a categorizar los errores.
     * (Required)
     */
    @JsonProperty("codigo")
    public String getCodigo() {
        return codigo;
    }

    /**
     * C\u00f3digo de error textual de alto nivel, para ayudar a categorizar los errores.
     * (Required)
     */
    @JsonProperty("codigo")
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    /**
     * Una referencia \u00fanica para la instancia de error, para fines de auditor\u00eda, en caso de errores desconocidos / no clasificados.
     */
    @JsonProperty("id")
    public String getId() {
        return id;
    }

    /**
     * Una referencia \u00fanica para la instancia de error, para fines de auditor\u00eda, en caso de errores desconocidos / no clasificados.
     */
    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Breve mensaje de error, por ejemplo, "Hay alg\u00fan problema con los par\u00e1metros de solicitud proporcionados'
     * (Required)
     */
    @JsonProperty("mensaje")
    public String getMensaje() {
        return mensaje;
    }

    /**
     * Breve mensaje de error, por ejemplo, "Hay alg\u00fan problema con los par\u00e1metros de solicitud proporcionados'
     * (Required)
     */
    @JsonProperty("mensaje")
    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    /**
     * (Required)
     */
    @JsonProperty("errores")
    public List<OBSError> getErrores() {
        return errores;
    }

    /**
     * (Required)
     */
    @JsonProperty("errores")
    public void setErrores(List<OBSError> errores) {
        this.errores = errores;
    }

}
