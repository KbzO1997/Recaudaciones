package com.bolivariano.microservice.recatx.service.beans;

import javax.annotation.processing.Generated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "canal",
        "depuracion",
        "fecha",
        "oficina",
        "secuencial",
        "transaccion",
        "usuario",
        "servicio"
})
@Generated("jsonschema2pojo")
public class MensajeEntradaConsultar  extends MensajeBaseEntradaConsultar{

   
    @JsonProperty("servicio")
    @JsonPropertyDescription("Servicio a consultar")
    private Servicio servicio;

    @JsonProperty("servicio")
    public Servicio getServicio() {
        return servicio;
    }

    @JsonProperty("servicio")
    public void setServicios(Servicio servicio) {
        this.servicio = servicio;
    }
}
