package com.bolivariano.microservice.recatx.service.restclient.domain;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;


/**
 * The persistent class for the OTC_M_GRUPO_SERVICIO database table.
 */

@Data
@NoArgsConstructor
public class GrupoServicio implements Serializable {
    private static final long serialVersionUID = 1L;


    private Long id;

    private List<Servicio> servicios;

    private Catalogo tipoBanca;

    private Catalogo tipoServicio;

    private Empresa empresa;

    private Boolean convenioVisible;

    private Boolean matriculable;

    private Boolean matriculacionMultiple;

    private Boolean validable;
}