package com.bolivariano.microservice.recatx.mq;

import com.bolivariano.microservice.recatx.configuration.ApplicationProperties;
import com.bolivariano.microservice.recatx.configuration.MQConnectionFactoryData;
import com.bolivariano.microservice.recatx.utils.MQUtil;
import com.ibm.mq.MQMessage;
import com.ibm.mq.constants.CMQC;
import org.jboss.logging.Logger;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.jms.*;

@ApplicationScoped
public class MessageSender {

    @Inject
    ApplicationProperties applicationProperties;

    @Inject
    Logger log;

    @Inject
    @MQConnectionFactoryData
    ConnectionFactory mqConnectionFactory;

    public void sendMQMessage(String message, final String userId, boolean testMQ)  {
        try{
            
            MQMessage mqmessage = new MQMessage();
            mqmessage.correlationId = userId.getBytes();
            mqmessage.messageType = CMQC.MQMT_DATAGRAM;
            mqmessage.format = CMQC.MQFMT_STRING;
            mqmessage.expiry=applicationProperties.mq().timeToLive().intValue();

            if (!testMQ){
                mqmessage.writeString("<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>"+message);
                MQUtil sender = new MQUtil(applicationProperties.mq().host(), applicationProperties.mq().channel(), applicationProperties.mq().port(), applicationProperties.mq().queueManager(), applicationProperties.mq().queueReplay());
                sender.sendMessage(mqmessage);
                log.info("TEXT--> "+ message);
            } else {
                mqmessage.writeString(message);
                MQUtil sender = new MQUtil(applicationProperties.mq().host(), applicationProperties.mq().channel(), applicationProperties.mq().port(), applicationProperties.mq().queueManager(), applicationProperties.mq().queueRequest());
                sender.sendMessage(mqmessage);
            }

        }catch(Exception ex){
            log.error("Error en producir de servicio MQ", ex);
        }
    }


}
