package com.bolivariano.microservice.recatx.service.beans;

import java.util.List;

import com.bolivariano.microservice.recatx.domain.cts.request.CTSMessage;
import com.bolivariano.microservice.recatx.service.restclient.message.MensajeEntradaProcesar;


public class MensajeFlujoGenericDTO {
	
	List<CTSMessage.Data.ProcedureRequest.Param> params;
    MensajeEntradaProcesar peticionObj;
    com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage respuesta;
    com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data data;
    com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse pr;
    String convenio;
    String tipoServicio;
    String empresa;
    String tipoBanca;
    String valorComision;
    String valorPago;
    
	public String getValorComision() {
		return valorComision;
	}
	public void setValorComision(String valorComision) {
		this.valorComision = valorComision;
	}
	public String getValorPago() {
		return valorPago;
	}
	public void setValorPago(String valorPago) {
		this.valorPago = valorPago;
	}
	public List<CTSMessage.Data.ProcedureRequest.Param> getParams() {
		return params;
	}
	public void setParams(List<CTSMessage.Data.ProcedureRequest.Param> params) {
		this.params = params;
	}
	public MensajeEntradaProcesar getPeticionObj() {
		return peticionObj;
	}
	public void setPeticionObj(MensajeEntradaProcesar peticionObj) {
		this.peticionObj = peticionObj;
	}
	public com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage getRespuesta() {
		return respuesta;
	}
	public void setRespuesta(com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage respuesta) {
		this.respuesta = respuesta;
	}
	public com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data getData() {
		return data;
	}
	public void setData(com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data data) {
		this.data = data;
	}
	public com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse getPr() {
		return pr;
	}
	public void setPr(com.bolivariano.microservice.recatx.domain.cts.response.CTSMessage.Data.ProcedureResponse pr) {
		this.pr = pr;
	}
	public String getConvenio() {
		return convenio;
	}
	public void setConvenio(String convenio) {
		this.convenio = convenio;
	}
	public String getTipoServicio() {
		return tipoServicio;
	}
	public void setTipoServicio(String tipoServicio) {
		this.tipoServicio = tipoServicio;
	}
	public String getEmpresa() {
		return empresa;
	}
	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}
	public String getTipoBanca() {
		return tipoBanca;
	}
	public void setTipoBanca(String tipoBanca) {
		this.tipoBanca = tipoBanca;
	}
}
