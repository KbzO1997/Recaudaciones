package com.bolivariano.microservice.recatx.service.restclient.domain;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the OTC_M_CATALOGO database table.
 */

@Data
@NoArgsConstructor
public class TipoCatalogo implements Serializable {
    private static final long serialVersionUID = 1L;

    private Long id;

    private String descripcion;

    private String estado;

    private Date fechaRegistro;

    private String nombre;

    private String codigo;

    private List<Catalogo> catalogos;

}