package com.bolivariano.microservice.recatx.service.beans;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import javax.annotation.processing.Generated;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "codigoError",
        "mensaje",
        "ruta",
        "url"
})
@Generated("jsonschema2pojo")
public class OBSError {

    /**
     * C\u00f3digo de error textual de bajo nivel, por ejemplo, com.bolivariano.Field.Missing
     * (Required)
     */
    @JsonProperty("codigoError")
    @JsonPropertyDescription("C\u00f3digo de error textual de bajo nivel, por ejemplo, com.bolivariano.Field.Missing")
    private String codigoError;
    /**
     * Una descripci\u00f3n del error que ocurri\u00f3. p. ej., 'No se proporciona un campo obligatorio' o 'RequestedExecutionDateTime debe ser en el futuro' OBIE no estandariza este campo
     * (Required)
     */
    @JsonProperty("mensaje")
    @JsonPropertyDescription("Una descripci\u00f3n del error que ocurri\u00f3. p. ej., 'No se proporciona un campo obligatorio' o 'RequestedExecutionDateTime debe ser en el futuro' OBIE no estandariza este campo")
    private String mensaje;
    /**
     * Referencia recomendada pero opcional a la ruta JSON del campo con error, por ejemplo, Data.Initiation.InstructedAmount.Currency
     */
    @JsonProperty("ruta")
    @JsonPropertyDescription("Referencia recomendada pero opcional a la ruta JSON del campo con error, por ejemplo, Data.Initiation.InstructedAmount.Currency")
    private String ruta;
    /**
     * URL para ayudar a solucionar el problema, o proporcionar m\u00e1s informaci\u00f3n, o referencia de API, o ayuda, etc.
     */
    @JsonProperty("url")
    @JsonPropertyDescription("URL para ayudar a solucionar el problema, o proporcionar m\u00e1s informaci\u00f3n, o referencia de API, o ayuda, etc.")
    private String url;

    /**
     * C\u00f3digo de error textual de bajo nivel, por ejemplo, com.bolivariano.Field.Missing
     * (Required)
     */
    @JsonProperty("codigoError")
    public String getCodigoError() {
        return codigoError;
    }

    /**
     * C\u00f3digo de error textual de bajo nivel, por ejemplo, com.bolivariano.Field.Missing
     * (Required)
     */
    @JsonProperty("codigoError")
    public void setCodigoError(String codigoError) {
        this.codigoError = codigoError;
    }

    /**
     * Una descripci\u00f3n del error que ocurri\u00f3. p. ej., 'No se proporciona un campo obligatorio' o 'RequestedExecutionDateTime debe ser en el futuro' OBIE no estandariza este campo
     * (Required)
     */
    @JsonProperty("mensaje")
    public String getMensaje() {
        return mensaje;
    }

    /**
     * Una descripci\u00f3n del error que ocurri\u00f3. p. ej., 'No se proporciona un campo obligatorio' o 'RequestedExecutionDateTime debe ser en el futuro' OBIE no estandariza este campo
     * (Required)
     */
    @JsonProperty("mensaje")
    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    /**
     * Referencia recomendada pero opcional a la ruta JSON del campo con error, por ejemplo, Data.Initiation.InstructedAmount.Currency
     */
    @JsonProperty("ruta")
    public String getRuta() {
        return ruta;
    }

    /**
     * Referencia recomendada pero opcional a la ruta JSON del campo con error, por ejemplo, Data.Initiation.InstructedAmount.Currency
     */
    @JsonProperty("ruta")
    public void setRuta(String ruta) {
        this.ruta = ruta;
    }

    /**
     * URL para ayudar a solucionar el problema, o proporcionar m\u00e1s informaci\u00f3n, o referencia de API, o ayuda, etc.
     */
    @JsonProperty("url")
    public String getUrl() {
        return url;
    }

    /**
     * URL para ayudar a solucionar el problema, o proporcionar m\u00e1s informaci\u00f3n, o referencia de API, o ayuda, etc.
     */
    @JsonProperty("url")
    public void setUrl(String url) {
        this.url = url;
    }

}
