package com.bolivariano.microservice.recatx.configuration;

import com.bolivariano.microservice.recatx.exception.BusinessException;
import com.bolivariano.microservice.recatx.service.wsclient.SecurityFrameworkClient;
import io.quarkus.arc.DefaultBean;

import javax.enterprise.context.Dependent;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.inject.Singleton;
import java.util.Map;


@Dependent
public class FrameworkSecurityInitializer {
	@Inject
	ApplicationProperties applicationProperties;
	
	@Produces
	@Singleton
	@DefaultBean
	Map<String, String> frameworkSecurityParams(SecurityFrameworkClient securityFrameworkClient) throws BusinessException {
		System.setProperty("javax.net.ssl.trustStore", applicationProperties.truststore().path());
		System.setProperty("javax.net.ssl.trustStorePassword", applicationProperties.truststore().password() );
		System.setProperty("javax.net.ssl.trustStoreType", applicationProperties.truststore().type());
		return securityFrameworkClient.loginAplicacion();
	}

}
