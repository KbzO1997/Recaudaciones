package com.bolivariano.microservice.recatx.service.restclient.message;

import com.bolivariano.microservice.recatx.service.restclient.domain.GrupoServicio;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@JsonInclude(Include.NON_NULL)
@Data
@NoArgsConstructor
public class MensajeSalidaConsultarGrupoServicio implements Serializable {

    private static final long serialVersionUID = -4723237529017319717L;

    private String codigo;
    private String mensajeUsuario;
    private String estado;
    private List<GrupoServicio> mensaje;

}
