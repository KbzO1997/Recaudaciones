@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.bolivariano.com/dominio/Recibo")
package com.bolivariano.microservice.recatx.domain.xml.dominio.recibo;
