package com.bolivariano.microservice.recatx.service.beans;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import javax.annotation.processing.Generated;
import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "comprobante",
        "concepto",
        "cuota",
        "datosAdicionales",
        "dato1",
        "dato2",
        "dividendo",
        "fecha",
        "formaPago",
        "identificador",
        "impuesto",
        "interes",
        "interesesPagados",
        "interesesPendientes",
        "numeroPredial",
        "pago",
        "referencia",
        "secuencia",
        "tipoProceso",
        "totalAPagar",
        "valor"
})
@Generated("jsonschema2pojo")
public class Recibo {

    @JsonProperty("comprobante")
    private String comprobante;
    @JsonProperty("concepto")
    private String concepto;
    @JsonProperty("cuota")
    private String cuota;
    @JsonProperty("datosAdicionales")
    private List<DatoAdicional> datosAdicionales = new ArrayList<DatoAdicional>();
    @JsonProperty("dato1")
    private String dato1;
    @JsonProperty("dato2")
    private String dato2;
    @JsonProperty("dividendo")
    private String dividendo;
    @JsonProperty("fecha")
    private String fecha;
    @JsonProperty("formaPago")
    private String formaPago;
    @JsonProperty("identificador")
    private String identificador;
    @JsonProperty("impuesto")
    private String impuesto;
    @JsonProperty("interes")
    private Double interes;
    @JsonProperty("interesesPagados")
    private Double interesesPagados;
    @JsonProperty("interesesPendientes")
    private Double interesesPendientes;
    @JsonProperty("numeroPredial")
    private String numeroPredial;
    @JsonProperty("pago")
    private Double pago;
    @JsonProperty("referencia")
    private String referencia;
    @JsonProperty("secuencia")
    private String secuencia;
    @JsonProperty("tipoProceso")
    private String tipoProceso;
    @JsonProperty("totalAPagar")
    private Double totalAPagar;
    @JsonProperty("valor")
    private Double valor;

    @JsonProperty("comprobante")
    public String getComprobante() {
        return comprobante;
    }

    @JsonProperty("comprobante")
    public void setComprobante(String comprobante) {
        this.comprobante = comprobante;
    }

    @JsonProperty("concepto")
    public String getConcepto() {
        return concepto;
    }

    @JsonProperty("concepto")
    public void setConcepto(String concepto) {
        this.concepto = concepto;
    }

    @JsonProperty("cuota")
    public String getCuota() {
        return cuota;
    }

    @JsonProperty("cuota")
    public void setCuota(String cuota) {
        this.cuota = cuota;
    }

    @JsonProperty("datosAdicionales")
    public List<DatoAdicional> getDatosAdicionales() {
        return datosAdicionales;
    }

    @JsonProperty("datosAdicionales")
    public void setDatosAdicionales(List<DatoAdicional> datosAdicionales) {
        this.datosAdicionales = datosAdicionales;
    }

    @JsonProperty("dato1")
    public String getDato1() {
        return dato1;
    }

    @JsonProperty("dato1")
    public void setDato1(String dato1) {
        this.dato1 = dato1;
    }

    @JsonProperty("dato2")
    public String getDato2() {
        return dato2;
    }

    @JsonProperty("dato2")
    public void setDato2(String dato2) {
        this.dato2 = dato2;
    }

    @JsonProperty("dividendo")
    public String getDividendo() {
        return dividendo;
    }

    @JsonProperty("dividendo")
    public void setDividendo(String dividendo) {
        this.dividendo = dividendo;
    }

    @JsonProperty("fecha")
    public String getFecha() {
        return fecha;
    }

    @JsonProperty("fecha")
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    @JsonProperty("formaPago")
    public String getFormaPago() {
        return formaPago;
    }

    @JsonProperty("formaPago")
    public void setFormaPago(String formaPago) {
        this.formaPago = formaPago;
    }

    @JsonProperty("identificador")
    public String getIdentificador() {
        return identificador;
    }

    @JsonProperty("identificador")
    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }

    @JsonProperty("impuesto")
    public String getImpuesto() {
        return impuesto;
    }

    @JsonProperty("impuesto")
    public void setImpuesto(String impuesto) {
        this.impuesto = impuesto;
    }

    @JsonProperty("interes")
    public Double getInteres() {
        return interes;
    }

    @JsonProperty("interes")
    public void setInteres(Double interes) {
        this.interes = interes;
    }

    @JsonProperty("interesesPagados")
    public Double getInteresesPagados() {
        return interesesPagados;
    }

    @JsonProperty("interesesPagados")
    public void setInteresesPagados(Double interesesPagados) {
        this.interesesPagados = interesesPagados;
    }

    @JsonProperty("interesesPendientes")
    public Double getInteresesPendientes() {
        return interesesPendientes;
    }

    @JsonProperty("interesesPendientes")
    public void setInteresesPendientes(Double interesesPendientes) {
        this.interesesPendientes = interesesPendientes;
    }

    @JsonProperty("numeroPredial")
    public String getNumeroPredial() {
        return numeroPredial;
    }

    @JsonProperty("numeroPredial")
    public void setNumeroPredial(String numeroPredial) {
        this.numeroPredial = numeroPredial;
    }

    @JsonProperty("pago")
    public Double getPago() {
        return pago;
    }

    @JsonProperty("pago")
    public void setPago(Double pago) {
        this.pago = pago;
    }

    @JsonProperty("referencia")
    public String getReferencia() {
        return referencia;
    }

    @JsonProperty("referencia")
    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    @JsonProperty("secuencia")
    public String getSecuencia() {
        return secuencia;
    }

    @JsonProperty("secuencia")
    public void setSecuencia(String secuencia) {
        this.secuencia = secuencia;
    }

    @JsonProperty("tipoProceso")
    public String getTipoProceso() {
        return tipoProceso;
    }

    @JsonProperty("tipoProceso")
    public void setTipoProceso(String tipoProceso) {
        this.tipoProceso = tipoProceso;
    }

    @JsonProperty("totalAPagar")
    public Double getTotalAPagar() {
        return totalAPagar;
    }

    @JsonProperty("totalAPagar")
    public void setTotalAPagar(Double totalAPagar) {
        this.totalAPagar = totalAPagar;
    }

    @JsonProperty("valor")
    public Double getValor() {
        return valor;
    }

    @JsonProperty("valor")
    public void setValor(Double valor) {
        this.valor = valor;
    }

}
