package com.bolivariano.microservice.recatx.service.beans;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import javax.annotation.processing.Generated;
import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "codigo",
        "etiquetaCodigo",
        "tipoIdentificadores"
})
@Generated("jsonschema2pojo")
public class Convenio {

    /**
     * codigo de convenio
     */
    @JsonProperty("codigo")
    @JsonPropertyDescription("codigo de convenio")
    private String codigo;
    /**
     * etiqueta codigo
     */
    @JsonProperty("etiquetaCodigo")
    @JsonPropertyDescription("etiqueta codigo")
    private String etiquetaCodigo;
    /**
     * tipos de idenficadores
     */
    @JsonProperty("tipoIdentificadores")
    @JsonPropertyDescription("tipos de idenficadores")
    private List<TipoIdentificador> tipoIdentificadores = new ArrayList<TipoIdentificador>();

    /**
     * codigo de convenio
     */
    @JsonProperty("codigo")
    public String getCodigo() {
        return codigo;
    }

    /**
     * codigo de convenio
     */
    @JsonProperty("codigo")
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    /**
     * etiqueta codigo
     */
    @JsonProperty("etiquetaCodigo")
    public String getEtiquetaCodigo() {
        return etiquetaCodigo;
    }

    /**
     * etiqueta codigo
     */
    @JsonProperty("etiquetaCodigo")
    public void setEtiquetaCodigo(String etiquetaCodigo) {
        this.etiquetaCodigo = etiquetaCodigo;
    }

    /**
     * tipos de idenficadores
     */
    @JsonProperty("tipoIdentificadores")
    public List<TipoIdentificador> getTipoIdentificadores() {
        return tipoIdentificadores;
    }

    /**
     * tipos de idenficadores
     */
    @JsonProperty("tipoIdentificadores")
    public void setTipoIdentificadores(List<TipoIdentificador> tipoIdentificadores) {
        this.tipoIdentificadores = tipoIdentificadores;
    }

}
