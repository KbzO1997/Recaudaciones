package com.bolivariano.microservice.recatx.service.beans;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import javax.annotation.processing.Generated;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "codigo",
        "etiqueta"
})
@Generated("jsonschema2pojo")
public class ListaSeleccion {
    @JsonProperty("codigo")
    private String codigo;
    @JsonProperty("etiqueta")
    private String etiqueta;

    @JsonProperty("codigo")
    public String getCodigo() {
        return codigo;
    }

    @JsonProperty("codigo")
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    @JsonProperty("etiqueta")
    public String getEtiqueta() {
        return etiqueta;
    }

    @JsonProperty("etiqueta")
    public void setEtiqueta(String etiqueta) {
        this.etiqueta = etiqueta;
    }

}