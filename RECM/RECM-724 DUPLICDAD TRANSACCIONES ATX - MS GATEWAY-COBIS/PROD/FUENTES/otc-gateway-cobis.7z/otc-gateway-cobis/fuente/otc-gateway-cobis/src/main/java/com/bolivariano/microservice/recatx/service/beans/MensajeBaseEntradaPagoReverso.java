package com.bolivariano.microservice.recatx.service.beans;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "canal",
        "cuenta",
        "datosAdicionales",
        "depuracion",
        "esquemaFirma",
        "fechaPago",
        "moneda",
        "nombreCliente",
        "oficina",
        "recibos",
        "secuencial",
        "servicio",
        "tipoCuenta",
        "transaccion",
        "usuario",
        "valorComision",
        "valorPago"
})
public class MensajeBaseEntradaPagoReverso {
	/**
     * identificador canal
     */
    @JsonProperty("canal")
    @JsonPropertyDescription("identificador canal")
    private String canal;
    /**
     * cuenta
     */
    @JsonProperty("cuenta")
    @JsonPropertyDescription("cuenta")
    private String cuenta;
    /**
     * datos adicionales
     */
    @JsonProperty("datosAdicionales")
    @JsonPropertyDescription("datos adicionales")
    private List<DatoAdicional> datosAdicionales = new ArrayList<>();
    /**
     * identificador depuracion
     */
    @JsonProperty("depuracion")
    @JsonPropertyDescription("identificador depuracion")
    private String depuracion;
    /**
     * esquema firma
     */
    @JsonProperty("esquemaFirma")
    @JsonPropertyDescription("esquema firma")
    private String esquemaFirma;
    /**
     * fecha de pago
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "America/Guayaquil")
    @JsonProperty("fechaPago")
    @JsonPropertyDescription("fecha de pago")
    private Date fechaPago;
    /**
     * moneda
     */
    @JsonProperty("moneda")
    @JsonPropertyDescription("moneda")
    private String moneda;
    /**
     * nombre cliente
     */
    @JsonProperty("nombreCliente")
    @JsonPropertyDescription("nombre cliente")
    private String nombreCliente;
    /**
     * oficina
     */
    @JsonProperty("oficina")
    @JsonPropertyDescription("oficina")
    private String oficina;
    /**
     * recibos
     */
    @JsonProperty("recibos")
    @JsonPropertyDescription("recibos")
    private List<Recibo> recibos = new ArrayList<>();
    /**
     * secuencial
     */
    @JsonProperty("secuencial")
    @JsonPropertyDescription("secuencial")
    private String secuencial;
    @JsonProperty("servicio")
    private Servicio servicio;
    /**
     * tipo cuenta
     */
    @JsonProperty("tipoCuenta")
    @JsonPropertyDescription("tipo cuenta")
    private String tipoCuenta;
    @JsonProperty("transaccion")
    private String transaccion;
    @JsonProperty("usuario")
    private String usuario;
    /**
     * valor comision
     */
    @JsonProperty("valorComision")
    @JsonPropertyDescription("valor comision")
    private Double valorComision;
    /**
     * valor pago
     */
    @JsonProperty("valorPago")
    @JsonPropertyDescription("valor pago")
    private Double valorPago;
	public String getCanal() {
		return canal;
	}
	public void setCanal(String canal) {
		this.canal = canal;
	}
	public String getCuenta() {
		return cuenta;
	}
	public void setCuenta(String cuenta) {
		this.cuenta = cuenta;
	}
	public List<DatoAdicional> getDatosAdicionales() {
		return datosAdicionales;
	}
	public void setDatosAdicionales(List<DatoAdicional> datosAdicionales) {
		this.datosAdicionales = datosAdicionales;
	}
	public String getDepuracion() {
		return depuracion;
	}
	public void setDepuracion(String depuracion) {
		this.depuracion = depuracion;
	}
	public String getEsquemaFirma() {
		return esquemaFirma;
	}
	public void setEsquemaFirma(String esquemaFirma) {
		this.esquemaFirma = esquemaFirma;
	}
	public Date getFechaPago() {
		return fechaPago;
	}
	public void setFechaPago(Date fechaPago) {
		this.fechaPago = fechaPago;
	}
	public String getMoneda() {
		return moneda;
	}
	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}
	public String getNombreCliente() {
		return nombreCliente;
	}
	public void setNombreCliente(String nombreCliente) {
		this.nombreCliente = nombreCliente;
	}
	public String getOficina() {
		return oficina;
	}
	public void setOficina(String oficina) {
		this.oficina = oficina;
	}
	public List<Recibo> getRecibos() {
		return recibos;
	}
	public void setRecibos(List<Recibo> recibos) {
		this.recibos = recibos;
	}
	public String getSecuencial() {
		return secuencial;
	}
	public void setSecuencial(String secuencial) {
		this.secuencial = secuencial;
	}
	public Servicio getServicio() {
		return servicio;
	}
	public void setServicio(Servicio servicio) {
		this.servicio = servicio;
	}
	public String getTipoCuenta() {
		return tipoCuenta;
	}
	public void setTipoCuenta(String tipoCuenta) {
		this.tipoCuenta = tipoCuenta;
	}
	public String getTransaccion() {
		return transaccion;
	}
	public void setTransaccion(String transaccion) {
		this.transaccion = transaccion;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public Double getValorComision() {
		return valorComision;
	}
	public void setValorComision(Double valorComision) {
		this.valorComision = valorComision;
	}
	public Double getValorPago() {
		return valorPago;
	}
	public void setValorPago(Double valorPago) {
		this.valorPago = valorPago;
	}
    
}
