package com.bolivariano.microservice.recatx.service.restclient.domain;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
public class ServicioCanal implements Serializable {
    private static final long serialVersionUID = 1L;

    private Long id;

    private Servicio servicio;

    private Canal canal;

}