package com.bolivariano.microservice.recatx.utils;

import com.bolivariano.microservice.recatx.exception.BusinessException;
import com.ibm.mq.*;
import com.ibm.mq.constants.CMQC;

public class MQUtil {

    private String hostname;
    private String channel;
    private int port;
    private String queueManager;
    private String requestQueue;
    private MQQueue outQueue;
    private MQQueueManager qmgr; //Connection to Queue Manager


    /*
     * Constructor
     */
    public MQUtil(String hostname, String channel, int port, String queueManager, String requestQueue) {
        this.hostname = hostname;
        this.channel = channel;
        this.port = port;
        this.queueManager = queueManager;
        this.requestQueue = requestQueue;
    }


    /*
     * Create a new Queue Manager connection if one doesn't exist
     */
    @SuppressWarnings("unchecked")
    private MQQueueManager getQueueManager() throws MQException {
        MQEnvironment.hostname = this.hostname;
        MQEnvironment.port = this.port;
        MQEnvironment.channel = this.channel;
        MQEnvironment.properties.put(CMQC.TRANSPORT_PROPERTY, CMQC.TRANSPORT_MQSERIES);

        if ((qmgr == null) || !qmgr.isConnected()) {
            qmgr = new MQQueueManager(this.queueManager);
        }
        return qmgr;
    }


    /*
     * Send an MQ message
     */
    public void sendMessage(MQMessage sendMsg) throws BusinessException {
        try {

            MQMessage outMsg = sendMsg;
            outMsg.messageType = CMQC.MQMT_DATAGRAM;

            int openOptions = CMQC.MQOO_OUTPUT | CMQC.MQOO_FAIL_IF_QUIESCING;
            outQueue = getQueueManager().accessQueue(this.requestQueue, openOptions);
            MQPutMessageOptions pmo = new MQPutMessageOptions();

            outQueue.put(outMsg, pmo);
            outQueue.close();
            qmgr.disconnect();

        } catch (MQException e) {
            disconnect();
            throw new BusinessException("MQException", e);
        } catch (Exception e) {
            disconnect();
            throw new BusinessException("Exception", e);
        }
    }

    /*
     * Disconnect from the Queue Manager
     */
    private void disconnect() {
        try {
            if (outQueue != null && outQueue.isOpen()) {
                outQueue.close();
            }
            if (qmgr != null) {
                if (qmgr.isConnected())
                    qmgr.close();
                qmgr.disconnect();
            }
        } catch (MQException e) {
            qmgr = null;
        }
    }

}
