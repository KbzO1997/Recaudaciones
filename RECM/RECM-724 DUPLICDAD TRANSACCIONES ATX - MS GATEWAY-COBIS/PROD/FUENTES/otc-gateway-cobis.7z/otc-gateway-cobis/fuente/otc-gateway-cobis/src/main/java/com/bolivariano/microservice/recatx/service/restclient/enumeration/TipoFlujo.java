package com.bolivariano.microservice.recatx.service.restclient.enumeration;

public enum TipoFlujo {

    PAGO,
    CONSULTA,
    REVERSO,
    VALIDA;

}
