package com.bolivariano.microservice.recatx.service.restclient;

import com.bolivariano.microservice.recatx.service.restclient.message.MensajeEntradaConsultarGrupoServicio;
import com.bolivariano.microservice.recatx.service.restclient.message.MensajeEntradaConsultarGrupoServicioOBS;
import com.bolivariano.microservice.recatx.service.restclient.message.MensajeSalidaConsultarGrupoServicio;
import org.eclipse.microprofile.rest.client.annotation.RegisterClientHeaders;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import javax.ws.rs.POST;
import javax.ws.rs.Path;

@Path("/gruposervicio")
@RegisterRestClient
@RegisterClientHeaders(RequestUUIDHeaderFactory.class)
public interface GrupoServicioProxy {

    @POST
    MensajeSalidaConsultarGrupoServicio obtenerGrupoServicio(MensajeEntradaConsultarGrupoServicio peticionObj);

    @POST
    @Path("/obtenerGrupoServicioOBS")
    MensajeSalidaConsultarGrupoServicio obtenerGrupoServicioOBS(MensajeEntradaConsultarGrupoServicioOBS peticionObj);

}
